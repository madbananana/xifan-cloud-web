#!/bin/bash

#开始部署---
echo "开始部署\n"

basepath=$(cd `dirname $0`; pwd)
source ${basepath}/vars-uat.sh

#
#拷贝程序其他服务器
for host in ${hosts[@]}
do
    if [ ${host} = ${SELF_HOST} ];then
#          ssh root@${host} "sh ${packagePath}/run.sh newtv-nft-cms restart"
    PID=$(ps -ef | grep nft_wallet_service_linux | grep -v grep | awk '{ print $2 }')
    if [ -z "$PID" ]
    then
        echo nft_wallet_service_linux $PID is already stopped
    else
        echo kill $PID
        kill -9  $PID
    fi
    nohup /home/tianmai/newtv-nft/doc/nft_wallet_service_linux >>/data0/logs/nft_go_serivce.log 2>&1 &
    sh ${packagePath}/run-uat.sh newtv-nft-cms restart
#    else
#          sh ${packagePath}/run.sh newtv-nft-cms restart
    fi
done
