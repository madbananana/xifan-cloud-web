package com.foundao.nft.test;

import cn.hutool.core.lang.Dict;
import cn.hutool.http.HttpUtil;
import cn.hutool.json.JSONUtil;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;

public class ZxDindAddressServiceImplTest {

    @Test
    public void testUploadSecret(){
        //        平台注册
        ZxDindAddressServiceImpl service = new ZxDindAddressServiceImpl();
        //获取用户手机验证码 - 用户信息查询
//        System.out.println(service.getQueryUserVerifyCode(1,1));
        //根据验证码获取用户唯一标识
//        System.out.println(service.getQueryUser(1,"269998"));

        // 获取用户信息验证码 - nft 绑定

//        System.out.println(service.getQueryUserVerifyCode(1,2));
//        签名
        System.out.println(service.getSignByPriKey(service.platformMnemonic, service.platformUserIdentification));
//        System.out.println(service.getplatformSelf(service.platformSignData,service.platformPubKey,service.platformUserIdentification,"030241"));

        String apiData = HttpUtil.createPost("http://127.0.0.1:30505/PubKey2Address").body(JSONUtil.toJsonStr(new Dict().set("pubKey",service.platformPubKey))).execute().body();
        System.out.println(service.getIdentityQueryUrl(Arrays.asList("ZX8c278b8cbacbd76849954829313d6f66c0c2f4c4")));
        //自然人注册
        //Dict pldict = service.getSignByPriKey(service.platformMnemonic, service.platformUserIdentification);
        //service.platformPriKey = pldict.getStr("priKey");
        //service.platformPubKey = pldict.getStr("pubKey");
        //service.platformSignData = pldict.getStr("signData");
        //service.platformAddress = "ZX8c278b8cbacbd76849954829313d6f66c0c2f4c4";
        //
        //String userMnemonic = "bachelor believe space bridge vapor buyer filter occur trouble fetch lounge still";
        //String userIdentification = "ae93f257efa91f4ea485934c30b537e94c9a20b887c516d058835368b2008b86";
        //Dict userdict = service.getSignByPriKey(userMnemonic, userIdentification);
        //
        //String userPriKey = userdict.getStr("priKey");
        //String userPubKey = userdict.getStr("pubKey");
        //String userSignData = pldict.getStr("signData");
        //String userAddress = "ZX69cf12b880bb87512185c1acda6a330163f5275b";
        //
        ////素材上传操作 平台发行
        //String seriesName = "未来头像";
        //String timestamp = Long.toString(System.currentTimeMillis() / 1000);
        //
        //String pubSignedData = service.getSignedData(service.platformPriKey, timestamp + "_" + seriesName + "_" + service.platformPubKey);
        //String userSignedData = service.getSignedData(service.platformPriKey, timestamp + "_" + seriesName);
        //
        //Dict dict = service.uploadSecret(seriesName, timestamp, service.platformPubKey, pubSignedData, service.platformPubKey, userSignedData);
        //System.out.println(JSONUtil.toJsonStr(dict));


    }
}
