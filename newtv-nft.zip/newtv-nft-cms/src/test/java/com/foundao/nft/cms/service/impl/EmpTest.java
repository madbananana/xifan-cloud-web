package com.foundao.nft.cms.service.impl;

import cn.hutool.core.io.FileUtil;
import cn.hutool.core.util.RandomUtil;
import cn.hutool.poi.excel.ExcelReader;
import cn.hutool.poi.excel.ExcelUtil;
import com.foundao.nft.BaseApplicationTest;
import com.foundao.nft.common.model.NewtvEmp;
import com.foundao.nft.common.model.NftUser;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @ClassName EmpTest
 * @Description TODO
 * @Author xifan
 * @Date 2022/1/23 11:39
 * @Version 1.0
 */
@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("uat")
public class EmpTest extends BaseApplicationTest {

    @Autowired
    private NewtvEmpService empService;

    @Autowired
    private NftUserService userService;

    @Test
    public void testEmpInsert(){
        Set<NewtvEmp> emps =new HashSet<>();
        Set<NewtvEmp> oldEmps = new HashSet<>();
        ExcelReader reader = ExcelUtil.getReader(FileUtil.file("emp.xlsx"));
        List<List<Object>> readAll = reader.read(1);
        readAll.forEach(
                list -> {
                    for (int i=0;i<list.size();i++) {
                        if (i==1) {
                            NewtvEmp newtvEmp = NewtvEmp.builder().mobile(list.get(i) + "").name(list.get(i) + "").specialType(1).build();
                            oldEmps.add(newtvEmp);
                        } else if (i==0){
                            emps.add(NewtvEmp.builder().mobile(list.get(i)+"").name(list.get(i)+"").build());
                        }
                    }
                }
        );
        oldEmps.forEach(emp->{
            emps.removeIf(empp -> empp.getMobile().equals(emp.getMobile()));
        });
        empService.saveBatch(emps);
        empService.saveBatch(oldEmps);

    }

    public static void main(String[] args) {

        for (int j = 0; j < 200; j++) {
            int i = RandomUtil.randomInt(5);
                System.out.println(i +":" +j);
        }
    }

    @Test
    public void queryEmp(){
        Set<String> emps =new HashSet<>();
        ExcelReader reader = ExcelUtil.getReader(FileUtil.file("emp.xlsx"));
        List<List<Object>> readAll = reader.read(1);
        readAll.forEach(
                list -> {
                    for (int i=0;i<list.size();i++) {
                        if (i==1) {
                        } else if (i==0){
                            emps.add(list.get(i)+"");
                        }
                    }
                }
        );
        List<NewtvEmp> list = empService.list();
        list.forEach(emp -> {
            if (!emps.contains(emp.getMobile())) {
                System.out.println(emp.getMobile());
            }
        });
        System.out.println(111);
    }


    @Test
    public void test(){
        log.info("手机号从 {} 变更为 {} ，结果{}","17323048583","17323048584",true?"成功":"失败");
        NftUser userByMobileNoLock = userService.findUserByMobileNoLock("17323048584");
        System.out.println(userByMobileNoLock);
    }
}
