package com.foundao.nft.test;

import cn.hutool.core.net.NetUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.tx.core.util.RunShellUtil;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.util.LinkedHashSet;

/**
 * @Package: com.foundao.nft.test
 * @ClassName: NftTest
 * @Author: chenli
 * @CreateTime: 2021/12/14 5:30 下午
 * @Description:
 */
@Slf4j
public class NftTest {
    public static void main(String[] args) {
        LinkedHashSet<String> strings = NetUtil.localIpv4s();
        if (strings.contains("192.168.21.168")) {
            System.out.println("包含");
        }
        String url = "http://127.0.0.1:30505/generateApiSign";
        RestTemplate restTemplate = new RestTemplate();
        // 配置参数
        MultiValueMap<String, Object> param = new LinkedMultiValueMap<>(5);

        param.add("appKey", "63a43c8f29b047039cdec6f335716533");
        param.add("appId", "211130000100001");
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        HttpEntity<?> requestEntity = new HttpEntity<>(param,headers);
        ResponseEntity<String> responseEntity = restTemplate.postForEntity(url,requestEntity,String.class);
        String respBody = responseEntity.getBody();

        System.out.println(111);

        String platformPriKey="-----BEGIN protected KEY-----\n" +
                "        MIGTAgEAMBMGByqGSM49AgEGCCqBHM9VAYItBHkwdwIBAQQg4WvQHn89B0grKWNA\n" +
                "                yPPeZS8fkBcdqrCEzEztOT7wHxKgCgYIKoEcz1UBgi2hRANCAASWFE3zshNTYvEw\n" +
                "        AepjvLpBzalCgHa2cb4aVVjPP3ijiJsD8KK2RGrpL28rwfq3Z3gwxdLEul0p3wPX\n" +
                "                yhFBRPBT\n" +
                "        -----END protected KEY-----";
        String platformPubKey="-----BEGIN PUBLIC KEY-----\n" +
                "        MFkwEwYHKoZIzj0CAQYIKoEcz1UBgi0DQgAElhRN87ITU2LxMAHqY7y6Qc2pQoB2\n" +
                "        tnG+GlVYzz94o4ibA/CitkRq6S9vK8H6t2d4MMXSxLpdKd8D18oRQUTwUw==\n" +
                "                -----END PUBLIC KEY-----";
        System.out.println(platformPriKey);
        System.out.println(platformPubKey);
    }





    @Test
    public void testRestTemplate(){
//        NftMetaDataPartAttr attr = new NftMetaDataPartAttr();
//        attr.setIsUnique(0);
//        attr.setRatio(16.6);
//        attr.setIsSpecialType(0);
//        attr.setPartName("连衣帽");
//        attr.setPartType(6);
//        System.out.println(JSON.toJSONString(attr));

        String str= " {\"partAttr\":[\n" +
                "{\"isSpecialType\":0,\"isUnique\":0,\"partName\":\"衣服-001\",\"partType\":6,\"ratio\":16.6},\n" +
                "{\"isSpecialType\":0,\"isUnique\":0,\"partName\":\"背景-001\",\"partType\":1,\"ratio\":16.6},\n" +
                "{\"isSpecialType\":0,\"isUnique\":0,\"partName\":\"道具-001\",\"partType\":2,\"ratio\":16.6},\n" +
                "{\"isSpecialType\":0,\"isUnique\":0,\"partName\":\"耳机-001\",\"partType\":3,\"ratio\":16.6},\n" +
                "{\"isSpecialType\":0,\"isUnique\":0,\"partName\":\"头饰-001\",\"partType\":4,\"ratio\":16.6},\n" +
                "{\"isSpecialType\":0,\"isUnique\":0,\"partName\":\"眼镜-001\",\"partType\":5,\"ratio\":16.6}\n" +
                "]}\n";

        JSONObject jsonObject = JSON.parseObject(str);
        System.out.println(JSON.toJSONString(jsonObject));
    }




}
