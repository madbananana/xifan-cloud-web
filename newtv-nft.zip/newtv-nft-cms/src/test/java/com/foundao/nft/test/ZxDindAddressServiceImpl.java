package com.foundao.nft.test;


import cn.hutool.core.lang.Dict;
import cn.hutool.http.HttpUtil;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.alibaba.fastjson.JSON;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.LayeredConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContexts;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpRequestRetryHandler;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.util.EntityUtils;
import org.junit.platform.commons.util.StringUtils;
import org.springframework.stereotype.Service;

import javax.net.ssl.SSLContext;
import java.net.URLEncoder;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.apache.http.Consts.UTF_8;

/**
 * @author zhangshaobo
 * @Title: BlockChainService
 * @ProjectName blockchain
 * @Description: TODO
 * @date 2021/11/11 3:01 下午
 */

@Service
public class ZxDindAddressServiceImpl {

    protected String generateApiSignUrl = "http://127.0.0.1:30505/generateApiSign";
    protected String queryUserVerifyCodeUrl = "https://nfa.zxinchain.com/api/v1/nft/user/query/verify_code";
    protected String nftInfoUrl = "https://nfa.zxinchain.com/api/v1/nft/info";
    protected String seriesClaimUrl = "https://nfa.zxinchain.com/api/v1/nft/series/claim";
    protected String nftPublishUrl = "https://nfa.zxinchain.com/api/v1/nft/publish";
    protected String nftpublishResultUrl = "https://nfa.zxinchain.com/api/v1/nft/publish/result";
    protected String queryUserUrl = "https://nfa.zxinchain.com/api/v1/nft/user/query";
    protected String faceAddressUrl = "https://nfa.zxinchain.com/api/v1/nft/face/url_by_address";
    protected String faceUrl = "https://nfa.zxinchain.com/api/v1/nft/face/url";
    protected String uploadSecretUrl = "https://nfa.zxinchain.com/api/v1/nft/upload/secret";
    protected String registerpersonplatformUrl = "https://nfa.zxinchain.com/api/v1/nft/register/person_platform";
    protected String imageModerationUrl = "https://nfa.zxinchain.com/api/v1/nft/query/image/moderation";
    protected String signByPriKeyUrl = "http://127.0.0.1:30505/SignByPriKey";
    protected String createMnemonicUrl = "http://127.0.0.1:30505/createMnemonic";
    protected String deriveKeyPairUrl = "http://127.0.0.1:30505/DeriveKeyPair";
    protected String platformSelfUrl = "https://nfa.zxinchain.com/api/v1/nft/identity/bind/platform_self";
    protected String submitByTrustedPlatformUrl = "https://nfa.zxinchain.com/api/v1/nft/identity/bind/submit_by_trusted_platform";
    protected String identityQueryUrl = "https://nfa.zxinchain.com/api/v1/nft/identity/bind/query";
    protected String pointApplyUrl = "https://nfa.zxinchain.com/api/v1/nft/point/apply";
    protected String pointApplyResultUrl = "https://nfa.zxinchain.com/api/v1/nft/point/apply/result";
    protected String pointQueryUrl = "https://nfa.zxinchain.com/api/v1/nft/point/query";
    protected String nftBuyUrl = "https://nfa.zxinchain.com/api/v1/nft/buy";
    protected String nftBuyResultUrl = "https://nfa.zxinchain.com/api/v1/nft/buy/result";
    protected String transferUrl = "https://nfa.zxinchain.com/api/v1/nft/transfer";
    protected String transferResultUrl = "https://nfa.zxinchain.com/api/v1/nft/transfer/result";
    protected String addressListUrl = "https://nfa.zxinchain.com/api/v1/nft/address/list";

    protected String appId = "220122003000001";
    protected String cardNo = "120103198809183517";
    protected String platformUserIdentification = "655eb55a67f49c02a8a8dc4d35eb295134c6b0aab41a31053362d61d4b127804";
    protected String platformMnemonic = "myself remind miss inherit echo nation vicious lunch stock alert math meat";
    protected String platformPriKey = "";
    protected String platformPubKey = "";
    protected String platformSignData = "";
    protected String platformAddress = "";


    public String getQueryUserVerifyCode(Integer type, Integer scene) {
        //获取签名数据
        Dict generateApiSign = getGenerateApiSign();
        String Signature = generateApiSign.getStr("Signature");
        String SignatureTime = generateApiSign.getStr("SignatureTime");
        String Nonce = generateApiSign.getStr("Nonce");

        Dict dict = Dict.create().set("type", type).set("cardNo", cardNo).set("scene", scene);

        String apiData = HttpUtil.createPost(queryUserVerifyCodeUrl).
                header("Content-Type", "application/json").
                header("Signature", Signature).
                header("Signature-Time", SignatureTime).
                header("Nonce", Nonce)
                .body(JSONUtil.toJsonStr(dict))
                .execute().body();
        return "获取验证码成功";
    }

    public String getQueryUser(Integer type, String verifyCode) {
        //获取签名数据
        Dict generateApiSign = getGenerateApiSign();
        String Signature = generateApiSign.getStr("Signature");
        String SignatureTime = generateApiSign.getStr("SignatureTime");
        String Nonce = generateApiSign.getStr("Nonce");

        Dict dict = Dict.create().set("type", type).set("cardNo", cardNo).set("verifyCode", verifyCode);
        //Joiner.on("&").withKeyValueSeparator("=").join(Dict.create().set("type",1).set("cardNo",2).set("verifyCode",1))
        String apiData = HttpUtil.createGet(queryUserUrl).form(dict).
                header("Content-Type", "application/json").
                header("Signature", Signature).
                header("Signature-Time", SignatureTime).
                header("Nonce", Nonce)
                .execute().body();

        return JSONUtil.toBean((JSONObject) JSONUtil.toBean(apiData, Dict.class).get("data"), Dict.class).getStr("userIdentification");
    }

    public Dict getSignByPriKey(String mnemonic, String userIdentification) {
        //获取助记词
        if (StringUtils.isBlank(mnemonic)) {
            mnemonic = (String) JSONUtil.toBean(HttpUtil.createPost(createMnemonicUrl).execute().body(), Map.class).get("mnemonic");
        }
        //获取公私钥
        Dict deriveKeyPair = JSONUtil.toBean(HttpUtil.createPost(deriveKeyPairUrl).body(JSONUtil.toJsonStr(new Dict().set("mnemonic", mnemonic).set("index", 66))).execute().body(), Dict.class);
        String priKey = deriveKeyPair.getStr("priKey");
        String pubKey = deriveKeyPair.getStr("pubKey");
        Dict dict = JSONUtil.toBean(HttpUtil.createPost(signByPriKeyUrl).body(JSONUtil.toJsonStr(new Dict().set("priKey", priKey).set("data", userIdentification))).execute().body(), Dict.class);
        String signData = dict.getStr("signedData");
        Dict dict1 = new Dict().set("mnemonic", mnemonic).set("userIdentification", userIdentification).set("priKey", priKey).set("pubKey", pubKey).set("signData", signData);
        platformPubKey = pubKey;
        platformPriKey = priKey;
        platformSignData = signData;
        return dict1;
    }

    public String getplatformSelf(String signedData, String pubKey, String userIdentification, String verifyCode) {
        Dict generateApiSign = getGenerateApiSign1();
        String Signature = generateApiSign.getStr("Signature");
        String SignatureTime = generateApiSign.getStr("SignatureTime");
        String Nonce = generateApiSign.getStr("Nonce");
        String d = JSONUtil.toJsonStr(new Dict().set("pubKey", pubKey).set("signData", signedData).set("userIdentification", userIdentification).set("verifyCode", verifyCode));
        Dict dict = JSONUtil.toBean(HttpUtil.createPost(platformSelfUrl).
                header("Content-Type", "application/json").
                header("Signature", Signature).
                header("Signature-Time", SignatureTime).
                header("Nonce", Nonce).
                header("App-Id", appId).body(d).execute().body(), Dict.class);

        return dict.getStr("data");
    }

    public Dict getIdentityQueryUrl(List<String> addressList) {

        //获取签名数据
        Dict generateApiSign = getGenerateApiSign();
        String Signature = generateApiSign.getStr("Signature");
        String SignatureTime = generateApiSign.getStr("SignatureTime");
        String Nonce = generateApiSign.getStr("Nonce");

        Dict dict = Dict.create().set("addressList", addressList);
        //Joiner.on("&").withKeyValueSeparator("=").join(Dict.create().set("type",1).set("cardNo",2).set("verifyCode",1))
        Dict apiData = JSONUtil.toBean(HttpUtil.createGet(identityQueryUrl).form(dict).
                header("Content-Type", "application/json").
                header("Signature", Signature).
                header("Signature-Time", SignatureTime).
                header("Nonce", Nonce)
                .execute().body(), Dict.class);

        return apiData;
    }

    public String registerPresonPlatform(String personName, String email, String mobile, String idCard, Integer cardType) {
        //获取签名数据
        Dict generateApiSign = getGenerateApiSign1();
        String Signature = generateApiSign.getStr("Signature");
        String SignatureTime = generateApiSign.getStr("SignatureTime");
        String Nonce = generateApiSign.getStr("Nonce");

        Dict dict = Dict.create().set("personName", personName).set("mobile", mobile).set("idCard", idCard).set("cardType", cardType).set("platformPubKey", platformPubKey).set("platformSignData", platformSignData);
//        HttpUtil.createGet(registerpersonplatformUrl).get
        String apiData = HttpUtil.createPost(registerpersonplatformUrl).
                header("Content-Type", "application/json").
                header("Signature", Signature).
                header("Signature-Time", SignatureTime).
                header("Nonce", Nonce).
                header("App-Id", appId)
                .body(JSONUtil.toJsonStr(dict))
                .execute().body();

        return JSONUtil.toBean((JSONObject) JSONUtil.toBean(apiData, Dict.class).get("data"), Dict.class).getStr("userIdentification");
    }

    public Dict submitByTrustedPlatform(String userSignData, String userPubKey, String platformPubKey, String platformSignData, String userIdentification) {
        //获取签名数据
        Dict generateApiSign = getGenerateApiSign1();
        String Signature = generateApiSign.getStr("Signature");
        String SignatureTime = generateApiSign.getStr("SignatureTime");
        String Nonce = generateApiSign.getStr("Nonce");

        Dict dict = Dict.create().set("userSignData", userSignData).set("userPubKey", userPubKey).set("platformPubKey", platformPubKey).set("platformSignData", platformSignData).set("userIdentification", userIdentification);
//        HttpUtil.createGet(registerpersonplatformUrl).get
        String apiData = HttpUtil.createPost(submitByTrustedPlatformUrl).
                header("Content-Type", "application/json").
                header("Signature", Signature).
                header("Signature-Time", SignatureTime).
                header("Nonce", Nonce).
                header("App-Id", appId)
                .body(JSONUtil.toJsonStr(dict))
                .execute().body();

        return JSONUtil.toBean(apiData, Dict.class);
    }

    public Dict imageModeration(String imageUrl, int interval, int maxFrames) {
        //获取签名数据
        Dict generateApiSign = getGenerateApiSign1();
        String Signature = generateApiSign.getStr("Signature");
        String SignatureTime = generateApiSign.getStr("SignatureTime");
        String Nonce = generateApiSign.getStr("Nonce");

        Dict dict = Dict.create().set("imageUrl", imageUrl).set("interval", interval).set("maxFrames", maxFrames);
        String apiData = HttpUtil.createPost(imageModerationUrl).
                header("Content-Type", "application/json").
                header("Signature", Signature).
                header("Signature-Time", SignatureTime).
                header("Nonce", Nonce).
                header("App-Id", appId)
                .body(JSONUtil.toJsonStr(dict))
                .execute().body();

        return JSONUtil.toBean(apiData, Dict.class);
    }

    public Dict uploadSecret(String seriesName, String timestamp, String plpubkey, String pubSignedData, String userPubKey, String userSignedData) {
        //获取签名数据
        Dict generateApiSign = getGenerateApiSign1();
        String Signature = generateApiSign.getStr("Signature");
        String SignatureTime = generateApiSign.getStr("SignatureTime");
        String Nonce = generateApiSign.getStr("Nonce");

        Dict dict = Dict.create().set("seriesName", seriesName).set("timestamp", timestamp).set("pubkey", plpubkey).set("pubSignedData", pubSignedData).set("userPubKey", userPubKey).set("userSignedData", userSignedData);
        String apiData = HttpUtil.createPost(uploadSecretUrl).
                header("Content-Type", "application/json").
                header("Signature", Signature).
                header("Signature-Time", SignatureTime).
                header("Nonce", Nonce).
                header("App-Id", appId)
                .body(JSONUtil.toJsonStr(dict))
                .execute().body();
        return JSONUtil.toBean((JSONObject) JSONUtil.toBean(apiData, Dict.class).get("data"), Dict.class);
    }

    public Dict faceurlUrl(String userIdentification, String from) {
        //获取签名数据
        Dict generateApiSign = getGenerateApiSign();
        String Signature = generateApiSign.getStr("Signature");
        String SignatureTime = generateApiSign.getStr("SignatureTime");
        String Nonce = generateApiSign.getStr("Nonce");

        Dict dict = Dict.create().set("userIdentification", userIdentification).set("from", from);
        String apiData = HttpUtil.createPost(faceUrl).
                header("Content-Type", "application/json").
                header("Signature", Signature).
                header("Signature-Time", SignatureTime).
                header("Nonce", Nonce)
//                .header("App-Id", appId)
                .body(JSONUtil.toJsonStr(dict))
                .execute().body();
        return JSONUtil.toBean((JSONObject) JSONUtil.toBean(apiData, Dict.class).get("data"), Dict.class);
    }

    public Dict nftPublish(String pubkey, String platformPubKey, String author, String name, String url, String displayUrl, String hash, String desc, String flag, int publishCount, String seriesId, int seriesBeginIndex, int sellStatus, int sellCount, String operateId, String metaData, String signature, String platformSignature) {
        //获取签名数据
        Dict generateApiSign = getGenerateApiSign1();
        String Signature = generateApiSign.getStr("Signature");
        String SignatureTime = generateApiSign.getStr("SignatureTime");
        String Nonce = generateApiSign.getStr("Nonce");

        Dict dict = Dict.create().set("pubkey", pubkey).set("platformPubKey", platformPubKey).set("author", author).set("name", name).set("url", url).set("displayUrl", displayUrl).set("hash", hash).set("desc", desc).set("flag", flag).set("publishCount", publishCount).set("seriesId", seriesId).set("seriesBeginIndex", seriesBeginIndex).set("sellStatus", sellStatus).set("sellCount", sellCount).set("operateId", operateId).set("metaData", metaData).set("signature", signature).set("platformSignature", platformSignature);
        String apiData = HttpUtil.createPost(nftPublishUrl).
                header("Content-Type", "application/json").
                header("Signature", Signature).
                header("Signature-Time", SignatureTime).
                header("Nonce", Nonce)
                .header("App-Id", appId)
                .body(JSONUtil.toJsonStr(dict))
                .execute().body();
        return JSONUtil.toBean((JSONObject) JSONUtil.toBean(apiData, Dict.class).get("data"), Dict.class);
    }

    public Dict getTransferResult(String url, String operatorPubkey, String taskId) throws Exception {

        StringBuffer sb = new StringBuffer(url);
        sb.append("?operatorPubkey=" + URLEncoder.encode(operatorPubkey, "utf-8")).append("&taskId=" + URLEncoder.encode(taskId, "utf-8"));
        url = sb.toString();
//        //获取签名数据
        Dict generateApiSign = getGenerateApiSign();
        String Signature = generateApiSign.getStr("Signature");
        String SignatureTime = generateApiSign.getStr("SignatureTime");
        String Nonce = generateApiSign.getStr("Nonce");

        CloseableHttpClient httpClient = HttpClientBuilder.create().build();
        if (url.contains("https")) {
            httpClient = getHttpClient();
        }
        HttpGet httpGet = new HttpGet(url);
        httpGet.setHeader("Content-Type", "application/json;charset=utf-8");
        httpGet.setHeader("Signature", Signature);
        httpGet.setHeader("Signature-Time", SignatureTime);
        httpGet.setHeader("Nonce", Nonce);
        HttpResponse httpResponse = httpClient.execute(httpGet);
        HttpEntity httpEntity = httpResponse.getEntity();
        String result = EntityUtils.toString(httpEntity, UTF_8);
        return JSONUtil.toBean((JSONObject) JSONUtil.toBean(result, Dict.class).get("data"), Dict.class);
    }

    public Dict taskQueryResult(String url, String platformPubKey, String taskId) throws Exception {
        StringBuffer sb = new StringBuffer(url);
        sb.append("?platformPubKey=" + URLEncoder.encode(platformPubKey, "UTF-8")).append("&taskId=" + URLEncoder.encode(taskId, "UTF-8"));
        url = sb.toString();
        //获取签名数据
        Dict generateApiSign = getGenerateApiSign1();
        String Signature = generateApiSign.getStr("Signature");
        String SignatureTime = generateApiSign.getStr("SignatureTime");
        String Nonce = generateApiSign.getStr("Nonce");
        CloseableHttpClient httpClient = HttpClientBuilder.create().build();
        if (url.contains("https")) {
            httpClient = getHttpClient();
        }
        HttpGet httpGet = new HttpGet(url);
        httpGet.setHeader("Content-Type", "application/x-www-form-urlencoded");
        httpGet.setHeader("Signature", Signature);
        httpGet.setHeader("Signature-Time", SignatureTime);
        httpGet.setHeader("Nonce", Nonce);
        httpGet.setHeader("App-Id", appId);
        HttpResponse httpResponse = httpClient.execute(httpGet);
        HttpEntity httpEntity = httpResponse.getEntity();
        String result = EntityUtils.toString(httpEntity, UTF_8);
        return JSONUtil.toBean((JSONObject) JSONUtil.toBean(result, Dict.class).get("data"), Dict.class);
    }
    public static CloseableHttpClient getHttpClient()
            throws KeyStoreException, NoSuchAlgorithmException, KeyManagementException {
        RegistryBuilder<ConnectionSocketFactory> registryBuilder = RegistryBuilder.<ConnectionSocketFactory>create();
        ConnectionSocketFactory plainSF = new PlainConnectionSocketFactory();
        registryBuilder.register("http", plainSF);
        //指定信任密钥存储对象和连接套接字工厂
        KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
        //信任任何链接
        TrustStrategy anyTrustStrategy = new TrustStrategy() {
            @Override
            public boolean isTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
                return true;
            }
        };
        SSLContext sslContext = SSLContexts.custom().useTLS().loadTrustMaterial(trustStore, anyTrustStrategy).build();
        LayeredConnectionSocketFactory sslSF =
                new SSLConnectionSocketFactory(sslContext, SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
        registryBuilder.register("https", sslSF);
        Registry<ConnectionSocketFactory> registry = registryBuilder.build();
        //设置连接管理器
        PoolingHttpClientConnectionManager connManager = new PoolingHttpClientConnectionManager(registry);
        //构建客户端
        return HttpClientBuilder.create().setConnectionManager(connManager).setRetryHandler(new DefaultHttpRequestRetryHandler()).build();
    }

    public Dict pointApply(String applyerAddr, String platformPubKey, int count, String operateId, String platformSignature) {
        //获取签名数据
        Dict generateApiSign = getGenerateApiSign1();
        String Signature = generateApiSign.getStr("Signature");
        String SignatureTime = generateApiSign.getStr("SignatureTime");
        String Nonce = generateApiSign.getStr("Nonce");

        Dict dict = Dict.create().set("applyerAddr", applyerAddr).set("platformPubKey", platformPubKey).set("count", count).set("operateId", operateId).set("platformSignature", platformSignature);
        String apiData = HttpUtil.createPost(pointApplyUrl).
                header("Content-Type", "application/json").
                header("Signature", Signature).
                header("Signature-Time", SignatureTime).
                header("Nonce", Nonce)
                .header("App-Id", appId)
                .body(JSONUtil.toJsonStr(dict))
                .execute().body();
        return JSONUtil.toBean((JSONObject) JSONUtil.toBean(apiData, Dict.class).get("data"), Dict.class);

    }


    public Dict getNftBuy(String nftId, int applyScore, String receiverPubKey, String pointReceiverAddr, String platformPubKey, int offerCount, String operateId, String signature, String platformSignature) {
        //获取签名数据
        Dict generateApiSign = getGenerateApiSign1();
        String Signature = generateApiSign.getStr("Signature");
        String SignatureTime = generateApiSign.getStr("SignatureTime");
        String Nonce = generateApiSign.getStr("Nonce");

        Dict dict = Dict.create().set("nftId", nftId).set("applyScore", applyScore).set("receiverPubKey", receiverPubKey).set("pointReceiverAddr", pointReceiverAddr).set("platformPubKey", platformPubKey).set("offerCount", offerCount).set("operateId", operateId).set("signature", signature).set("platformSignature", platformSignature);
        String apiData = HttpUtil.createPost(nftBuyUrl).
                header("Content-Type", "application/json").
                header("Signature", Signature).
                header("Signature-Time", SignatureTime).
                header("Nonce", Nonce)
                .header("App-Id", appId)
                .body(JSONUtil.toJsonStr(dict))
                .execute().body();
        return JSONUtil.toBean((JSONObject) JSONUtil.toBean(apiData, Dict.class).get("data"), Dict.class);
    }

    public Dict transfer(String pubkey, String receiverAddr, String nftId, String operateId, String signature) {
        //获取签名数据
        Dict generateApiSign = getGenerateApiSign();
        String Signature = generateApiSign.getStr("Signature");
        String SignatureTime = generateApiSign.getStr("SignatureTime");
        String Nonce = generateApiSign.getStr("Nonce");

        Dict dict = Dict.create().set("nftId", nftId).set("pubkey", pubkey).set("receiverAddr", receiverAddr).set("operateId", operateId).set("signature", signature);
        String apiData = HttpUtil.createPost(transferUrl).
                header("Content-Type", "application/json").
                header("Signature", Signature).
                header("Signature-Time", SignatureTime).
                header("Nonce", Nonce)
                .body(JSONUtil.toJsonStr(dict))
                .execute().body();
        return JSONUtil.toBean((JSONObject) JSONUtil.toBean(apiData, Dict.class).get("data"), Dict.class);
    }


    public Dict getPointQuery(String platformAddr, String addr) throws Exception {
        StringBuffer sb = new StringBuffer(pointQueryUrl);
        sb.append("?platformAddr=" + URLEncoder.encode(platformAddr, "UTF-8")).append("&addr=" + URLEncoder.encode(addr, "UTF-8"));
        String url = sb.toString();
        //获取签名数据
        Dict generateApiSign = getGenerateApiSign1();
        String Signature = generateApiSign.getStr("Signature");
        String SignatureTime = generateApiSign.getStr("SignatureTime");
        String Nonce = generateApiSign.getStr("Nonce");
        CloseableHttpClient httpClient = HttpClientBuilder.create().build();
        if (url.contains("https")) {
            httpClient = getHttpClient();
        }
        HttpGet httpGet = new HttpGet(url);
        httpGet.setHeader("Content-Type", "application/json;charset=utf-8");
        httpGet.setHeader("Signature", Signature);
        httpGet.setHeader("Signature-Time", SignatureTime);
        httpGet.setHeader("Nonce", Nonce);
        httpGet.setHeader("App-Id", appId);
        HttpResponse httpResponse = httpClient.execute(httpGet);
        HttpEntity httpEntity = httpResponse.getEntity();
        String result = EntityUtils.toString(httpEntity, UTF_8);
        return JSONUtil.toBean((JSONObject) JSONUtil.toBean(result, Dict.class).get("data"), Dict.class);
    }

    public Dict getAddressList(String addr, String seriesId,int offset,int limit) {
        //获取签名数据
        Dict generateApiSign = getGenerateApiSign();
        String Signature = generateApiSign.getStr("Signature");
        String SignatureTime = generateApiSign.getStr("SignatureTime");
        String Nonce = generateApiSign.getStr("Nonce");

        Dict dict = Dict.create().set("addr", addr).set("offset", offset).set("limit", limit);
        //Joiner.on("&").withKeyValueSeparator("=").join(Dict.create().set("type",1).set("cardNo",2).set("verifyCode",1))
        String apiData = HttpUtil.createGet(addressListUrl).form(dict).
                header("Content-Type", "application/json").
                header("Signature", Signature).
                header("Signature-Time", SignatureTime).
                header("Nonce", Nonce)
                .execute().body();

//        return JSONUtil.toBean((JSONObject) JSONUtil.toBean(apiData, Dict.class).get("data"), Dict.class).getStr("userIdentification");
        return JSONUtil.toBean((JSONObject) JSONUtil.toBean(apiData, Dict.class).get("data"), Dict.class);
    }

    protected Dict getGenerateApiSign() {
        Dict dict = Dict.create().set("appId", "").set("appKey", "");
        String apiData = HttpUtil.createPost(generateApiSignUrl)
                .body(JSONUtil.toJsonStr(dict))
                .execute().body();
        return JSONUtil.toBean((JSONObject) JSONUtil.toBean(apiData, Dict.class).get("signData"), Dict.class);
    }


    protected Dict getGenerateApiSign1() {
        Dict dict = Dict.create().set("appId", "220122003000001").set("appKey", "594ac087bd884cd8b6eeabacc6fd46e5");
        String apiData = HttpUtil.createPost(generateApiSignUrl)
                .body(JSONUtil.toJsonStr(dict))
                .execute().body();
        return JSONUtil.toBean((JSONObject) JSONUtil.toBean(apiData, Dict.class).get("signData"), Dict.class);
    }

    protected String getSignedData(String priKey, String data) {
        Dict dict = JSONUtil.toBean(HttpUtil.createPost(signByPriKeyUrl).body(JSONUtil.toJsonStr(new Dict().set("priKey", priKey).set("data", data))).execute().body(), Dict.class);
        String signData = dict.getStr("signedData");
        return signData;
    }

    //    String apiData = HttpUtil.createPost("http://127.0.0.1:30505/PubKey2Address").body(JSONUtil.toJsonStr(new Dict().set("pubKey", service.platformPubKey))).execute().body();
//    String apiData1 = HttpUtil.createPost("http://127.0.0.1:30505/PubKey2Address").body(JSONUtil.toJsonStr(new Dict().set("pubKey", userPubKey))).execute().body();
//        System.out.println(service.getIdentityQueryUrl(Arrays.asList("ZX8c278b8cbacbd76849954829313d6f66c0c2f4c4")));
//        System.out.println(service.getIdentityQueryUrl(Arrays.asList("ZX69cf12b880bb87512185c1acda6a330163f5275b")));
    public static void main(String[] args) throws Exception {
//        平台注册
        ZxDindAddressServiceImpl service = new ZxDindAddressServiceImpl();
        //获取用户手机验证码 - 用户信息查询
//        System.out.println(service.getQueryUserVerifyCode(1,1));
        //根据验证码获取用户唯一标识
//        System.out.println(service.getQueryUser(1,"690501"));

        // 获取用户信息验证码 - nft 绑定

//        System.out.println(service.getQueryUserVerifyCode(1,2));
//        签名
//        System.out.println(service.getSignByPriKey(service.platformMnemonic, service.platformUserIdentification));
//        System.out.println(service.getplatformSelf(service.platformSignData,service.platformPubKey,service.platformUserIdentification,"898130"));

        String apiData = HttpUtil.createPost("http://127.0.0.1:30505/PubKey2Address").body(JSONUtil.toJsonStr(new Dict().set("pubKey",service.platformPubKey))).execute().body();
        System.out.println(service.getIdentityQueryUrl(Arrays.asList("ZX8c278b8cbacbd76849954829313d6f66c0c2f4c4")));
        //自然人注册
        Dict pldict = service.getSignByPriKey(service.platformMnemonic, service.platformUserIdentification);
        service.platformPriKey = pldict.getStr("priKey");
        service.platformPubKey = pldict.getStr("pubKey");
        service.platformSignData = pldict.getStr("signData");
        service.platformAddress = "ZX8c278b8cbacbd76849954829313d6f66c0c2f4c4";
//
//        String userMnemonic = "bachelor believe space bridge vapor buyer filter occur trouble fetch lounge still";
//        String userIdentification = "ae93f257efa91f4ea485934c30b537e94c9a20b887c516d058835368b2008b86";
//        Dict userdict = service.getSignByPriKey(userMnemonic, userIdentification);
//
//        String userPriKey = userdict.getStr("priKey");
//        String userPubKey = userdict.getStr("pubKey");
//        String userSignData = pldict.getStr("signData");
//        String userAddress = "ZX69cf12b880bb87512185c1acda6a330163f5275b";

//                System.out.println(service.getSignByPriKey(service.platformMnemonic,"张少博_"+"15620987727_"+"620102199303272711"));
//        String userIdentification = JSONUtil.toBean(service.registerPresonPlatform("张少博","zhang.shaobo@chinaott.net","15620987727","620102199303272711",1),Dict.class).getStr("");

//        Dict dict = JSONUtil.toBean(HttpUtil.createPost(service.signByPriKeyUrl).body(JSONUtil.toJsonStr(new Dict().set("priKey", pldict.getStr("priKey")).set("data", userdict.getStr("signData")))).execute().body(), Dict.class);
//        String platformSignData = dict.getStr("signedData");
//        service.submitByTrustedPlatform(userdict.getStr("signData"),userdict.getStr("pubKey"),pldict.getStr("pubKey"),platformSignData,userIdentification);
//

//        String apiData = HttpUtil.createPost("http://127.0.0.1:30505/PubKey2Address").body(JSONUtil.toJsonStr(new Dict().set("pubKey",userdict.getStr("pubKey")))).execute().body();
//        System.out.println(service.getIdentityQueryUrl(Arrays.asList("")));
//        人脸核实
//        Dict dict= service.faceurlUrl(userIdentification,"browser");
//        String faceId = dict.getStr("faceId");
//        String faceId = "08556102570911ec87d65e5eab4dd209";
//        String h5Url =  dict.getStr("h5Url");
//        String h5Url = "https://ida.webank.com/api/web/login?webankAppId=IDAIYX2V&version=1.0.0&nonce=08853eda570911ec87d65e5eab4dd209&orderNo=08556102570911ec87d65e5eab4dd209&h5faceId=wb05201bf363fa8d7f711634e0c22d42&url=https%3A%2F%2Fcicdtestwww.zxinchain.com%2Fapi%2Fnftal%2Fnft%2Fface%2Freceive&userId=ae93f257efa91f4ea485934c30b537e94c9a20b887c516d058835368b2008b86&sign=8C443BFFB656EBB288E1BFF37B0DF405BB09AA93&from=browser&redirectType=1&resultType=1";

        //素材上传操作 平台发行
//        String seriesName = "未来头像";
//        String timestamp = Long.toString(System.currentTimeMillis() / 1000);
//
//        String pubSignedData = service.getSignedData(service.platformPriKey, timestamp + "_" + seriesName + "_" + service.platformPubKey);
//        String userSignedData = service.getSignedData(service.platformPriKey, timestamp + "_" + seriesName);
//
//        Dict dict = service.uploadSecret(seriesName, timestamp, service.platformPubKey, pubSignedData, service.platformPubKey, userSignedData);
//        System.out.println(JSONUtil.toJsonStr(dict));
//
//        String tempSecretKey = dict.getStr("tempSecretKey");
//        //cosPath = uploadAddress+ 文件名
//        String cosPath = dict.getStr("uploadAddress") + "1_2_2_3_3.png";
//        String tempSecretId = dict.getStr("tempSecretId");
//        String sessionToken = dict.getStr("sessionToken");

//        String tempSecretKey = "fKZjGSuso2n/FiJkMhEoO+tjaN1IvudsK6dSc21g03Q=";
        //cosPath = uploadAddress+ 文件名
//        String cosPath = "https://zhixinliantest-1302317679.cos.ap-guangzhou.myqcloud.com/nft/e63de5373a0c5b679decf9442ac6f91d1305400955da91acdf0c85c6a23d2963/未来头像/" + "1_2_2_3_3.png";
        String cosPath = "https://zhixinliantest-1302317679.cos.ap-guangzhou.myqcloud.com/nft/e63de5373a0c5b679decf9442ac6f91d1305400955da91acdf0c85c6a23d2963/newTv/material/d1d0339ccf184a78bea4b53497176f6c.png";
//        String tempSecretId = "AKIDhEC16qkWd8wz0VvSZmJai0CKx2ABoFKIBRpUWAeDBPTIgIQBAJxK9H6IchtE9Ids";
//        String sessionToken = "buiEiDM3uepvsPC810Jz7UFvWBtud10a54ca7d934320f8749d76f272189074casLj6ttWmT6ttfe9r954Kew69VsdH-J32aYSggw-e_fxBfTePKvaHLzYywv3ILbUYzV-82u50Jvh571D-VBEv77Y17v8mziGH5nYamyU525mCFwFnROL3WpiRnB4rdJPrmvs6qrFYjz1O5yxG7GYlhj9YGDwY8ThlFirFZBkqA2v7YXDp9qeu1YIyAgBHrLm_ndEtP9L6BUHkPI5xqs3C24FXdIEiGefJAS_5IMngrKvMBq9wPcnl1-ZD-jksUTWaTZsIt4nVy1U3q8i-ktntiFyV8bpLXk_BEXzokpf3kXSBCtU2HdaqED-YXuHZUSFlXPTgeaioJSgsSMaDB5B2p_C0pxeWJGVVUx3jVjMXgXP-C_8e8VX4cFT0jgyC4Fxq64-pOsTi1w1MvOfAL7a6RdAH-E-bWKNoP1SEwtzxzoKxg7Kdho2fRlqGB6zhNP7nxBwu2q0R_WkEPSQtMUGmQyR-nDm0DfMIKUEGstLXK46DWOQITMcUBkiCGvl0hIGUjm60OvPpjL8v_QVxFlX57aQz1VZvhGiPAtu5pjnJghpqXk-19qdTMh_bD8K-5uAdNfg9A8hbhwiPkeXAT19xa4Oj3S-twW0Y0zonxymY2MWpoI90U4jYr6OqcnaHVKw59WS45wf7DLJwjx_BdZpMraoi8P5UMJQixOTzGZcROr4dXMJssvgmN6tYtFLa2NE91rVFGCba01Om0YlZJUymkrZVz7zieVUKYHyj6F83p_WgA8Z6rgf-IHzceAuhApoK6aQtPnjSxIUFtvsFrcMDuWTvBxU2hjKQFXNqNnrYdiA";
//        String filePath ="/Users/zhang.shaobo/Desktop/图片部位素材/导出/2_2_1_3_3.png";
        //获取调用 http://127.0.0.1:30505/uploadToCos 接口上传素材
//        String apiData = HttpUtil.createPost("http://127.0.0.1:30505/uploadToCos").body(JSONUtil.toJsonStr(new Dict().set("tempSecretKey",tempSecretKey).set("cosPath",cosPath).set("tempSecretId",tempSecretId).set("sessionToken",sessionToken).set("filePath",filePath))).execute().body();

//        声明系列


////        nft发行 平台发行
//        byte[] readAllBytes = Files.readAllBytes(new File("/Users/dxp/Downloads/assets/人物/2_2_1_3_1.png").toPath());
//        Dict dict = Dict.create().set("data", readAllBytes);
//        String hash = (String) JSONUtil.toBean(HttpUtil.createPost("http://127.0.0.1:30505/SM3HashEncode").body(com.alibaba.fastjson.JSONObject.toJSONString(dict)).execute().body(), Dict.class).get("digest");
//        //platformPubKey_pubKey_publish_nft_author_name_url_displayUrl_hash_desc_flag_publishCount_seriesId_seriesBeginIndex_sellStatus_sellCount_metaData_operateId
//        String operateId = UUID.randomUUID().toString();
////        String s = Joiner.on("_").join(service.platformPubKey, service.platformPubKey, "publish_nft", "张san", "未来头像01", cosPath, cosPath, hash, "测试", "", 1, "", 1, 1, 1, "", operateId);
//        String s = String.join("_",service.platformPubKey, service.platformPubKey, "publish_nft", "张san", "未来头像02", cosPath, cosPath, hash, "测试", "", "1", "", "1", "1", "1", "", operateId);
//        String signature = service.getSignedData(service.platformPriKey, s);
//        String platformSignaturesignature = service.getSignedData(service.platformPriKey, s);
//        Dict nftData = service.nftPublish(service.platformPubKey, service.platformPubKey, "张san", "未来头像02", cosPath, cosPath, hash, "测试", "", 1, "", 1, 1, 1, operateId, "", signature, platformSignaturesignature);
//        String taskId = nftData.getStr("taskId");
////        查询结果
////        String taskId = "c147fca9-af74-4cee-a735-d73d2a17d005_nft-publish_2";
//        TimeUnit.SECONDS.sleep(1);
//        Dict dictzz = service.taskQueryResult(service.nftpublishResultUrl, service.platformPubKey, taskId);
//        String nftId = (String) dictzz.get("nftIdBegin");
////        nft元数据
//        Dict nftInfoDict = service.getNftInfoUrl(nftId);


//        积分领取，可直接调用购买NFT接口

//        //platformPubKey_applyerAddr_apply_point_count_operateId
//        String operateId = UUID.randomUUID().toString();
//        String s = Joiner.on("_").join(service.platformPubKey, userAddress, "apply_point",10,operateId);
//        String platformSignature = service.getSignedData(service.platformPriKey, s);
//        Dict applyDict = service.pointApply(userAddress,service.platformPubKey,10,operateId,platformSignature);
//        String applyTaskId = applyDict.getStr("taskId");
//        结果查询
//        String applyTaskId = "5d51c472-2ea0-4088-af25-b6af615f922a_apply-point_1";
//        Dict dictzz = service.taskQueryResult(service.pointApplyResultUrl,service.platformPubKey, applyTaskId);

//        查询积分
        //10
//        Dict user = service.getPointQuery(service.platformAddress, userAddress);
        //0
//        Dict pl = service.getPointQuery(service.platformAddress, service.platformAddress);

//        购买
//        String operateId = UUID.randomUUID().toString();
//        platformPubKey_receiverPubKey_pointReceiverAddr_applyScore_buy_nft_nftId_ offerCount_operateId
//        String s= Joiner.on("_").join(service.platformPubKey,userPubKey,service.platformAddress,100,"buy_nft",nftId,20,operateId);
//        String signature = service.getSignedData(userPriKey, s);
//        String platformSignaturesignature = service.getSignedData(service.platformPriKey, s);
//        Dict dictbb = service.getNftBuy(nftId, 100, userPubKey, service.platformAddress,service.platformPubKey,20, operateId,signature,platformSignaturesignature);
//        String taskId = nftData.getStr("taskId");
//        String taskIdz = "06160a30-42fb-43b4-8fda-4034f51ff732_buy-nft_1";
//        Dict dictaa = service.taskQueryResult(service.nftBuyResultUrl, service.platformPubKey, taskIdz);

//        转移
//        String operateId = UUID.randomUUID().toString();
//        pubKey_receiverAddr_nft_transfer_nftId_operateId
//        String s = Joiner.on("_").join(userPubKey, service.platformAddress, "nft_transfer", nftId, operateId);
//        String signature = service.getSignedData(userPriKey, s);
//        Dict dictzzz = service.transfer(userPubKey, service.platformAddress, nftId, operateId, signature);
//        String taskIdzz = dictzzz.getStr("taskId");

//        查询账户资产
//        service.getAddressList(service.platformAddress,null,0,10);
//        String seriesId = "e63de5373a0c5b679decf9442ac6f91d1305400955da91acdf0c85c6a23d2963_9ac9f3d6ff53ddcda540fcb8dbee198db9a56c71b17718a74ce157141c0672e4";
//        Dict data = service.getAddressList("ZX0a953cc62cdc044b7076fcbc45b10484c5270b05", seriesId, 0, 10);
//        System.out.println(JSON.toJSONString(data));
    }


}
