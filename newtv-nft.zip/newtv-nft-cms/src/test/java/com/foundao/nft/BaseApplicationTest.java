package com.foundao.nft;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
public class BaseApplicationTest {
    public static void main(String[] args) {
    }
}
