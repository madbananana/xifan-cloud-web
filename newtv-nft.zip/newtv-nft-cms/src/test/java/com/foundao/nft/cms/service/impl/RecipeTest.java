package com.foundao.nft.cms.service.impl;

import com.foundao.nft.BaseApplicationTest;
import com.foundao.nft.common.model.vo.MergeVO;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.PageResponseListVo;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @Package: com.foundao.nft.cms.service.impl
 * @ClassName: RecipeTest
 * @Author: chenli
 * @CreateTime: 2022/10/11 2:43 PM
 * @Description:
 */
@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("uat")
public class RecipeTest extends BaseApplicationTest {

    @Autowired
    private MergeService mergeService;

    @Test
    public void testMergePage(){
        BaseRequestVo baseRequestVo = new BaseRequestVo();
        PageResponseListVo<MergeVO> mergeVOPageResponseListVo = mergeService.mergePage(baseRequestVo);
        System.out.println(mergeVOPageResponseListVo);
    }
}
