package com.foundao.nft.cms.service.impl;

import cn.hutool.poi.excel.ExcelReader;
import cn.hutool.poi.excel.ExcelUtil;
import com.foundao.nft.BaseApplicationTest;
import com.foundao.nft.cms.controller.IntegralController;
import com.foundao.nft.common.properties.NftProperties;
import com.tx.core.beans.JsonResult;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

/**
 * @Package: com.foundao.nft.cms.service.impl
 * @ClassName: ReplenishTest
 * @Author: chenli
 * @CreateTime: 2022/9/20 11:35 上午
 * @Description:
 */
@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("uat")
public class ReplenishTest extends BaseApplicationTest {

    @Autowired
    private NftProperties nftProperties;

    @Test
    public void testAvatar() {
        ExcelReader reader = ExcelUtil.getReader(ReplenishTest.class.getResourceAsStream("/avatarLottery"+"2022-09-20"+".xlsx"));
        List<List<Object>> readAll = reader.read(1);
        readAll.forEach( r -> {

            System.out.println(r.get(0)+"");
        });
        System.out.println(111);
    }

    @Test
    public void testBlindBox(){
        //ExcelReader reader = ExcelUtil.getReader(IntegralController.class.getResourceAsStream("/replenish"+"2022-09-22"+".xlsx"));
        ExcelReader reader = ExcelUtil.getReader(nftProperties.getTempFilePath()+"replenish"+"2022-09-22"+".xlsx");
        List<List<Object>> readAll = reader.read(1);
        readAll.forEach( r -> {
            int count = Integer.parseInt(r.get(1) + "");
            for (int i = 0; i < count; i++) {
                replenish(r.get(0)+"",i,Integer.parseInt(r.get(2) + ""));
            }
        });
        System.out.println(1111);
    }

    private void blindBox(String mobile,Integer count){
        System.out.println("手机号："+ mobile + " 数量" + count);
    }

    private void replenish(String mobile,int i,int metaId){
        System.out.println("手机号："+ mobile + " 第"+i+"次发放藏品" + metaId);
    }
}
