package com.foundao.nft.cms.service.impl;

import cn.hutool.core.io.FileUtil;
import cn.hutool.core.io.IoUtil;
import cn.hutool.core.util.CharsetUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.poi.excel.ExcelReader;
import cn.hutool.poi.excel.ExcelUtil;
import com.foundao.nft.BaseApplicationTest;
import com.foundao.nft.cms.controller.IntegralController;
import com.foundao.nft.cms.controller.OperationController;
import com.foundao.nft.common.model.LogIp;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName IntegralTest
 * @Description TODO
 * @Author xifan
 * @Date 2022/9/16 15:23
 * @Version 1.0
 */
@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("uat")
public class IntegralTest extends BaseApplicationTest {

    @Autowired
    private LogIpService logIpService;

    public static void main(String[] args) {
        ExcelReader reader = ExcelUtil.getReader(FileUtil.file("integralReward2022-09-16.xlsx"));
        List<List<Object>> readAll = reader.read(1);
        System.out.println(readAll);
    }


    @Test
    public void testLogIp(){
        List<String> integralErrors = new ArrayList<>();
        integralErrors = IoUtil.readLines(OperationController.class.getResourceAsStream("/integralError.txt"), CharsetUtil.CHARSET_UTF_8,integralErrors);
        List<LogIp> list = new ArrayList<>();
        integralErrors.forEach( str -> {
            str=str.trim();
            if (StrUtil.isBlank(str)) {
                return ;
            }
            String[] s = str.split(" ");
            if (s.length<3) {
                return ;
            }
            LogIp logIp = new LogIp();
            logIp.setIp(s[1]);
            logIp.setCount(Integer.valueOf(s[0]));
            logIp.setInviteCode(Integer.valueOf(s[2]));
            list.add(logIp);
        });
        logIpService.saveBatch(list);
    }

    @Test
    public void awardIntegral(){
        ExcelReader reader = ExcelUtil.getReader(IntegralTest.class.getResourceAsStream("/integralReward2022-09-16.xlsx"));
        List<List<Object>> readAll = reader.read(1);
        readAll.forEach( r ->{
            System.out.println(r);
        });
        System.out.println(readAll);
    }
}
