package com.foundao.nft.cms.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.io.FileUtil;
import cn.hutool.core.io.file.PathUtil;
import cn.hutool.core.util.IdUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.poi.excel.ExcelReader;
import cn.hutool.poi.excel.ExcelUtil;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.extension.toolkit.ChainWrappers;
import com.foundao.nft.BaseApplicationTest;
import com.foundao.nft.cms.mapper.AvatarFullMapper;
import com.foundao.nft.cms.mapper.AvatarPartMapper;
import com.foundao.nft.cms.mapper.NftMetadataMapper;
import com.foundao.nft.common.constant.AvatarPartTypeEnum;
import com.foundao.nft.common.model.*;
import com.foundao.nft.common.model.sdk.client.NftService;
import com.foundao.nft.common.model.sdk.response.NftPublishTaskResultResponse;
import com.foundao.nft.common.model.sdk.response.SdkResponseBase;
import com.foundao.nft.common.model.sdk.response.SeriesTaskResultResponse;
import com.foundao.nft.common.model.vo.NftPublishVO;
import com.foundao.nft.common.properties.NftProperties;
import com.foundao.nft.common.util.NftCommonUtil;
import com.foundao.nft.common.util.OssFactory;
import com.tx.core.exception.BusException;
import com.tx.core.util.FFmpegUtil;
import com.tx.objectstorage.enums.OssAcl;
import com.tx.objectstorage.properties.OssPropertiesConfig;
import com.tx.objectstorage.service.ObjectStorageService;
import lombok.Data;
import org.junit.jupiter.api.Test;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.File;
import java.io.FileInputStream;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * 资源shuom :
 * 命名规则：人物文件夹：道具_耳机_头饰_眼镜_衣服.png
 * 人物+背景：         道具_耳机_头饰_眼镜_衣服_背景.png
 */

public class NftMetadataServiceTest extends BaseApplicationTest {

    @Autowired
    private OssPropertiesConfig ossPropertiesConfig;


    @Data
    public  static class AvatarPartAttr implements Serializable {
        /**
         * 图片文件名称
         */
        private String sourceFileName;
        /**
         * 部件位置
         */
        private String partPosition;
        /**
         * 部件名称
         */
        private String partName;
        /**
         * 比例
         */
        private String ratio;
        /**
         * 是否老员工  是  否
         */
        private String isSpecialType;
        /**
         * 是否唯一 是  否
         */
        private String IsUnique;
    }


    private final Integer seriesAutoId = 1;


    private static String imagePath = "/Users/chenli/Downloads/元素合成/元素展示1/";
//    private static String imagePath = "C:\\Users\\Administrator\\Desktop\\assets\\";
    //完整头像下划线路由
    private  List<String> routeList = CollUtil.newArrayList("道具","耳机","头饰","眼镜","衣服","背景");

    /**
     * 部件素材描述
     */
    private List<AvatarPartAttr> avatarPartAttrs;

    @Autowired
    private NftSeriesClaimService nftSeriesClaimService;
    @Autowired
    private NftMetadataService nftMetadataService;
    @Autowired
    private NftCommonUtil nftCommonUtil;
    @Autowired
    private NftService nftService;
    @Autowired
    private NftTaskService taskService;
    @Autowired
    private AvatarServiceImpl avatarService;
    @Autowired
    private NftMetadataMapper nftMetadataMapper;
    @Autowired
    private NftProperties nftProperties;
    @Autowired
    private AvatarPartMapper avatarPartMapper;
    @Autowired
    private AvatarFullMapper avatarFullMapper;


    private String getFilePrefix(String fileName){
        String filePrefix = FileUtil.getPrefix(fileName);
        //if(!filePrefix.contains("_")){
        //    filePrefix = String.valueOf(Integer.parseInt(filePrefix));
        //}
        return filePrefix;
    }

    /**
     * 找到头像对应的各个部件的id
     * @param sourceFileName 头像名称，不包含后缀名称
     * @return list
     */
    private List<AvatarPart> fullAvatarPartIdList(String sourceFileName){
        List<AvatarPart> resList = CollUtil.newArrayList();
        List<String> partNameList = Stream.of(sourceFileName.split("_")).collect(Collectors.toList());
        for (int i = 0; i < partNameList.size(); i++) {
            String routePartName = routeList.get(i);
            String partName = partNameList.get(i);
            if(StrUtil.isBlank(routePartName)){
                throw new BusException(String.format("不正确的格式:%s",sourceFileName));
            }
            Integer routeType = AvatarPartTypeEnum.getCodeByName(routePartName);
            AvatarPart avatarPart = avatarService.getAvatarPartByNameAndType(partName, routeType);
            if(avatarPart == null){
                throw new BusException(String.format("头像+背景:%s,找到对应部件:%s-%s",sourceFileName,partName,routeType));
            }
            resList.add(avatarPart);
            if (routePartName.equals("背景")) {
                AvatarPart fullBackendGround = avatarService.getAvatarPartByNameAndType(partName, 7);
                resList.add(fullBackendGround);
            }
        }
        return resList;
    }



    /**
     * 读取头像图片的属性
     * @return
     */
    private Optional<AvatarPartAttr> findAvatarPartAttr(String type,String fileName){
        if(avatarPartAttrs == null){
            ExcelReader reader = ExcelUtil.getReader(imagePath+"素材描述.xlsx",0);
            avatarPartAttrs = reader.readAll(AvatarPartAttr.class);
        }
        return avatarPartAttrs.stream().filter(p -> p.getPartPosition().equals(type) && p.getPartName().equals(fileName)).findFirst();
    }

    /**
     * 判断头像是否老员工能够获取的头像
     * @param sourceFileName 头像名称，不包含后缀名称
     * @return boolean
     */
    private int isSpecialType(String sourceFileName){
        String path = imagePath + "十年老员工人物";
        File dirFile = new File(path);
        List<File> files = PathUtil.loopFiles(dirFile.toPath(), null);

        Optional<File> first = files.stream().filter(file -> {
            String fileName = file.getName();
            String filePrefix = getFilePrefix(fileName);
            //查询
            return sourceFileName.contains(filePrefix);
        }).findFirst();
        if(first.isPresent()){
            return 1;
        }
        return 0;
    }

    /**
     * 尝试上传去cos
     * @param file 本地文件
     * @return 访问url
     */
    private String tryUploadToCos(File file){
        String imageUrl = "";
        //for (int i = 0; i < 3; i++){
        //    String key = "material/"+IdUtil.simpleUUID()+ "."+FileUtil.extName(file.getName());
        //    imageUrl = nftCommonUtil.uploadToCos(key, file.getAbsolutePath());
        //    if(StrUtil.isNotBlank(imageUrl)){
        //        break;
        //    }
        //    try {
        //        TimeUnit.SECONDS.sleep(1);
        //    } catch (InterruptedException e) {
        //        e.printStackTrace();
        //    }
        //}
        String key = "material/"+IdUtil.simpleUUID()+ "."+FileUtil.extName(file.getName());
        try (FileInputStream inputStream = new FileInputStream(file)){
            ObjectStorageService objectStorageService = OssFactory.getObject(ossPropertiesConfig);
            imageUrl = objectStorageService.putObject(inputStream, inputStream.available(), key, OssAcl.PublicRead);
            objectStorageService.shutdown();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return imageUrl;
    }

    /**
     * 声明牛头系列 第一步
     */
    @Test
    public void testSeriesClaim() throws InterruptedException {
//        系列图片路径
        String filePath = imagePath + "系列声明图.jpg";
        String key = "material/"+IdUtil.simpleUUID()+ "."+FileUtil.extName(filePath);
        //头像系列特殊，直接默认id为1
        NftSeriesClaim firstNftSeriesClaim = nftSeriesClaimService.getById(seriesAutoId);
        if(firstNftSeriesClaim != null){
            nftSeriesClaimService.removeById(seriesAutoId);
        }

        String imageUrl = nftCommonUtil.uploadToCos(key, filePath);
//        String imageUrl = "https://zhixinliantest-1302317679.cos.ap-guangzhou.myqcloud.com/nft/e63de5373a0c5b679decf9442ac6f91d1305400955da91acdf0c85c6a23d2963/newTv/material/be4e6705f3904be2bdc1cb0cbce92d4c.jpg";
        //1.声明牛头系列
        NftSeriesClaim seriesClaimVO = new NftSeriesClaim();
        seriesClaimVO.setMetaType(2);
        seriesClaimVO.setSeriesName("未来未来1“牛翻天”数字头像");
        seriesClaimVO.setBeginTime(DateUtil.now());
        seriesClaimVO.setCoverUrl(imageUrl);
        seriesClaimVO.setTotalCount(600);
        seriesClaimVO.setDesc("未来“牛翻天”数字头像，作为未来电视“十周年纪念款”数字藏品，在2022年新春面向公司全员发放。600个不同的形象造型源自设计部件和背景元素的随机组合生成，每一个形象都蕴含着面对未来独一无二的想象和态度。十年荏苒，是每一位未来人的同心同行，成就了彼此的高光时刻。下个十年，一起开新向未来！\n" +
                "未来“牛翻天”数字头像此次共发放600枚，每份藏品拥有唯一的数字藏品ID，不可篡改，永久贮藏。发放对象为截止2022年1月31日入职，管理主体为未来电视有限公司的全体正式员工。");
        nftSeriesClaimService.seriesClaim(seriesClaimVO,new CmsUser(){{
            setUserId(1);
            setUsername("系统生成");
        }});
        nftSeriesClaimService.updateId(seriesClaimVO.getId(),seriesAutoId);
        //阻塞方式查询系列声明是否成功
        while(true){
            NftSeriesClaim seriesClaim = nftSeriesClaimService.getById(seriesAutoId);
            //NftSeriesClaim seriesClaim = nftSeriesClaimService.getById(seriesClaimVO.getId());
            String taskId = seriesClaim.getTaskId();
            NftTask task = taskService.getTaskByTaskId(taskId);
            SdkResponseBase<SeriesTaskResultResponse> taskResult = nftService.seriesClaimResult(taskId);
            if (taskResult.getRetCode()==0) {
                SeriesTaskResultResponse result = taskResult.getData();
                task.setStatus(result.getTaskStatus());
                task.setChainTimestamp(new Date(result.getChainTimestamp()));
                task.setTxHash(result.getTxHash());
                task.setTaskMsg(result.getTaskMsg());
                seriesClaim.setSeriesId(result.getSeriesId());
                seriesClaim.setTaskStatus(result.getTaskStatus());

                taskService.updateById(task);
                nftSeriesClaimService.updateById(seriesClaim);
                if(result.getTaskStatus() != 2){
                    break;
                }
                try {
                    TimeUnit.SECONDS.sleep(2);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    /**
     * 导入部件 第二步2,抛出异常，请重新执行
     */
    @Test
    public void testImportAvatar2(){

        //1.导入部件
        Map<String,String>  partPathNameMap = new LinkedHashMap<String, String>(){{
            put("道具","道具");
            put("耳机","耳机");
            put("头饰","头饰");
            put("眼镜","眼镜");
            put("衣服","衣服");
            put("背景","背景");
            put("完整背景","完整背景");
            put("人物","人物");
            put("十年老员工人物","人物");
            put("特殊头像","人物");
        }};
        Set<String> partPathNameList =partPathNameMap.keySet();
        partPathNameList.forEach(partPathName->{
            String dirPath = imagePath+partPathName;
            File dirFile = new File(dirPath);
            List<File> files = PathUtil.loopFiles(dirFile.toPath(), null);
            files.forEach(file ->{
                String fileName = file.getName();
                String filePrefix = getFilePrefix(fileName);
                Integer codeByName = AvatarPartTypeEnum.getCodeByName(partPathNameMap.get(partPathName));
                if(codeByName != null ){
                    AvatarPart avatarPart = avatarService.getAvatarPartByNameAndType(filePrefix, codeByName);
                    if(avatarPart ==  null || StrUtil.isBlank(avatarPart.getUrl())){
                        if(avatarPart == null){
                            avatarPart = new AvatarPart();
                        }
                        //上传
                        String imageUrl =  tryUploadToCos(file);
                        if(StrUtil.isBlank(imageUrl)){
                            throw new BusException("上传文件异常-组件类型:"+ partPathName+" 组件号:"+fileName);
                        }

                        avatarPart.setCreateTime(new Date());
                        avatarPart.setPartType(codeByName);
                        avatarPart.setSourceFileName(filePrefix);
                        avatarPart.setUrl(imageUrl);
                        if(partPathName.equals("十年老员工人物")){
                            avatarPart.setSpecialType(isSpecialType(filePrefix));
                        }
                        if(partPathName.equals("特殊头像")){
                            avatarPart.setSpecialType(2);
                        }

                        //在素材描述中找到对应的素材秒速
                        Optional<AvatarPartAttr> optionalAvatarPartAttr = findAvatarPartAttr(partPathName, filePrefix);
                        if(optionalAvatarPartAttr.isPresent()){
                            AvatarPartAttr avatarPartAttr = optionalAvatarPartAttr.get();
                            avatarPart.setName(avatarPartAttr.getPartName());
                            avatarPart.setSourceFileName(avatarPartAttr.getSourceFileName());
                            if(StrUtil.isNotBlank(avatarPartAttr.getRatio())){
                                avatarPart.setRatio(new BigDecimal(avatarPartAttr.getRatio().replace("%","")));
                            }
                            //是否唯一部件
                            String isUnique = avatarPartAttr.getIsUnique();
                            avatarPart.setIsUnique("是".equals(isUnique) ? 1 : 0);
                            //是否老员工独有
                            String isSpecialType = avatarPartAttr.getIsSpecialType();
                            avatarPart.setSpecialType("是".equals(isSpecialType) ? 1 : 0);
                        }
                        avatarService.saveAvatarPart(avatarPart);
                    }

                }
            } );
        });
    }

    /**
     * 导入头像+背景 第三步
     */
    @Test
    public void testImportAvatarAndBackgound(){
        NftSeriesClaim seriesClaim = nftSeriesClaimService.getById(seriesAutoId);
        if(StrUtil.isBlank(seriesClaim.getSeriesId())){
            System.out.println("没有系列id生成");
            return;
        }
        String fullAvatarPath = imagePath+"人物背景";
        File dirFile = new File(fullAvatarPath);
        List<File> files = PathUtil.loopFiles(dirFile.toPath(), null);
        files.forEach(file -> {
            String fileName = file.getName();
            String filePrefix = getFilePrefix(fileName);
            List<AvatarPart> avatarParts = fullAvatarPartIdList(filePrefix);
            //1.上传
            AvatarFull avatarFull = avatarService.getFullAvatarByName(filePrefix);
            if(avatarFull == null){
                avatarFull = new AvatarFull();
                //上传
                String imageUrl =  tryUploadToCos(file);
                if(StrUtil.isBlank(imageUrl)){
                    throw new BusException("上传文件异常-人物+背景类型,"+ " 号:"+fileName);
                }
                avatarFull.setCreateTime(new Date());
                avatarFull.setSourceFileName(filePrefix);
                avatarFull.setUrl(imageUrl);
                //找到组成组件的组成部分
                List<Integer> partIds = avatarParts.stream().map(AvatarPart::getPartId).collect(Collectors.toList());
                avatarFull.setParts(JSON.toJSONString(partIds));
                avatarFull.setSpecialType(isSpecialType(filePrefix));
                //设置头像部件id
                String personFileName = filePrefix.substring(0, filePrefix.lastIndexOf("_"));
                AvatarPart avatarPartByNameAndType = avatarService.getAvatarPartByNameAndType(personFileName, 100);
                avatarFull.setAvatarPartId(avatarPartByNameAndType.getPartId());

                avatarService.saveAvatarFull(avatarFull);

                //重新查询
                avatarFull = avatarService.getFullAvatarByName(filePrefix);
            }
            //2.nft入库
            if(avatarFull.getNftMetaId() == null || avatarFull.getNftMetaId() == 0){
                //查询
                List<NftMetadata> nftMetadataList = ChainWrappers.lambdaQueryChain(nftMetadataMapper).eq(NftMetadata::getUrl, avatarFull.getUrl()).list();
                NftMetadata nftMetadata;
                if(CollUtil.isNotEmpty(nftMetadataList)){
                    nftMetadata = nftMetadataList.get(0);
                }else{
                    NftPublishVO publishVO = new NftPublishVO();
                    publishVO.setPublishCount(1);
                    publishVO.setSeriesId(seriesClaim.getSeriesId());
                    publishVO.setName(seriesClaim.getSeriesName()+"#"+nftMetadataService.getMaxSeriesBeginIndex(publishVO.getSeriesId()));
                    publishVO.setDesc("未来“牛翻天”数字头像");
                    publishVO.setUrl(avatarFull.getUrl());
                    publishVO.setDisplayUrl(avatarFull.getUrl());
                    publishVO.setSellFee(1);
                    NftMetadata newNftMetadata = new NftMetadata();
                    BeanUtils.copyProperties(publishVO, newNftMetadata);

                    //获取头像的部件描述
                    List<NftMetaDataPartAttr> metaDataPartAttrs = CollUtil.newArrayList();
                    avatarParts.forEach(p->{
                        NftMetaDataPartAttr nftMetaDataPartAttr = new NftMetaDataPartAttr();
                        nftMetaDataPartAttr.setPartName(p.getName());
                        nftMetaDataPartAttr.setPartType(p.getPartType());
                        nftMetaDataPartAttr.setRatio(p.getRatio().doubleValue());
                        nftMetaDataPartAttr.setIsSpecialType(p.getSpecialType());
                        nftMetaDataPartAttr.setIsUnique(p.getIsUnique());
                        metaDataPartAttrs.add(nftMetaDataPartAttr);
                    });
                    Map<String,Object> metaData = new HashMap<>(2);
                    metaData.put("partAttr",metaDataPartAttrs);

                    newNftMetadata.setMetaData(JSON.toJSONString(metaData));
                    newNftMetadata.setMetaType(2);
                    nftMetadata = nftMetadataService.publishNftMetaData(newNftMetadata,new CmsUser(){{
                        setUserId(1);
                        setUsername("系统导入");
                    }});
                }
                //更新头像的nft_meta_id
                avatarFull.setNftMetaId(nftMetadata.getMetaId());
                avatarService.saveAvatarFull(avatarFull);
                //查询结果
                //阻塞方式查询系列声明是否成功

                nftMetadata = nftMetadataService.getById(nftMetadata.getMetaId());
                while(true){
                    String taskId = nftMetadata.getTaskId();
                    NftTask task = taskService.getTaskByTaskId(taskId);
                    SdkResponseBase<NftPublishTaskResultResponse> taskResult = nftService.nftPublishResult(taskId);
                    if (taskResult.getRetCode()==0) {
                        NftPublishTaskResultResponse result = taskResult.getData();
                        task.setStatus(result.getTaskStatus());
                        task.setChainTimestamp(new Date(result.getChainTimestamp()));
                        task.setTxHash(result.getTxHash());
                        task.setTaskMsg(result.getTaskMsg());
                        nftMetadata.setNftId(result.getNftIdBegin());
                        nftMetadata.setTaskStatus(result.getTaskStatus());

                        taskService.updateById(task);
                        nftMetadataService.updateById(nftMetadata);
                        if(result.getTaskStatus() != 2){
                            break;
                        }
                        try {
                            TimeUnit.SECONDS.sleep(2);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }

            }
        });
    }

    @Test
    public void testExcel(){
        //在素材描述中找到对应的素材秒速
        Optional<AvatarPartAttr> optionalAvatarPartAttr = findAvatarPartAttr("道具", "超神手柄");
        System.out.println(111);
    }


    public static void main(String[] args) {
        String fileName = "/data0/012.png";
        System.out.println(FileUtil.getName(fileName));
    }
}