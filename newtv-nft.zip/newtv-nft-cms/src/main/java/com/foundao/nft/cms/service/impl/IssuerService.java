package com.foundao.nft.cms.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.common.constant.FoundaoConstant;
import com.foundao.nft.common.util.SortUtil;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.PageResponseListVo;
import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.cms.mapper.IssuerMapper;
import com.foundao.nft.common.model.Issuer;
@Service
public class IssuerService extends ServiceImpl<IssuerMapper, Issuer> {

    public PageResponseListVo<Issuer> pageIssuer(BaseRequestVo request) {
        Page<Issuer> page = new Page<>(request.getPage(),request.getNum());
        SortUtil.handlePageSort(request, page, "id", FoundaoConstant.ORDER_DESC, true);
        IPage<Issuer> resultList = baseMapper.pageList(page);
        long total = resultList.getTotal();
        return PageResponseListVo.createPageResponseListVo(resultList.getRecords(), total);
    }
}
