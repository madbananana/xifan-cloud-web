package com.foundao.nft.cms.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.validation.annotation.Validated;

/**
 * @ClassName SeriesBaseQueryVO
 * @Description TODO
 * @Author xifan
 * @Date 2022/9/8 15:13
 * @Version 1.0
 */
@Data
@ApiModel
@Validated
public class SeriesBaseQueryVO {

    @ApiModelProperty("是否免费0：收费1：免费")
    private Integer charge;

    @ApiModelProperty("1：普通3：盲盒")
    private Integer metaType;

    @ApiModelProperty("0:不可预约1：可预约")
    private Integer advanceBuy;

    @ApiModelProperty("是否可用兑换码兑换 0：不可以 1：可以")
    private Integer exchange;
}
