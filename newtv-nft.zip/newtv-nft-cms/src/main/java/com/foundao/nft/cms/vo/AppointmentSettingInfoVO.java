package com.foundao.nft.cms.vo;

import lombok.Data;

/**
 * @Package: com.foundao.nft.cms.vo
 * @ClassName: AppointmentSettingInfoVO
 * @Author: chenli
 * @CreateTime: 2022/7/20 4:57 下午
 * @Description:
 */
@Data
public class AppointmentSettingInfoVO {

    /**
     * 是否展示系列预约人数 （0展示1不展示）
     */
    private Integer showStatus;

    /**
     * 系列短id
     */
    private Integer id;

    /**
     * 预约总人数
     */
    private Integer appointmentTotalCount;

    /**
     * 预约人数增量
     */
    private Integer appointmentDelta;

    /**
     * 系列名
     */
    private String seriesName;
}
