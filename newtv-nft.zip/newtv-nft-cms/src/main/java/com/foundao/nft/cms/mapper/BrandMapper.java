package com.foundao.nft.cms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.common.model.Brand;
import com.foundao.nft.common.model.vo.BrandVO;
import com.tx.core.beans.BaseRequestVo;
import org.apache.ibatis.annotations.Mapper;

/**
    @Package: com.foundao.nft.cms.mapper
    @ClassName: BrandMapper
    @Author: chenli
    @CreateTime: 2022/2/21 4:26 下午
    @Description:
*/
@Mapper
public interface BrandMapper extends BaseMapper<Brand> {
    IPage<BrandVO> pageList(Page<BrandVO> page);
}
