package com.foundao.nft.cms.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName SystemIntegralInfoVO
 * @Description TODO
 * @Author xifan
 * @Date 2022/8/31 15:57
 * @Version 1.0
 */
@Data
@ApiModel
public class SystemIntegralInfoVO {

    @ApiModelProperty("系统投放总积分")
    private Integer totalPut;

    @ApiModelProperty("系统剩余总积分")
    private Integer totalRest;
}
