package com.foundao.nft.cms.service.impl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.cms.mapper.CategoryMapper;
import com.foundao.nft.common.model.Category;
/**
    @Package: com.foundao.nft.cms.service.impl
    @ClassName: CategoryService
    @Author: chenli
    @CreateTime: 2022/6/23 11:38 上午
    @Description:
*/
@Service
public class CategoryService extends ServiceImpl<CategoryMapper, Category> {

}
