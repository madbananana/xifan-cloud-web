package com.foundao.nft.cms.service.impl;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.foundao.nft.common.model.AwardInfo;
import com.foundao.nft.common.model.AwardRecord;
import com.foundao.nft.common.model.NftUser;
import com.foundao.nft.common.model.vo.UserConsumeVO;
import com.foundao.nft.common.util.RedisKeyFactory;
import com.tx.redis.service.RedisLockService;
import com.tx.redis.service.RedisService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.common.model.UserConsume;
import com.foundao.nft.cms.mapper.UserConsumeMapper;
/**
    @Package: com.foundao.nft.cms.service.impl
    @ClassName: UserConsumeService
    @Author: chenli
    @CreateTime: 2022/11/3 11:17 AM
    @Description:
*/
@Service
@RequiredArgsConstructor
public class UserConsumeService extends ServiceImpl<UserConsumeMapper, UserConsume> {
    private final RedisService redisService;
    private final RedisLockService redisLockService;
    private final NftUserService userService;
    private final AwardInfoService awardInfoService;
    private final AwardRecordService awardRecordService;

    private final NftOrderService orderService;

    public void initUserConsume() {
        String beginDateStr = (String) redisService.hget(RedisKeyFactory.getH5ActivityInfoKey(), "beginDate");
        String endDateStr = (String) redisService.hget(RedisKeyFactory.getH5ActivityInfoKey(), "endDate");
        String activityId = (String) redisService.hget(RedisKeyFactory.getH5ActivityInfoKey(), "activityId");

        //利用分布式锁扣除库存
        String awardLockKey = RedisKeyFactory.getPlaceAwardLock(activityId);
        boolean isSuccess = redisLockService.tryLock(awardLockKey, 5);
        if (isSuccess) {
            try {

                List<UserConsumeVO> consumeList = orderService.findConsume(beginDateStr,endDateStr);

                DateTime beginDate = DateUtil.parse(beginDateStr);
                DateTime endDate = DateUtil.parse(endDateStr);
                DateTime now = DateUtil.date();

                consumeList.forEach(vo -> {
                    NftUser user = userService.getById(vo.getUserId());
                    if (StrUtil.isNotBlank(activityId) && DateUtil.compare(now, beginDate) >= 0 && DateUtil.compare(endDate, now) >= 0) {
                        UserConsume userConsume = this.lambdaQuery()
                                .eq(UserConsume::getUserId, user.getUserId())
                                .eq(UserConsume::getActivityId, activityId)
                                .one();

                        if (userConsume == null) {
                            userConsume = new UserConsume();
                            userConsume.setUserId(user.getUserId());
                            userConsume.setActivityId(Integer.valueOf(activityId));
                            userConsume.setTotalCostFee(0);
                        }
                        userConsume.setTotalCostFee(vo.getTotalFee());
                        this.saveOrUpdate(userConsume);

                        List<AwardInfo> list = awardInfoService.lambdaQuery()
                                .eq(AwardInfo::getActivityId, activityId)
                                .orderByAsc(AwardInfo::getLevel)
                                .orderByDesc(AwardInfo::getIsGoldAward)
                                .list();

                        for (AwardInfo awardInfo : list) {
                            if (userConsume.getTotalCostFee()>=awardInfo.getLevel()) {
                                if (awardInfo.getIsGoldAward()==1) {
                                    if (user.getRightLevel()!=2) {
                                        continue;
                                    }
                                }
                                Integer count = awardRecordService.lambdaQuery()
                                        .eq(AwardRecord::getUserId, vo.getUserId())
                                        .eq(AwardRecord::getActivityId, activityId)
                                        .eq(AwardRecord::getLevel,awardInfo.getLevel())
                                        .count();
                                if (count==0) {
                                    if (awardInfo.getRestCount()>0) {
                                        AwardRecord record = new AwardRecord();
                                        record.setIsGoldAward(awardInfo.getIsGoldAward());
                                        record.setAwardId(awardInfo.getAwardId());
                                        record.setLevel(awardInfo.getLevel());
                                        record.setUserId(vo.getUserId());
                                        record.setActivityId(Integer.valueOf(activityId));
                                        awardRecordService.save(record);
                                        awardInfo.setRestCount(awardInfo.getRestCount()-1);
                                        awardInfoService.updateById(awardInfo);
                                    }
                                }
                            }
                        }
                    }
                });
            } finally {
                redisLockService.unlock(awardLockKey);
            }
        }



    }
}
