package com.foundao.nft.cms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.foundao.nft.common.model.LogIp;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface LogIpMapper extends BaseMapper<LogIp> {
}