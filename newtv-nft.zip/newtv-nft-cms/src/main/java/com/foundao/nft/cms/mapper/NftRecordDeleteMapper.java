package com.foundao.nft.cms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.foundao.nft.common.model.NftRecordDelete;
import org.apache.ibatis.annotations.Mapper;

/**
    @Package: com.foundao.nft.cms.mapper
    @ClassName: NftRecordDeleteMapper
    @Author: chenli
    @CreateTime: 2022/3/10 10:06 上午
    @Description:
*/
@Mapper
public interface NftRecordDeleteMapper extends BaseMapper<NftRecordDelete> {
}