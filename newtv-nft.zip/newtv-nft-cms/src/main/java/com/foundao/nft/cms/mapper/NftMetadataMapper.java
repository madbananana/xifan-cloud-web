package com.foundao.nft.cms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.foundao.nft.common.model.NftMetadata;
import com.foundao.nft.common.model.vo.NftListVO;
import com.foundao.nft.common.model.vo.NftMetaDataBaseVO;
import com.tx.core.beans.BaseRequestVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface NftMetadataMapper extends BaseMapper<NftMetadata> {


    @Select("select sum(publish_count) seriesBeginIndex from nft_metadata where series_id = #{seriesId} and task_status=7  order by series_begin_index desc ")
    NftMetadata getMaxSeriesBeginIndex(@Param("seriesId") String seriesId);

    IPage<NftListVO> pageList(IPage<?> page, @Param("requestVo") BaseRequestVo requestVo);

    Integer countRestCount(@Param("seriesId") String seriesId);

    List<NftMetaDataBaseVO> listBase(@Param("id") Integer id,@Param("metaType") Integer metaType);
}
