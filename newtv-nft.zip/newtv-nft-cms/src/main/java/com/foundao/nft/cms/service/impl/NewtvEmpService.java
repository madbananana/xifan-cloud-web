package com.foundao.nft.cms.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.cms.mapper.NewtvEmpMapper;
import com.foundao.nft.common.model.NewtvEmp;
import org.springframework.stereotype.Service;

/**
    @Package: com.foundao.nft.api.service.impl
    @ClassName: NewtvEmpService
    @Author: chenli
    @CreateTime: 2021/12/20 6:17 下午
    @Description:
*/
@Service
public class NewtvEmpService extends ServiceImpl<NewtvEmpMapper, NewtvEmp> {

}
