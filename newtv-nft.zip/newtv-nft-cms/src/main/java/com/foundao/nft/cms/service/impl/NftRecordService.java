package com.foundao.nft.cms.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.cms.mapper.NftRecordMapper;
import com.foundao.nft.cms.vo.SystemIntegralInfoPageResponseListVo;
import com.foundao.nft.common.constant.FoundaoConstant;
import com.foundao.nft.common.model.NftMetadata;
import com.foundao.nft.common.model.NftRecord;
import com.foundao.nft.common.model.NftTask;
import com.foundao.nft.common.model.NftUserPlatform;
import com.foundao.nft.common.model.vo.HoldInfoResponseVO;
import com.foundao.nft.common.model.vo.IntegralStatsVO;
import com.foundao.nft.common.model.vo.NftListVO;
import com.foundao.nft.common.model.vo.UserNftInfoVO;
import com.foundao.nft.common.util.SortUtil;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.PageResponseListVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
@Slf4j
public class NftRecordService extends ServiceImpl<NftRecordMapper, NftRecord> {

    @Autowired
    private NftMetadataService nftMetadataService;
    @Autowired
    private NftUserPlatformService nftUserPlatformService;


    public PageResponseListVo<NftListVO> pageList(BaseRequestVo request) {
        Page<NftListVO> page = new Page<>(request.getPage(),request.getNum());
        SortUtil.handlePageSort(request, page, "meta_id", FoundaoConstant.ORDER_DESC, true);
        IPage<NftListVO> resultList = baseMapper.pageList(page,request);
        long total = resultList.getTotal();
        return PageResponseListVo.createPageResponseListVo(resultList.getRecords(), total);
    }

    /**
     * 新增购买记录
     * @param extData
     */
    public NftRecord addBuyRecord(NftTask.NftBuyExtInfo extData){
        //获取meta信息
        NftMetadata nftMetadata = nftMetadataService.getById(extData.getMetaId());
        NftUserPlatform userPlatform = nftUserPlatformService.getById(extData.getUserId());
        NftRecord nftRecord = new NftRecord();
        nftRecord.setNftId(nftMetadata.getNftId());
        nftRecord.setActualNftId(extData.getNftId());
        nftRecord.setObtainType(1);
        //2 执行中
        nftRecord.setBuyStatus(2);
        nftRecord.setMetaId(extData.getMetaId());
        nftRecord.setOwnerTime(new Date());
        nftRecord.setUserId(extData.getUserId());
        nftRecord.setMetaType(nftMetadata.getMetaType());
        nftRecord.setCreateTime(new Date());
        nftRecord.setOwnerAddr(userPlatform.getAddr());
        nftRecord.setTxHash("");
        try {
            boolean save = save(nftRecord);
            if (!save) {
                log.info("插入nft下发记录失败");
            }
        } catch (Exception e) {
            log.error("nft下发记录插入异常",e);
        }

        log.info("nft下发插入记录：{}",nftRecord);
        return nftRecord;
    }

    public List<Integer> findMoreBuyPrimaryUserId(Integer metaId) {
        return baseMapper.findMoreBuyPrimaryUserId(metaId);
    }

    public void deleteBak(NftRecord one) {
        baseMapper.deleteBak(one.getId());
        baseMapper.deleteById(one.getId());
    }

    public NftRecord findFromBak(String backId) {
        return baseMapper.findFromBak(backId);
    }

    public void updateBak(String id) {
        baseMapper.updateBak(id);
    }

    public PageResponseListVo<UserNftInfoVO> userNftInfo(BaseRequestVo request) {
        Page<UserNftInfoVO> page = new Page<>(request.getPage(),request.getNum());
        SortUtil.handlePageSort(request, page, "user_id", FoundaoConstant.ORDER_DESC, true);
        IPage<UserNftInfoVO> resultList = baseMapper.userNftInfo(page,request);
        long total = resultList.getTotal();
        return SystemIntegralInfoPageResponseListVo.createPageResponseListVo(resultList.getRecords(), total);
    }

    public List<HoldInfoResponseVO> userHoldInfo(Integer shortSeriesId) {
        return baseMapper.userHoldInfo(shortSeriesId);
    }
}

