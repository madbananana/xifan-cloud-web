package com.foundao.nft.cms.upload;

import com.tx.upload.core.UploadPostProcessor;
import com.tx.upload.vo.UploadFile;

/**
 * zip上传之后处理
 */
//@Component
public class ZipUploadPostProcessor implements UploadPostProcessor {
    @Override
    public void complete(UploadFile uploadFile, String url, String type) {

    }

}
