package com.foundao.nft.cms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.common.model.Integral;
import com.foundao.nft.common.model.vo.IntegralStatsVO;
import com.foundao.nft.common.model.vo.UserIntegralDetailsVO;
import com.tx.core.beans.BaseRequestVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface IntegralMapper extends BaseMapper<Integral> {
    IPage<Integral> pageIntegral(Page<Integral> page,@Param("request") BaseRequestVo request);

    UserIntegralDetailsVO personIntegralStats(Integer userId);

    IPage<IntegralStatsVO> integralStats(Page<IntegralStatsVO> page,@Param("request") BaseRequestVo request);
}
