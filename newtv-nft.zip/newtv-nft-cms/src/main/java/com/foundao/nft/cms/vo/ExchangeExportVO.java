package com.foundao.nft.cms.vo;

import lombok.Data;

/**
 * @ClassName ExchangeExportVO
 * @Description TODO
 * @Author xifan
 * @Date 2022/9/14 11:11
 * @Version 1.0
 */
@Data
public class ExchangeExportVO {

    private Integer id;
}
