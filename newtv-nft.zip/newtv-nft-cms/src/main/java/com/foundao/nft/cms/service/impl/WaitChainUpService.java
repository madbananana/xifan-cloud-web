package com.foundao.nft.cms.service.impl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.cms.mapper.WaitChainUpMapper;
import com.foundao.nft.common.model.WaitChainUp;
/**
    @Author: chenli
    @CreateTime: 2023/2/3 11:45
    @Description:
*/
@Service
public class WaitChainUpService extends ServiceImpl<WaitChainUpMapper, WaitChainUp> {

}
