package com.foundao.nft.cms.service.impl;

import cn.hutool.core.io.FileUtil;
import cn.hutool.core.util.IdUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.extension.toolkit.ChainWrappers;
import com.foundao.nft.cms.mapper.NftMetadataMapper;
import com.foundao.nft.common.constant.FoundaoConstant;
import com.foundao.nft.common.constant.TaskEnum;
import com.foundao.nft.common.model.*;
import com.foundao.nft.common.model.sdk.client.NftService;
import com.foundao.nft.common.model.sdk.request.NftPublishRequest;
import com.foundao.nft.common.model.sdk.response.SM3HashResponse;
import com.foundao.nft.common.model.sdk.response.SdkResponseBase;
import com.foundao.nft.common.model.sdk.response.TaskResponse;
import com.foundao.nft.common.model.vo.NftListVO;
import com.foundao.nft.common.model.vo.NftMetaDataBaseVO;
import com.foundao.nft.common.properties.NftProperties;
import com.foundao.nft.common.util.NftCommonUtil;
import com.foundao.nft.common.util.RedisKeyFactory;
import com.foundao.nft.common.util.SortUtil;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.PageResponseListVo;
import com.tx.core.exception.BusException;
import com.tx.core.util.file.FileDownloadUtil;
import com.tx.redis.annotation.FdRedisCache;
import com.tx.redis.service.RedisService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.net.URL;
import java.util.List;
import java.util.Optional;

@Service
@Slf4j
@RequiredArgsConstructor
public class NftMetadataService extends ServiceImpl<NftMetadataMapper, NftMetadata> {

    private final NftProperties nftProperties;
    private final NftCommonUtil nftCommonUtil;
    private final NftService nftService;
    private final NftTaskService taskService;
    private final RedisService redisService;

    public PageResponseListVo<NftListVO> pageList(BaseRequestVo request) {
        Page<NftListVO> page = new Page<>(request.getPage(),request.getNum());
        SortUtil.handlePageSort(request, page, "meta_id", FoundaoConstant.ORDER_DESC, true);
        IPage<NftListVO> resultList = baseMapper.pageList(page,request);
        resultList.getRecords().forEach(vo->{
            Integer count = (Integer) redisService.hget(RedisKeyFactory.getShowCountKey(), vo.getMetaId() + "");
            if (count!=null && count!=0) {
                vo.setShowCount(count);
            }
            if (vo.getMetaType()==4) {
                List<RecipeMaterial> recipeMaterials = JSON.parseObject(vo.getMetaData(), new TypeReference<List<RecipeMaterial>>() {
                });
                vo.setRecipeMaterials(recipeMaterials);
            }
        });
        long total = resultList.getTotal();
        return PageResponseListVo.createPageResponseListVo(resultList.getRecords(), total);
    }


    /**
     * 得到该系列发行的最大的nft索引id
     * @param seriesId
     * @return
     */
    public Integer getMaxSeriesBeginIndex(String seriesId){
        NftMetadata maxSeriesBeginIndex = baseMapper.getMaxSeriesBeginIndex(seriesId);
        if(maxSeriesBeginIndex == null){
            return 1;
        }
        return maxSeriesBeginIndex.getSeriesBeginIndex()+1;
    }

    /**
     * 通过nft名称获取唯一nft
     * @param name nft名称
     * @return
     */
    public NftMetadata getNftByName(String name,String seriesId){
        return ChainWrappers.lambdaQueryChain(baseMapper)
                .eq(NftMetadata::getName,name)
                .eq(NftMetadata::getSeriesId,seriesId)
                .eq(NftMetadata::getTaskStatus,7)
                .last("limit 1")
                .one();
    }
    /**
     * 获取文件hash
     *
     * @param fileUrl 文件url
     * @return hash值
     */
    private String getFileHash(String fileUrl) {
        //下载文件
        String downloadTempPath = nftProperties.getTempFilePath() + "download/";
        File tempPathFile = new File(downloadTempPath);
        if (!tempPathFile.exists()) {
            boolean mkSuccess = tempPathFile.mkdirs();
            if (!mkSuccess) {
                log.error("NftMetadataService:getFileHash 创建目录失败,{}", downloadTempPath);
            }
        }
        URL url;
        File file = null;
        try {
            url = new URL(fileUrl);
            String filePath = downloadTempPath + FileUtil.getName(url.getFile());
            file = new File(filePath);
            if (!file.exists()) {
                FileDownloadUtil.remoteToLocal(fileUrl, filePath);
            }
            SM3HashResponse sm3HashResponse = nftCommonUtil.sm3HashEncode(FileUtil.readBytes(filePath));
            if (StrUtil.isBlank(sm3HashResponse.getErr())) {
                return sm3HashResponse.getDigest();
            } else {
                return "";
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new BusException("下载远程文件失败");
        }finally {
            if(file != null && file.exists()){
                file.delete();
            }
        }
    }

    /**
     * 发布nft
     * @param nftMetadata nft信息
     * @param user 用户信息
     * @return
     */
    public NftMetadata publishNftMetaData(NftMetadata nftMetadata,CmsUser user) {
        nftMetadata.setCreator(user.getUserId());
        if(nftMetadata.getMetaId() == null){
            //新增发布的时候需要设置的数据
            nftMetadata.setSeriesBeginIndex(getMaxSeriesBeginIndex(nftMetadata.getSeriesId()));
            nftMetadata.setRestCount(nftMetadata.getPublishCount());
            if(nftMetadata.getSellFee() == 0 ){
                nftMetadata.setSellCount(1);
            }else{
                nftMetadata.setSellCount(nftMetadata.getSellFee());
            }
        }
        nftMetadata.setOperateId(IdUtil.randomUUID());

        //构建nft发布的请求信息
        //要保证文件hash值存在
        if (StrUtil.isBlank(nftMetadata.getHash())) {
            nftMetadata.setHash(getFileHash(nftMetadata.getUrl()));
        }
        if (StrUtil.isBlank(nftMetadata.getHash())) {
            throw new BusException("获取文件hash失败");
        }
        NftPublishRequest request = new NftPublishRequest();
        BeanUtils.copyProperties(nftMetadata, request);

        SdkResponseBase<TaskResponse> firstTaskResponse = null;
        if (nftMetadata.getPublishCount()>5000) {

            int times = request.getPublishCount()/5000+1;
            for (int i=0;i<times;i++) {
                if (i>0) {
                    request.setOperateId(IdUtil.randomUUID());
                }
                request.setSeriesBeginIndex(i*5000+nftMetadata.getSeriesBeginIndex());
                if ((i+1)*5000<=nftMetadata.getPublishCount()) {
                    request.setPublishCount(5000);
                } else {
                    request.setPublishCount(nftMetadata.getPublishCount()-i*5000);
                }

                SdkResponseBase<TaskResponse> taskResponse = nftService.nftPublish(request);
                if (i==0) {
                    firstTaskResponse = taskResponse;
                }
                if (taskResponse == null || taskResponse.getRetCode() != 0) {
                    if (i==0) {
                        break;
                    } else {
                        log.info("发行重试："+request);
                        taskResponse = nftService.nftPublish(request);
                        if (taskResponse == null || taskResponse.getRetCode() != 0) {
                            break;
                        }
                    }
                }
                //添加任务到任务表中
                if (StrUtil.isNotBlank(taskResponse.getData().getTaskId())) {
                    NftTask task = new NftTask();
                    task.setTaskId(taskResponse.getData().getTaskId());
                    task.setType(TaskEnum.NFT_PUBLISH.getCode());
                    task.setStatus(2);
                    task.setOperateId(request.getOperateId());
                    taskService.addTask(task);
                }
            }

        } else {
            firstTaskResponse = nftService.nftPublish(request);
            if (firstTaskResponse != null && firstTaskResponse.getRetCode() == 0) {
                //添加任务到任务表中
                if (StrUtil.isNotBlank(firstTaskResponse.getData().getTaskId())) {
                    NftTask task = new NftTask();
                    task.setTaskId(firstTaskResponse.getData().getTaskId());
                    task.setType(TaskEnum.NFT_PUBLISH.getCode());
                    task.setStatus(2);
                    task.setOperateId(request.getOperateId());
                    taskService.addTask(task);
                }
            }
        }

        if (firstTaskResponse != null && firstTaskResponse.getRetCode() == 0) {
            // 新增任务并添加nft元数据到库
            nftMetadata.setTaskId(firstTaskResponse.getData().getTaskId());
            if(nftMetadata.getMetaId() != null){
                updateById(nftMetadata);
            }else{
                save(nftMetadata);
            }
            return nftMetadata;
        }
        return null;
    }

    /**
     * 获取该系列下面还有多少未售完的记录
     * @param seriesId 系列id
     * @return
     */
    public int countRestCount(String seriesId){
        return Optional.ofNullable(baseMapper.countRestCount(seriesId)).orElse(0);
    }

    /**
     * 减少库存
     * @param metaId 自增id
     * @param version 版本号
     * @param reduceCount 减少数量
     */
    public boolean reduceNftStock(Integer metaId, Integer version, int reduceCount){
        return  ChainWrappers.lambdaUpdateChain(baseMapper)
                .eq(NftMetadata::getMetaId, metaId)
//                .eq(NftMetadata::getVersion, version)
                .setSql("rest_count=rest_count-" + reduceCount)
//                .setSql("show_count=show_count-" + reduceCount)
                .update();
    }

    /**
     * 减少库存
     * @param metaId 自增id
     * @param version 版本号
     * @param reduceCount 减少数量
     */
    public boolean reduceNftStockAndShowCount(Integer metaId, Integer version, int reduceCount){
        return  ChainWrappers.lambdaUpdateChain(baseMapper)
                .eq(NftMetadata::getMetaId, metaId)
//                .eq(NftMetadata::getVersion, version)
                .setSql("rest_count=rest_count-" + reduceCount)
                .setSql("show_count=show_count-" + reduceCount)
                .update();
    }

    /**
     * 增加nft的库存
     * @param metaId nft的自增id
     * @param count 增加库存数量
     * @return
     */
    public boolean incrementNftStock(Integer metaId,int count, Integer metaType, NftSeriesClaim seriesClaim){
        if (metaType==3) {
            //增加系列库存
            Long restCount = redisService.incr(RedisKeyFactory.getSeriesStockKey(seriesClaim.getId()), 1L);
        }
        return  ChainWrappers.lambdaUpdateChain(baseMapper)
                .eq(NftMetadata::getMetaId, metaId)
                .setSql("rest_count=rest_count+" + count)
                .update();
    }
    /**
     * 增加nft的库存
     * @param metaId nft的自增id
     * @param count 增加库存数量
     * @return
     */
    public boolean incrementNftStockAndShowCount(Integer metaId, int count, Integer metaType, NftSeriesClaim seriesClaim){
        if (metaType==3) {
            //增加系列库存
            Long restCount = redisService.incr(RedisKeyFactory.getSeriesStockKey(seriesClaim.getId()), 1L);
        }
        return  ChainWrappers.lambdaUpdateChain(baseMapper)
                .eq(NftMetadata::getMetaId, metaId)
                .setSql("rest_count=rest_count+" + count)
                .setSql("show_count=show_count+" + count)
                .update();
    }

    public List<NftMetaDataBaseVO> listBase(Integer id,Integer metaType) {
        List<NftMetaDataBaseVO> list = baseMapper.listBase(id, metaType);

        list.forEach( vo -> {
            Integer count = (Integer) redisService.hget(RedisKeyFactory.getShowCountKey(), vo.getMetaId() + "");
            if (count!=null && count!=0) {
                vo.setTotalShowCount(count);
            }
        } );
        return list;
    }

    @FdRedisCache(expireTime = 6000,key = "'nftMetaData:'+#metaId")
    public NftMetadata getByMetaId(String metaId) {
        return getById(metaId);
    }
}

