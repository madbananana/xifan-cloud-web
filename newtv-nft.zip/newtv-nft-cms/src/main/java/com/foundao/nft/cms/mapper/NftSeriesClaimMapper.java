package com.foundao.nft.cms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.foundao.nft.cms.vo.SeriesBaseQueryVO;
import com.foundao.nft.cms.vo.SeriesListVO;
import com.foundao.nft.common.model.NftSeriesClaim;
import com.foundao.nft.common.model.vo.SeriesBaseVO;
import com.tx.core.beans.BaseRequestVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @Package: com.foundao.nft.cms.mapper
 * @ClassName: NftSeriesClaimMapper
 * @Author: chenli
 * @CreateTime: 2021/12/22 11:28 上午
 * @Description:
 */
@Mapper
public interface NftSeriesClaimMapper extends BaseMapper<NftSeriesClaim> {
    IPage<SeriesListVO> pageSeries(IPage<?> page, @Param("requestVo") BaseRequestVo requestVo);

    List<SeriesBaseVO> listBase(@Param("baseQuery") SeriesBaseQueryVO baseQuery);
}
