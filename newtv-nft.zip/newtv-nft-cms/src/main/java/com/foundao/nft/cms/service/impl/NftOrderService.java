package com.foundao.nft.cms.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.IdUtil;
import cn.hutool.core.util.RandomUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.cms.vo.RecordForBlindBoxVO;
import com.foundao.nft.common.constant.FoundaoConstant;
import com.foundao.nft.common.constant.OrderStatusEnum;
import com.foundao.nft.common.constant.PayTypeEnum;
import com.foundao.nft.common.model.*;
import com.foundao.nft.common.model.apple.AppleOrderItem;
import com.foundao.nft.common.model.sdk.request.NftBuyRequest;
import com.foundao.nft.common.model.vo.OrderHistoryDetailsVO;
import com.foundao.nft.common.model.vo.PurchaseHistory;
import com.foundao.nft.common.model.vo.TradeCapitalInfoVO;
import com.foundao.nft.common.model.vo.UserConsumeVO;
import com.foundao.nft.common.model.vo.UserListVO;
import com.foundao.nft.common.properties.NftProperties;
import com.foundao.nft.common.util.RedisKeyFactory;
import com.foundao.nft.common.util.SortUtil;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.PageResponseListVo;
import com.tx.core.exception.BusException;
import com.tx.core.util.HttpRequestUtil;
import com.tx.redis.service.RedisLockService;
import com.tx.redis.service.RedisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.DefaultTypedTuple;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.*;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.cms.mapper.NftOrderMapper;
import org.springframework.transaction.annotation.Transactional;

/**
    @Package: com.foundao.nft.cms.service.impl
    @ClassName: NftOrderService
    @Author: chenli
    @CreateTime: 2022/3/7 3:20 下午
    @Description:
*/
@Service
public class NftOrderService extends ServiceImpl<NftOrderMapper, NftOrder> {

    @Autowired
    private NftUserPlatformService userPlatformService;
    @Autowired
    private NftMetadataService nftMetadataService;
    @Autowired
    private NftOrderInteractionService orderInteractionService;
    @Autowired
    private NftProperties nftProperties;
    @Autowired
    private RedisLockService redisLockService;
    @Autowired
    private RedisTemplate<String,Object> redisTemplate;
    @Autowired
    private RedisService redisService;
    @Autowired
    private NftSeriesClaimService seriesClaimService;
    @Autowired
    private NftMetadataService metadataService;
    @Autowired
    private BlindboxRecordService blindboxRecordService;


    public List<PurchaseHistory> getPurchaseHistory(String userId) {
        List<PurchaseHistory> purchaseHistory = baseMapper.getPurchaseHistory(userId);
        purchaseHistory.forEach( r-> {
            if (r.getMetaType()==3) {
                RecordForBlindBoxVO vo = baseMapper.selectRecordForBlindBox(r.getActualNftId());
                if (vo!=null) {
                    r.setPayType(vo.getPayType());
                    r.setFee(vo.getFee()/vo.getCount());
                }
            }
        });
        return baseMapper.getPurchaseHistory(userId);
    }

    public PageResponseListVo<TradeCapitalInfoVO> tradeList(BaseRequestVo requestVo) {
        Page<TradeCapitalInfoVO> page = new Page<>(requestVo.getPage(),requestVo.getNum());
        SortUtil.handlePageSort(requestVo, page, "order_id", FoundaoConstant.ORDER_DESC, true);
        IPage<TradeCapitalInfoVO> result = baseMapper.tradeList(page,requestVo);
        return PageResponseListVo.createPageResponseListVo(result.getRecords(),result.getTotal());
    }

    /**
     * 锁定库存
     *
     * @param nftMetadata nft元数据信息
     * @return 锁定的nftId
     */
    private String lockStock(NftMetadata nftMetadata,Integer reduceShowCount) {
        //利用分布式锁扣除库存
        String orderLockKey = RedisKeyFactory.getPlaceOrderLock(nftMetadata.getNftId());
        boolean isSuccess = redisLockService.tryLock(orderLockKey, 5);
        String actualNftId;
        if (isSuccess) {
            try {
                //查询库存
                NftMetadata newNftMetaData = nftMetadataService.getById(nftMetadata.getMetaId());
                //检查库存
                if (newNftMetaData.getRestCount() <= 0) {
                    throw new BusException("该作品已经售罄");
                }
                //减少库存
                boolean isUpdateSuccess;
                if (reduceShowCount!=null && reduceShowCount==1) {
                    isUpdateSuccess = nftMetadataService.reduceNftStockAndShowCount(nftMetadata.getMetaId(), null, 1);
                } else {
                    isUpdateSuccess = nftMetadataService.reduceNftStock(nftMetadata.getMetaId(), null, 1);
                }
                if (!isUpdateSuccess) {
                    throw new BusException("生成订单出现异常,请重试");
                }
                //获取唯一的真实的nftId
                actualNftId = popActualNftId(nftMetadata.getNftId(),reduceShowCount);
                if(actualNftId == null){
                    throw new BusException("该作品已经售罄");
                }
            } finally {
                redisLockService.unlock(orderLockKey);
            }
        } else {
            throw new BusException("生成订单超时，请重试");
        }
        return actualNftId;
    }

    public String lockActualNftStock(NftMetadata metadata,Integer reduceShowCount){
        //利用分布式锁扣除库存
        NftSeriesClaim seriesClaim = seriesClaimService.getBySeriesId(metadata.getSeriesId());
        String orderLockKey = RedisKeyFactory.getPlaceOrderLock(seriesClaim.getId()+"");
        boolean isSuccess = redisLockService.tryLock(orderLockKey, 5);
        String actualNftId = null;
        if (isSuccess) {
            try {
                if (metadata.getRestCount()<=0) {
                    throw new BusException("库存不足");
                }

                //减少库存
                boolean isUpdateSuccess;
                if (reduceShowCount!=null && reduceShowCount==1) {

                    if (seriesClaim.getMetaType()==3) {
                        //查询系列库存
                        Integer num = (Integer) redisService.get(RedisKeyFactory.getSeriesStockKey(seriesClaim.getId()));
                        if (num<1) {
                            throw new BusException("库存不足");
                        }
                        //减少系列库存
                        Long restCount = redisService.decr(RedisKeyFactory.getSeriesStockKey(seriesClaim.getId()), 1L);
                    }

                    isUpdateSuccess = nftMetadataService.reduceNftStockAndShowCount(metadata.getMetaId(), null, 1);

                } else {
                    isUpdateSuccess = nftMetadataService.reduceNftStock(metadata.getMetaId(), null, 1);
                }
                if (!isUpdateSuccess) {
                    throw new BusException("生成订单出现异常,请重试");
                }

                //获取唯一的真实的nftId
                actualNftId = popBlindBoxActualNftId(seriesClaim.getId(),metadata.getMetaId());
                if(actualNftId == null){
                    log.error("盲盒库存不足");
                    throw new BusException("生成订单出现异常,请重试");
                }
            } finally {
                redisLockService.unlock(orderLockKey);
            }
        } else {
            throw new BusException("当前购买人数过多，请稍后再试");
        }
        return actualNftId;
    }

    public String popBlindBoxActualNftId(Integer shortSeriesId,Integer metaId) {
        String setKey = RedisKeyFactory.getSeriesNftIdKey(shortSeriesId+"");
        Set<Object> sets =  redisTemplate.opsForZSet().rangeByScore(setKey, 0, 0);
        if(sets == null || sets.size() < 1){
            return null;
        }
        List<Object> lists = CollUtil.newArrayList(sets);
        String actualNftId=null;
        for (Object list : lists) {
            String info = (String) list;
            String[] metaIdAndIndex = info.split("-");
            String metaIdFromRedis = metaIdAndIndex[0];
            if (metaIdFromRedis.equals(metaId + "")) {
                NftMetadata metadata = metadataService.getById(metaId);
                actualNftId = metadata.getNftId().split("_")[0] + "_" + metaIdAndIndex[1];
                redisTemplate.opsForZSet().incrementScore(setKey, list, 10);
                break;
            }
        }
        return actualNftId;
    }

    public String replenish(NftMetadata metadata, Integer userId,Integer metaType,Integer reduceShowCount,NftSeriesClaim seriesClaim) {


        //获取用户认证信息
        NftUserPlatform userPlatform = userPlatformService.getById(userId);
        if (userPlatform==null) {
            return null;
        }
        String actualNftId ;
        if (metaType==3) {
            actualNftId = lockActualNftStock(metadata,reduceShowCount);
        } else {
            actualNftId = lockStock(metadata,reduceShowCount);
        }
        if (StrUtil.isBlank(actualNftId)) {
            return null;
        }

        NftBuyRequest request = new NftBuyRequest();
        request.setApplyScore(metadata.getSellCount());
        request.setNftId(actualNftId);
        request.setOfferCount(metadata.getSellCount());
        request.setOperateId(IdUtil.fastUUID());
        request.setPointReceiverAddr(userPlatform.getAddr());
        request.setReceiverPubKey(userPlatform.getPubkey());
        request.setPlatformPubKey(nftProperties.getPubKey());

        String taskId;
        try {
            NftTask.NftBuyExtInfo extData = new NftTask.NftBuyExtInfo();
            extData.setNftId(actualNftId);
            extData.setMetaId(metadata.getMetaId());
            extData.setMetaType(1);
            extData.setUserId(userId);
            extData.setShortSeriesId(seriesClaim.getId());
            extData.setIsReplenish("replenish");
            taskId = orderInteractionService.doBuyNft(request, userPlatform.getPrikey(), extData);
            if (taskId == null) {
                throw new BusException("领取发生异常,上链异常");
            }
        } catch (Exception e) {
            log.error("", e);
            //更新库存
            if (reduceShowCount!=null && reduceShowCount==1) {
                nftMetadataService.incrementNftStockAndShowCount(metadata.getMetaId(), 1,metaType,seriesClaim);
            } else {
                nftMetadataService.incrementNftStock(metadata.getMetaId(), 1,metaType,seriesClaim);
            }
            //释放redis zset的nft标记
            releaseNftFlag(metadata.getNftId(), actualNftId);
            throw new BusException("领取发生异常", e);
        }
        return taskId;
    }

    /**
     * 从redis中获取未被使用的nftId
     * @param nftBeginId 原始nft开始id
     * @return String 新的nft
     */
    public String popActualNftId(String nftBeginId,Integer reduceShowCount) {
        String setKey = RedisKeyFactory.getNftIdKey(nftBeginId);
        int min = 0;
        int max = 0;
        if (reduceShowCount==null || reduceShowCount!=1) {
            min=-1;
            max=-1;
        }
        Set<Object> sets =  redisTemplate.opsForZSet().rangeByScore(setKey, min, max);
        if(sets == null || sets.size() == 0){
            return null;
        }
        List<Object> lists = CollUtil.newArrayList(sets);
        int selectedIndex = RandomUtil.randomInt(0, lists.size());
        String newNftId = nftBeginId.split("_")[0]+"_"+lists.get(selectedIndex);
        redisTemplate.opsForZSet().incrementScore(setKey,lists.get(selectedIndex),10);
        return newNftId;
    }

    /**
     * 释放nftId标记
     * @param nftBeginId nft开始id
     * @param productId2 商品id
     */
    public void releaseNftFlag(String nftBeginId,String productId2) {
        String setKey = RedisKeyFactory.getNftIdKey(nftBeginId);
        int releaseNftIndex = Integer.parseInt(productId2.split("_")[1]);
        redisTemplate.opsForZSet().incrementScore(setKey,releaseNftIndex,-10);
    }

    /**
     * 获取购买两个未来星球的用户
     * @return
     */
    public List<String> getAborigines(String metaId) {
        return baseMapper.getAborigines(metaId);
    }

    public Map<String, String> blindBoxReplenish(NftSeriesClaim seriesClaim, Integer userId, Integer reduceShowCount, Integer count) {
        String tradeNo = StrUtil.format("Ntv{}{}{}",userId, DateUtil.format(new Date(),"yyMMddHHmmss"), RandomUtil.randomInt(10,99));

        NftOrder order = new NftOrder();
        order.setTradeNo(tradeNo);
        order.setCount(count);
        order.setOrderType(11);
        order.setShortSeriesId(seriesClaim.getId());
        order.setStatus(OrderStatusEnum.PAY_SUCCESS.getCode());
        order.setUserId(userId);
        order.setPayType("FREEACCESS");
        order.setAppleGoodsId("");
        //普通订单，非牛头订单
        order.setOrderType(11);
        order.setFee(0);
        order.setOrderFee(0);
        order.setIp(HttpRequestUtil.getClientIp());
        order.setIntegral(0);
        order.setPayTime(new Date());
        order.setThirdTransactionId("blindBoxReplenish"+userId+ DateUtil.format(new Date(),"yyMMddHHmmss") + RandomUtil.randomInt(10,99));
        save(order);

        if (reduceShowCount!=null && reduceShowCount==1) {
            lockStockBlindBox(seriesClaim,count);
        }

        Map<String, String> nftIds = lockActualNftStock(seriesClaim,userId,reduceShowCount,count);
        List<BlindboxRecord> records = new ArrayList<>();
        nftIds.forEach((id,metaId) -> {
            BlindboxRecord record = new BlindboxRecord();
            record.setUserId(userId);
            record.setStatus(0);
            record.setActualNftId(id);
            record.setShortSeriesId(seriesClaim.getId());
            record.setMetaId(Integer.valueOf(metaId));
            record.setOrderId(order.getOrderId());
            record.setBlindBoxIcon(seriesClaim.getBlindBoxIcon());
            record.setOpenTime(seriesClaim.getOpenTime());
            records.add(record);
        });
        blindboxRecordService.saveBatch(records);
        return nftIds;
    }
    public Map<String, String> lockActualNftStock(NftSeriesClaim seriesClaim, Integer userId, Integer reduceShowCount, Integer count) {
        //利用分布式锁扣除库存
        String orderLockKey = RedisKeyFactory.getPlaceOrderLock(seriesClaim.getId()+"");
        boolean isSuccess = redisLockService.tryLock(orderLockKey, 5);
        Map<String,String> actualNftIds;
        if (isSuccess) {
            try {

                //获取唯一的真实的nftId
                actualNftIds = popBlindBoxActualNftId(seriesClaim.getId() + "", reduceShowCount, count);
                if(actualNftIds == null){
                    log.error("盲盒库存不足");
                }
                if (actualNftIds==null || actualNftIds.size()==0) {
                    throw new BusException("生成订单出现异常,请重试");
                }
                actualNftIds.forEach((nftId,metaId) -> {
                    //减少库存
                    boolean isUpdateSuccess ;
                    if (reduceShowCount!=null && reduceShowCount==1) {
                        isUpdateSuccess = nftMetadataService.reduceNftStockAndShowCount(Integer.valueOf(metaId), null, 1);
                    } else {
                        isUpdateSuccess = nftMetadataService.reduceNftStock(Integer.valueOf(metaId), null, 1);
                    }
                    if (!isUpdateSuccess) {
                        throw new BusException("生成订单出现异常,请重试");
                    }
                } );
            } finally {
                redisLockService.unlock(orderLockKey);
            }
        } else {
            throw new BusException("当前购买人数过多，请稍后再试");
        }
        return actualNftIds;
    }

    /**
     * 从redis中获取未被使用的nftId
     * @param shortSeriesId 系列短id
     * @param count 个数
     * @return String 新的nft
     */
    public Map<String,String> popBlindBoxActualNftId(String shortSeriesId,Integer reduceShowCount,Integer count) {
        Map<String,String> newNftIds = new HashMap<>();
        String setKey = RedisKeyFactory.getSeriesNftIdKey(shortSeriesId);
        int min = 0;
        int max = 0;
        if (reduceShowCount==null || reduceShowCount!=1) {
            min = -1;
            max = -1;
        }
        Set<Object> sets =  redisTemplate.opsForZSet().rangeByScore(setKey, min, max);
        if(sets == null || sets.size() < count){
            return null;
        }
        List<Object> lists = CollUtil.newArrayList(sets);
        for (int i=0;i<count;i++) {
            int selectedIndex = RandomUtil.randomInt(0, lists.size());
            String info = (String) lists.get(selectedIndex);
            String[] metaIdAndIndex = info.split("-");
            String metaId = metaIdAndIndex[0];
            NftMetadata metadata = metadataService.getByMetaId(metaId);

            String newNftId = metadata.getNftId().split("_")[0]+"_"+metaIdAndIndex[1];
            redisTemplate.opsForZSet().incrementScore(setKey,lists.get(selectedIndex),10);
            lists.remove(selectedIndex);
            newNftIds.put(newNftId,metaId);
        }
        return newNftIds;
    }

    /**
     * 锁定库存
     *
     * @param seriesClaim 系列申明信息
     * @return
     */
    private String lockStockBlindBox(NftSeriesClaim seriesClaim,Integer count) {
        //利用分布式锁扣除库存
        String orderLockKey = RedisKeyFactory.getPlaceOrderLock(seriesClaim.getId()+"");
        boolean isSuccess = redisLockService.tryLock(orderLockKey, 5);
        if (isSuccess) {
            try {
                //查询库存
                Integer num = (Integer) redisService.get(RedisKeyFactory.getSeriesStockKey(seriesClaim.getId()));
                if (num<count) {
                    throw new BusException("库存不足");
                }
                //减少库存
                Long restCount = redisService.decr(RedisKeyFactory.getSeriesStockKey(seriesClaim.getId()), Long.valueOf(count));
            } finally {
                redisLockService.unlock(orderLockKey);
            }
        } else {
            throw new BusException("当前购买人数过多，请稍后再试");
        }
        return "";
    }

    /**
     * 盲盒藏品空投数量调整
     * @param metadata 藏品
     * @param id 盲盒id
     * @param count 目标数量
     */
    public int readjustAirdropCount(NftMetadata metadata,Integer id, Integer count) {
        //利用分布式锁扣除库存
        int airdropCount=0;
        String orderLockKey = RedisKeyFactory.getPlaceOrderLock(id+"");
        boolean isSuccess = redisLockService.tryLock(orderLockKey, 5);
        if (isSuccess) {
            try {

                String setKey = RedisKeyFactory.getSeriesNftIdKey(id+"");
                Set<Object> oldAirdropSets =  redisTemplate.opsForZSet().rangeByScore(setKey, -1, -1);
                if(oldAirdropSets == null){
                    throw new BusException("库存异常");
                }
                List<Object> oldAirdropList = CollUtil.newArrayList(oldAirdropSets);
                int oldMataIdAirdropCount = 0;
                List<Object> oldAirdropListByMetaId = new ArrayList<>();
                for (int i=0;i<oldAirdropList.size();i++) {
                    String info = (String) oldAirdropList.get(i);
                    String[] metaIdAndIndex = info.split("-");
                    String airdropMetaId = metaIdAndIndex[0];
                    if (airdropMetaId.equals(metadata.getMetaId()+"")) {
                        oldMataIdAirdropCount++;
                        oldAirdropListByMetaId.add(oldAirdropList.get(i));
                    }
                }
                airdropCount = oldMataIdAirdropCount;

                if (count<oldMataIdAirdropCount) {
                    int endIndex = oldMataIdAirdropCount-count;
                    if (oldAirdropListByMetaId.size()<endIndex) {
                        endIndex=oldAirdropListByMetaId.size();
                    }
                    for (int i = 0; i < endIndex; i++) {
                        redisTemplate.opsForZSet().incrementScore(setKey,oldAirdropListByMetaId.get(i),1);
                    }
                    airdropCount = oldMataIdAirdropCount-endIndex;
                } else if (count>oldMataIdAirdropCount) {
//                    Set<Object> readjustAirdropSets =  redisTemplate.opsForZSet().rangeByScore(setKey, 0, 0,0,count-oldMataIdAirdropCount);
                    Set<Object> totalReadjustAirdropSets =  redisTemplate.opsForZSet().rangeByScore(setKey, 0, 0);
                    List<Object> totalReadjustAirdropList = CollUtil.newArrayList(totalReadjustAirdropSets);
                    List<Object> readjustAirdropList = new ArrayList<>();

                    int endIndex = count-oldMataIdAirdropCount;
                    int addIndex = 0;
                    for (int i=0;i<totalReadjustAirdropList.size();i++) {
                        String info = (String) totalReadjustAirdropList.get(i);
                        if (info.contains(metadata.getMetaId()+"-")) {
                            readjustAirdropList.add(totalReadjustAirdropList.get(i));
                            addIndex++;
                            if (addIndex==endIndex) {
                                break;
                            }
                        }
                    }


                    if (readjustAirdropList.size()<endIndex) {
                        endIndex=readjustAirdropList.size();
                    }
                    for (int i = 0; i < endIndex; i++) {
                        redisTemplate.opsForZSet().incrementScore(setKey,readjustAirdropList.get(i),-1);
                    }
                    airdropCount=oldMataIdAirdropCount+endIndex;
                }
//                redisService.hset(RedisKeyFactory.getShowCountKey(),metadata.getMetaId()+"",metadata.getPublishCount()-airdropCount);
                metadata.setShowCount(metadata.getRestCount()-airdropCount);
                nftMetadataService.updateById(metadata);
                //减少库存
                Long showCount = redisTemplate.opsForZSet().count(setKey, 0, 0);
                if (showCount==null) {
                    showCount = 0L;
                }
                redisService.set(RedisKeyFactory.getSeriesStockKey(id), showCount);
            } finally {
                redisLockService.unlock(orderLockKey);
            }
        }
        return airdropCount;

    }

    public int readjustAirdropCount(NftMetadata metadata, Integer count) {
        int airdropCount=0;
        //利用分布式锁扣除库存
        String orderLockKey = RedisKeyFactory.getPlaceOrderLock(metadata.getNftId());
        boolean isSuccess = redisLockService.tryLock(orderLockKey, 5);
        if (isSuccess) {
            try {

                String setKey = RedisKeyFactory.getNftIdKey(metadata.getNftId());
                Set<Object> oldAirdropSets =  redisTemplate.opsForZSet().rangeByScore(setKey, -1, -1);
                if(oldAirdropSets == null){
                    throw new BusException("库存异常");
                }
                List<Object> oldAirdropList = CollUtil.newArrayList(oldAirdropSets);
                int oldMataIdAirdropCount = oldAirdropList.size();
                airdropCount = oldMataIdAirdropCount;

                if (count<oldMataIdAirdropCount) {
                    int endIndex = oldMataIdAirdropCount-count;
                    if (oldAirdropList.size()<endIndex) {
                        endIndex=oldAirdropList.size();
                    }
                    for (int i = 0; i < endIndex; i++) {
                        redisTemplate.opsForZSet().incrementScore(setKey,oldAirdropList.get(i),1);
                    }
                    airdropCount = oldAirdropList.size()-endIndex;
                } else if (count>oldMataIdAirdropCount) {
                    Set<Object> readjustAirdropSets =  redisTemplate.opsForZSet().rangeByScore(setKey, 0, 0,0,count-oldMataIdAirdropCount);
                    List<Object> readjustAirdropList = CollUtil.newArrayList(readjustAirdropSets);
                    int endIndex = count-oldMataIdAirdropCount;
                    if (readjustAirdropList.size()<endIndex) {
                        endIndex=readjustAirdropList.size();
                    }
                    for (int i = 0; i < endIndex; i++) {
                        redisTemplate.opsForZSet().incrementScore(setKey,readjustAirdropList.get(i),-1);
                    }
                    airdropCount=oldAirdropList.size()+endIndex;
                }
//                redisService.hset(RedisKeyFactory.getShowCountKey(),metadata.getMetaId()+"",metadata.getPublishCount()-airdropCount);
                metadata.setShowCount(metadata.getRestCount()-airdropCount);
                nftMetadataService.updateById(metadata);
            } finally {
                redisLockService.unlock(orderLockKey);
            }
        }
        return airdropCount;
    }

    public PageResponseListVo<OrderHistoryDetailsVO> orderHistoryDetails(BaseRequestVo request) {
        Page<OrderHistoryDetailsVO> page = new Page<>(request.getPage(),request.getNum());
        SortUtil.handlePageSort(request, page, "create_time", FoundaoConstant.ORDER_DESC, true);
        IPage<OrderHistoryDetailsVO> resultList =  baseMapper.orderHistoryDetails(page,request);
        long total = resultList.getTotal();
        return PageResponseListVo.createPageResponseListVo(resultList.getRecords(), total);
    }

    public List<UserConsumeVO> findConsume(String beginDateStr, String endDateStr) {
        return baseMapper.findConsume(beginDateStr,endDateStr);
    }
}
