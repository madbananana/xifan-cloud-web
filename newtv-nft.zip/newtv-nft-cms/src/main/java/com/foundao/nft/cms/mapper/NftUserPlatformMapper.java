package com.foundao.nft.cms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.common.model.NftUserPlatform;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface NftUserPlatformMapper extends BaseMapper<NftUserPlatform> {
    List<NftUserPlatform> selectNoIntegralUser(Page<NftUserPlatform> page);
}
