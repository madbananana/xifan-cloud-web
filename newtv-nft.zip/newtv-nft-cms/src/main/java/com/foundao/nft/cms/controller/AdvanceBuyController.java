package com.foundao.nft.cms.controller;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import com.foundao.nft.cms.service.impl.AdvanceBuyService;
import com.foundao.nft.cms.service.impl.NftSeriesClaimService;
import com.foundao.nft.cms.vo.AppointmentSettingInfoVO;
import com.foundao.nft.common.model.NftSeriesClaim;
import com.foundao.nft.common.util.RedisKeyFactory;
import com.tx.core.beans.JsonResult;
import com.tx.core.enums.errcode.ParamErrorEnum;
import com.tx.redis.service.RedisService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.concurrent.TimeUnit;

/**
 * @Package: com.foundao.nft.cms.controller
 * @ClassName: AdvanceBuyController
 * @Author: chenli
 * @CreateTime: 2022/7/20 4:22 下午
 * @Description:
 */
@RestController
@RequiredArgsConstructor
@Api(tags = "预约相关设置")
@RequestMapping("advanceBuy")
@Slf4j
@Validated
public class AdvanceBuyController {

    private final RedisService redisService;
    private final NftSeriesClaimService seriesClaimService;
    private final AdvanceBuyService advanceBuyService;

    @ApiOperation("设置预约人数增量")
    @PostMapping("/setAppointmentDelta")
    public JsonResult<Integer> setAppointmentTotalCount(Integer delta, Integer id,Integer status){
        NftSeriesClaim seriesClaim = seriesClaimService.getById(id);
        if (seriesClaim==null) {
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"不存在的系列");
        }
        if (status!=null) {
            if (status!=1 && status!=0) {
                return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"显示状态传递错误");
            }
            redisService.set(RedisKeyFactory.getSeriesShowAppointCountKey(seriesClaim.getId()),status);
        } else {
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"显示状态不能为空");
        }
        if (delta<0) {
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"预约人数增量不能小于0");
        }
        DateTime endTime = DateUtil.parse(seriesClaim.getEndTime());
        Date now = new Date();

        long expire = endTime.getTime() - now.getTime();
        redisService.set(RedisKeyFactory.getAppointmentDeltaKey(seriesClaim.getSeriesId()),delta);
        redisService.setExpire(RedisKeyFactory.getAppointmentDeltaKey(seriesClaim.getSeriesId()),expire, TimeUnit.MILLISECONDS);
        return JsonResult.success();
    }

    @ApiOperation("是否显示预约人数")
    @PostMapping("/toggleAppointStatus")
    public JsonResult<Void> toggleAppointStatus(Integer status,Integer id){
        NftSeriesClaim seriesClaim = seriesClaimService.getById(id);
        if (seriesClaim==null) {
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"不存在的系列");
        }
        if (seriesClaim.getAdvanceBuy()!=1) {
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"该系列不可预约");
        }
        if (status!=null) {
            if (status!=1 && status!=0) {
                return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"显示状态传递错误");
            }
            redisService.set(RedisKeyFactory.getSeriesShowAppointCountKey(seriesClaim.getId()),status);
        } else {
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"显示状态不能为空");
        }
        return JsonResult.success();
    }

    @ApiOperation("获取系列人数展示状态和系列预约人数")
    @PostMapping("/info")
    public JsonResult<AppointmentSettingInfoVO> info(Integer id){
        AppointmentSettingInfoVO vo = new AppointmentSettingInfoVO();
        if (id!=null) {
            NftSeriesClaim seriesClaim = seriesClaimService.getById(id);
            if (seriesClaim==null) {
                return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"不存在的系列");
            }
            if (seriesClaim.getAdvanceBuy()!=1) {
                return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"该系列不可预约");
            }
            Integer num = advanceBuyService.selectAppointmentCount(seriesClaim.getSeriesId());
            //Integer num = (Integer) redisService.get(RedisKeyFactory.getAppointmentNumKey(seriesClaim.getSeriesId()));
            Integer delta = (Integer) redisService.get(RedisKeyFactory.getAppointmentDeltaKey(seriesClaim.getSeriesId()));
            if (num==null) {
                num = 0;
            }
            if (delta == null) {
                delta = 0;
            }
            vo.setSeriesName(seriesClaim.getSeriesName());
            vo.setAppointmentTotalCount(num);
            vo.setAppointmentDelta(delta);
            // 默认展示
            vo.setShowStatus(0);
            Integer status = (Integer) redisService.get(RedisKeyFactory.getSeriesShowAppointCountKey(seriesClaim.getId()));
            if (status!=null) {
                vo.setShowStatus(status);
            }
        }
        return JsonResult.success(vo);
    }
}
