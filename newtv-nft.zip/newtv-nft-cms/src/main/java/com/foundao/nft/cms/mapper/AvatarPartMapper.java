package com.foundao.nft.cms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.foundao.nft.common.model.AvatarPart;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface AvatarPartMapper extends BaseMapper<AvatarPart> {

    List<Long> listCanLotteryAvatarIdList(@Param("specialType") Integer specialType);

    @Select("select * from avatar_part where lock_user_id=#{userId} limit 1")
    AvatarPart getUserLockAvatarPart(@Param("userId") Integer userId);

    List<Long> listSpecialAvatarPart();

    List<Long> listCanLotteryAvatarIdListBySourceFileName(String sourceFileName);
}
