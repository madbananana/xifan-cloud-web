package com.foundao.nft.cms.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.foundao.nft.common.model.CmsUser;
import com.foundao.nft.common.model.NftUser;
import com.tx.security.bean.AuthUser;
import com.tx.security.bean.JwtUserDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * @Package: com.foundao.nft.cms.service.impl
 * @ClassName: UserDetailServiceImpl
 * @Author: chenli
 * @CreateTime: 2021/12/23 12:36 下午
 * @Description:
 */
@Component
@Slf4j
@RequiredArgsConstructor
public class UserDetailServiceImpl implements UserDetailsService {
    private final CmsUserService userService;

    @Override
    public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
        AuthUser<CmsUser> authUser = new AuthUser<>();
        authUser.setUserDetails(userService.findUserByName(userName));
        authUser.setPassword(authUser.getUserDetails().getPassword());
        authUser.getUserDetails().setPassword(null);
        authUser.setUserId((long)authUser.getUserDetails().getUserId());
        authUser.setLoginName(userName);
        JwtUserDto<CmsUser> jwtUserDto = new JwtUserDto<>();
        jwtUserDto.setUser(authUser);
        return jwtUserDto;
    }
}
