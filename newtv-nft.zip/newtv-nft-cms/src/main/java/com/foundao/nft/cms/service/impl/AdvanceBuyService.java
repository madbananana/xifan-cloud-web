package com.foundao.nft.cms.service.impl;

import com.foundao.nft.cms.vo.AppointmentDetailsVO;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.cms.mapper.AdvanceBuyMapper;
import com.foundao.nft.common.model.AdvanceBuy;

/**
 * @Package: com.foundao.nft.cms.service.impl
 * @ClassName: AdvanceBuyService
 * @Author: chenli
 * @CreateTime: 2022/4/14 4:45 下午
 * @Description:
 */
@Service
public class AdvanceBuyService extends ServiceImpl<AdvanceBuyMapper, AdvanceBuy> {

    public List<AppointmentDetailsVO> stats() {
        return baseMapper.stats();
    }

    public Integer selectAppointmentCount(String seriesId) {
        return baseMapper.selectAppointmentCount(seriesId);
    }
}

