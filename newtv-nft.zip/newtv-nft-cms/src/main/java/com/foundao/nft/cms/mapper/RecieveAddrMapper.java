package com.foundao.nft.cms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.common.model.RecieveAddr;
import com.tx.core.beans.BaseRequestVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
    @Package: com.foundao.nft.cms.mapper
    @ClassName: RecieveAddrMapper
    @Author: chenli
    @CreateTime: 2022/7/12 3:55 下午
    @Description:
*/
@Mapper
public interface RecieveAddrMapper extends BaseMapper<RecieveAddr> {

    @Select("select r.*,u.mobile bindMobile from nft_recieve_addr r left join nft_user u on u.user_id=r.user_id")
    IPage<RecieveAddr> pageList(Page<RecieveAddr> page);

    @Select("select r.*,u.mobile bindMobile from nft_recieve_addr r left join nft_user u on u.user_id=r.user_id")
    List<RecieveAddr> pageListExport();
}
