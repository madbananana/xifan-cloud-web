package com.foundao.nft.cms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.common.model.ExchangeCode;
import com.foundao.nft.common.model.vo.ExchangeCodeVO;
import com.foundao.nft.common.model.vo.ExchangeRecordVO;
import com.tx.core.beans.BaseRequestVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface ExchangeCodeMapper extends BaseMapper<ExchangeCode> {
    List<ExchangeCodeVO> lsitExchangeCodeVO(@Param("seriesId") String seriesId);

    IPage<ExchangeRecordVO> pageExchangeRecordVO(Page<ExchangeRecordVO> page,@Param("request") BaseRequestVo request);

    List<ExchangeRecordVO> exchangeRecordVOExport(@Param("request") BaseRequestVo request);
}
