package com.foundao.nft.cms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.common.model.NftUser;
import com.foundao.nft.common.model.vo.UserDetailsVO;
import com.foundao.nft.common.model.vo.UserListVO;
import com.tx.core.beans.BaseRequestVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface NftUserMapper extends BaseMapper<NftUser> {
    NftUser findUserByMobile(String mobile);

    NftUser findUserByMobileNoLock(String mobile);

    IPage<UserListVO> pageUserVO(Page<UserListVO> page,@Param("request") BaseRequestVo requestVo);

    UserDetailsVO getDetails(String userId);

    int findPrimaryUserCount();

    List<NftUser> findPrimaryUser(Page<NftUser> page);

    @Select("select DISTINCT user_id from nft_record where meta_id=#{primaryMetaId} and buy_status=7")
    List<String> findUserIdByMetaIdDistinct(Integer primaryMetaId);
}
