package com.foundao.nft.cms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.common.model.Banner;
import com.foundao.nft.common.model.vo.BannerVO;
import com.tx.core.beans.BaseRequestVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

/**
    @Package: com.foundao.nft.cms.mapper
    @ClassName: BannerMapper
    @Author: chenli
    @CreateTime: 2022/6/7 11:07 上午
    @Description:
*/
@Mapper
public interface BannerMapper extends BaseMapper<Banner> {

    IPage<Banner> pageBanner(Page<Banner> page);
}