package com.foundao.nft.cms.vo;

import lombok.Data;

/**
 * @Package: com.foundao.nft.cms.vo
 * @ClassName: RecordForBlindBoxVO
 * @Author: chenli
 * @CreateTime: 2022/7/21 4:51 下午
 * @Description:
 */
@Data
public class RecordForBlindBoxVO {

    private Integer orderId;

    private Integer fee;

    private Integer count;

    private String payType;
}
