package com.foundao.nft.cms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.foundao.nft.common.model.CmsUser;
import org.apache.ibatis.annotations.Mapper;

/**
    @Package: com.foundao.nft.cms.mapper
    @ClassName: CmsUserMapper
    @Author: chenli
    @CreateTime: 2021/12/21 4:15 下午
    @Description:
*/
@Mapper
public interface CmsUserMapper extends BaseMapper<CmsUser> {
}
