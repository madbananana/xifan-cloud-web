package com.foundao.nft.cms.controller;

import cn.hutool.core.collection.CollUtil;
import com.foundao.nft.cms.service.impl.RecieveAddrService;
import com.foundao.nft.common.model.RecieveAddr;
import com.foundao.nft.common.model.vo.UserVo;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.JsonResult;
import com.tx.core.beans.PageResponseListVo;
import com.tx.core.util.excel.PoiExcelExportUtil;
import com.tx.security.bean.AuthUser;
import com.tx.security.util.SecurityUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * @Package: com.foundao.nft.cms.controller
 * @ClassName: RecieveAddrController
 * @Author: chenli
 * @CreateTime: 2022/7/12 3:55 下午
 * @Description:
 */
@RestController
@RequiredArgsConstructor
@Api(tags = "收货地址")
@RequestMapping("addr")
@Slf4j
@Validated
public class RecieveAddrController {

    private final RecieveAddrService recieveAddrService;

    @ApiOperation("收货地址列表")
    @PostMapping("list")
    @ApiOperationSupport(includeParameters = {"page","num"})
    public JsonResult<PageResponseListVo<RecieveAddr>> list(BaseRequestVo requestVo){
        PageResponseListVo<RecieveAddr> addrs = recieveAddrService.pageAddr(requestVo);
        return JsonResult.success(addrs);
    }

    @ApiOperation("收货地址列表导出")
    @PostMapping("list/export")
    public void listExport(HttpServletResponse response) throws IOException {
        String fileName = "收货地址";
        List<RecieveAddr> addrs = recieveAddrService.pageAddrExport();
        List<String> heads = CollUtil.newArrayList("用户ID","收货人","手机号","收货人手机号","省","市","区","详细地址");
        List<List<Object>> datas = new ArrayList<>();
        addrs.forEach(data -> datas.add(CollUtil.newArrayList(data.getUserId(),data.getConsignee(),data.getBindMobile(),data.getMobile(),data.getProvince(),data.getCity(),data.getArea(),data.getAddr())));
        PoiExcelExportUtil.exportExcelHTTP(fileName,heads,datas,response);
    }
}
