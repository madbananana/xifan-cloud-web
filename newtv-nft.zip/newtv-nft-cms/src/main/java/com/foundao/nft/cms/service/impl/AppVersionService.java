package com.foundao.nft.cms.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.common.constant.FoundaoConstant;
import com.foundao.nft.common.util.SortUtil;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.PageResponseListVo;
import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.cms.mapper.AppVersionMapper;
import com.foundao.nft.common.model.AppVersion;
/**
    @Package: com.foundao.nft.cms.service.impl
    @ClassName: AppVersionService
    @Author: chenli
    @CreateTime: 2022/4/29 4:09 下午
    @Description:
*/
@Service
public class AppVersionService extends ServiceImpl<AppVersionMapper, AppVersion> {

    public PageResponseListVo<AppVersion> pageAppVersion(BaseRequestVo request,String deviceType) {
        Page<AppVersion> page = new Page<>(request.getPage(),request.getNum());
        SortUtil.handlePageSort(request, page, "id", FoundaoConstant.ORDER_DESC, true);
        IPage<AppVersion> resultList = baseMapper.pageList(page,request,deviceType);
        long total = resultList.getTotal();
        return PageResponseListVo.createPageResponseListVo(resultList.getRecords(), total);

    }
}
