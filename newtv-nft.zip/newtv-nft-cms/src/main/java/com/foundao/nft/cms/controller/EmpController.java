package com.foundao.nft.cms.controller;

import com.foundao.nft.cms.service.impl.NewtvEmpService;
import com.foundao.nft.common.model.NewtvEmp;
import com.tx.core.beans.JsonResult;
import com.tx.security.annotation.AnonymousPostMapping;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@Api(tags = "员工相关")
@RequestMapping("/emp")
@Slf4j
@Validated
public class EmpController {
    private final NewtvEmpService newtvEmpService;

    @ApiOperation("保存未来电视员工")
    @AnonymousPostMapping("/saveEmp")
    public JsonResult<?> saveEmp(NewtvEmp newtvEmp){
        NewtvEmp oldEmp = newtvEmpService.getById(newtvEmp.getMobile());
        if(oldEmp == null){
            newtvEmpService.save(newtvEmp);
        }else{
            newtvEmpService.updateById(newtvEmp);
        }
        return JsonResult.success();
    }
}
