package com.foundao.nft.cms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.foundao.nft.common.model.AvatarFull;
import com.foundao.nft.common.model.AvatarPart;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface AvatarFullMapper extends BaseMapper<AvatarFull> {

    @Select("select id,url,parts,nft_meta_id,status from avatar_full where status = 0 and special_type = #{specialType}")
    List<AvatarFull> listCanLotteryAvatar(@Param("specialType") Integer specialType);


    @Select("select id from avatar_full where status = 0 and special_type = #{specialType}")
    List<Long> listCanLotteryAvatarIdList(@Param("specialType") Integer specialType);


    @Select("select * from avatar_full where avatar_part_id = #{avatarPartId}")
    List<AvatarFull> listAvatarFullByAvatarPartId(@Param("avatarPartId") Integer avatarPartId);

    @Select("select id from avatar_full where status = 0 ")
    List<Long> getWaitLotteryIds();

    @Select("select * from avatar_full where status != 0 and lock_user_id=#{userId} ")
    AvatarFull getUserLockAvatarFull(@Param("userId")Integer userId);
}
