package com.foundao.nft.cms.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.common.constant.FoundaoConstant;
import com.foundao.nft.common.model.Issuer;
import com.foundao.nft.common.model.vo.TransferHistoryDetailsVO;
import com.foundao.nft.common.model.vo.TransferRecordQueryVO;
import com.foundao.nft.common.util.SortUtil;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.PageResponseListVo;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.common.model.TransferRecord;
import com.foundao.nft.cms.mapper.TransferRecordMapper;
@Service
public class TransferRecordService extends ServiceImpl<TransferRecordMapper, TransferRecord> {

    public PageResponseListVo<TransferRecord> pageTransfer(BaseRequestVo request,Integer status) {
        Page<TransferRecord> page = new Page<>(request.getPage(),request.getNum());
        SortUtil.handlePageSort(request, page, "trans_id", FoundaoConstant.ORDER_DESC, true);
        IPage<TransferRecord> resultList = baseMapper.pageTransfer(page,status);
        long total = resultList.getTotal();
        return PageResponseListVo.createPageResponseListVo(resultList.getRecords(), total);
    }

    public List<TransferRecord> transferExport(TransferRecordQueryVO query) {
        return baseMapper.transferExport(query);
    }

    public PageResponseListVo<TransferHistoryDetailsVO> transferHistoryDetails(BaseRequestVo request) {
        Page<TransferHistoryDetailsVO> page = new Page<>(request.getPage(),request.getNum());
        SortUtil.handlePageSort(request, page, "create_time", FoundaoConstant.ORDER_DESC, true);
        IPage<TransferHistoryDetailsVO> resultList = baseMapper.transferHistoryDetails(page,request);
        long total = resultList.getTotal();
        return PageResponseListVo.createPageResponseListVo(resultList.getRecords(), total);
    }
}
