package com.foundao.nft.cms.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.foundao.nft.cms.service.impl.CategoryService;
import com.foundao.nft.common.model.Banner;
import com.foundao.nft.common.model.Category;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.JsonResult;
import com.tx.core.beans.PageResponseListVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @Package: com.foundao.nft.cms.controller
 * @ClassName: CategoryController
 * @Author: chenli
 * @CreateTime: 2022/6/23 4:17 下午
 * @Description:
 */
@RestController
@RequiredArgsConstructor
@Api(tags = "分类")
@RequestMapping("/category")
@Slf4j
@Validated
public class CategoryController {

    private final CategoryService categoryService;

    @ApiOperation("分类列表")
    @GetMapping("/list")
    public JsonResult<List<Category>> list(){
        List<Category> list = categoryService.list(new LambdaQueryWrapper<Category>().eq(Category::getStatus, 0));
        return JsonResult.success(list);
    }
}
