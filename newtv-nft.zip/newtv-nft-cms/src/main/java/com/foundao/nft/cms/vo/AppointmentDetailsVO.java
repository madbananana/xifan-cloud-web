package com.foundao.nft.cms.vo;

import lombok.Data;

/**
 * @Package: com.foundao.nft.cms.vo
 * @ClassName: AppointmentDetailsVO
 * @Author: chenli
 * @CreateTime: 2022/7/1 3:20 下午
 * @Description:
 */
@Data
public class AppointmentDetailsVO {

    public String seriesName;

    public String id;

    public Integer appointmentCount;
}
