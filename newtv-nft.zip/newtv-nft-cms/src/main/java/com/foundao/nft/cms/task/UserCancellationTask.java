package com.foundao.nft.cms.task;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import com.baomidou.mybatisplus.extension.toolkit.ChainWrappers;
import com.foundao.nft.cms.service.impl.NftUserService;
import com.foundao.nft.common.model.NftUser;
import com.foundao.nft.common.util.RedisKeyFactory;
import com.tx.redis.service.RedisService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;

/**
 * @Package: com.foundao.nft.cms.task
 * @ClassName: UserCancellationTask
 * @Author: chenli
 * @CreateTime: 2022/3/9 4:46 下午
 * @Description:
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class UserCancellationTask {

    private final NftUserService userService;
    private final RedisService redisService;

    @Scheduled(initialDelay = 5 * 1000, fixedDelay = 60 * 1000)
    public void scanTask() {
        List<NftUser> list = ChainWrappers.lambdaQueryChain(userService.getBaseMapper())
                .eq(NftUser::getStatus, 2)
                .last("limit 100")
                .list();
        Date now = new Date();
        list.forEach(user -> {
            //log.info("用户注销："+user.getUserName());
            Date date = (Date) redisService.get(RedisKeyFactory.getUserCancellationKey(user.getUserId()+""));
            if (date!=null) {
                Date closingTime = DateUtil.offsetDay(date, 7);
//                Date closingTime = DateUtil.offsetMinute(date, 1);
                if (DateUtil.compare(now,closingTime)>0) {
                    userService.executeCancellation(user);
                }
            }
        });
    }
}
