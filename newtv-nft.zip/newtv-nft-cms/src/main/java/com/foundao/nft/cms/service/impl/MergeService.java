package com.foundao.nft.cms.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.common.constant.FoundaoConstant;
import com.foundao.nft.common.model.vo.MergeVO;
import com.foundao.nft.common.util.SortUtil;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.PageResponseListVo;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.cms.mapper.MergeMapper;
import com.foundao.nft.common.model.Merge;
@Service
public class MergeService extends ServiceImpl<MergeMapper, Merge> {

    public PageResponseListVo<MergeVO> mergePage(BaseRequestVo request) {
        Page<MergeVO> page = new Page<>(request.getPage(), request.getNum());
        SortUtil.handlePageSort(request, page, "create_time", FoundaoConstant.ORDER_DESC, true);
        IPage<MergeVO> resultList = baseMapper.mergePage(page,request);
        long total = resultList.getTotal();
        return PageResponseListVo.createPageResponseListVo(resultList.getRecords(), total);
    }
}
