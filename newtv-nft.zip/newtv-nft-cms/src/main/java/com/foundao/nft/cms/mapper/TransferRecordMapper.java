package com.foundao.nft.cms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.common.model.TransferRecord;
import com.foundao.nft.common.model.vo.TransferHistoryDetailsVO;
import com.foundao.nft.common.model.vo.TransferRecordQueryVO;
import com.tx.core.beans.BaseRequestVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface TransferRecordMapper extends BaseMapper<TransferRecord> {
    IPage<TransferRecord> pageTransfer(Page<TransferRecord> page,@Param("status") Integer status);

    List<TransferRecord> transferExport(@Param("query") TransferRecordQueryVO query);

    IPage<TransferHistoryDetailsVO> transferHistoryDetails(Page<TransferHistoryDetailsVO> page,@Param("request") BaseRequestVo request);
}
