package com.foundao.nft.cms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.foundao.nft.common.model.Category;
import org.apache.ibatis.annotations.Mapper;

/**
    @Package: com.foundao.nft.cms.mapper
    @ClassName: CategoryMapper
    @Author: chenli
    @CreateTime: 2022/6/23 11:38 上午
    @Description:
*/
@Mapper
public interface CategoryMapper extends BaseMapper<Category> {
}