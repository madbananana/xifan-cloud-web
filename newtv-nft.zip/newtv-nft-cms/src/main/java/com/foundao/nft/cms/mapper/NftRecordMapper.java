package com.foundao.nft.cms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.common.model.NftRecord;
import com.foundao.nft.common.model.vo.HoldInfoResponseVO;
import com.foundao.nft.common.model.vo.NftListVO;
import com.foundao.nft.common.model.vo.UserNftInfoVO;
import com.tx.core.beans.BaseRequestVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface NftRecordMapper extends BaseMapper<NftRecord> {
    IPage<NftListVO> pageList(IPage<?> page,@Param("requestVo") BaseRequestVo requestVo);

    List<Integer> findMoreBuyPrimaryUserId(Integer metaId);

    void deleteBak(String id);

    NftRecord findFromBak(String backId);

    void updateBak(String id);

    IPage<UserNftInfoVO> userNftInfo(Page<UserNftInfoVO> page,@Param("request") BaseRequestVo request);

    List<HoldInfoResponseVO> userHoldInfo(Integer shortSeriesId);
}
