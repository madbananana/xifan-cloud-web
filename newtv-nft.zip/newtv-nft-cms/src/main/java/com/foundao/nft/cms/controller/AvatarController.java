package com.foundao.nft.cms.controller;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.IdUtil;
import cn.hutool.core.util.RandomUtil;
import cn.hutool.crypto.SecureUtil;
import cn.hutool.poi.excel.ExcelReader;
import cn.hutool.poi.excel.ExcelUtil;
import com.alibaba.fastjson.JSON;
import com.foundao.nft.cms.service.impl.*;
import com.foundao.nft.common.constant.TaskEnum;
import com.foundao.nft.common.model.*;
import com.foundao.nft.common.model.sdk.client.NftService;
import com.foundao.nft.common.model.sdk.request.NftBuyRequest;
import com.foundao.nft.common.model.sdk.response.NftTaskResultResponse;
import com.foundao.nft.common.model.sdk.response.SdkResponseBase;
import com.foundao.nft.common.model.sdk.response.TaskResponse;
import com.foundao.nft.common.model.vo.AvatarVo;
import com.foundao.nft.common.model.vo.UserVo;
import com.foundao.nft.common.properties.NftProperties;
import com.foundao.nft.common.util.NftCommonUtil;
import com.foundao.nft.common.util.RedisKeyFactory;
import com.tx.core.beans.JsonResult;
import com.tx.core.enums.errcode.ApiStatusErrorEnum;
import com.tx.core.enums.errcode.ParamErrorEnum;
import com.tx.core.exception.BusException;
import com.tx.redis.service.RedisService;
import com.tx.security.bean.AuthUser;
import com.tx.security.util.SecurityUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.concurrent.CompletableFuture;

/**
 * @ClassName AvatarController
 * @Description TODO
 * @Author xifan
 * @Date 2022/8/30 11:05
 * @Version 1.0
 */
@RequestMapping("/avatar")
@Slf4j
@RestController
@RequiredArgsConstructor
@Api(tags = "牛头相关")
public class AvatarController {

    private final NftUserPlatformService userPlatformService;
    private final NftProperties nftProperties;
    private final NftService nftService;
    private final NftTaskService taskService;
    private final AvatarServiceImpl avatarService;
    private final NftMetadataService nftMetadataService;
    private final NftSeriesClaimService seriesClaimService;
    private final NftUserService userService;
    private final NftRecordService recordService;
    private final RedisService redisService;

    @ApiOperation("抽取牛头")
    @PostMapping("/lottery")
    public JsonResult<?> lottery(String mobile){
        log.info("{} 抽取牛头",mobile);
        //校验重复提交
        Map<String,Object> hashData = new HashMap<>(3);
        hashData.put("mobile",mobile);

        String orderRepeatLimitKey = RedisKeyFactory.getOrderRepeatLimitKey(SecureUtil.md5(JSON.toJSONString(hashData)));
        if(redisService.get(orderRepeatLimitKey) != null){
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"操作过于频繁,请稍后再试");
        }
        NftUser user = userService.findUserByMobile(mobile);
        if (user==null) {
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"用户不存在");
        }
        NftUserPlatform userPlatform = userPlatformService.getById(user.getUserId());
        if (userPlatform==null) {
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"用户未实名");
        }
        redisService.set(orderRepeatLimitKey,mobile,3L);
        NftSeriesClaim seriesClaim = seriesClaimService.getById(1);
        if (seriesClaim==null ) {
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"系列还未发行");
        }
        Long fullId = avatarService.lotteryFull(user.getUserId());
        if (fullId!=null) {
            if (fullId==0L) {
                return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"库存不足");
            }
            return confirmAvatar(Math.toIntExact(fullId),user.getUserId());
        }
        return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"牛头抽取失败");
    }


    private JsonResult<?> confirmAvatar(Integer id,Integer userId){
        log.info("{} 背景选择{}",userId,id);
        AvatarFull avatarFull = avatarService.getAvatarFullById(id);
        if(avatarFull == null){
            return JsonResult.error(ApiStatusErrorEnum.INTERNAL_ERROR.getCode(),"未知的参数");
        }
        NftMetadata nftMetadata = nftMetadataService.getById(avatarFull.getNftMetaId());
        try{
            Map<String,String> res = new HashMap<>(2);
            //获取用户认证信息
            NftUserPlatform userPlatform = userPlatformService.getById(userId);
            NftBuyRequest request = new NftBuyRequest();
            request.setApplyScore(1);
            request.setNftId(nftMetadata.getNftId());
            request.setOfferCount(1);
            request.setOperateId(IdUtil.fastUUID());
            request.setPointReceiverAddr(userPlatform.getAddr());
            request.setReceiverPubKey(userPlatform.getPubkey());
            request.setPlatformPubKey(nftProperties.getPubKey());

            SdkResponseBase<TaskResponse> taskResponse = nftService.nftBuy(request,userPlatform.getPrikey());
            if (taskResponse.getRetCode()==0) {
                res.put("taskId",taskResponse.getData().getTaskId());
                CompletableFuture.runAsync(()->{
                    NftRecord nftRecord = new NftRecord();
                    nftRecord.setNftId(request.getNftId());
                    nftRecord.setActualNftId(request.getNftId());
                    nftRecord.setObtainType(1);
                    //2 执行中
                    nftRecord.setBuyStatus(2);
                    nftRecord.setMetaId(nftMetadata.getMetaId());
                    nftRecord.setOwnerTime(new Date());
                    nftRecord.setUserId(userId);
                    nftRecord.setMetaType(2);
                    nftRecord.setCreateTime(new Date());
                    nftRecord.setOwnerAddr(userPlatform.getAddr());
                    nftRecord.setTxHash("");
                    recordService.save(nftRecord);

                    Map<String,Object> extData = new HashMap<>();
                    extData.put("nftId",request.getNftId());
                    extData.put("userId",userId);
                    extData.put("metaId",nftMetadata.getMetaId());
                    extData.put("fullAvatarId",id);
                    extData.put("metaType",2);
                    extData.put("isReplenish","replenish");
                    extData.put("shortSeriesId",1);
                    extData.put("actualNftId",request.getNftId());
                    extData.put("recordId",nftRecord.getId());

                    NftTask task = new NftTask();
                    task.setStatus(2);
                    task.setType(TaskEnum.NFT_BUY.getCode());
                    task.setExtend1(request.getNftId());
                    task.setExtend2(userId+"");
                    task.setExtend3(JSON.toJSONString(extData));
                    task.setTaskId(taskResponse.getData().getTaskId());
                    taskService.save(task);
                });

            }else{
                throw new BusException("抽取发生异常");
            }
            return JsonResult.success(res);
        }catch (Exception e){
            e.printStackTrace();
            avatarService.releaseFullAvatarToLotteryPool(avatarFull,nftMetadata);
        }
        return JsonResult.error(ApiStatusErrorEnum.INTERNAL_ERROR.getCode(),"抽奖发生异常");

    }

    @ApiOperation("初始化完整牛头锁定状态")
    @PostMapping("/initFullAvatarLockStatus")
    private JsonResult<Void> initFullAvatarLockStatus(){
        List<NftRecord> list = recordService.lambdaQuery().eq(NftRecord::getMetaType, 2)
                .eq(NftRecord::getBuyStatus,7)
                .list();
        List<AvatarFull> updateList = new ArrayList<>();
        list.forEach( record -> {
            AvatarFull avatarFull = avatarService.getAvatarFullMetaId(record.getMetaId());
            avatarFull.setStatus(2);
            avatarFull.setLockUserId(record.getUserId());
            updateList.add(avatarFull);
        });
        boolean flag = avatarService.updateBatchFullAvatar(updateList);
        if (!flag) {
            throw new BusException("更新状态异常");
        }
        return JsonResult.success();
    }


    @ApiOperation("批量空投牛头")
    @PostMapping("/lotteryBatch")
    public JsonResult<Void> lotteryBatch(String dateTime){
        ExcelReader reader = ExcelUtil.getReader(IntegralController.class.getResourceAsStream("/avatarLottery"+dateTime+".xlsx"));
        List<List<Object>> readAll = reader.read(1);
        readAll.forEach( r -> {
            NftUser user = userService.findUserByMobile(r.get(0) + "");
            if (user==null) {
                log.info(r.get(0)+"用户不存在");
                return;
            }
            Integer count = recordService.lambdaQuery()
                    .eq(NftRecord::getUserId, user.getUserId())
                    .eq(NftRecord::getMetaType, 2)
                    .like(NftRecord::getNftId, "2778d7063f6ff8be22e5beb412abda24ce33d326f4fde51781c35e5d8f180b59")
                    .between(NftRecord::getCreateTime, dateTime + " 00:00:00", dateTime + " 23:59:59")
                    .count();
            if (count>0) {
                return;
            }
            NftRecord one = recordService.lambdaQuery()
                    .eq(NftRecord::getUserId, user.getUserId())
                    .eq(NftRecord::getMetaType, 2)
                    .eq(NftRecord::getBuyStatus, 2)
                    .like(NftRecord::getNftId, "2778d7063f6ff8be22e5beb412abda24ce33d326f4fde51781c35e5d8f180b59")
                    .between(NftRecord::getCreateTime, dateTime + " 00:00:00", dateTime + " 23:59:59")
                    .last("limit 1")
                    .one();
            if (one!=null) {
                NftTask task = taskService.lambdaQuery()
                        .eq(NftTask::getExtend1, one.getActualNftId())
                        .eq(NftTask::getStatus, 2)
                        .orderByDesc(NftTask::getId)
                        .last("limit 1")
                        .one();
                if (task!=null) {
                    NftTask.NftBuyExtInfo extInfo = JSON.parseObject(task.getExtend3(),NftTask.NftBuyExtInfo.class);
                    if (extInfo.getRecordId()==null) {
                        extInfo.setRecordId(Integer.valueOf(one.getId()));
                        task.setExtend3(JSON.toJSONString(extInfo));
                        taskService.updateById(task);
                    }
                }
                return;
            }
            JsonResult<?> result = lottery(r.get(0)+"");
            log.info(result.toString());
        });
        return JsonResult.success();
    }

}
