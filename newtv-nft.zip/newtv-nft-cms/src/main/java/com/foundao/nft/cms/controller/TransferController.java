package com.foundao.nft.cms.controller;

import cn.hutool.core.collection.CollUtil;
import com.foundao.nft.cms.service.impl.TransferRecordService;
import com.foundao.nft.common.model.Issuer;
import com.foundao.nft.common.model.TransferRecord;
import com.foundao.nft.common.model.vo.InviteVO;
import com.foundao.nft.common.model.vo.TransferRecordQueryVO;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.JsonResult;
import com.tx.core.beans.PageResponseListVo;
import com.tx.core.util.excel.PoiExcelExportUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName TransferController
 * @Description TODO
 * @Author xifan
 * @Date 2022/9/7 17:32
 * @Version 1.0
 */
@Slf4j
@RestController
@RequestMapping("transfer")
@RequiredArgsConstructor
@Api(tags = "转赠相关")
public class TransferController {

    private final TransferRecordService transferRecordService;

    @ApiOperation("转赠列表")
    @PostMapping("/page")
    @ApiOperationSupport(includeParameters = {"page","num","status"})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "status",required = true,value = "转赠状态 0：转赠中 1：转赠成功 2：转赠失败")
    })
    public JsonResult<PageResponseListVo<TransferRecord>> page(BaseRequestVo requestVo, Integer status){
        PageResponseListVo<TransferRecord> page = transferRecordService.pageTransfer(requestVo,status);
        return JsonResult.success(page);
    }

    @ApiOperation("转赠记录导出")
    @PostMapping("/export")
    @ApiOperationSupport(includeParameters = {"status"})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "status",required = true,value = "转赠状态 0：转赠中 1：转赠成功 2：转赠失败")
    })
    public void export(@RequestBody TransferRecordQueryVO query, HttpServletResponse response) throws IOException {
        List<TransferRecord> list = transferRecordService.transferExport(query);
        String fileName = "转赠记录";
        List<String> heads = CollUtil.newArrayList("转出用户ID","手机号","转赠藏品","受赠用户ID","手机号","完成时间");
        List<List<Object>> datas = new ArrayList<>();
        list.forEach(data -> datas.add(CollUtil.newArrayList(data.getGiveUserId(),data.getGiveMobile(),data.getName(),data.getReceiveUserId(),data.getReceiveMobile(),data.getUpdateTime())));
        PoiExcelExportUtil.exportExcelHTTP(fileName,heads,datas,response);
    }
}
