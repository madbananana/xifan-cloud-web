package com.foundao.nft.cms.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.PageResponseListVo;
import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.cms.mapper.GoodsMapper;
import com.foundao.nft.common.model.Goods;

/**
 * @Package: com.foundao.nft.cms.service.impl
 * @ClassName: GoodsService
 * @Author: chenli
 * @CreateTime: 2022/2/21 4:11 下午
 * @Description:
 */
@Service
public class GoodsService extends ServiceImpl<GoodsMapper, Goods> {

    public PageResponseListVo<Goods> pageList(BaseRequestVo request) {
        Page<Goods> page = new Page<>(request.getPage(), request.getNum());
        IPage<Goods> resultList = baseMapper.pageList(page);
        long total = resultList.getTotal();
        return PageResponseListVo.createPageResponseListVo(resultList.getRecords(), total);
    }
}

