package com.foundao.nft.cms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.cms.vo.RecordForBlindBoxVO;
import com.foundao.nft.common.model.NftOrder;
import com.foundao.nft.common.model.vo.OrderHistoryDetailsVO;
import com.foundao.nft.common.model.vo.PurchaseHistory;
import com.foundao.nft.common.model.vo.TradeCapitalInfoVO;
import com.foundao.nft.common.model.vo.UserConsumeVO;
import com.tx.core.beans.BaseRequestVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

/**
    @Package: com.foundao.nft.cms.mapper
    @ClassName: NftOrderMapper
    @Author: chenli
    @CreateTime: 2022/3/7 3:20 下午
    @Description:
*/
@Mapper
public interface NftOrderMapper extends BaseMapper<NftOrder> {
    List<PurchaseHistory> getPurchaseHistory(String userId);

    IPage<TradeCapitalInfoVO> tradeList(Page<TradeCapitalInfoVO> page,@Param("request") BaseRequestVo requestVo);

    List<String> getAborigines(String metaId);

    RecordForBlindBoxVO selectRecordForBlindBox(String actualNftId);

    IPage<OrderHistoryDetailsVO> orderHistoryDetails(Page<OrderHistoryDetailsVO> page,@Param("request") BaseRequestVo request);

    List<UserConsumeVO> findConsume(@Param("startDate")String startDate, @Param("endDate")String endDate);
}