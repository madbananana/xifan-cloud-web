package com.foundao.nft.cms.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.conditions.query.QueryChainWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.common.constant.FoundaoConstant;
import com.foundao.nft.common.constant.IntegralTypeEnum;
import com.foundao.nft.common.model.IntegralRecord;
import com.foundao.nft.common.model.vo.InviteVO;
import com.foundao.nft.common.util.SortUtil;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.PageResponseListVo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.cms.mapper.InviteMapper;
import com.foundao.nft.common.model.Invite;
import org.springframework.util.CollectionUtils;

@Service
@RequiredArgsConstructor
public class InviteService extends ServiceImpl<InviteMapper, Invite> {

    private final IntegralRecordService integralRecordService;

    public PageResponseListVo<InviteVO> pageInviteVO(BaseRequestVo request) {
        Page<InviteVO> page = new Page<>(request.getPage(),request.getNum());
        SortUtil.handlePageSort(request, page, "reg_time", FoundaoConstant.ORDER_DESC, true);
        IPage<InviteVO> resultList = baseMapper.pageInviteVO(page,request);
        resultList.getRecords().forEach(vo->{
            vo.setBonusIntegral(0);
            vo.setInviteBonusIntegral(0);
            QueryWrapper<IntegralRecord> wrapper = new QueryWrapper<>();
            wrapper.select("IFNULL(integral, 0) totalIntegral")
                    .eq("user_id", vo.getUserId())
                    .eq("source_id", vo.getUserId())
                    .eq("source_type", IntegralTypeEnum.REAL_NAME_AUTH.getType());
            Map<String, Object> userMap = integralRecordService.getMap(wrapper);
            if (!CollectionUtils.isEmpty(userMap)) {
                vo.setBonusIntegral(Integer.parseInt(String.valueOf(userMap.get("totalIntegral"))));
            }
            QueryWrapper<IntegralRecord> inviteWrapper = new QueryWrapper<>();
            inviteWrapper.select("IFNULL(integral, 0) totalIntegral")
                    .eq("user_id", vo.getInviteUserId())
                    .eq("source_id",vo.getUserId())
                    .in("source_type", IntegralTypeEnum.INVITE.getType(),IntegralTypeEnum.INVITE_REAL_NAME_AUTH.getType());
            Map<String, Object> inviteUserMap = integralRecordService.getMap(inviteWrapper);
            if (!CollectionUtils.isEmpty(inviteUserMap)) {
                vo.setInviteBonusIntegral(Integer.parseInt(String.valueOf(inviteUserMap.get("totalIntegral"))));
            }
        });
        long total = resultList.getTotal();
        return PageResponseListVo.createPageResponseListVo(resultList.getRecords(), total);
    }

    public List<InviteVO> pageInviteVOExport(String keyword) {
        List<InviteVO> resultList = baseMapper.pageInviteVOExport(keyword);
        resultList.forEach(vo->{
            vo.setBonusIntegral(0);
            vo.setInviteBonusIntegral(0);
            QueryWrapper<IntegralRecord> wrapper = new QueryWrapper<>();
            wrapper.select("IFNULL(integral, 0) totalIntegral")
                    .eq("user_id", vo.getUserId())
                    .in("source_type", IntegralTypeEnum.REAL_NAME_AUTH.getType());
            Map<String, Object> userMap = integralRecordService.getMap(wrapper);
            if (!CollectionUtils.isEmpty(userMap)) {
                vo.setBonusIntegral(Integer.parseInt(String.valueOf(userMap.get("totalIntegral"))));
            }
            QueryWrapper<IntegralRecord> inviteWrapper = new QueryWrapper<>();
            inviteWrapper.select("IFNULL(integral, 0) totalIntegral")
                    .eq("user_id", vo.getInviteUserId())
                    .eq("source_id",vo.getUserId())
                    .in("source_type", IntegralTypeEnum.INVITE.getType(),IntegralTypeEnum.INVITE_REAL_NAME_AUTH.getType());
            Map<String, Object> inviteUserMap = integralRecordService.getMap(inviteWrapper);
            if (!CollectionUtils.isEmpty(inviteUserMap)) {
                vo.setInviteBonusIntegral(Integer.parseInt(String.valueOf(inviteUserMap.get("totalIntegral"))));
            }
        });
        return resultList;
    }
}
