package com.foundao.nft.cms.service.impl;

import com.baomidou.mybatisplus.extension.toolkit.ChainWrappers;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.cms.mapper.CmsUserMapper;
import com.foundao.nft.common.model.CmsUser;
/**
    @Package: com.foundao.nft.cms.service.impl
    @ClassName: CmsUserService
    @Author: chenli
    @CreateTime: 2021/12/21 4:15 下午
    @Description:
*/
@Service
public class CmsUserService extends ServiceImpl<CmsUserMapper, CmsUser> {

    public CmsUser findUserByName(String userName) {
        return ChainWrappers.lambdaQueryChain(baseMapper)
                .eq(CmsUser::getUsername,userName)
                .one();
    }
}
