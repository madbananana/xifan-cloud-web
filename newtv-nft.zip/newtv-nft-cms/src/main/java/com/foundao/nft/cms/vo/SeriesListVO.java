package com.foundao.nft.cms.vo;

import com.foundao.nft.common.model.NftSeriesClaim;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SeriesListVO extends NftSeriesClaim {

    @ApiModelProperty(value="系列声明人姓名")
    private String operatorName;

    @ApiModelProperty(value="该系列下拥有的作品数")
    private Integer nftCount;

    @ApiModelProperty(value="预约总人数")
    private Integer appointmentTotalCount;

    @ApiModelProperty(value="预约人数增量")
    private Integer appointmentDelta;

    /**
     * 是否展示系列预约人数 （0展示1不展示）
     */
    private Integer showAppointmentStatus;
}
