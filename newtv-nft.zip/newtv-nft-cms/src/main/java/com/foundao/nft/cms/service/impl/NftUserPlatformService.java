package com.foundao.nft.cms.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.cms.mapper.NftUserPlatformMapper;
import com.foundao.nft.common.model.NftUserPlatform;

/**
 * @Package: com.foundao.nft.cms.service.impl
 * @ClassName: NftUserPlatformService
 * @Author: chenli
 * @CreateTime: 2021/12/21 3:24 下午
 * @Description:
 */
@Service
public class NftUserPlatformService extends ServiceImpl<NftUserPlatformMapper, NftUserPlatform> {

    public NftUserPlatform findByAddr(String ownerAddr) {
        return baseMapper.selectOne(new LambdaQueryWrapper<NftUserPlatform>().eq(NftUserPlatform::getAddr, ownerAddr).last("limit 1"));
    }

    public List<NftUserPlatform> selectNoIntegralUser(Page<NftUserPlatform> page) {
        return baseMapper.selectNoIntegralUser(page);
    }
}

