package com.foundao.nft.cms.service.impl;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.common.constant.FoundaoConstant;
import com.foundao.nft.common.model.Merge;
import com.foundao.nft.common.model.NftMetadata;
import com.foundao.nft.common.model.NftSeriesClaim;
import com.foundao.nft.common.model.Recipe;
import com.foundao.nft.common.model.RecipeMaterial;
import com.foundao.nft.common.model.vo.RecipeCollectionVO;
import com.foundao.nft.common.util.SortUtil;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.PageResponseListVo;
import com.tx.core.exception.BusException;
import io.swagger.annotations.ApiModelProperty;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.cms.mapper.RecipeCollectionMapper;
import com.foundao.nft.common.model.RecipeCollection;
import org.springframework.util.CollectionUtils;

@Service
@RequiredArgsConstructor
public class RecipeCollectionService extends ServiceImpl<RecipeCollectionMapper, RecipeCollection> {

    private final RecipeService recipeService;
    private final NftMetadataService metadataService;
    private final RecipeMaterialService materialService;
    private final NftSeriesClaimService seriesClaimService;
    private final MergeService mergeService;

    public PageResponseListVo<RecipeCollection> collectionPage(BaseRequestVo request) {
        Page<RecipeCollection> page = new Page<>(request.getPage(), request.getNum());
        SortUtil.handlePageSort(request, page, "create_time", FoundaoConstant.ORDER_DESC, true);
        IPage<RecipeCollection> resultList = baseMapper.collectionPage(page);
        resultList.getRecords().forEach(collection -> {
            List<RecipeMaterial> list = materialService.lambdaQuery()
                    .eq(RecipeMaterial::getRecipeId, collection.getRecipeId())
                    .list();
            collection.setMaterials(list);
            Integer count = mergeService.lambdaQuery()
                    .eq(Merge::getCollectionId, collection.getCollectionId())
                    .eq(Merge::getMetaId,collection.getMetaId())
                    .eq(Merge::getStatus,1)
                    .eq(Merge::getRecipeId,collection.getRecipeId())
                    .count();
            collection.setMergeCount(count);
        });
        long total = resultList.getTotal();
        return PageResponseListVo.createPageResponseListVo(resultList.getRecords(), total);
    }

    public void saveCollection(RecipeCollectionVO vo) {
        RecipeCollection newCollection = new RecipeCollection();
        NftMetadata metadata = null;

        if (vo.getCollectionId() != null) {
            newCollection.setCollectionId(vo.getCollectionId());
            if (!CollectionUtils.isEmpty(vo.getImageDesc())) {
                newCollection.setImageDesc(JSON.toJSONString(vo.getImageDesc()));
            }
            newCollection.setDisplayUrl(vo.getDisplayUrl());
            newCollection.setCollectionName(vo.getCollectionName());
            if (StrUtil.isNotBlank(vo.getBeginTime()) && StrUtil.isNotBlank(vo.getEndTime())) {
                DateTime beginTime = DateUtil.parseDateTime(vo.getBeginTime());
                DateTime endTime = DateUtil.parseDateTime(vo.getEndTime());
                if (DateUtil.compare(beginTime, endTime) > 0) {
                    throw new BusException("开始必须小于结束时间");
                }
                newCollection.setBeginTime(vo.getBeginTime());
                newCollection.setEndTime(vo.getEndTime());

            }
            updateById(newCollection);
        } else {

            String now = DateUtil.now();
            Integer count = this.lambdaQuery()
                    .eq(RecipeCollection::getMetaId, vo.getMetaId())
                    .lt(RecipeCollection::getBeginTime,now)
                    .gt(RecipeCollection::getEndTime,now)
                    .count();
            if (count > 0) {
                throw new BusException("存在未结束的活动绑定该藏品");
            }

            if (CollectionUtils.isEmpty(vo.getMaterials())) {
                throw new BusException("合成原料为必填项");
            }
            vo.getMaterials().forEach(material -> {
                NftMetadata byMetaId = metadataService.getByMetaId(material.getMetaId() + "");
                if (byMetaId == null) {
                    throw new BusException("藏品不存在");
                }
                if (!Objects.equals(byMetaId.getShortSeriesId(), material.getSeriesId())) {
                    throw new BusException("藏品所属系列填写错误");
                }
                if (material.getCount()==null || material.getCount() < 1) {
                    throw new BusException("合成所需份数填写错误");
                }
            });

            if (vo.getMetaId() == null) {
                throw new BusException("合成藏品ID不能为空");
            }

            metadata = metadataService.getById(vo.getMetaId());

            if (metadata == null) {
                throw new BusException("请选择合成藏品");
            }

            if (!Objects.equals(metadata.getShortSeriesId(),vo.getShortSeriesId())) {
                throw new BusException("系列id和所选藏品id不一致");
            }

            if (metadata.getShowCount()<=0) {
                throw new BusException("藏品库存不足");
            }

            if (vo.getTotalMergeCount()==null || vo.getTotalMergeCount()<=0) {
                throw new BusException("可合成份数填写错误");
            }

            if (metadata.getShowCount()<vo.getTotalMergeCount()) {
                throw new BusException("可合成份数不能大于藏于的剩余份数");
            }

            newCollection.setTotalMergeCount(vo.getTotalMergeCount());
            newCollection.setRestMergeCount(vo.getTotalMergeCount());
            NftSeriesClaim seriesClaim = seriesClaimService.getById(metadata.getShortSeriesId());
            if (seriesClaim.getMetaType()==3) {
                throw new BusException("盲盒中的藏品不能作为合成结果");
            }

            newCollection.setShortSeriesId(metadata.getShortSeriesId());

            if (metadata.getTaskStatus() != 7) {
                throw new BusException("该藏品未发行成功");
            }

            newCollection.setName(metadata.getName());
            newCollection.setMetaId(metadata.getMetaId());
            Recipe recipe = recipeService.creatRecipe(metadata, vo.getMaterials());

            if (StrUtil.isBlank(vo.getBeginTime()) || StrUtil.isBlank(vo.getEndTime())) {
                throw new BusException("开始和结束时间不能为空");
            }
            DateTime beginTime = DateUtil.parseDateTime(vo.getBeginTime());
            DateTime endTime = DateUtil.parseDateTime(vo.getEndTime());
            if (DateUtil.compare(beginTime, endTime) > 0) {
                throw new BusException("开始必须小于结束时间");
            }
            newCollection.setBeginTime(vo.getBeginTime());
            newCollection.setEndTime(vo.getEndTime());

            if (CollectionUtils.isEmpty(vo.getImageDesc())) {
                throw new BusException("活动描述不能为空");
            }
            if (StrUtil.isBlank(vo.getCollectionName())) {
                throw new BusException("活动名称不能为空");
            }

            newCollection.setMetaId(metadata.getMetaId());
            newCollection.setName(metadata.getName());
            newCollection.setDisplayUrl(vo.getDisplayUrl());
            newCollection.setStatus(0);
            newCollection.setImageDesc(JSON.toJSONString(vo.getImageDesc()));
            newCollection.setCollectionName(vo.getCollectionName());
            newCollection.setRecipeId(recipe.getRecipeId());
            save(newCollection);
        }
    }
}
