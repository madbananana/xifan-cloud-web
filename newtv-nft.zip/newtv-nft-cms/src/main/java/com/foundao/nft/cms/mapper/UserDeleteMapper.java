package com.foundao.nft.cms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.foundao.nft.common.model.UserDelete;
import org.apache.ibatis.annotations.Mapper;

/**
    @Package: com.foundao.nft.cms.mapper
    @ClassName: UserDeleteMapper
    @Author: chenli
    @CreateTime: 2022/4/14 6:25 下午
    @Description:
*/
@Mapper
public interface UserDeleteMapper extends BaseMapper<UserDelete> {
}