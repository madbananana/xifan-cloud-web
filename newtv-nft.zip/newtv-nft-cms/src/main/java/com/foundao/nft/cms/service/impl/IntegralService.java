package com.foundao.nft.cms.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.cms.vo.SystemIntegralInfoPageResponseListVo;
import com.foundao.nft.common.constant.FoundaoConstant;
import com.foundao.nft.common.constant.IntegralTypeEnum;
import com.foundao.nft.common.model.IntegralRecord;
import com.foundao.nft.common.model.vo.IntegralStatsVO;
import com.foundao.nft.common.model.vo.UserIntegralDetailsVO;
import com.foundao.nft.common.util.SortUtil;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.PageResponseListVo;
import com.tx.redis.service.RedisService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.cms.mapper.IntegralMapper;
import com.foundao.nft.common.model.Integral;

@Service
@RequiredArgsConstructor
@Slf4j
public class IntegralService extends ServiceImpl<IntegralMapper, Integral> {

    private final IntegralRecordService integralRecordService;

    public SystemIntegralInfoPageResponseListVo<Integral> pageIntegral(BaseRequestVo request) {
        Page<Integral> page = new Page<>(request.getPage(),request.getNum());
        SortUtil.handlePageSort(request, page, "user_id", FoundaoConstant.ORDER_DESC, true);
        IPage<Integral> resultList = baseMapper.pageIntegral(page,request);
        long total = resultList.getTotal();
        return SystemIntegralInfoPageResponseListVo.createPageResponseListVo(resultList.getRecords(), total);
    }

    public UserIntegralDetailsVO personIntegralStats(Integer userId) {
        return baseMapper.personIntegralStats(userId);
    }

    /**
     * 给用户增加或减少积分
     * @param userId 用户
     * @param sourceId 资源id
     * @param sourceType 类型
     */
    public void integralOperation(Integer userId,String sourceId,String sourceType,String symbol,Integer count,String remark,String txTime){
        if (userId!=null) {
            Integral integralModel = getById(userId);
            if (integralModel==null) {
                integralModel = new Integral();
                integralModel.setUserId(userId);
                integralModel.setFrozenIntegral(0);
                integralModel.setUsableIntegral(0);
            }
            if (IntegralTypeEnum.BUY_NFT.getType().equals(sourceType)) {
                if (integralModel.getFrozenIntegral()>=count) {
                    integralModel.setFrozenIntegral(integralModel.getFrozenIntegral()-count);
                } else {
                    log.error("{}积分购买NFT，冻结积分不足",userId);
                }
            } else {
                if (count!=null && count>0) {
                    if ("in".equals(symbol)) {
                        integralModel.setUsableIntegral(integralModel.getUsableIntegral()+count);
                    }else if ("out".equals(symbol)) {
                        integralModel.setUsableIntegral(integralModel.getUsableIntegral()-count);
                    }
                }
            }
            if (count!=null) {
                IntegralRecord integralRecord = new IntegralRecord();
                integralRecord.setUserId(userId);
                integralRecord.setSourceId(sourceId);
                integralRecord.setSourceType(sourceType);
                integralRecord.setSymbol(symbol);
                integralRecord.setIntegral(count);
                integralRecord.setRemark(remark);
                integralRecord.setRestUsableIntegral(integralModel.getUsableIntegral());
                integralRecord.setCreateTime(txTime);
                integralRecordService.save(integralRecord);
            }
            saveOrUpdate(integralModel);
        }

    }

    public PageResponseListVo<IntegralStatsVO> integralStats(BaseRequestVo request) {
        Page<IntegralStatsVO> page = new Page<>(request.getPage(),request.getNum());
        SortUtil.handlePageSort(request, page, "user_id", FoundaoConstant.ORDER_DESC, true);
        IPage<IntegralStatsVO> resultList = baseMapper.integralStats(page,request);
        long total = resultList.getTotal();
        return SystemIntegralInfoPageResponseListVo.createPageResponseListVo(resultList.getRecords(), total);
    }
}
