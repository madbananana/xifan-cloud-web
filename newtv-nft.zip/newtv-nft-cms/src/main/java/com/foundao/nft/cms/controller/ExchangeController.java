package com.foundao.nft.cms.controller;

import cn.hutool.core.collection.CollUtil;
import com.foundao.nft.cms.service.impl.ExchangeCodeService;
import com.foundao.nft.cms.service.impl.NftSeriesClaimService;
import com.foundao.nft.cms.vo.ExchangeExportVO;
import com.foundao.nft.common.model.NftSeriesClaim;
import com.foundao.nft.common.model.vo.ExchangeCodeVO;
import com.foundao.nft.common.model.vo.ExchangeRecordVO;
import com.foundao.nft.common.model.vo.InviteVO;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.JsonResult;
import com.tx.core.beans.PageResponseListVo;
import com.tx.core.util.excel.PoiExcelExportUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName ExchangeController
 * @Description TODO
 * @Author xifan
 * @Date 2022/9/7 9:58
 * @Version 1.0
 */
@RestController
@RequiredArgsConstructor
@Api(tags = "兑换码管理")
@RequestMapping("exchange")
@Slf4j
@Validated
public class ExchangeController {

    private final ExchangeCodeService exchangeCodeService;
    private final NftSeriesClaimService seriesClaimService;

    @ApiOperation("导出系列兑换码")
    @PostMapping("/series/export")
    public void pageExchangeCodeVO(@RequestBody ExchangeExportVO vo, HttpServletResponse response) throws IOException {
        NftSeriesClaim seriesClaim = seriesClaimService.getById(vo.getId());
        String fileName = seriesClaim.getSeriesName() +"兑换码";
        List<ExchangeCodeVO> list = exchangeCodeService.lsitExchangeCodeVO(vo.getId()+"");
        List<String> heads = CollUtil.newArrayList("系列名称","藏品名称","兑换码","是否使用");
        List<List<Object>> datas = new ArrayList<>();
        list.forEach(data -> datas.add(CollUtil.newArrayList(data.getSeriesName(),data.getName(),data.getCode(),data.getStatus()==1?"已使用":"未使用")));
        PoiExcelExportUtil.exportExcelHTTP(fileName,heads,datas,response);
    }

    @ApiOperation("兑换记录列表导出")
    @PostMapping("/record/export")
    @ApiOperationSupport(includeParameters = {"keyword"})
    public void exchangeRecordExport(@RequestBody BaseRequestVo request,HttpServletResponse response) throws IOException {
        List<ExchangeRecordVO> list = exchangeCodeService.exchangeRecordVOExport(request);
        String fileName = "兑换记录";
        List<String> heads = CollUtil.newArrayList("用户ID","手机号","兑换藏品","完成时间");
        List<List<Object>> datas = new ArrayList<>();
        list.forEach(data -> datas.add(CollUtil.newArrayList(data.getUserId(),data.getMobile(),data.getName(),data.getExchangeTime())));
        PoiExcelExportUtil.exportExcelHTTP(fileName,heads,datas,response);
    }

    @ApiOperation("兑换记录列表")
    @PostMapping("/record")
    @ApiOperationSupport(includeParameters = {"page","num","keyword"})
    public JsonResult<PageResponseListVo<ExchangeRecordVO>> page(BaseRequestVo request){
        PageResponseListVo<ExchangeRecordVO> page = exchangeCodeService.pageExchangeRecordVO(request);
        return JsonResult.success(page);
    }

}
