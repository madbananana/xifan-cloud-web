package com.foundao.nft.cms.vo;

import com.foundao.nft.common.model.vo.UserIntegralDetailsVO;
import com.tx.core.beans.PageResponseListVo;
import lombok.Data;

import java.util.List;

/**
 * @ClassName IntegralPageResponseListVo
 * @Description TODO
 * @Author xifan
 * @Date 2022/9/1 11:00
 * @Version 1.0
 */
@Data
public class IntegralPageResponseListVo <T> extends PageResponseListVo<T> {

    private UserIntegralDetailsVO userInfo;

    public IntegralPageResponseListVo(Long total, List<T> list) {
        super.setTotal(total);
        this.setList(list);
    }

    public static <T> IntegralPageResponseListVo<T> createPageResponseListVo(List<T> list, Long total) {
        return new IntegralPageResponseListVo<>(total, list);
    }
}
