package com.foundao.nft.cms.configure;

import com.foundao.nft.common.properties.CustomProperties;
import com.foundao.nft.common.properties.MsgProperties;
import com.foundao.nft.common.properties.NftProperties;
import com.foundao.nft.common.util.NftCommonUtil;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

/**
 * @Package: com.foundao.nft.cms.configure
 * @ClassName: WebConfig
 * @Author: chenli
 * @CreateTime: 2021/12/9 3:39 下午
 * @Description:
 */
@Configuration
@ComponentScan(basePackages = {"com.foundao.nft.common.model.sdk.client"})
public class WebConfig {

    @Bean
    public RestTemplate restTemplate(){
        return new RestTemplate();
    }


    @Bean
    @ConfigurationProperties(prefix = "nft")
    public NftProperties nftProperties() {
        return new NftProperties();
    }

    @Bean
    @ConfigurationProperties(prefix = "foundao.custom")
    public CustomProperties customProperties() {
        return new CustomProperties();
    }

    @Bean
    public NftCommonUtil nftCommonUtil(){
        return new NftCommonUtil(restTemplate(),nftProperties());
    }

    @Bean
    public FilterRegistrationBean<CorsFilter> corsFilter() {
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowCredentials(true);
        config.addAllowedOrigin("*");
        config.addAllowedHeader("*");
        config.addAllowedMethod("*");
        source.registerCorsConfiguration("/**", config);
        FilterRegistrationBean<CorsFilter> filterRegistrationBean = new FilterRegistrationBean<>(new CorsFilter(source));
        // 代表这个过滤器在众多过滤器中级别最高，也就是过滤的时候最先执行
        filterRegistrationBean.setOrder(Ordered.HIGHEST_PRECEDENCE);
        return filterRegistrationBean;
    }

    @Bean
    @ConfigurationProperties(prefix = "newtv.msg")
    public MsgProperties msgProperties(){
        return new MsgProperties();
    }

}
