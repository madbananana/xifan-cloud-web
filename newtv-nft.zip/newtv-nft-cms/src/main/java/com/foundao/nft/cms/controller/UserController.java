package com.foundao.nft.cms.controller;

import cn.hutool.core.util.StrUtil;
import cn.hutool.dfa.SensitiveUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.foundao.nft.cms.service.impl.NftUserService;
import com.foundao.nft.cms.service.impl.UserDetailServiceImpl;
import com.foundao.nft.cms.vo.PageUserResponseListVo;
import com.foundao.nft.common.model.CmsUser;
import com.foundao.nft.common.model.NftUser;
import com.foundao.nft.common.model.vo.CmsUserVO;
import com.foundao.nft.common.model.vo.UserDetailsVO;
import com.foundao.nft.common.model.vo.UserListVO;
import com.foundao.nft.common.model.vo.UserVo;
import com.foundao.nft.common.util.RedisKeyFactory;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.JsonResult;
import com.tx.core.beans.PageResponseListVo;
import com.tx.core.enums.errcode.ApiStatusErrorEnum;
import com.tx.redis.service.RedisService;
import com.tx.security.annotation.AnonymousPostMapping;
import com.tx.security.bean.AuthUser;
import com.tx.security.bean.JwtUserDto;
import com.tx.security.service.OnlineUserService;
import com.tx.security.util.SecurityUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.validator.constraints.Length;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.spring.web.json.Json;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * @Package: com.foundao.nft.cms.controller
 * @ClassName: LoginController
 * @Author: chenli
 * @CreateTime: 2021/12/23 1:03 下午
 * @Description:
 */
@Slf4j
@RestController
@RequestMapping("user")
@RequiredArgsConstructor
@Api(tags = "用户相关接口")
@Validated
public class UserController {

    private final AuthenticationManagerBuilder authenticationManagerBuilder;
    private final OnlineUserService onlineUserService;
    private final UserDetailServiceImpl userDetailService;
    private final NftUserService userService;
    private final RedisService redisService;

    @ApiOperation("登录授权")
    @AnonymousPostMapping(value = "login")
    public JsonResult<JwtUserDto<CmsUser>> login(@Validated @RequestBody CmsUserVO user, HttpServletRequest request) throws Exception {

        UsernamePasswordAuthenticationToken authenticationToken =
                new UsernamePasswordAuthenticationToken(user.getUsername(), user.getPassword());
        Authentication authentication = authenticationManagerBuilder.getObject().authenticate(authenticationToken);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        JwtUserDto<CmsUser> jwtUserDto = (JwtUserDto<CmsUser>) userDetailService.loadUserByUsername(user.getUsername());
        onlineUserService.createTokenAndSave(jwtUserDto);
        return JsonResult.success(jwtUserDto);
    }

    @ApiOperation("冻结或解冻用户")
    @PostMapping("/offon")
    public JsonResult<Void> userLock(@RequestParam String userId){
        NftUser user = userService.getById(userId);
        if (user!=null) {
            user.setStatus(user.getStatus()==1?0:1);
            userService.updateById(user);
            onlineUserService.kickOut("online-token-api", Long.valueOf(user.getUserId()));
            return JsonResult.success();
        } else {
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"用户不存在");
        }
    }

    @ApiOperation("翻转用户修改信息权限")
    @PostMapping("/toggleModifyInhibit")
    public JsonResult<NftUser> offModify(@RequestParam String userId){
        NftUser user = userService.getById(userId);
        if (user!=null) {
            if (user.getModifyInhibit()==null) {
                user.setModifyInhibit(0);
            }
            user.setModifyInhibit(1-user.getModifyInhibit());
            userService.updateById(user);
            return JsonResult.success(user);
        } else {
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"用户不存在");
        }
    }

    @ApiOperation("用户列表")
    @PostMapping("/list")
    public JsonResult<PageUserResponseListVo<UserListVO>> userList(BaseRequestVo requestVo){
        PageResponseListVo<UserListVO> userLists = userService.pageUserVO(requestVo);
        PageUserResponseListVo<UserListVO> vo = new PageUserResponseListVo<>(userLists.getTotal(),userLists.getList());
        Integer flag = (Integer) redisService.get(RedisKeyFactory.getGlobalInhibitKey());
        if (flag!=null) {
            vo.setGlobalInhibit(flag);
        } else {
            vo.setGlobalInhibit(0);
        }
        return JsonResult.success(vo);
    }

    @ApiOperation("用户详情")
    @PostMapping("/details")
    public JsonResult<UserDetailsVO> userDetails(@RequestParam String userId){
        UserDetailsVO details = userService.getDetails(userId);
        return JsonResult.success(details);
    }

    @ApiOperation("修改用户信息")
    @PostMapping("userInfo")
    @ApiOperationSupport(includeParameters = {"nickname","avatar","userId"})
    public JsonResult<Void> userInfo(@Validated @Length(max = 10,message = "昵称长度不能超过10个字符") String nickname, String avatar, String userId){
        log.info("cms修改用户信息，昵称{},头像{}",nickname,avatar);
        if(StrUtil.isBlank(nickname) && StrUtil.isBlank(avatar)){
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"昵称和头像不能为空");
        }
        NftUser user = userService.getById(userId);
        if (user==null) {
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"用户不存在");
        }

        JwtUserDto<UserVo> one = onlineUserService.getOne("online-token-api", Long.valueOf(userId));
        UserVo userDetails = null;
        if (one!=null) {
            userDetails = one.getUser().getUserDetails();
        }

        if (StrUtil.isNotBlank(nickname)) {
            boolean flag = SensitiveUtil.containsSensitive(nickname);
            if (flag) {
                return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"昵称包含敏感词");
            }
            if (userDetails != null) {
                userDetails.setNickName(nickname);
            }
            user.setNickName(nickname);
        }

        if (StrUtil.isNotBlank(avatar)) {
            if (userDetails != null) {
                userDetails.setAvatar(avatar);
            }
            user.setAvatar(avatar);
        }

        userService.updateById(user);
        if (userDetails != null) {
            onlineUserService.updateUser("online-token-api",one.getUser());
        }
        return JsonResult.success();
    }

    @ApiOperation("更新所有用户信息")
    @PostMapping("updateApiUser")
    public JsonResult<Void> updateApiUser(){
        int count = userService.count();
        int size = 100;
        int page = count/size +1;
        CompletableFuture.runAsync(() -> {
            for (int i=0;i<page;i++) {
                List<NftUser> list = userService.list(new LambdaQueryWrapper<NftUser>()
                        .last("limit " + i * size + "," + size));

                list.forEach( user -> {
                    JwtUserDto<UserVo> one = onlineUserService.getOne("online-token-api", Long.valueOf(user.getUserId()));
                    UserVo userDetails = null;
                    if (one!=null) {
                        userDetails = one.getUser().getUserDetails();
                        userDetails.setNickName(user.getNickName());
                        onlineUserService.updateUser("online-token-api",one.getUser());
                    }
                });
            }
        });
        return JsonResult.success();
    }
}
