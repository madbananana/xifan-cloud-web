package com.foundao.nft.cms.controller;

import com.foundao.nft.cms.service.impl.NftUserService;
import com.foundao.nft.common.model.NftUser;
import com.foundao.nft.common.model.vo.UserVo;
import com.foundao.nft.common.util.RedisKeyFactory;
import com.tx.core.beans.JsonResult;
import com.tx.redis.service.RedisService;
import com.tx.security.bean.JwtUserDto;
import com.tx.security.service.OnlineUserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Set;

/**
 * @Package: com.foundao.nft.cms.controller
 * @ClassName: RightController
 * @Author: chenli
 * @CreateTime: 2022/9/27 4:49 下午
 * @Description:
 */
@RestController
@RequiredArgsConstructor
@Api(tags = "权益相关")
@RequestMapping("right")
@Slf4j
@Validated
public class RightController {

    private final NftUserService userService;
    private final RedisTemplate<String,Object> redisTemplate;
    private final OnlineUserService onlineUserService;

    @Value("${spring.profiles.active}")
    private String env;

    @ApiOperation("初始化用户权益")
    @PostMapping("/init")
    public JsonResult<Void> initRightUser(){
        log.info("当前激活环境："+env);

        String setKey = RedisKeyFactory.getMetaId2RightLevelKey();
        Set<ZSetOperations.TypedTuple<Object>> sets = redisTemplate.opsForZSet().rangeByScoreWithScores(setKey, 1, 10);
        if (!CollectionUtils.isEmpty(sets)) {
            sets.forEach( metaId2RightLevel -> {
                int rightLevel = metaId2RightLevel.getScore().intValue();
                Integer metaId = (Integer)metaId2RightLevel.getValue();
                List<String> starUser = userService.findUserIdByMetaIdDistinct(metaId);
                starUser.forEach( userId-> {
                    NftUser user = userService.getById(userId);
                    user.setRightLevel(rightLevel);
                    userService.updateById(user);
                    JwtUserDto<UserVo> one = onlineUserService.getOne("online-token-api", Long.valueOf(userId));
                    one.getUser().getUserDetails().setRightLevel(rightLevel);
                    onlineUserService.updateUser("online-token-api",one.getUser());
                });
            });
        }
        return JsonResult.success();
    }
}
