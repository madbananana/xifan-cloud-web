package com.foundao.nft.cms.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.extension.toolkit.ChainWrappers;
import com.foundao.nft.cms.mapper.NftTaskMapper;
import com.foundao.nft.common.model.NftTask;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional
public class NftTaskService extends ServiceImpl<NftTaskMapper, NftTask> {


    /**
     * 通过任务id获取任务
     * @param taskId 任务id
     * @return
     */
    public NftTask getTaskByTaskId(String taskId){
        return ChainWrappers.lambdaQueryChain(baseMapper)
                .eq(NftTask::getTaskId, taskId)
                .one();
    }

    /**
     * 新增一个初始任务
     * @param task 任务信息
     */
    public void addTask(NftTask task){
        task.setStatus(2);
        save(task);
    }
}
