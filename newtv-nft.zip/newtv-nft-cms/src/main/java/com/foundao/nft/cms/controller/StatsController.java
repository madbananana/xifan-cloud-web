package com.foundao.nft.cms.controller;

import cn.hutool.core.collection.CollUtil;
import com.foundao.nft.cms.service.impl.AdvanceBuyService;
import com.foundao.nft.cms.service.impl.IntegralRecordService;
import com.foundao.nft.cms.service.impl.IntegralService;
import com.foundao.nft.cms.service.impl.NftOrderService;
import com.foundao.nft.cms.service.impl.NftRecordService;
import com.foundao.nft.cms.service.impl.SignRecordService;
import com.foundao.nft.cms.service.impl.TransferRecordService;
import com.foundao.nft.cms.vo.AppointmentDetailsVO;
import com.foundao.nft.cms.vo.AppointmentStatsVO;
import com.foundao.nft.common.model.SignRecord;
import com.foundao.nft.common.model.vo.*;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.JsonResult;
import com.tx.core.beans.PageResponseListVo;
import com.tx.core.util.excel.PoiExcelExportUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * @Package: com.foundao.nft.cms.controller
 * @ClassName: StatsController
 * @Author: chenli
 * @CreateTime: 2022/7/1 3:14 下午
 * @Description:
 */
@Slf4j
@RestController
@RequestMapping("stats")
@RequiredArgsConstructor
@Api(tags = "统计接口")
public class StatsController {


    private final AdvanceBuyService advanceBuyService;
    private final NftOrderService orderService;
    private final SignRecordService signRecordService;
    private final TransferRecordService transferRecordService;
    private final IntegralService integralService;
    private final IntegralRecordService integralRecordService;
    private final NftRecordService recordService;

    @GetMapping("appointment")
    @ApiOperation("预约统计")
    public JsonResult<AppointmentStatsVO> appointment(){
        List<AppointmentDetailsVO> list = advanceBuyService.stats();
        int totalAppointmentCount = list.stream().mapToInt(AppointmentDetailsVO::getAppointmentCount).sum();
        AppointmentStatsVO vo = new AppointmentStatsVO();
        vo.setAppointmentCountTotal(totalAppointmentCount);
        vo.setDetails(list);
        return JsonResult.success(vo);
    }

    @PostMapping("order/history/details")
    @ApiOperation("历史订单明细")
    public JsonResult<PageResponseListVo<OrderHistoryDetailsVO>> orderHistoryDetails(BaseRequestVo request){
        PageResponseListVo<OrderHistoryDetailsVO> page = orderService.orderHistoryDetails(request);
        return JsonResult.success(page);
    }

    @PostMapping("order/history/details/export")
    @ApiOperation("历史订单明细导出")
    public JsonResult<PageResponseListVo<OrderHistoryDetailsVO>> orderHistoryDetailsExport(@RequestBody BaseRequestVo request, HttpServletResponse response) throws IOException {
        PageResponseListVo<OrderHistoryDetailsVO> page = orderService.orderHistoryDetails(request);
        String fileName = "历史订单明细";
        List<String> heads = CollUtil.newArrayList("下单时间","支付时间","用户ID","用户昵称","姓名","手机号","系列名称","藏品名称","支付方式","支付金额/积分","购买数量");
        List<List<Object>> datas = new ArrayList<>();
        page.getList().forEach(data -> datas.add(CollUtil.newArrayList(data.getCreateTime(),data.getPayTime(),data.getUserId(),data.getNickName(),data.getUserName(),
                data.getMobile(),data.getSeriesName(),data.getName(),data.getPayTypeText(),"INTEGRAL_PAY".equals(data.getPayType())?data.getIntegral():data.getFee(),data.getCount())));
        PoiExcelExportUtil.exportExcelHTTP(fileName,heads,datas,response);
        return JsonResult.success();
    }

    @PostMapping("/signRecord")
    @ApiOperation("签到记录")
    public JsonResult<PageResponseListVo<SignRecordStatsVO>> signRecord(BaseRequestVo request){
        PageResponseListVo<SignRecordStatsVO> page = signRecordService.signRecordPage(request);
        return JsonResult.success(page);
    }

    @PostMapping("/signRecord/details")
    @ApiOperation("签到记录详情")
    public JsonResult<PageResponseListVo<SignRecord>> signRecordDetails(BaseRequestVo request,Integer userId){
        PageResponseListVo<SignRecord> page = signRecordService.signRecordByUserPage(request,userId);
        return JsonResult.success(page);
    }

    @PostMapping("/signRecord/export")
    @ApiOperation("签到记录导出")
    public void signRecordExport(@RequestBody BaseRequestVo request, HttpServletResponse response) throws IOException {
        String fileName = "签到记录";
        List<String> heads = CollUtil.newArrayList("用户ID","用户","手机号","签到时间");
        PageResponseListVo<SignRecordStatsVO> page = signRecordService.signRecordPage(request);
        List<List<Object>> datas = new ArrayList<>();
        page.getList().forEach(data -> datas.add(CollUtil.newArrayList(data.getUserId(),data.getUserName(),data.getMobile(),data.getCreateTime())));
        PoiExcelExportUtil.exportExcelHTTP(fileName,heads,datas,response);
    }

    @PostMapping("/transfer/history/details")
    @ApiOperation("历史转赠明细")
    public JsonResult<PageResponseListVo<TransferHistoryDetailsVO>> transferHistoryDetails(BaseRequestVo request){
        PageResponseListVo<TransferHistoryDetailsVO> page = transferRecordService.transferHistoryDetails(request);
        return JsonResult.success(page);
    }

    @PostMapping("/transfer/history/details/export")
    @ApiOperation("历史转赠明细导出")
    public void transferHistoryDetailsExport(@RequestBody BaseRequestVo request, HttpServletResponse response) throws IOException {
        PageResponseListVo<TransferHistoryDetailsVO> page = transferRecordService.transferHistoryDetails(request);
        String fileName = "历史转赠明细";
        List<String> heads = CollUtil.newArrayList("转赠时间","用户ID","用户昵称","姓名","手机号","转赠藏品名称","受赠用户ID","受赠用户手机号","领取转赠藏品时间");
        List<List<Object>> datas = new ArrayList<>();
        page.getList().forEach(data -> datas.add(CollUtil.newArrayList(data.getCreateTime(),data.getGiveUserId(),data.getGiveNickName(),data.getGiveUserName(),data.getGiveMobile(),
                data.getName(),data.getReceiveUserId(),data.getReceiveMobile(),data.getReceiveTime())));
        PoiExcelExportUtil.exportExcelHTTP(fileName,heads,datas,response);
    }

    @PostMapping("/integral/history/details")
    @ApiOperation("积分明细")
    public JsonResult<PageResponseListVo<IntegralHistoryDetailsVO>> integralHistoryDetails(BaseRequestVo request){
        PageResponseListVo<IntegralHistoryDetailsVO> page = integralRecordService.integralHistoryDetails(request);
        return JsonResult.success(page);
    }

    @PostMapping("/integral/history/details/export")
    @ApiOperation("积分明细导出")
    public void integralHistoryDetailsExport(@RequestBody BaseRequestVo request, HttpServletResponse response) throws IOException {
        PageResponseListVo<IntegralHistoryDetailsVO> page = integralRecordService.integralHistoryDetails(request);
        String fileName = "积分明细";
        List<String> heads = CollUtil.newArrayList("时间","用户ID","用户手机号","状态","积分流水","订单号","当时积分余额");
        List<List<Object>> datas = new ArrayList<>();
        page.getList().forEach(data -> datas.add(CollUtil.newArrayList(data.getCreateTime(),data.getUserId(),data.getSymbolText(),data.getIntegral(),
                data.getTradeNo(),data.getRestUsableIntegral())));
        PoiExcelExportUtil.exportExcelHTTP(fileName,heads,datas,response);
    }

    @PostMapping("/integral/")
    @ApiOperation("用户积分")
    public JsonResult<PageResponseListVo<IntegralStatsVO>> integralStats(BaseRequestVo request){
        PageResponseListVo<IntegralStatsVO> page = integralService.integralStats(request);
        return JsonResult.success(page);
    }

    @PostMapping("/integral/export")
    @ApiOperation("用户积分导出")
    public void integralStatsExport(BaseRequestVo request, HttpServletResponse response) throws IOException {
        PageResponseListVo<IntegralStatsVO> page = integralService.integralStats(request);
        String fileName = "用户积分";
        List<String> heads = CollUtil.newArrayList("用户ID","用户昵称","姓名","手机号","当前积分余额","累计消耗积分");
        List<List<Object>> datas = new ArrayList<>();
        page.getList().forEach(data -> datas.add(CollUtil.newArrayList(data.getUserId(),data.getNickName(),data.getUserName(),
                data.getUsableIntegral(),data.getUsedIntegral())));
        PoiExcelExportUtil.exportExcelHTTP(fileName,heads,datas,response);
    }

    @PostMapping("/userNftInfo")
    @ApiOperation("用户当前持有藏品数据")
    public JsonResult<PageResponseListVo<UserNftInfoVO>> userNftInfo(BaseRequestVo request){
        PageResponseListVo<UserNftInfoVO> page = recordService.userNftInfo(request);
        return JsonResult.success(page);
    }

    @PostMapping("/userNftInfo/export")
    @ApiOperation("用户当前持有藏品数据导出")
    public void userNftInfoExport(@RequestBody BaseRequestVo request, HttpServletResponse response) throws IOException {
        PageResponseListVo<UserNftInfoVO> page = recordService.userNftInfo(request);
        String fileName = "用户当前持有藏品数据";
        List<String> heads = CollUtil.newArrayList("用户ID","用户昵称","姓名","手机号","持有数字藏品名称","持有数字藏品数量");
        List<List<Object>> datas = new ArrayList<>();
        page.getList().forEach(data -> datas.add(CollUtil.newArrayList(data.getUserId(),data.getNickName(),data.getUserName(),
                data.getMobile(),data.getName(),data.getBuyCount())));
        PoiExcelExportUtil.exportExcelHTTP(fileName,heads,datas,response);
    }

    @PostMapping("/holdInfo/export")
    @ApiOperation("用户当前持有藏品数据导出")
    public void userHoldInfo(HttpServletResponse response,@RequestBody @Validated HoldInfoQequestVO vo) throws IOException {
        String fileName = "系列持有藏品信息";
        List<String> heads = CollUtil.newArrayList("用户ID","用户昵称","姓名","手机号","持有数字藏品名称","持有数字藏品数量");
        List<HoldInfoResponseVO> list = recordService.userHoldInfo(vo.getShortSeriesId());
        List<List<Object>> datas = new ArrayList<>();
        list.forEach(data -> datas.add(CollUtil.newArrayList(data.getUserId(),data.getNickName(),data.getUserName(),
                data.getMobile(),data.getName(),data.getHoldCount())));
        PoiExcelExportUtil.exportExcelHTTP(fileName,heads,datas,response);
    }

}
