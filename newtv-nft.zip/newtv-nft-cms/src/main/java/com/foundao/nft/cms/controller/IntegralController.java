package com.foundao.nft.cms.controller;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.io.FileUtil;
import cn.hutool.poi.excel.ExcelReader;
import cn.hutool.poi.excel.ExcelUtil;
import com.foundao.nft.cms.service.impl.IntegralRecordService;
import com.foundao.nft.cms.service.impl.IntegralService;
import com.foundao.nft.cms.service.impl.NftUserService;
import com.foundao.nft.cms.vo.IntegralPageResponseListVo;
import com.foundao.nft.cms.vo.SystemIntegralInfoPageResponseListVo;
import com.foundao.nft.cms.vo.SystemIntegralInfoVO;
import com.foundao.nft.common.constant.IntegralTypeEnum;
import com.foundao.nft.common.model.Integral;
import com.foundao.nft.common.model.IntegralRecord;
import com.foundao.nft.common.model.NftUser;
import com.foundao.nft.common.model.vo.UserIntegralDetailsVO;
import com.foundao.nft.common.properties.NftProperties;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.JsonResult;
import com.tx.core.exception.BusException;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @ClassName IntegralController
 * @Description TODO
 * @Author xifan
 * @Date 2022/8/23 11:18
 * @Version 1.0
 */
@RestController
@RequiredArgsConstructor
@Api(tags = "积分")
@RequestMapping("integral")
@Slf4j
@Validated
public class IntegralController {

    private final IntegralRecordService integralRecordService;
    private final IntegralService integralService;
    private final NftUserService userService;
    private final NftProperties nftProperties;

//    @ApiOperation("系统积分信息")
//    @GetMapping("/system/info")
//    public JsonResult<SystemIntegralInfoVO> info(){
//        SystemIntegralInfoVO info = integralRecordService.systemInfo();
//        return JsonResult.success(info);
//    }

    @ApiOperation("用户积分列表(分页)")
    @PostMapping("/page")
    @ApiOperationSupport(includeParameters = {"page","num","keyword"})
    public JsonResult<SystemIntegralInfoPageResponseListVo<Integral>> page(BaseRequestVo request){
        SystemIntegralInfoPageResponseListVo<Integral> page = integralService.pageIntegral(request);
        SystemIntegralInfoVO info = integralRecordService.systemInfo();
        page.setSystemIntegralInfo(info);
        return JsonResult.success(page);
    }

    @ApiOperation("用户积分详情")
    @PostMapping("/user/details")
    public JsonResult<IntegralPageResponseListVo<IntegralRecord>> details(BaseRequestVo request,String userId){
        NftUser user = userService.getById(userId);
        if (user==null) {
            throw new BusException("用户不存在");
        }
        UserIntegralDetailsVO userInfo = integralService.personIntegralStats(user.getUserId());
        IntegralPageResponseListVo<IntegralRecord> page = integralRecordService.pageRecord(request,user.getUserId());
        page.setUserInfo(userInfo);
        return JsonResult.success(page);
    }

    @ApiOperation("发放或扣除用户积分")
    @PostMapping("/awardIntegral")
    public JsonResult<String> awardIntegral(String mobile,Integer count){
        NftUser user = userService.findUserByMobile(mobile);
        if (user==null) {
            return JsonResult.error(HttpStatus.INTERNAL_SERVER_ERROR.value(),"用户不存在");
        }
        if (count==0) {
            return JsonResult.error(HttpStatus.INTERNAL_SERVER_ERROR.value(),"发放的积分不能为0");
        }
        String sourceType = "systemReward";
        String symbol = "in";
        if (count<0) {
            sourceType="systemReduce";
            symbol="out";
            count=-1*count;
        }
        integralService.integralOperation(user.getUserId(),"system",sourceType,symbol,count,null, DateUtil.now());
        return JsonResult.success("用户"+mobile+ IntegralTypeEnum.getTypeName(sourceType) + count +"积分");
    }

    @ApiOperation("批量发放或扣除用户积分")
    @PostMapping("/batch/awardIntegral")
    public JsonResult<Void> batchAwardIntegral(String dateTime){
        ExcelReader reader = ExcelUtil.getReader(nftProperties.getTempFilePath()+"integralReward"+dateTime+".xlsx");
        //ExcelReader reader = ExcelUtil.getReader(IntegralController.class.getResourceAsStream("/integralReward"+dateTime+".xlsx"));
        List<List<Object>> readAll = reader.read(1);
        readAll.forEach( r -> {
            JsonResult<String> result = awardIntegral(r.get(0)+"", Integer.parseInt(r.get(1)+""));
            log.info(result.getData());
        });

        return JsonResult.success();
    }

}
