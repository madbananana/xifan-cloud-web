package com.foundao.nft.cms.vo;

import com.tx.core.beans.PageResponseListVo;
import lombok.Data;

import java.util.List;

/**
 * @ClassName SystemIntegralInfoPageResponseListVo
 * @Description TODO
 * @Author xifan
 * @Date 2022/9/1 16:21
 * @Version 1.0
 */
@Data
public class SystemIntegralInfoPageResponseListVo <T> extends PageResponseListVo<T> {

    private SystemIntegralInfoVO systemIntegralInfo;

    public SystemIntegralInfoPageResponseListVo(Long total, List<T> list) {
        super.setTotal(total);
        this.setList(list);
    }

    public static <T> SystemIntegralInfoPageResponseListVo<T> createPageResponseListVo(List<T> list, Long total) {
        return new SystemIntegralInfoPageResponseListVo<>(total, list);
    }
}
