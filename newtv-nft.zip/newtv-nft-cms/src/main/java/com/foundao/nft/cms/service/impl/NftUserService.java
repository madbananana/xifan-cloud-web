package com.foundao.nft.cms.service.impl;

import cn.hutool.core.bean.BeanUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.toolkit.ChainWrappers;
import com.foundao.nft.common.constant.FoundaoConstant;
import com.foundao.nft.common.model.AdvanceBuy;
import com.foundao.nft.common.model.AvatarPart;
import com.foundao.nft.common.model.NewtvEmp;
import com.foundao.nft.common.model.NftRecord;
import com.foundao.nft.common.model.NftRecordDelete;
import com.foundao.nft.common.model.UserDelete;
import com.foundao.nft.common.model.vo.PurchaseHistory;
import com.foundao.nft.common.model.vo.UserDetailsVO;
import com.foundao.nft.common.model.vo.UserListVO;
import com.foundao.nft.common.util.RedisKeyFactory;
import com.foundao.nft.common.util.SortUtil;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.JsonResult;
import com.tx.core.beans.PageResponseListVo;
import com.tx.redis.service.RedisService;
import com.tx.security.service.OnlineUserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.cms.mapper.NftUserMapper;
import com.foundao.nft.common.model.NftUser;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional
@Slf4j
public class NftUserService extends ServiceImpl<NftUserMapper, NftUser> {

    private final NftUserConnectionService userConnectionService;
    private final NftUserPlatformService userPlatformService;
    private final OnlineUserService onlineUserService;
    private final NewtvEmpService empService;
    private final NftOrderService orderService;
    private final NftRecordDeleteService recordDeleteService;
    private final NftRecordService recordService;
    private final RedisService redisService;
    private final AdvanceBuyService advanceBuyService;
    private final UserDeleteService userDeleteService;

    @Transactional(rollbackFor = Exception.class)
    public void clean(String mobile) {
        NftUser user = ChainWrappers.lambdaQueryChain(baseMapper)
                .eq(NftUser::getMobile, mobile)
                .last("limit 1")
                .one();
        if (user!=null) {
            removeById(user.getUserId());
            userConnectionService.removeById(user.getUserId());
            userPlatformService.removeById(user.getUserId());
            ChainWrappers.lambdaUpdateChain(advanceBuyService.getBaseMapper())
                    .eq(AdvanceBuy::getUserId, user.getUserId())
                    .remove();
            onlineUserService.kickOut("online-token-api", Long.valueOf(user.getUserId()));
        }
    }

    public NftUser findUserByMobile(String mobile){
        return this.baseMapper.findUserByMobile(mobile);
    }

    public NftUser findUserByMobileNoLock(String mobile){
        return this.baseMapper.findUserByMobileNoLock(mobile);
    }

    @Transactional(rollbackFor = Exception.class)
    public boolean modMobile(String newMobile,String oldMobile){
        NftUser user = findUserByMobileNoLock(oldMobile);
        if (user!=null) {
            user.setMobile(newMobile);
            user.setInternalEmp(1);
            updateById(user);
            onlineUserService.kickOut("online-token-api", Long.valueOf(user.getUserId()));

            empService.removeById(oldMobile);
            NewtvEmp emp = NewtvEmp.builder().mobile(newMobile).name(newMobile).specialType(0).build();
            empService.saveOrUpdate(emp);
            return true;
        }
        return false;
    }

    public PageResponseListVo<UserListVO> pageUserVO(BaseRequestVo requestVo) {
        Page<UserListVO> page = new Page<>(requestVo.getPage(),requestVo.getNum());
        SortUtil.handlePageSort(requestVo, page, "user_id", FoundaoConstant.ORDER_DESC, true);
        IPage<UserListVO> result = baseMapper.pageUserVO(page,requestVo);
        return PageResponseListVo.createPageResponseListVo(result.getRecords(),result.getTotal());
    }

    public UserDetailsVO getDetails(String userId) {
        UserDetailsVO userDetails = baseMapper.getDetails(userId);
        List<PurchaseHistory> purchaseHistory = orderService.getPurchaseHistory(userId);
        userDetails.setPurchaseHistory(purchaseHistory);
        return userDetails;
    }

    @Transactional(rollbackFor = Exception.class)
    public void executeCancellation(NftUser user) {
        //List<NftRecord> list = recordService.lambdaQuery()
        //        .eq(NftRecord::getUserId, user.getUserId())
        //        .list();
        //List<NftRecordDelete> deletes = new ArrayList<>();
        //list.forEach(record -> {
        //    NftRecordDelete delete = new NftRecordDelete();
        //    BeanUtil.copyProperties(record,delete);
        //    deletes.add(delete);
        //});
        //recordDeleteService.saveBatch(deletes);
        //ChainWrappers.lambdaUpdateChain(recordService.getBaseMapper())
        //        .eq(NftRecord::getUserId,user.getUserId())
        //        .remove();
        //ChainWrappers.lambdaUpdateChain(advanceBuyService.getBaseMapper())
        //        .eq(AdvanceBuy::getUserId, user.getUserId())
        //        .remove();
        //user.setStatus(3);
        //user.setUserName(user.getMobile());
        //updateById(user);
        userConnectionService.removeById(user.getUserId());
        userPlatformService.removeById(user.getUserId());
        UserDelete userDelete = new UserDelete();
        BeanUtil.copyProperties(user,userDelete);
        userDeleteService.save(userDelete);
        removeById(user.getUserId());
        onlineUserService.kickOut("online-token-api", Long.valueOf(user.getUserId()));
        redisService.del(RedisKeyFactory.getUserCancellationKey(user.getUserId()+""));
    }

    public int findPrimaryUserCount() {
        return baseMapper.findPrimaryUserCount();
    }

    public List<NftUser> findPrimaryUser(Integer num, int size) {
        Page<NftUser> page = new Page<>(num,size);
        List<NftUser> list = baseMapper.findPrimaryUser(page);
        return list;
    }

    public List<String> findUserIdByMetaIdDistinct(Integer primaryMetaId) {
        return baseMapper.findUserIdByMetaIdDistinct(primaryMetaId);
    }
}
