package com.foundao.nft.cms.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.common.model.vo.BrandVO;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.PageResponseListVo;
import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.cms.mapper.BrandMapper;
import com.foundao.nft.common.model.Brand;
/**
    @Package: com.foundao.nft.cms.service.impl
    @ClassName: BrandService
    @Author: chenli
    @CreateTime: 2022/2/21 4:26 下午
    @Description:
*/
@Service
public class BrandService extends ServiceImpl<BrandMapper, Brand> {

    public PageResponseListVo<BrandVO> pageList(BaseRequestVo request) {
        Page<BrandVO> page = new Page<>(request.getPage(),request.getNum());
        IPage<BrandVO> resultList = baseMapper.pageList(page);
        long total = resultList.getTotal();
        return PageResponseListVo.createPageResponseListVo(resultList.getRecords(), total);
    }
}
