package com.foundao.nft.cms.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.common.constant.FoundaoConstant;
import com.foundao.nft.common.model.vo.ExchangeCodeVO;
import com.foundao.nft.common.model.vo.ExchangeRecordVO;
import com.foundao.nft.common.util.SortUtil;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.PageResponseListVo;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.common.model.ExchangeCode;
import com.foundao.nft.cms.mapper.ExchangeCodeMapper;
@Service
public class ExchangeCodeService extends ServiceImpl<ExchangeCodeMapper, ExchangeCode> {

    public List<ExchangeCodeVO> lsitExchangeCodeVO(String seriesId) {
       return baseMapper.lsitExchangeCodeVO(seriesId);
    }

    public PageResponseListVo<ExchangeRecordVO> pageExchangeRecordVO(BaseRequestVo request) {
        Page<ExchangeRecordVO> page = new Page<>(request.getPage(),request.getNum());
        IPage<ExchangeRecordVO>  resultList = baseMapper.pageExchangeRecordVO(page,request);
        long total = resultList.getTotal();
        return PageResponseListVo.createPageResponseListVo(resultList.getRecords(), total);
    }

    public List<ExchangeRecordVO> exchangeRecordVOExport(BaseRequestVo request){
        return baseMapper.exchangeRecordVOExport(request);
    }
}
