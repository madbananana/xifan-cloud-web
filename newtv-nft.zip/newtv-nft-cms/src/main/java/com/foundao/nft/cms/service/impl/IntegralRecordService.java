package com.foundao.nft.cms.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.cms.vo.IntegralPageResponseListVo;
import com.foundao.nft.cms.vo.SystemIntegralInfoVO;
import com.foundao.nft.common.constant.FoundaoConstant;
import com.foundao.nft.common.constant.IntegralTypeEnum;
import com.foundao.nft.common.model.Integral;
import com.foundao.nft.common.model.vo.IntegralHistoryDetailsVO;
import com.foundao.nft.common.util.SortUtil;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.PageResponseListVo;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.cms.mapper.IntegralRecordMapper;
import com.foundao.nft.common.model.IntegralRecord;
@Service
public class IntegralRecordService extends ServiceImpl<IntegralRecordMapper, IntegralRecord> {

    public SystemIntegralInfoVO systemInfo() {
        return baseMapper.systemInfo();
    }

    public IntegralPageResponseListVo<IntegralRecord> pageRecord(BaseRequestVo request,Integer userId) {
        Page<IntegralRecord> page = new Page<>(request.getPage(),request.getNum());
        SortUtil.handlePageSort(request, page, "create_time", FoundaoConstant.ORDER_DESC, true);
        IPage<IntegralRecord> resultList = baseMapper.pageRecord(page,userId);
        resultList.getRecords().forEach( vo -> {
            if (!vo.getSourceType().equals(IntegralTypeEnum.BUY_NFT.getType())) {
                vo.setSourceId("");
            }
        });
        long total = resultList.getTotal();
        return IntegralPageResponseListVo.createPageResponseListVo(resultList.getRecords(), total);
    }

    public PageResponseListVo<IntegralHistoryDetailsVO> integralHistoryDetails(BaseRequestVo request) {
        Page<IntegralHistoryDetailsVO> page = new Page<>(request.getPage(),request.getNum());
        SortUtil.handlePageSort(request, page, "create_time", FoundaoConstant.ORDER_DESC, true);
        IPage<IntegralHistoryDetailsVO> resultList = baseMapper.integralHistoryDetails(page,request);
        long total = resultList.getTotal();
        return IntegralPageResponseListVo.createPageResponseListVo(resultList.getRecords(), total);
    }
}
