package com.foundao.nft.cms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.cms.vo.SystemIntegralInfoVO;
import com.foundao.nft.common.model.IntegralRecord;
import com.foundao.nft.common.model.vo.IntegralHistoryDetailsVO;
import com.tx.core.beans.BaseRequestVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface IntegralRecordMapper extends BaseMapper<IntegralRecord> {
    SystemIntegralInfoVO systemInfo();

    IPage<IntegralRecord> pageRecord(Page<IntegralRecord> page,@Param("userId") Integer userId);

    IPage<IntegralHistoryDetailsVO> integralHistoryDetails(Page<IntegralHistoryDetailsVO> page,@Param("request") BaseRequestVo request);
}
