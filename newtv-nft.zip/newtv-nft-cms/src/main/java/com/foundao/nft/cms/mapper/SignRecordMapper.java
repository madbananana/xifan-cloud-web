package com.foundao.nft.cms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.common.model.SignRecord;
import com.foundao.nft.common.model.vo.SignRecordStatsVO;
import com.tx.core.beans.BaseRequestVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
    @Package: com.foundao.nft.cms.mapper
    @ClassName: SignRecordMapper
    @Author: chenli
    @CreateTime: 2022/9/23 4:41 下午
    @Description:
*/
@Mapper
public interface SignRecordMapper extends BaseMapper<SignRecord> {
    IPage<SignRecordStatsVO> signRecordPage(Page<SignRecordStatsVO> page,@Param("request") BaseRequestVo request);
}