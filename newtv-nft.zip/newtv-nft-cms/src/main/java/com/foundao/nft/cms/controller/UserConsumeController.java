package com.foundao.nft.cms.controller;

import com.foundao.nft.cms.service.impl.UserConsumeService;
import com.tx.core.beans.JsonResult;
import io.swagger.annotations.Api;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Package: com.foundao.nft.cms.controller
 * @ClassName: UserConsumeController
 * @Author: chenli
 * @CreateTime: 2022/11/8 11:11 AM
 * @Description:
 */
@Slf4j
@RestController
@RequestMapping("userConsume")
@RequiredArgsConstructor
@Api(tags = "用户h5消费初始化")
public class UserConsumeController {

    private final UserConsumeService userConsumeService;

    @PostMapping("init")
    public JsonResult<Void> initUserConsume(){
        userConsumeService.initUserConsume();
        return JsonResult.success();
    }
}
