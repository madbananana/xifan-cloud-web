package com.foundao.nft.cms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.common.model.Goods;
import org.apache.ibatis.annotations.Mapper;

/**
    @Package: com.foundao.nft.cms.mapper
    @ClassName: GoodsMapper
    @Author: chenli
    @CreateTime: 2022/2/21 4:11 下午
    @Description:
*/
@Mapper
public interface GoodsMapper extends BaseMapper<Goods> {
    IPage<Goods> pageList(Page<Goods> page);
}