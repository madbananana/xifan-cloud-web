package com.foundao.nft.cms.service.impl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.common.model.AwardInfo;
import com.foundao.nft.cms.mapper.AwardInfoMapper;
/**
    @Package: com.foundao.nft.cms.service.impl
    @ClassName: AwardInfoService
    @Author: chenli
    @CreateTime: 2022/11/3 11:17 AM
    @Description:
*/
@Service
public class AwardInfoService extends ServiceImpl<AwardInfoMapper, AwardInfo> {

}
