package com.foundao.nft.cms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.common.model.Merge;
import com.foundao.nft.common.model.vo.MergeVO;
import com.tx.core.beans.BaseRequestVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface MergeMapper extends BaseMapper<Merge> {
    IPage<MergeVO> mergePage(Page<MergeVO> page,@Param("request") BaseRequestVo request);
}