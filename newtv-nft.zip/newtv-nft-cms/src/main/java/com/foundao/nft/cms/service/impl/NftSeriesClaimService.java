package com.foundao.nft.cms.service.impl;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.IdUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.extension.toolkit.ChainWrappers;
import com.foundao.nft.cms.mapper.NftSeriesClaimMapper;
import com.foundao.nft.cms.vo.SeriesBaseQueryVO;
import com.foundao.nft.cms.vo.SeriesListVO;
import com.foundao.nft.common.constant.FoundaoConstant;
import com.foundao.nft.common.constant.TaskEnum;
import com.foundao.nft.common.model.CmsUser;
import com.foundao.nft.common.model.NftMetadata;
import com.foundao.nft.common.model.NftSeriesClaim;
import com.foundao.nft.common.model.NftTask;
import com.foundao.nft.common.model.sdk.client.NftService;
import com.foundao.nft.common.model.sdk.request.SeriesClaimRequest;
import com.foundao.nft.common.model.sdk.response.SdkResponseBase;
import com.foundao.nft.common.model.sdk.response.TaskResponse;
import com.foundao.nft.common.model.vo.SeriesBaseVO;
import com.foundao.nft.common.util.RedisKeyFactory;
import com.foundao.nft.common.util.SortUtil;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.PageResponseListVo;
import com.tx.core.exception.BusException;
import com.tx.redis.service.RedisService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Package: com.foundao.nft.cms.service.impl
 * @ClassName: NftSeriesClaimService
 * @Author: chenli
 * @CreateTime: 2021/12/21 3:16 下午
 * @Description:
 */
@Service
@RequiredArgsConstructor
public class NftSeriesClaimService extends ServiceImpl<NftSeriesClaimMapper, NftSeriesClaim> {
    private final NftTaskService nftTaskService;
    //private final NftProperties nftProperties;
    //private final NftCommonUtil nftCommonUtil;
    private final NftMetadataService metadataService;
    private final NftService nftService;
    private final RedisService redisService;
    private final AdvanceBuyService advanceBuyService;

    public NftSeriesClaim getBySeriesId(String seriesId) {
        return ChainWrappers.lambdaQueryChain(baseMapper)
                .eq(NftSeriesClaim::getSeriesId, seriesId)
                .one();
    }

    /**
     * 通过系列名称获取唯一系列
     * @param name 名称
     * @return
     */
    public NftSeriesClaim getBySeriesName(String name){
        return ChainWrappers.lambdaQueryChain(baseMapper)
                .eq(NftSeriesClaim::getSeriesName,name)
                .one();
    }

    public PageResponseListVo<SeriesListVO> pageSeries(BaseRequestVo request) {
        Page<SeriesListVO> page = new Page<>(request.getPage(),request.getNum());
        SortUtil.handlePageSort(request, page, "id", FoundaoConstant.ORDER_DESC, true);
        IPage<SeriesListVO> resultList = baseMapper.pageSeries(page,request);
        List<SeriesListVO> records = resultList.getRecords();
        records.forEach(seriesVO -> {
            if (StrUtil.isBlank(seriesVO.getSeriesId())) {
                seriesVO.setNftCount(0);
                seriesVO.setRestCount(0);
            } else {
                seriesVO.setRestCount(metadataService.countRestCount(seriesVO.getSeriesId()));
                if (seriesVO.getAdvanceBuy()==1) {
                    Integer num = advanceBuyService.selectAppointmentCount(seriesVO.getSeriesId());
                    //Integer num = (Integer) redisService.get(RedisKeyFactory.getAppointmentNumKey(seriesVO.getSeriesId()));
                    Integer delta = (Integer) redisService.get(RedisKeyFactory.getAppointmentDeltaKey(seriesVO.getSeriesId()));
                    if (num==null) {
                        num = 0;
                    }
                    if (delta == null) {
                        delta = 0;
                    }
                    seriesVO.setAppointmentTotalCount(num);
                    seriesVO.setAppointmentDelta(delta);
                    seriesVO.setShowAppointmentStatus(0);
                    Integer status = (Integer) redisService.get(RedisKeyFactory.getSeriesShowAppointCountKey(seriesVO.getId()));
                    if (status!=null) {
                        seriesVO.setShowAppointmentStatus(status);
                    }
                }
            }
        });
        long total = resultList.getTotal();
        return PageResponseListVo.createPageResponseListVo(resultList.getRecords(), total);
    }

    /**
     * 系列声明
     */
    public void seriesClaim(NftSeriesClaim nftSeriesClaim,CmsUser user){

        nftSeriesClaim.setOperateId(IdUtil.randomUUID());
        nftSeriesClaim.setOperator(user.getUserId());
        nftSeriesClaim.setAuthor(user.getUsername());

        if(nftSeriesClaim.getId() == null){
            //新增时需要初始化的字段
            nftSeriesClaim.setTotalCount(nftSeriesClaim.getTotalCount());
            nftSeriesClaim.setSeriesBeginFromZero(1);
        }

        SeriesClaimRequest request = new SeriesClaimRequest();
        BeanUtils.copyProperties(nftSeriesClaim,request);

        SdkResponseBase<TaskResponse> taskResponseSdkResponseBase = nftService.seriesClaim(request);
        if ( taskResponseSdkResponseBase != null ) {
            if (taskResponseSdkResponseBase.getRetCode()==0) {
                nftSeriesClaim.setTaskId(taskResponseSdkResponseBase.getData().getTaskId());
                saveSeriesClaim(nftSeriesClaim);
                return;
            }
        }
        throw new BusException("系列声明失败");
    }


    private void saveSeriesClaim(NftSeriesClaim nftSeriesClaim) {
        nftSeriesClaim.setCreateTime(DateUtil.now());
        nftSeriesClaim.setUpdateTime(DateUtil.now());
        if(nftSeriesClaim.getId() == null){
            nftSeriesClaim.setShowStatus(0);
            baseMapper.insert(nftSeriesClaim);
        }else {
            baseMapper.updateById(nftSeriesClaim);
        }

        //添加任务到任务表中
        if(StrUtil.isNotBlank(nftSeriesClaim.getTaskId())){
            NftTask task = new NftTask();
            task.setTaskId(nftSeriesClaim.getTaskId());
            task.setType(TaskEnum.SERIES_CLAIM.getCode());
            task.setStatus(2);
            nftTaskService.addTask(task);
        }

    }

    public void updateId(Integer sourceId,Integer targetId){
        ChainWrappers.lambdaUpdateChain(this.baseMapper)
                .eq(NftSeriesClaim::getId,sourceId)
                .set(NftSeriesClaim::getId,targetId)
                .update();
    }

    public List<SeriesBaseVO> listBase(SeriesBaseQueryVO baseQuery) {
        return baseMapper.listBase(baseQuery);
    }

    public String seriesOnline(Integer id, Integer showStatus) {
        NftSeriesClaim seriesClaim = getById(id);
        Integer count = ChainWrappers.lambdaQueryChain(metadataService.getBaseMapper())
                .eq(NftMetadata::getSeriesId, seriesClaim.getSeriesId())
                .count();
        seriesClaim.setShowStatus(showStatus);
        if (showStatus==1) {
            if (count==0) {
                return "nftCountError";
            }
        }
        updateById(seriesClaim);
        return "success";
    }
}


