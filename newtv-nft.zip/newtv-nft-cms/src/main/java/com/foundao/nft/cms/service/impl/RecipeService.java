package com.foundao.nft.cms.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.foundao.nft.common.model.NftMetadata;
import com.foundao.nft.common.model.RecipeMaterial;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.common.model.Recipe;
import com.foundao.nft.cms.mapper.RecipeMapper;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional
public class RecipeService extends ServiceImpl<RecipeMapper, Recipe> {

    private final RecipeMaterialService recipeMaterialService;

    public Recipe findByMetaId(Integer metaId) {
        return lambdaQuery()
                .eq(Recipe::getResultMetaId, metaId)
                .one();
    }

    @Transactional(rollbackFor = Exception.class)
    public Recipe creatRecipe(NftMetadata metadata,List<RecipeMaterial> recipeMaterials) {
        Recipe recipe = new Recipe();
        recipe.setRecipeName(metadata.getName());
        recipe.setResultMetaId(metadata.getMetaId());
        recipe.setResultSeriesId(metadata.getShortSeriesId());
        save(recipe);
        recipeMaterials.forEach(material -> {
            material.setRecipeId(recipe.getRecipeId());
        });
        recipeMaterialService.saveBatch(recipeMaterials);
        return recipe;
    }
}
