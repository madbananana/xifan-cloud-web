package com.foundao.nft.cms.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.common.constant.FoundaoConstant;
import com.foundao.nft.common.model.vo.UserListVO;
import com.foundao.nft.common.util.SortUtil;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.PageResponseListVo;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.LinkedHashMap;
import java.util.List;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.common.model.Banner;
import com.foundao.nft.cms.mapper.BannerMapper;
/**
    @Package: com.foundao.nft.cms.service.impl
    @ClassName: BannerService
    @Author: chenli
    @CreateTime: 2022/6/7 11:07 上午
    @Description:
*/
@Service
public class BannerService extends ServiceImpl<BannerMapper, Banner> {

    public PageResponseListVo<Banner> pageBanner(BaseRequestVo request) {

        Page<Banner> page = new Page<>(request.getPage(),request.getNum());
        LinkedHashMap<String,Boolean> orders = new LinkedHashMap<>();
        orders.put("show_status",false);
        orders.put("banner_id",false);
        SortUtil.handleMultiPageSort(request, page, orders, true);
        IPage<Banner> result = baseMapper.pageBanner(page);
        return PageResponseListVo.createPageResponseListVo(result.getRecords(),result.getTotal());
    }
}
