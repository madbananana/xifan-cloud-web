package com.foundao.nft.cms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.foundao.nft.common.model.NftUserConnection;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface NftUserConnectionMapper extends BaseMapper<NftUserConnection> {
}