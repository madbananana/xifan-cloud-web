package com.foundao.nft.cms.controller;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.foundao.nft.cms.service.impl.MergeService;
import com.foundao.nft.cms.service.impl.NftMetadataService;
import com.foundao.nft.cms.service.impl.RecipeCollectionService;
import com.foundao.nft.cms.service.impl.RecipeMaterialService;
import com.foundao.nft.cms.service.impl.RecipeService;
import com.foundao.nft.common.model.NftMetadata;
import com.foundao.nft.common.model.Recipe;
import com.foundao.nft.common.model.RecipeCollection;
import com.foundao.nft.common.model.vo.MergeVO;
import com.foundao.nft.common.model.vo.RecipeCollectionVO;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.JsonResult;
import com.tx.core.beans.PageResponseListVo;
import com.tx.core.enums.errcode.ParamErrorEnum;
import com.tx.core.exception.BusException;
import com.tx.core.util.excel.PoiExcelExportUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @ClassName RecipeController
 * @Description TODO
 * @Author xifan
 * @Date 2022/9/5 15:40
 * @Version 1.0
 */
@RestController
@RequiredArgsConstructor
@Api(tags = "合成配方相关")
@RequestMapping("recipe")
@Slf4j
@Validated
public class RecipeController {

    private final RecipeCollectionService collectionService;
    private final MergeService mergeService;


    @ApiOperation("新增或修改配方活动")
    @PostMapping("/collection/save")
    public JsonResult<?> saveCollection(@RequestBody @Validated RecipeCollectionVO vo){
        collectionService.saveCollection(vo);
        return JsonResult.success();
    }

    @ApiOperation("合成活动列表")
    @PostMapping("/collection/page")
    @ApiOperationSupport(includeParameters = {"page","num"})
    public JsonResult<PageResponseListVo<RecipeCollection>> collectionPage(BaseRequestVo request){
        return JsonResult.success(collectionService.collectionPage(request));
    }

    @ApiOperation("活动上下线")
    @PostMapping("/collection/online")
    public JsonResult<?> collectionOnline(@RequestParam("collectionId") Integer collectionId, @RequestParam("status") Integer status){
        //更新状态
        if(status !=0 && status != 1){
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"上下线状态传递不正确");
        }

        RecipeCollection collection = collectionService.getById(collectionId);
        if (collection==null) {
            throw new BusException("活动不存在");
        }

        collection.setStatus(status);
        collectionService.updateById(collection);
        return JsonResult.success();
    }

    @ApiOperation("合成记录列表")
    @PostMapping("/merge/page")
    @ApiOperationSupport(includeParameters = {"page","num","keyword"})
    public JsonResult<PageResponseListVo<MergeVO>> mergePage(BaseRequestVo request){
        return JsonResult.success(mergeService.mergePage(request));
    }

    @ApiOperation("合成记录列表导出")
    @PostMapping("/merge/page/export")
    @ApiOperationSupport(includeParameters = {"page","num","keyword"})
    public void mergePage(@RequestBody BaseRequestVo request, HttpServletResponse response) throws IOException {
        String fileName = "合成记录列表";
        PageResponseListVo<MergeVO> page = mergeService.mergePage(request);
        List<String> heads = CollUtil.newArrayList("用户ID","用户手机号","合成目标藏品","合成材料","合成时间");
        List<List<Object>> datas = new ArrayList<>();
        page.getList().forEach(data -> {
            List<String> materialArray = data.getMaterials().stream().map(Objects::toString).collect(Collectors.toList());
            datas.add(CollUtil.newArrayList(data.getUserId(), data.getMobile(), data.getName(), String.join("\n",materialArray), data.getCreateTime()));
        });
        PoiExcelExportUtil.exportExcelHTTP(fileName,heads,datas,response);
    }
}
