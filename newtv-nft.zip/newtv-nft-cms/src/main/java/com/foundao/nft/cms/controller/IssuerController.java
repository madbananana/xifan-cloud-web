package com.foundao.nft.cms.controller;

import cn.hutool.core.bean.BeanUtil;
import com.baomidou.mybatisplus.extension.toolkit.ChainWrappers;
import com.foundao.nft.cms.service.impl.IssuerService;
import com.foundao.nft.cms.service.impl.NftSeriesClaimService;
import com.foundao.nft.common.model.Brand;
import com.foundao.nft.common.model.Issuer;
import com.foundao.nft.common.model.NftSeriesClaim;
import com.foundao.nft.common.model.RecieveAddr;
import com.foundao.nft.common.model.vo.BrandDetailsVO;
import com.foundao.nft.common.model.vo.IssuerDetailsVO;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.JsonResult;
import com.tx.core.beans.PageResponseListVo;
import com.tx.core.enums.errcode.ParamErrorEnum;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName IssuerController
 * @Description TODO
 * @Author xifan
 * @Date 2022/7/14 23:35
 * @Version 1.0
 */
@RestController
@RequiredArgsConstructor
@Api(tags = "发行方")
@RequestMapping("issuer")
@Slf4j
@Validated
public class IssuerController {

    private final IssuerService issuerService;
    private final NftSeriesClaimService seriesClaimService;

    @ApiOperation("发行方列表")
    @PostMapping("/list")
    @ApiOperationSupport(includeParameters = {"page","num"})
    public JsonResult<PageResponseListVo<Issuer>> list(BaseRequestVo requestVo){
        PageResponseListVo<Issuer> page = issuerService.pageIssuer(requestVo);
        return JsonResult.success(page);
    }

    @ApiOperation("添加或更新发行方")
    @PostMapping("/add")
    public JsonResult<Void> add(@Validated Issuer issuer){
        issuerService.saveOrUpdate(issuer);
        return JsonResult.success();
    }

    @ApiOperation("发行发详情")
    @PostMapping("/details")
    public JsonResult<IssuerDetailsVO> issuerDetails(@RequestParam String id){
        Issuer issuer = issuerService.getById(id);
        if (issuer == null) {
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"不存在的发行方");
        }
        List<NftSeriesClaim> list = ChainWrappers.lambdaQueryChain(seriesClaimService.getBaseMapper())
                .eq(NftSeriesClaim::getIssuerId, issuer.getId())
                .select(NftSeriesClaim::getSeriesName)
                .list();
        IssuerDetailsVO vo = new IssuerDetailsVO();
        BeanUtil.copyProperties(issuer,vo);
        List<String> seriesNameList = new ArrayList<>();
        list.forEach(seriesClaim -> seriesNameList.add(seriesClaim.getSeriesName()));
        vo.setSeriesNames(seriesNameList);
        return JsonResult.success(vo);
    }
}
