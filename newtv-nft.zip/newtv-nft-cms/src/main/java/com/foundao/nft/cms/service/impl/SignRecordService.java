package com.foundao.nft.cms.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.conditions.query.LambdaQueryChainWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.common.constant.FoundaoConstant;
import com.foundao.nft.common.model.vo.SignRecordStatsVO;
import com.foundao.nft.common.util.SortUtil;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.PageResponseListVo;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.cms.mapper.SignRecordMapper;
import com.foundao.nft.common.model.SignRecord;
/**
    @Package: com.foundao.nft.cms.service.impl
    @ClassName: SignRecordService
    @Author: chenli
    @CreateTime: 2022/9/23 4:40 下午
    @Description:
*/
@Service
public class SignRecordService extends ServiceImpl<SignRecordMapper, SignRecord> {

    public PageResponseListVo<SignRecordStatsVO> signRecordPage(BaseRequestVo request) {
        Page<SignRecordStatsVO> page = new Page<>(request.getPage(),request.getNum());
        SortUtil.handlePageSort(request, page, "id", FoundaoConstant.ORDER_DESC, true);
        IPage<SignRecordStatsVO> resultList = baseMapper.signRecordPage(page,request);
        long total = resultList.getTotal();
        return PageResponseListVo.createPageResponseListVo(resultList.getRecords(), total);
    }

    public PageResponseListVo<SignRecord> signRecordByUserPage(BaseRequestVo request,Integer userId){
        Page<SignRecord> page = new Page<>(request.getPage(),request.getNum());
        SortUtil.handlePageSort(request, page, "id", FoundaoConstant.ORDER_DESC, true);
        LambdaQueryWrapper<SignRecord> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(SignRecord::getUserId,userId);
        IPage<SignRecord> resultList = baseMapper.selectPage(page,wrapper);
        long total = resultList.getTotal();
        return PageResponseListVo.createPageResponseListVo(resultList.getRecords(), total);
    }
}
