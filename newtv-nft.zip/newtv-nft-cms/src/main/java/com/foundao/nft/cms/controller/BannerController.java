package com.foundao.nft.cms.controller;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.toolkit.ChainWrappers;
import com.foundao.nft.cms.service.impl.BannerService;
import com.foundao.nft.common.model.AppVersion;
import com.foundao.nft.common.model.Banner;
import com.foundao.nft.common.util.RedisKeyFactory;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.JsonResult;
import com.tx.core.beans.PageResponseListVo;
import com.tx.core.enums.errcode.ParamErrorEnum;
import com.tx.redis.service.RedisService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

/**
 * @Package: com.foundao.nft.cms.controller
 * @ClassName: BannerController
 * @Author: chenli
 * @CreateTime: 2022/6/7 11:11 上午
 * @Description:
 */
@RestController
@RequiredArgsConstructor
@Api(tags = "banner相关")
@RequestMapping("/banner")
@Slf4j
@Validated
public class BannerController {

    private final BannerService bannerService;
    private final RedisService redisService;

    @ApiOperation("banner列表")
    @GetMapping("/list")
    public JsonResult<PageResponseListVo<Banner>> pageBanner(BaseRequestVo request){
        return JsonResult.success(bannerService.pageBanner(request));
    }

    @ApiOperation("新增或更新banner")
    @PostMapping("/save")
    public JsonResult<Void> pageBanner(@RequestBody Banner banner){
        if (banner.getBannerId()==null) {
            banner.setShowStatus(0);
            banner.setCreateTime(DateUtil.now());
        } else {
            Banner oldBanner = bannerService.getById(banner.getBannerId());
            if (oldBanner==null) {
                return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"banner不存在");
            }
            if (oldBanner.getType()!=null && oldBanner.getType()==0) {
                banner.setH5Url(null);
            }
            banner.setType(null);
            banner.setCreateTime(null);
        }
        bannerService.saveOrUpdate(banner);
        redisService.del(RedisKeyFactory.getBannerKey());
        return JsonResult.success();
    }

    @ApiOperation("上线或下线banner")
    @PostMapping("/online")
    public JsonResult<Void> online(String bannerId,Integer showStatus){
        //更新状态
        if(showStatus !=0 && showStatus != 1){
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"状态传递不正确");
        }
        Banner banner = bannerService.getById(bannerId);
        if (banner.getShowStatus()==showStatus) {
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"状态传递不正确");
        }
        int count = bannerService.count(new LambdaQueryWrapper<Banner>().eq(Banner::getShowStatus, 1));
        if (showStatus==1) {
            if (count>2) {
                return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"展示的banner个数超过限制");
            }
        }
        if (showStatus==0) {
            if (count==1) {
                return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"至少要保留一个banner");
            }
        }
        banner.setShowStatus(showStatus);
        bannerService.updateById(banner);
        redisService.del(RedisKeyFactory.getBannerKey());
        return JsonResult.success();
    }
}
