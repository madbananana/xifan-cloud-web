package com.foundao.nft.cms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.foundao.nft.cms.vo.AppointmentDetailsVO;
import com.foundao.nft.common.model.AdvanceBuy;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
    @Package: com.foundao.nft.cms.mapper
    @ClassName: AdvanceBuyMapper
    @Author: chenli
    @CreateTime: 2022/4/14 4:48 下午
    @Description:
*/
@Mapper
public interface AdvanceBuyMapper extends BaseMapper<AdvanceBuy> {
    List<AppointmentDetailsVO> stats();

    Integer selectAppointmentCount(String seriesId);
}