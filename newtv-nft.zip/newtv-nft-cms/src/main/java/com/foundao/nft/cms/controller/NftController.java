package com.foundao.nft.cms.controller;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.io.FileUtil;
import cn.hutool.core.util.IdUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.extension.toolkit.ChainWrappers;
import com.foundao.nft.cms.service.impl.*;
import com.foundao.nft.cms.vo.SeriesBaseQueryVO;
import com.foundao.nft.cms.vo.SeriesListVO;
import com.foundao.nft.common.constant.FileTypeEnum;
import com.foundao.nft.common.model.*;
import com.foundao.nft.common.model.vo.*;
import com.foundao.nft.common.properties.NftProperties;
import com.foundao.nft.common.util.FileTypeUtil;
import com.foundao.nft.common.util.NftCommonUtil;
import com.foundao.nft.common.util.RedisKeyFactory;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.JsonResult;
import com.tx.core.beans.PageResponseListVo;
import com.tx.core.enums.errcode.ApiStatusErrorEnum;
import com.tx.core.enums.errcode.ParamErrorEnum;
import com.tx.core.exception.BusException;
import com.tx.redis.service.RedisService;
import com.tx.security.bean.AuthUser;
import com.tx.security.util.SecurityUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.http.HttpStatus;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.io.File;
import java.io.IOException;
import java.util.*;

@RestController
@RequiredArgsConstructor
@Api(tags = "nft")
@RequestMapping("nft")
@Slf4j
@Validated
public class NftController {

    private final NftProperties nftProperties;
    private final NftSeriesClaimService seriesClaimService;
    private final NftCommonUtil nftCommonUtil;
    private final NftRecordService recordService;
    private final NftMetadataService nftMetadataService;
    private final BrandService brandService;
    private final GoodsService goodsService;
    private final NftOrderService orderService;
    private final RedisService redisService;

    @ApiOperation("系列声明")
    @PostMapping("seriesClaim")
    public JsonResult<Void> seriesClaim(@Validated @RequestBody SeriesClaimVO seriesClaimVO){
        AuthUser<CmsUser> currentUser = SecurityUtil.getCurrentUser();
        //判断系列的名称是否是唯一的
        NftSeriesClaim bySeriesName = seriesClaimService.getBySeriesName(seriesClaimVO.getSeriesName());
        if(bySeriesName != null){
            if(seriesClaimVO.getId() == null || bySeriesName.getId().intValue() != seriesClaimVO.getId()){
                return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"该系列名称已经存在");
            }
        }
        if (seriesClaimVO.getMetaType()!=null && seriesClaimVO.getMetaType()==3) {
            seriesClaimVO.setCharge(0);
            if (StrUtil.isBlank(seriesClaimVO.getAppleName()) && seriesClaimVO.getPrice()==null) {
                return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"盲盒系列必须设置价格");
            }
            if (StrUtil.isBlank(seriesClaimVO.getOpenTime())) {
                return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"盲盒系列必须设置开启时间");
            }

            if (StrUtil.isBlank(seriesClaimVO.getBlindBoxIcon())) {
                return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"盲盒预览图不能为空");
            }
            //if (seriesClaimVO.getBeginTime().compareTo(seriesClaimVO.getOpenTime())>0) {
            //    return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"开启时间必须大于开始时间");
            //}
            //if (seriesClaimVO.getEndTime().compareTo(seriesClaimVO.getOpenTime())>0) {
            //    return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"开启时间必须大于结束时间");
            //}
        }

        if (seriesClaimVO.getBeginTime().compareTo(seriesClaimVO.getEndTime())>0) {
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"开始时间不能大于结束时间");
        }

        NftSeriesClaim nftSeriesClaim;
        if(seriesClaimVO.getId() != null){
            nftSeriesClaim = seriesClaimService.getById(seriesClaimVO.getId());
            if(nftSeriesClaim == null){
                throw new BusException("修改的系列不存在");
            }
            if(nftSeriesClaim.getTaskStatus() != 10){
                throw new BusException("该系列当前状态不允许重新发布,只有失败状态的系列才能重新发布");
            }
        }else{
            nftSeriesClaim = new NftSeriesClaim();
        }
        BeanUtils.copyProperties(seriesClaimVO,nftSeriesClaim);

        List<String> imageDesc = seriesClaimVO.getImageDesc();
        nftSeriesClaim.setImageDesc(JSON.toJSONString(imageDesc));
        nftSeriesClaim.setTotalCount(0);
        Goods one = null;
        if (seriesClaimVO.getMetaType()!=null && seriesClaimVO.getMetaType()==3) {
            if (seriesClaimVO.getIosPayType()!=null && seriesClaimVO.getIosPayType()==0) {
                one = new Goods();
                one.setPrice(seriesClaimVO.getPrice());
            } else {
                one = ChainWrappers.lambdaQueryChain(goodsService.getBaseMapper())
                        .eq(Goods::getAppleName, nftSeriesClaim.getAppleName())
                        .last("limit 1")
                        .one();
            }
        }
        if (one!=null) {
            nftSeriesClaim.setPrice(one.getPrice());
        }
        seriesClaimService.seriesClaim(nftSeriesClaim,currentUser.getUserDetails());
        return JsonResult.success();
    }

    @ApiOperation("系列上下线")
    @PostMapping("/seriesOnline")
    public JsonResult<?> seriesOnline(@RequestParam("id") Integer id,@RequestParam("showStatus") Integer showStatus){
        //更新状态
        if(showStatus !=0 && showStatus != 1 && showStatus !=2){
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"上下线状态传递不正确");
        }
        NftSeriesClaim seriesClaim = seriesClaimService.getById(id);
        Integer count = ChainWrappers.lambdaQueryChain(nftMetadataService.getBaseMapper())
                .eq(NftMetadata::getSeriesId, seriesClaim.getSeriesId())
                .eq(NftMetadata::getTaskStatus,7)
                .eq(NftMetadata::getShowStatus,1)
                .count();
        if (seriesClaim.getShowStatus()==0) {
            if (showStatus==1) {
                return JsonResult.error(HttpStatus.INTERNAL_SERVER_ERROR.value(),"系列不能直接上线，请先设置为预上线状态");
            }
        }
        if (showStatus==1 || showStatus==2) {
            if (count==0) {
                return JsonResult.error(HttpStatus.INTERNAL_SERVER_ERROR.value(),"系列下不存在在售的nft，不能上线");
            }
        }
        seriesClaim.setShowStatus(showStatus);
        seriesClaimService.updateById(seriesClaim);
        redisService.del(RedisKeyFactory.getSeriesPriceInfoKey(seriesClaim.getSeriesId()));
        redisService.del("newtv-nft:series:"+seriesClaim.getSeriesId());
        redisService.del("newtv-nft:series:short:"+seriesClaim.getId());
        return JsonResult.success();
    }

    @ApiOperation("nft上下线")
    @PostMapping("/nftOnline")
    public JsonResult<?> nftOnline(@RequestParam("metaId") Integer metaId,@RequestParam("showStatus") Integer showStatus){
        //更新状态
        if(showStatus !=0 && showStatus != 1){
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"showStatus不正确");
        }
        NftMetadata metadata = nftMetadataService.getById(metaId);
        if (metadata.getShowStatus()==showStatus) {
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"状态传递错误");
        }
        if (showStatus==1) {
            if (metadata.getTaskStatus()!=7) {
                return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"该藏品未发行成功，不能上线");
            }
        } else {
            Integer count = ChainWrappers.lambdaQueryChain(nftMetadataService.getBaseMapper())
                    .eq(NftMetadata::getSeriesId, metadata.getSeriesId())
                    .eq(NftMetadata::getShowStatus, 1)
                    .count();
            if (count==1) {
                return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"该系列下只存在当前藏品，请直接下线系列");
            }
        }

        metadata.setShowStatus(showStatus);
        nftMetadataService.updateById(metadata);
        NftSeriesClaim seriesClaim = seriesClaimService.getBySeriesId(metadata.getSeriesId());
        if (seriesClaim.getMetaType()==3) {
            if (showStatus==1) {
                redisService.incr(RedisKeyFactory.getSeriesStockKey(seriesClaim.getId()), Long.valueOf(metadata.getShowCount()));
            } else {
                redisService.decr(RedisKeyFactory.getSeriesStockKey(seriesClaim.getId()), Long.valueOf(metadata.getShowCount()));
            }
        }
        //Integer showCount = (Integer) redisService.hget(RedisKeyFactory.getShowCountKey(), metadata.getMetaId() + "");
        //if (showCount==null) {
        //    showCount = metadata.getPublishCount();
        //}
        if (showStatus==1) {
            seriesClaim.setTotalCount(seriesClaim.getTotalCount()+metadata.getPublishCount());
        } else {
            seriesClaim.setTotalCount(seriesClaim.getTotalCount()-metadata.getPublishCount());
        }
        seriesClaimService.updateById(seriesClaim);
        redisService.del(RedisKeyFactory.getSeriesPriceInfoKey(metadata.getSeriesId()));

        return JsonResult.success();
    }


    @ApiOperation("上传素材")
    @PostMapping("uploadToCos")
    public JsonResult<?> uploadToCos(UploadToCosVO request) throws IOException {
        if(request.getFile() == null) {
             return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"请上传文件");
        }
        String oriFileName = request.getFile().getOriginalFilename();
        //1.上传文件到本地
        String fileName = IdUtil.simpleUUID() + "." + FileUtil.extName(oriFileName);
        File path = new File(nftProperties.getTempFilePath());
        if(!path.exists()){
            boolean isSuccess = path.mkdirs();
            if(!isSuccess){
                return JsonResult.error(HttpStatus.INTERNAL_SERVER_ERROR.value(),"目录:"+nftProperties.getTempFilePath()+"创建失败");
            }
        }
        String finalFilePath = nftProperties.getTempFilePath() +"/"+fileName;
        File file = new File(finalFilePath);
        request.getFile().transferTo(file);
        if(!file.exists()){
            log.error("文件删除之后不存在");
            return JsonResult.error(HttpStatus.INTERNAL_SERVER_ERROR.value(),"上传素材失败");
        }
        String cosKey = "material/"+fileName;
        String fileUrl = nftCommonUtil.uploadToCos(cosKey, finalFilePath);
        if(StrUtil.isNotBlank(fileUrl)){
            Map<String,Object> res = new HashMap<>(2);
            res.put("fileUrl",fileUrl);
            return JsonResult.success(res);
        }else{
            return JsonResult.error(HttpStatus.INTERNAL_SERVER_ERROR.value(),"上传素材失败");
        }
    }


    @ApiOperation("发行nft")
    @PostMapping("publish")
    public JsonResult<Void> publish(@Validated @RequestBody NftPublishVO publishVO){
        AuthUser<CmsUser> currentUser = SecurityUtil.getCurrentUser();
        //判断系列的名称是否是唯一的
        //if (publishVO.getMetaType()!=4) {
        //    if (StrUtil.isBlank(publishVO.getSeriesId())) {
        //        throw new BusException("系列ID不能为空");
        //    }
        //    NftMetadata oldNftMetadata = nftMetadataService.getNftByName(publishVO.getName(),publishVO.getSeriesId());
        //    if(oldNftMetadata != null){
        //        if(oldNftMetadata.getMetaId() == null || oldNftMetadata.getMetaId().intValue() != oldNftMetadata.getMetaId()){
        //            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"该nft名称已经存在");
        //        }
        //    }
        //
        //}

        NftMetadata nftMetadata;
        if(publishVO.getMetaId() == null){
            nftMetadata = new NftMetadata();
        }else{
            nftMetadata = nftMetadataService.getById(publishVO.getMetaId());
            if(nftMetadata == null){
                throw new BusException("不存在的nft");
            }
            if(nftMetadata.getTaskStatus() != 10){
                //只有失败才能重新发布，否则不允许重新发布
                throw new BusException("该nft当前状态不允许重新发布,只有失败状态的nft才能重新发布");
            }
        }
        NftSeriesClaim seriesClaim = null;
        if (publishVO.getMetaType()==4) {
            //seriesClaim = seriesClaimService.getById(2);
            //if (seriesClaim==null) {
            //    throw new BusException("合成系列不存在");
            //}
            //publishVO.setSeriesId(seriesClaim.getSeriesId());
            //if (CollectionUtils.isEmpty(publishVO.getRecipeMaterials())) {
            //    throw new BusException("合成原料为必填项");
            //}
            //
            //publishVO.getRecipeMaterials().forEach( material -> {
            //    NftMetadata byMetaId = nftMetadataService.getByMetaId(material.getMetaId() + "");
            //    if (byMetaId==null) {
            //        throw new BusException("藏品不存在");
            //    }
            //    if (!Objects.equals(byMetaId.getShortSeriesId(),material.getSeriesId())) {
            //        throw new BusException("藏品所属系列填写错误");
            //    }
            //    if (material.getCount()<1) {
            //        throw new BusException("合成所需份数填写错误");
            //    }
            //});
            //nftMetadata.setMetaData(JSON.toJSONString(publishVO.getRecipeMaterials()));
        } else {
            seriesClaim = seriesClaimService.getBySeriesId(publishVO.getSeriesId());

        }
        if (seriesClaim==null) {
            throw new BusException("父系列不存在");
        }

        //1.获取文件地址
        FileTypeEnum fileTypeEnum = FileTypeUtil.getTypeByUrl(publishVO.getUrl());
        if(!FileTypeUtil.checkType(fileTypeEnum,FileTypeEnum.PNG,FileTypeEnum.JPEG,FileTypeEnum.MP4,FileTypeEnum.MOV)){
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"视频请上传mp4,mov,图片请上传jpeg,jpg,png");
        }
        //0 图片 1 视频
        int type = fileTypeEnum == FileTypeEnum.MP4 || fileTypeEnum == FileTypeEnum.MOV ? 1 : 0;


        BeanUtils.copyProperties(publishVO, nftMetadata);
        nftMetadata.setShortSeriesId(seriesClaim.getId());
        if (nftMetadata.getShowCount()==null) {
            nftMetadata.setShowCount(nftMetadata.getPublishCount());
        }
        if (nftMetadata.getShowCount()>nftMetadata.getPublishCount()) {
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"展示份数不能大于发行份数");
        }
        nftMetadata.setImageDesc(JSON.toJSONString(publishVO.getImageDesc()));
        nftMetadata.setType(type);
        String goodsId;
        Goods goods = null;
        if (seriesClaim.getIosPayType()!=null && seriesClaim.getIosPayType()==0) {
            goods = new Goods();
            if (seriesClaim.getMetaType()==3) {
                goods.setPrice(seriesClaim.getPrice());
            } else {
                goods.setPrice(publishVO.getSellFee());
            }
        }else {
            if (seriesClaim.getMetaType()==3) {
                goods = goodsService.lambdaQuery()
                        .eq(Goods::getAppleName, seriesClaim.getAppleName())
                        .last("limit 1")
                        .one();
            } else {
                if (StrUtil.isNotBlank(publishVO.getGoodsId())) {
                    goods = goodsService.getById(publishVO.getGoodsId());
                }
            }
        }

        //收费
        if (seriesClaim.getCharge()==0) {
            if (goods==null || goods.getPrice()==0) {
                return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"该系列为收费系列，请选择合适的商品");
            }
            nftMetadata.setSellFee(goods.getPrice());
            nftMetadata.setAppleName(goods.getAppleName());
        }

        if (seriesClaim.getMetaType()==3) {

            if (!Objects.equals(seriesClaim.getPrice(),nftMetadata.getSellFee())) {
                return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"盲盒系列下的藏品价格必须一致");
            }
            //if (!seriesClaim.getAppleName().equals(nftMetadata.getAppleName())) {
            //    return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"盲盒系列下的藏品价格必须一致");
            //}
        }

        //免费
        if (seriesClaim.getCharge()==1) {
            //if (goods!=null) {
            //    if (goods.getPrice()>0) {
            //        return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"该系列为免费系列，请选择免费商品");
            //    }
            //}
            nftMetadata.setSellFee(0);
            nftMetadata.setAppleName("free");
        }

        NftMetadata nftMetadata1 = nftMetadataService.publishNftMetaData(nftMetadata, currentUser.getUserDetails());
        if (nftMetadata1==null) {
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"发行nft失败");
        }
        return JsonResult.success();
    }

//    @ApiOperation("批量发行nft")
//    @PostMapping("publish/batch")
//    public JsonResult<Void> publishBatch(@RequestBody List<NftPublishVO> publishs){
//        if (publishs==null || publishs.size()==0) {
//            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"参数输入错误");
//        }
//        AuthUser<CmsUser> currentUser = SecurityUtil.getCurrentUser();
//        for (NftPublishVO publishVO:publishs) {
//
//            //判断系列的名称是否是唯一的
//            NftMetadata oldNftMetadata = nftMetadataService.getNftByName(publishVO.getName(),publishVO.getSeriesId());
//            if(oldNftMetadata != null){
//                if(oldNftMetadata.getMetaId() == null || oldNftMetadata.getMetaId().intValue() != oldNftMetadata.getMetaId()){
//                    return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"该nft名称已经存在");
//                }
//            }
//            NftMetadata nftMetadata;
//            if(publishVO.getMetaId() == null){
//                nftMetadata = new NftMetadata();
//            }else{
//                nftMetadata = nftMetadataService.getById(publishVO.getMetaId());
//                if(nftMetadata == null){
//                    throw new BusException("不存在的nft");
//                }
//                if(nftMetadata.getTaskStatus() != 10){
//                    //只有失败才能重新发布，否则不允许重新发布
//                    throw new BusException("该nft当前状态不允许重新发布,只有失败状态的nft才能重新发布");
//                }
//            }
//            BeanUtils.copyProperties(publishVO, nftMetadata);
//            nftMetadataService.publishNftMetaData(nftMetadata,currentUser.getUserDetails());
//        }
//        return JsonResult.success();
//    }


    @ApiOperation("系列分页列表")
    @PostMapping("/series/list")
    @ApiOperationSupport(includeParameters = {"page","num","advanceBuy","exchange","keyword"})
    public JsonResult<PageResponseListVo<SeriesListVO>> seriesList(BaseRequestVo request,SeriesBaseQueryVO baseQuery){
        if (baseQuery.getAdvanceBuy()!=null) {
            if (baseQuery.getAdvanceBuy()==1 || baseQuery.getAdvanceBuy()==0) {
                request.getMultiValueSearch().put("advanceBuy",baseQuery.getAdvanceBuy());
            }
        }
        if (baseQuery.getExchange()!=null) {
            if (baseQuery.getExchange()==1 || baseQuery.getExchange()==0) {
                request.getMultiValueSearch().put("exchange",baseQuery.getExchange());
            }
        }
        if (baseQuery.getCharge()!=null) {
            if (baseQuery.getCharge()==1 || baseQuery.getCharge()==0) {
                request.getMultiValueSearch().put("exchange",baseQuery.getExchange());
            }
        }
        if (baseQuery.getMetaType()!=null) {
            request.getMultiValueSearch().put("exchange",baseQuery.getExchange());
        }
        return JsonResult.success(seriesClaimService.pageSeries(request));
    }

    @ApiOperation("NFT分页列表")
    @PostMapping("/nft/list")
    @ApiOperationSupport(includeParameters = {"page","num","seriesId"})
    public JsonResult<PageResponseListVo<NftListVO>> list(BaseRequestVo request,String seriesId){
        if (StrUtil.isNotBlank(seriesId)) {
            request.getMultiValueSearch().put("seriesId",seriesId);
        }
        return JsonResult.success(nftMetadataService.pageList(request));
    }

    @ApiOperation("品牌分页列表")
    @PostMapping("/brand/list")
    @ApiOperationSupport(includeParameters = {"page","num"})
    public JsonResult<PageResponseListVo<BrandVO>> brandList(BaseRequestVo request){
        return JsonResult.success(brandService.pageList(request));
    }

    @ApiOperation("添加或更新品牌方")
    @PostMapping("/brand/add")
    public JsonResult<Void> addBrand(@Validated Brand brand){
        brandService.saveOrUpdate(brand);
        return JsonResult.success();
    }

    @ApiOperation("品牌详情")
    @PostMapping("/brand/details")
    public JsonResult<BrandDetailsVO> brandDetails(@RequestParam String id){
        Brand brand = brandService.getById(id);
        List<NftSeriesClaim> list = ChainWrappers.lambdaQueryChain(seriesClaimService.getBaseMapper())
                .eq(NftSeriesClaim::getBrandId, brand.getId())
                .select(NftSeriesClaim::getSeriesName)
                .list();
        BrandDetailsVO vo = new BrandDetailsVO();
        BeanUtil.copyProperties(brand,vo);
        List<String> seriesNameList = new ArrayList<>();
        list.forEach(seriesClaim -> seriesNameList.add(seriesClaim.getSeriesName()));
        vo.setSeriesNames(seriesNameList);
        return JsonResult.success(vo);
    }

    @ApiOperation("内购分页列表")
    @PostMapping("/goods/list")
    @ApiOperationSupport(includeParameters = {"page","num"})
    public JsonResult<PageResponseListVo<Goods>> goodsList(BaseRequestVo request){
        return JsonResult.success(goodsService.pageList(request));
    }

    @ApiOperation("添加内购")
    @PostMapping("/goods/add")
    public JsonResult<Void> addBrand(@Validated Goods goods){
        goodsService.save(goods);
        return JsonResult.success();
    }

    @ApiOperation("查询系列基础信息列表")
    @GetMapping("/series/list/base")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "charge",value = "是否免费0：收费1：免费"),
            @ApiImplicitParam(name = "metaType",value = "1：普通3：盲盒"),
            @ApiImplicitParam(name = "advanceBuy",value = "0:不可预约1：可预约")
    })
    public JsonResult<List<SeriesBaseVO>> listSeriesBaseVO(SeriesBaseQueryVO baseQuery){
        List<SeriesBaseVO> list = seriesClaimService.listBase(baseQuery);
        return JsonResult.success(list);
    }

    @ApiOperation("查询藏品基础信息列表")
    @GetMapping("/meta/list/base")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id",value = "系列id"),
    })
    public JsonResult<List<NftMetaDataBaseVO>> nftBaseVO(Integer id,Integer metaType){
//        NftSeriesClaim seriesClaim = seriesClaimService.getById(id);
//        if (seriesClaim==null) {
//            throw new BusException("系列不存在");
//        }
        List<NftMetaDataBaseVO> list = nftMetadataService.listBase(id,metaType);
        return JsonResult.success(list);
    }

    @ApiOperation("查询系列详情")
    @GetMapping("/series/details")
    @ApiOperationSupport(includeParameters = {"id"})
    public JsonResult<NftSeriesClaim> seriesDetails(@RequestParam("id") Integer id){
        NftSeriesClaim seriesClaim = seriesClaimService.getById(id);
        nftMetadataService.countRestCount(seriesClaim.getSeriesId());
        return JsonResult.success(seriesClaim);
    }

    @ApiOperation("更新系列")
    @PostMapping("/series/update")
    public JsonResult<Void> updateSeries(@RequestBody SeriesUpdateVO vo){
        NftSeriesClaim seriesClaim = seriesClaimService.getById(vo.getId());

        if (seriesClaim.getShowStatus()!=0) {
            vo.setBeginTime(null);
            vo.setEndTime(null);
            //if (!seriesClaim.getBeginTime().equals(vo.getBeginTime()) || !seriesClaim.getEndTime().equals(vo.getEndTime())) {
            //    if (vo.getBeginTime()!=null||vo.getEndTime()!=null) {
            //        return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"只有下线的系列才能修改发售时间");
            //    }
            //}
        }

        if (DateUtil.compare(DateUtil.parseDate(seriesClaim.getBeginTime()),new Date())<0) {
            //if (vo.getBuyCount()!=null) {
            //    if (seriesClaim.getBuyCount()!=vo.getBuyCount().intValue()) {
            //        return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"已经开售的系列不允许修改可购买数量");
            //    }
            //}
            vo.setBuyCount(null);
        }

        if (seriesClaim.getAdvanceBuy()==1) {
            //if (!seriesClaim.getBeginTime().equals(vo.getBeginTime()) || !seriesClaim.getEndTime().equals(vo.getEndTime())) {
            //    if (vo.getBeginTime()!=null||vo.getEndTime()!=null) {
            //        return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"可预约系列不允许修改发售时间");
            //    }
            //}
            vo.setBeginTime(null);
            vo.setEndTime(null);
        } else {
            if (vo.getBeginTime()!=null&&vo.getEndTime()!=null) {
                if (vo.getBeginTime().compareTo(vo.getEndTime())>0) {
                    return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"开始时间不能大于结束时间");
                }
            }
        }
        if (vo.getImageDesc()!=null && vo.getImageDesc().size()==0) {
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"系列描述图不能为空");
        }
        BeanUtil.copyProperties(vo,seriesClaim);
        seriesClaim.setImageDesc(JSON.toJSONString(vo.getImageDesc()));
        seriesClaim.setCategoryId(vo.getCategoryId());
        seriesClaim.setBlindBoxIcon(vo.getBlindBoxIcon());
        seriesClaim.setOpenTime(vo.getOpenTime());
        seriesClaim.setShowCountInfo(vo.getShowCountInfo());
        seriesClaim.setShowPublishCount(vo.getShowPublishCount());
        seriesClaimService.updateById(seriesClaim);
        redisService.del("newtv-nft:series:short:"+seriesClaim.getId());
        return JsonResult.success();
    }

    @ApiOperation("查询nft详情")
    @GetMapping("/nft/details")
    @ApiOperationSupport(includeParameters = {"id"})
    public JsonResult<NftMetadata> nftDetails(@RequestParam("id") Integer id){
        NftMetadata metadata = nftMetadataService.getById(id);
        Integer count = (Integer) redisService.hget(RedisKeyFactory.getShowCountKey(), metadata.getMetaId() + "");
        if (count!=null && count!=0) {
            metadata.setTotalShowCount(count);
        }
        return JsonResult.success(metadata);
    }

    @ApiOperation("更新nft")
    @PostMapping("/nft/update")
    public JsonResult<Void> updateNft(@Validated @RequestBody NftUpdateVO vo){
        NftMetadata metadata = nftMetadataService.getById(vo.getMetaId());
        if (vo.getImageDesc()==null || vo.getImageDesc().size()==0) {
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"藏品描述图为空");
        }
        metadata.setImageDesc(JSON.toJSONString(vo.getImageDesc()));
        if (vo.getMetaType()!=null) {
            if (vo.getMetaType()==1 || vo.getMetaType()==3) {
                metadata.setMetaType(vo.getMetaType());
            }
        }
        nftMetadataService.updateById(metadata);
        return JsonResult.success();
    }

    @ApiOperation("交易流水")
    @PostMapping("/trade/list")
    public JsonResult<PageResponseListVo<TradeCapitalInfoVO>> tradeList(BaseRequestVo requestVo){
        PageResponseListVo<TradeCapitalInfoVO> tradeList = orderService.tradeList(requestVo);
        return JsonResult.success(tradeList);
    }

}
