package com.foundao.nft.cms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.common.model.Issuer;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface IssuerMapper extends BaseMapper<Issuer> {
    IPage<Issuer> pageList(Page<Issuer> page);
}
