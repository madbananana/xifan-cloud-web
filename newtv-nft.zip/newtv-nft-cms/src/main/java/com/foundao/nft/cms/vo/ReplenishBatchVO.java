package com.foundao.nft.cms.vo;

import lombok.Data;

/**
 * @Package: com.foundao.nft.cms.vo
 * @ClassName: ReplenishBatchVO
 * @Author: chenli
 * @CreateTime: 2022/7/22 10:04 上午
 * @Description:
 */
@Data
public class ReplenishBatchVO {
}
