package com.foundao.nft.cms.service.impl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.cms.mapper.UserDeleteMapper;
import com.foundao.nft.common.model.UserDelete;
/**
    @Package: com.foundao.nft.cms.service.impl
    @ClassName: UserDeleteService
    @Author: chenli
    @CreateTime: 2022/4/14 6:24 下午
    @Description:
*/
@Service
public class UserDeleteService extends ServiceImpl<UserDeleteMapper, UserDelete> {

}
