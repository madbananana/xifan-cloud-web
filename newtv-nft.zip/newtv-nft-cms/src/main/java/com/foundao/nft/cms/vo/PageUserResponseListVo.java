package com.foundao.nft.cms.vo;

import com.tx.core.beans.PageResponseListVo;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @Package: com.foundao.nft.cms.vo
 * @ClassName: PageUserResponseListVo
 * @Author: chenli
 * @CreateTime: 2022/4/25 2:53 下午
 * @Description:
 */
@Data
@ApiModel
public class PageUserResponseListVo<T> extends PageResponseListVo<T> {

    @ApiModelProperty("全局禁止标志 0：未禁止 1：禁止")
    private Integer globalInhibit;

    public PageUserResponseListVo(Long total, List<T> list) {
        super(total,list);
    }
}
