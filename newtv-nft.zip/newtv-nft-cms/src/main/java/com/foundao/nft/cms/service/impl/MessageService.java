package com.foundao.nft.cms.service.impl;

import cn.hutool.core.util.RandomUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSONObject;
import com.foundao.nft.common.model.AdvanceBuy;
import com.foundao.nft.common.model.NftUser;
import com.foundao.nft.common.model.vo.SendMessageVO;
import com.foundao.nft.common.model.vo.SendMsgResponse;
import com.foundao.nft.common.model.vo.SendMsgV2Response;
import com.foundao.nft.common.properties.MsgProperties;
import com.foundao.nft.common.util.RedisKeyFactory;
import com.foundao.nft.common.util.newtv.UnifyPayUtil;
import com.tx.redis.service.RedisService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @Package: com.foundao.nft.cms.service.impl
 * @ClassName: MessageService
 * @Author: chenli
 * @CreateTime: 2022/6/28 3:44 下午
 * @Description:
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class MessageService {

    private final RestTemplate restTemplate;
    private final MsgProperties properties;
    public SendMsgResponse sendNotice(List<NftUser> users,String notice) {
        log.info("发送短信通知："+users.size());
        List<String> mobileList = users.stream().map(NftUser::getMobile).collect(Collectors.toList());
        SendMsgResponse response = null;
        if (mobileList.size()>0) {
            String mobiles = StrUtil.join(",", mobileList);
            String url = properties.getRequestUrl()+"/api/sms/open/batchSend";
            // 配置参数
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            Map<String, String> param = new HashMap<>(5);
            param.put("appKey", properties.getAppKey());
            param.put("channel", "USER_CENTER");
            param.put("content", notice);
            param.put("mobile", mobiles);
            param.put("purpose", "MARKETING");
            HttpEntity<?> requestEntity = new HttpEntity<>(param,headers);
            String signValue = null;
            try {
                signValue = UnifyPayUtil.buildMapMsgSign(param,properties.getAppSecret());
            } catch (Exception e) {
                log.error("签名异常",e);
                e.printStackTrace();
            }
            param.put("sign", signValue);
            try {
                //response = new SendMsgResponse();
                //response.setResponse(true);
                //response.setStatusCode("1");
                response = restTemplate.postForObject(url,requestEntity,SendMsgResponse.class);
            } catch (Exception e) {
                log.error("短信群发失败",e);
            }
        } else {
            response = new SendMsgResponse();
            response.setMessage("未发送通知");
        }

        return response;
    }

    public SendMsgResponse sendNotice(String mobiles,String notice) {
        log.info("发送短信通知："+mobiles);
        SendMsgResponse response = null;
        if (mobiles.length()>0) {
            String url = properties.getRequestUrl()+"/api/sms/open/batchSend";
            // 配置参数
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            Map<String, String> param = new HashMap<>(5);
            param.put("appKey", properties.getAppKey());
            param.put("channel", "USER_CENTER");
            param.put("content", notice);
            param.put("mobile", mobiles);
            param.put("purpose", "MARKETING");
            HttpEntity<?> requestEntity = new HttpEntity<>(param,headers);
            String signValue = null;
            try {
                signValue = UnifyPayUtil.buildMapMsgSign(param,properties.getAppSecret());
            } catch (Exception e) {
                log.error("签名异常",e);
                e.printStackTrace();
            }
            param.put("sign", signValue);
            try {
                //response = new SendMsgResponse();
                //response.setResponse(true);
                //response.setStatusCode("1");
                response = restTemplate.postForObject(url,requestEntity,SendMsgResponse.class);
            } catch (Exception e) {
                log.error("短信群发失败",e);
            }
        } else {
            response = new SendMsgResponse();
            response.setMessage("未发送通知");
        }

        return response;
    }

    public SendMsgResponse sendMessage(String phone,String content) {
        SendMsgResponse response ;
        String url = properties.getRequestUrl()+"/api/sms/open/sendtext";
        // 配置参数
        MultiValueMap<String, String> param = new LinkedMultiValueMap<>(5);
        param.add("appKey", properties.getAppKey());
        param.add("channel", "USER_CENTER");
        param.add("content", content);
        param.add("mobile", phone);
        param.add("purpose", "MARKETING");
        String signValue = null;
        try {
            signValue = UnifyPayUtil.buildMapMsgSign(param,properties.getAppSecret());
        } catch (Exception e) {
            log.error("签名异常",e);
            e.printStackTrace();
        }
        param.add("sign", signValue);

        response = restTemplate.postForObject(url,param,SendMsgResponse.class);
        log.info("短信发送，请求：{},响应：{}",param,response);
        return response;
    }

    public SendMsgV2Response sendNoticeV2(String templateId, String mobile, String[] params) throws Exception {
        SendMessageVO vo = new SendMessageVO();
        SendMsgV2Response response ;
        String url = properties.getRequestUrl()+"/service/sms/send";
        // 配置参数
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        vo.setAppKey(properties.getAppKey());
        vo.setMobile(mobile);
        vo.setTemplateId(templateId);
        if (params==null || params.length==0) {
            vo.setTemplateParamSet(Collections.emptyList());
        } else {
            vo.setTemplateParamSet(Arrays.asList(params));
        }

        String signValue = UnifyPayUtil.buildMapMsgSignByJSON((JSONObject)JSONObject.toJSON(vo),properties.getAppSecret());
        vo.setSign(signValue);
        HttpEntity<?> requestEntity = new HttpEntity<>(vo,headers);
        response = restTemplate.postForObject(url,requestEntity,SendMsgV2Response.class);
        log.info("短信发送，请求：{},响应：{}",vo,response);
        return response;
    }
}
