package com.foundao.nft.cms.controller;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.io.FileUtil;
import cn.hutool.core.io.IoUtil;
import cn.hutool.core.io.file.PathUtil;
import cn.hutool.core.util.CharsetUtil;
import cn.hutool.core.util.IdUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.poi.excel.ExcelReader;
import cn.hutool.poi.excel.ExcelUtil;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.conditions.query.LambdaQueryChainWrapper;
import com.baomidou.mybatisplus.extension.conditions.update.LambdaUpdateChainWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.toolkit.ChainWrappers;
import com.foundao.nft.cms.mapper.NftMetadataMapper;
import com.foundao.nft.cms.service.impl.*;
import com.foundao.nft.common.constant.AvatarPartTypeEnum;
import com.foundao.nft.common.constant.IntegralTypeEnum;
import com.foundao.nft.common.constant.NftTypeMetaIdEnum;
import com.foundao.nft.common.constant.TaskEnum;
import com.foundao.nft.common.model.*;
import com.foundao.nft.common.model.sdk.client.NftService;
import com.foundao.nft.common.model.sdk.request.NftTransferRequest;
import com.foundao.nft.common.model.sdk.response.NftInfoResultResponse;
import com.foundao.nft.common.model.sdk.response.NftPublishTaskResultResponse;
import com.foundao.nft.common.model.sdk.response.SdkResponseBase;
import com.foundao.nft.common.model.sdk.response.SeriesTaskResultResponse;
import com.foundao.nft.common.model.sdk.response.SignByPriKeyResponse;
import com.foundao.nft.common.model.sdk.response.TaskResponse;
import com.foundao.nft.common.model.vo.AvatarPartAttr;
import com.foundao.nft.common.model.vo.NftPublishVO;
import com.foundao.nft.common.model.vo.SendMsgResponse;
import com.foundao.nft.common.model.vo.SendMsgV2Response;
import com.foundao.nft.common.properties.CustomProperties;
import com.foundao.nft.common.properties.NftProperties;
import com.foundao.nft.common.util.NftCommonUtil;
import com.foundao.nft.common.util.OssFactory;
import com.foundao.nft.common.util.RedisKeyFactory;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.JsonResult;
import com.tx.core.beans.PageResponseListVo;
import com.tx.core.enums.errcode.ApiStatusErrorEnum;
import com.tx.core.enums.errcode.ParamErrorEnum;
import com.tx.core.exception.BusException;
import com.tx.objectstorage.enums.OssAcl;
import com.tx.objectstorage.properties.OssPropertiesConfig;
import com.tx.objectstorage.service.ObjectStorageService;
import com.tx.redis.service.RedisService;
import com.tx.security.annotation.AnonymousGetMapping;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.File;
import java.io.FileInputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.stream.Stream;


/**
 * @Package: com.foundao.nft.cms.controller
 * @ClassName: OperationController
 * @Author: chenli
 * @CreateTime: 2022/1/11 5:55 下午
 * @Description:
 */
@RestController
@RequiredArgsConstructor
@Api(tags = "operation")
@RequestMapping("operation")
@Slf4j
@Validated
public class OperationController {

    private final NftSeriesClaimService nftSeriesClaimService;
    private final NftMetadataService nftMetadataService;
    private final NftService nftService;
    private final NftTaskService taskService;
    private final AvatarServiceImpl avatarService;
    private final NftMetadataMapper nftMetadataMapper;
    private final CustomProperties customProperties;
    private final OssPropertiesConfig ossPropertiesConfig;
    private final RedisService redisService;
    private final NftUserService userService;
    private final AppVersionService appVersionService;
    private final NftOrderService orderService;
    private final CategoryService categoryService;
    private final MessageService messageService;
    private final NftRecordService recordService;
    private final NftUserPlatformService userPlatformService;
    private final NftCommonUtil nftCommonUtil;
    private final NftProperties nftProperties;
    private final IntegralService integralService;
    private final IntegralRecordService integralRecordService;



    @ApiOperation("获取版本管理列表")
    @GetMapping("app/version/list")
    public JsonResult<PageResponseListVo<AppVersion>> appVersion(BaseRequestVo request,String deviceType){
        return JsonResult.success(appVersionService.pageAppVersion(request,deviceType));
    }

    @ApiOperation("新增app版本")
    @PostMapping("app/version/add")
    public JsonResult<Void> appVersion(AppVersion appVersion){
        if (appVersion.getDeviceType()==1) {
            if (appVersion.getDownUrl()==null) {
                return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"安卓app下载链接不能为空");
            }
        }
        String now = DateUtil.formatDateTime(new Date());
        if (appVersion.getExecuteNow()!=null && appVersion.getExecuteNow()==1) {
            appVersion.setBeginTime(now);
        } else {
            if (appVersion.getBeginTime()==null) {
                return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"更新时间不能为空");
            }
        }
        if (appVersion.getId()==null) {
            appVersion.setCreateTime(now);
        }
        appVersionService.saveOrUpdate(appVersion);
        return JsonResult.success();
    }


    @ApiOperation("翻转全局禁止用户修改信息状态")
    @GetMapping("toggleGlobalInhibit")
    public JsonResult<Integer> globalInhibit(){
        Integer status = (Integer) redisService.get(RedisKeyFactory.getGlobalInhibitKey());
        if (status == null) {
            status = 0;
        }
        Integer newStatus = 1-status;
        redisService.set(RedisKeyFactory.getGlobalInhibitKey(),newStatus);
        return JsonResult.success(newStatus);
    }

    @ApiOperation("新增白名单")
    @AnonymousGetMapping("addWhiteList")
    public JsonResult<Void> addWhiteList(String mobile){
        List<String> whiteList = (List<String>) redisService.get(RedisKeyFactory.getWhiteUserKey());
        if (whiteList==null) {
            whiteList = new ArrayList<>();
        }
        whiteList.add(mobile);
        redisService.set(RedisKeyFactory.getWhiteUserKey(),whiteList);
        return JsonResult.success();
    }

    @ApiOperation("新增补发白名单")
    @AnonymousGetMapping("addReplenishSet")
    public JsonResult<Void> addReplenishSet(String mobile){
        Set<String> whiteList = (Set<String>) redisService.get(RedisKeyFactory.getReplenishUserKey());
        if (whiteList==null) {
            whiteList = new HashSet<>();
        }
        whiteList.add(mobile);
        redisService.set(RedisKeyFactory.getReplenishUserKey(),whiteList);
        return JsonResult.success();
    }

    @ApiOperation("清理用户数据")
    @AnonymousGetMapping("clean")
    public JsonResult<Void> clean(String mobile){
        userService.clean(mobile);
        return JsonResult.success();
    }

    @ApiOperation("更改用户手机号")
    @PostMapping("modMobile")
    public JsonResult<Void> modMobile(String newMobile,String oldMobile){
        boolean flag = userService.modMobile(newMobile, oldMobile);
        log.info("手机号从 {} 变更为 {} ，结果{}",oldMobile,newMobile,flag?"成功":"失败");
        if (flag) {
            return JsonResult.success();
        }
        return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"修改手机号失败");
    }

    @ApiOperation("系列声明")
    @PostMapping("seriesClaim")
    public JsonResult<?> seriesClaim(String seriesName) {
        String lockFlag = (String) redisService.get("newtv-nft:init-series-claim");
        if (StrUtil.isBlank(lockFlag)) {
            Boolean lockSuccess = redisService.set("newtv-nft:init-series-claim", "lock");
            if (lockSuccess) {
//        系列图片路径
                String filePath = customProperties.getImagePath() + "系列声明图.jpg";
                String key = "material/"+IdUtil.simpleUUID()+ "."+FileUtil.extName(filePath);
                //头像系列特殊，直接默认id为1
                NftSeriesClaim firstNftSeriesClaim = nftSeriesClaimService.getById(1);
                if(firstNftSeriesClaim != null){
                    nftSeriesClaimService.removeById(1);
                }
                String imageUrl = tryUploadToCos(new File(filePath));
                //String imageUrl = nftCommonUtil.uploadToCos(key, filePath);
//        String imageUrl = "https://zhixinliantest-1302317679.cos.ap-guangzhou.myqcloud.com/nft/e63de5373a0c5b679decf9442ac6f91d1305400955da91acdf0c85c6a23d2963/newTv/material/be4e6705f3904be2bdc1cb0cbce92d4c.jpg";
                //1.声明牛头系列
                NftSeriesClaim seriesClaimVO = new NftSeriesClaim();
                seriesClaimVO.setMetaType(2);
                seriesClaimVO.setSeriesName(seriesName);
                seriesClaimVO.setBeginTime(DateUtil.now());
                seriesClaimVO.setCoverUrl(imageUrl);
                seriesClaimVO.setTotalCount(0);
                seriesClaimVO.setEndTime(DateUtil.formatDateTime(DateUtil.offsetDay(new Date(),10)));
                seriesClaimVO.setDesc("　　未来“牛翻天”数字头像，作为未来电视“十周年纪念款”NFT数字藏品，在2022年“开新”之时上线啦！\n" +
                        "　　在NFT数藏世界里，每一个形象都蕴含着面对未来独一无二的想象和态度，是数字时代每一个人的专属印记。\n" +
                        "　　因为唯一，弥足珍贵；因为想象，未来可期。十年探索与沉淀，十年创新与跨越，是每一位“未来家园”人的同心同行，让我们一起“开新”，共赴下一个十年。\n" +
                        "　　备注：此次未来“牛翻天”数字头像，发放对象为未来电视全体员工。");
                nftSeriesClaimService.seriesClaim(seriesClaimVO,new CmsUser(){{
                    setUserId(1);
                    setUsername("系统生成");
                }});
                nftSeriesClaimService.updateId(seriesClaimVO.getId(),1);
                //阻塞方式查询系列声明是否成功
                while(true){
                    NftSeriesClaim seriesClaim = nftSeriesClaimService.getById(1);
                    //NftSeriesClaim seriesClaim = nftSeriesClaimService.getById(seriesClaimVO.getId());
                    String taskId = seriesClaim.getTaskId();
                    NftTask task = taskService.getTaskByTaskId(taskId);
                    SdkResponseBase<SeriesTaskResultResponse> taskResult = nftService.seriesClaimResult(taskId);
                    if (taskResult.getRetCode()==0) {
                        SeriesTaskResultResponse result = taskResult.getData();
                        task.setStatus(result.getTaskStatus());
                        task.setChainTimestamp(new Date(result.getChainTimestamp()));
                        task.setTxHash(result.getTxHash());
                        task.setTaskMsg(result.getTaskMsg());
                        seriesClaim.setSeriesId(result.getSeriesId());
                        seriesClaim.setTaskStatus(result.getTaskStatus());
                        seriesClaim.setSeriesName("未来“牛翻天”数字头像");
                        seriesClaim.setTotalCount(600);

                        taskService.updateById(task);
                        nftSeriesClaimService.updateById(seriesClaim);
                        if(result.getTaskStatus() != 2){
                            if (result.getTaskStatus()==7) {
                                return JsonResult.success();
                            } else {
                                return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),result.getTaskMsg());
                            }

                            //break;
                        }
                        try {
                            TimeUnit.SECONDS.sleep(2);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
            } else {
                return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"任务正在执行，不要重复执行");
            }
        } else {
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"任务已锁定");
        }

    }

    @ApiOperation("导入头像素材")
    @PostMapping("importAvatar")
    public JsonResult<?> importAvatar(){
        //1.导入部件
        Map<String,String>  partPathNameMap = new LinkedHashMap<String, String>(){{
            put("道具","道具");
            put("耳机","耳机");
            put("头饰","头饰");
            put("眼镜","眼镜");
            put("衣服","衣服");
            put("背景","背景");
            put("完整背景","完整背景");
            put("人物","人物");
            put("十年老员工人物","人物");
            put("特殊头像","人物");
        }};
        Set<String> partPathNameList =partPathNameMap.keySet();
        partPathNameList.forEach(partPathName->{
            String dirPath = customProperties.getImagePath()+partPathName;
            File dirFile = new File(dirPath);
            List<File> files = PathUtil.loopFiles(dirFile.toPath(), null);
            log.info("目录：{} 文件数：{}",partPathName,files.size());
            files.forEach(file ->{
                String fileName = file.getName();
                String filePrefix = getFilePrefix(fileName);
                Integer codeByName = AvatarPartTypeEnum.getCodeByName(partPathNameMap.get(partPathName));
                if(codeByName != null && StrUtil.isNotBlank(filePrefix)){
                    AvatarPart avatarPart = avatarService.getAvatarPartByNameAndType(filePrefix, codeByName);
                    if (avatarPart == null) {
                        avatarPart = avatarService.getAvatarPartByPartNameAndType(filePrefix, codeByName);
                    }
                    if(avatarPart ==  null || StrUtil.isBlank(avatarPart.getUrl())){
                        if(avatarPart == null){
                            avatarPart = new AvatarPart();
                        }
                        //上传
                        String imageUrl =  tryUploadToCos(file);
                        if(StrUtil.isBlank(imageUrl)){
                            throw new BusException("上传文件异常-组件类型:"+ partPathName+" 组件号:"+fileName);
                        }

                        avatarPart.setCreateTime(new Date());
                        avatarPart.setPartType(codeByName);
                        avatarPart.setSourceFileName(filePrefix);
                        avatarPart.setUrl(imageUrl);
                        if(partPathName.equals("十年老员工人物")){
                            avatarPart.setSpecialType(1);
                        }
                        if(partPathName.equals("特殊头像")){
                            avatarPart.setSpecialType(2);
                            avatarPart.setIsUnique(1);
                        }

                        //在素材描述中找到对应的素材秒速
                        Optional<AvatarPartAttr> optionalAvatarPartAttr = findAvatarPartAttr(partPathName, filePrefix);
                        if(optionalAvatarPartAttr.isPresent()){
                            AvatarPartAttr avatarPartAttr = optionalAvatarPartAttr.get();
                            avatarPart.setName(avatarPartAttr.getPartName());
                            avatarPart.setSourceFileName(avatarPartAttr.getSourceFileName());
                            if(StrUtil.isNotBlank(avatarPartAttr.getRatio())){
                                avatarPart.setRatio(new BigDecimal(avatarPartAttr.getRatio().replace("%","")));
                            }
                            //是否唯一部件
                            String isUnique = avatarPartAttr.getIsUnique();
                            avatarPart.setIsUnique("是".equals(isUnique) ? 1 : 0);
                            //是否老员工独有
                            String isSpecialType = avatarPartAttr.getIsSpecialType();
                            avatarPart.setSpecialType("是".equals(isSpecialType) ? 1 : 0);
                            if ("是".equals(isUnique)) {
                                avatarPart.setSpecialType(2);
                            }
                        }
                        avatarService.saveAvatarPart(avatarPart);
                    }

                }
            } );
        });

        return JsonResult.success();
    }

    @ApiOperation("处理问题订单")
    @PostMapping("dealProblemOrder")
    public JsonResult<Void> dealProblemOrder(String metaId){
        CompletableFuture.runAsync(() -> {
            List<NftRecord> list = recordService.list(new LambdaQueryWrapper<NftRecord>()
                    .eq(NftRecord::getMetaId, metaId)
                    .eq(NftRecord::getBuyStatus, 2));
            for (NftRecord record:list) {
                try {
                    Thread.sleep(200);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                NftRecord one = ChainWrappers.lambdaQueryChain(recordService.getBaseMapper())
                        .eq(NftRecord::getActualNftId, record.getActualNftId())
                        .ne(NftRecord::getUserId, record.getUserId())
                        .last("limit 1")
                        .one();
                if (one==null) {
                    NftUserPlatform userPlatform = userPlatformService.getById(record.getUserId());
                    SdkResponseBase<NftInfoResultResponse> infoResponse = nftService.nftInfo(record.getActualNftId());
                    if (infoResponse==null || infoResponse.getRetCode()!=0) {
                        log.info("查询信息失败："+record.getId());
                    } else {
                        if (StrUtil.equalsIgnoreCase(infoResponse.getData().getNftInfo().getPublisherAddr(),infoResponse.getData().getNftInfo().getOwnerAddr())) {
                            log.info("该nft属于平台："+record.getId());
                            NftTransferRequest request = new NftTransferRequest();
                            request.setNftId(record.getActualNftId());
                            request.setOperateId(IdUtil.objectId());
                            request.setPubKey(nftProperties.getPubKey());
                            request.setReceiverAddr(userPlatform.getAddr());

                            String str = "{}_{}_{}_{}_{}";
                            String signData = StrUtil.format(str,nftProperties.getPubKey(), userPlatform.getAddr(),"nft_transfer"
                                    , request.getNftId(), request.getOperateId());
                            SignByPriKeyResponse userSignResponse = nftCommonUtil.signByPriKey(nftProperties.getPriKey(), signData);
                            request.setSignature(userSignResponse.getSignedData());
                            log.info("nft {} 转移:{}->{}",record.getActualNftId(),"平台",record.getUserId());
                            SdkResponseBase<TaskResponse> taskResponse = nftService.nftTransfer(request);
                            if (taskResponse.getRetCode()==0) {
                                Map<String, Object> extData = new HashMap<>();
                                extData.put("nftId", record.getActualNftId());
                                extData.put("recordId", record.getId());
                                extData.put("transferUserId", "平台");
                                extData.put("receiveUserId", record.getUserId());

                                NftTask task = new NftTask();
                                task.setStatus(2);
                                task.setType(TaskEnum.NFT_TRANSFER.getCode());
                                task.setOperateId(request.getOperateId());
                                task.setTaskId(taskResponse.getData().getTaskId());
                                task.setExtend1(record.getId());
                                task.setExtend2("平台");
                                task.setExtend3(JSON.toJSONString(extData));
                                taskService.save(task);
                            }
                        }
                        if (!StrUtil.equalsIgnoreCase(userPlatform.getAddr(),infoResponse.getData().getNftInfo().getOwnerAddr())) {
                            NftUserPlatform owner = userPlatformService.findByAddr(infoResponse.getData().getNftInfo().getOwnerAddr());
                            log.info("该nft属于{}：{}",owner.getUserId(),owner.getAddr());

                            NftTransferRequest request = new NftTransferRequest();
                            request.setNftId(record.getActualNftId());
                            request.setOperateId(IdUtil.objectId());
                            request.setReceiverAddr(userPlatform.getAddr());
                            request.setPubKey(owner.getPubkey());

                            String str = "{}_{}_{}_{}_{}";
                            String signData = StrUtil.format(str,owner.getPubkey(), userPlatform.getAddr(),"nft_transfer"
                                    , request.getNftId(), request.getOperateId());
                            SignByPriKeyResponse userSignResponse = nftCommonUtil.signByPriKey(owner.getPrikey(), signData);
                            request.setSignature(userSignResponse.getSignedData());
                            log.info("nft {} 转移:{}->{}",record.getActualNftId(),owner.getUserId(),record.getUserId());
                            SdkResponseBase<TaskResponse> taskResponse = nftService.nftTransfer(request);
                            if (taskResponse.getRetCode()==0) {
                                Map<String, Object> extData = new HashMap<>();
                                extData.put("nftId", record.getActualNftId());
                                extData.put("recordId", record.getId());
                                extData.put("transferUserId", owner.getUserId());
                                extData.put("receiveUserId", record.getUserId());

                                NftTask task = new NftTask();
                                task.setStatus(2);
                                task.setType(TaskEnum.NFT_TRANSFER.getCode());
                                task.setOperateId(request.getOperateId());
                                task.setTaskId(taskResponse.getData().getTaskId());
                                task.setExtend1(record.getId());
                                task.setExtend2(owner.getUserId()+"");
                                task.setExtend3(JSON.toJSONString(extData));
                                taskService.save(task);
                            }
                        } else {
                            log.info("该nft属于自身："+record.getId());
                            record.setBuyStatus(7);
                            record.setTxHash(record.getActualNftId());
                            record.setUpdateTime(DateUtil.now());
                            recordService.updateById(record);
                        }

                    }
                }
            }
        });

        return JsonResult.success();
    }

    @ApiOperation("初始化牛头nft")
    @PostMapping("initAvatar")
    public JsonResult<Void> initAvatar(){
        log.info("初始化牛头头像nft");
        NftSeriesClaim seriesClaim = nftSeriesClaimService.getById(1);
        if(StrUtil.isBlank(seriesClaim.getSeriesId())){
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"没有系列id生成");
        }
        String lockFlag = (String) redisService.get("newtv-nft:init-lock");
        if (StrUtil.isBlank(lockFlag)) {
            Boolean lockSuccess = redisService.set("newtv-nft:init-lock", "lock");
            if (lockSuccess) {
                CompletableFuture.runAsync(() -> {
                    customProperties.getFullRouteList().forEach(path -> {
                        String fullAvatarPath = customProperties.getImagePath() + path;
                        log.info("目录："+fullAvatarPath);
                        File dirFile = new File(fullAvatarPath);
                        List<File> files = PathUtil.loopFiles(dirFile.toPath(), null);
                        log.info("文件数："+files.size());
                        files.forEach(file -> {
                            String fileName = file.getName();
                            String filePrefix = getFilePrefix(fileName);
                            List<AvatarPart> avatarParts = fullAvatarPartIdList(filePrefix);
                            //1.上传
                            AvatarFull avatarFull = avatarService.getFullAvatarByName(filePrefix);
                            if (avatarFull == null) {
                                avatarFull = new AvatarFull();
                                //上传
                                String imageUrl = tryUploadToCos(file);
                                if (StrUtil.isBlank(imageUrl)) {
                                    throw new BusException("上传文件异常-人物+背景类型," + " 号:" + fileName);
                                }
                                avatarFull.setCreateTime(new Date());
                                avatarFull.setSourceFileName(filePrefix);
                                avatarFull.setUrl(imageUrl);
                                //找到组成组件的组成部分
                                List<Integer> partIds = avatarParts.stream().map(AvatarPart::getPartId).collect(Collectors.toList());
                                avatarFull.setParts(JSON.toJSONString(partIds));
                                avatarFull.setSpecialType(isSpecialType(filePrefix));
                                //设置头像部件id
                                String personFileName = filePrefix.substring(0, filePrefix.lastIndexOf("_"));
                                if (avatarFull.getSpecialType()==2) {
                                    personFileName = filePrefix;
                                }
                                AvatarPart avatarPartByNameAndType = avatarService.getAvatarPartByNameAndType(personFileName, 100);
                                avatarFull.setAvatarPartId(avatarPartByNameAndType.getPartId());

                                avatarService.saveAvatarFull(avatarFull);

                                //重新查询
                                avatarFull = avatarService.getFullAvatarByName(filePrefix);
                            }
                            //2.nft入库
                            if (avatarFull.getNftMetaId() == null || avatarFull.getNftMetaId() == 0) {
                                //查询
                                List<NftMetadata> nftMetadataList = ChainWrappers.lambdaQueryChain(nftMetadataMapper).eq(NftMetadata::getUrl, avatarFull.getUrl()).list();
                                NftMetadata nftMetadata;
                                if (CollUtil.isNotEmpty(nftMetadataList)) {
                                    nftMetadata = nftMetadataList.get(0);
                                } else {
                                    NftPublishVO publishVO = new NftPublishVO();
                                    publishVO.setPublishCount(1);
                                    publishVO.setSeriesId(seriesClaim.getSeriesId());
                                    publishVO.setName(seriesClaim.getSeriesName() + "#" + nftMetadataService.getMaxSeriesBeginIndex(publishVO.getSeriesId()));
                                    publishVO.setDesc("未来“牛翻天”数字头像");
                                    publishVO.setUrl(avatarFull.getUrl());
                                    publishVO.setDisplayUrl(avatarFull.getUrl());
                                    publishVO.setSellFee(1);
                                    NftMetadata newNftMetadata = new NftMetadata();
                                    BeanUtils.copyProperties(publishVO, newNftMetadata);

                                    //获取头像的部件描述
                                    List<NftMetaDataPartAttr> metaDataPartAttrs = CollUtil.newArrayList();
                                    avatarParts.forEach(p -> {
                                        if (p.getPartType()==AvatarPartTypeEnum.FULL_BACKGROUND.getCode()) {
                                            return;
                                        }
                                        NftMetaDataPartAttr nftMetaDataPartAttr = new NftMetaDataPartAttr();
                                        nftMetaDataPartAttr.setPartName(p.getName());
                                        nftMetaDataPartAttr.setPartType(p.getPartType());
                                        nftMetaDataPartAttr.setRatio(p.getRatio().doubleValue());
                                        nftMetaDataPartAttr.setIsSpecialType(p.getSpecialType());
                                        nftMetaDataPartAttr.setIsUnique(p.getIsUnique());
                                        metaDataPartAttrs.add(nftMetaDataPartAttr);
                                    });
                                    Map<String, Object> metaData = new HashMap<>(2);
                                    metaData.put("partAttr", metaDataPartAttrs);

                                    newNftMetadata.setMetaData(JSON.toJSONString(metaData));
                                    newNftMetadata.setMetaType(2);
                                    nftMetadata = nftMetadataService.publishNftMetaData(newNftMetadata, new CmsUser() {{
                                        setUserId(1);
                                        setUsername("系统导入");
                                    }});
                                }
                                //更新头像的nft_meta_id
                                avatarFull.setNftMetaId(nftMetadata.getMetaId());
                                avatarService.saveAvatarFull(avatarFull);
                                //查询结果
                                //阻塞方式查询系列声明是否成功

                                nftMetadata = nftMetadataService.getById(nftMetadata.getMetaId());
                                while (true) {
                                    String taskId = nftMetadata.getTaskId();
                                    NftTask task = taskService.getTaskByTaskId(taskId);
                                    SdkResponseBase<NftPublishTaskResultResponse> taskResult = nftService.nftPublishResult(taskId);
                                    if (taskResult.getRetCode() == 0) {
                                        NftPublishTaskResultResponse result = taskResult.getData();
                                        task.setStatus(result.getTaskStatus());
                                        task.setChainTimestamp(new Date(result.getChainTimestamp()));
                                        task.setTxHash(result.getTxHash());
                                        task.setTaskMsg(result.getTaskMsg());
                                        nftMetadata.setNftId(result.getNftIdBegin());
                                        nftMetadata.setTaskStatus(result.getTaskStatus());

                                        taskService.updateById(task);
                                        nftMetadataService.updateById(nftMetadata);
                                        if (result.getTaskStatus() != 2) {
                                            break;
                                        }
                                        try {
                                            TimeUnit.SECONDS.sleep(2);
                                        } catch (InterruptedException e) {
                                            e.printStackTrace();
                                        }
                                    }
                                }
                            }
                        });
                    });
                });
            } else {
                return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"任务正在执行，不要重复执行");
            }
        } else {
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"任务已锁定");
        }
        return JsonResult.success();
    }

    private String getFilePrefix(String fileName){
        String filePrefix = FileUtil.getPrefix(fileName);
        //if(!filePrefix.contains("_")){
        //    filePrefix = String.valueOf(Integer.parseInt(filePrefix));
        //}
        return filePrefix;
    }

    /**
     * 找到头像对应的各个部件的id
     * @param sourceFileName 头像名称，不包含后缀名称
     * @return list
     */
    private List<AvatarPart> fullAvatarPartIdList(String sourceFileName){
        List<AvatarPart> resList = CollUtil.newArrayList();
        List<String> partNameList = Stream.of(sourceFileName.split("_")).collect(Collectors.toList());
        for (int i = 0; i < partNameList.size(); i++) {
            String routePartName = customProperties.getRouteList().get(i);
            String partName = partNameList.get(i);
            if(StrUtil.isBlank(routePartName)){
                throw new BusException(String.format("不正确的格式:%s",sourceFileName));
            }
            Integer routeType = AvatarPartTypeEnum.getCodeByName(routePartName);
            AvatarPart avatarPart = avatarService.getAvatarPartByNameAndType(partName, routeType);
            if(avatarPart == null){
                throw new BusException(String.format("头像+背景:%s,找到对应部件:%s-%s",sourceFileName,partName,routeType));
            }
            resList.add(avatarPart);
            if (routePartName.equals("背景")) {
                AvatarPart fullBackendGround = avatarService.getAvatarPartByNameAndType(partName, 7);
                if (fullBackendGround!=null) {
                    resList.add(fullBackendGround);
                }
            }
        }
        return resList;
    }

    /**
     * 尝试上传去cos
     * @param file 本地文件
     * @return 访问url
     */
    private String tryUploadToCos(File file){
        String imageUrl = "";
        //for (int i = 0; i < 3; i++){
        //    String key = "material/"+IdUtil.simpleUUID()+ "."+FileUtil.extName(file.getName());
        //    imageUrl = nftCommonUtil.uploadToCos(key, file.getAbsolutePath());
        //    if(StrUtil.isNotBlank(imageUrl)){
        //        break;
        //    }
        //    try {
        //        TimeUnit.SECONDS.sleep(1);
        //    } catch (InterruptedException e) {
        //        e.printStackTrace();
        //    }
        //}
        String key = "material/"+ IdUtil.simpleUUID()+ "."+FileUtil.extName(file.getName());
        try (FileInputStream inputStream = new FileInputStream(file)){
            ObjectStorageService objectStorageService = OssFactory.getObject(ossPropertiesConfig);
            imageUrl = objectStorageService.putObject(inputStream, inputStream.available(), key, OssAcl.PublicRead);
            objectStorageService.shutdown();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return imageUrl;
    }

    /**
     * 判断头像是否老员工能够获取的头像
     * @param sourceFileName 头像名称，不包含后缀名称
     * @return boolean
     */
    private int isSpecialType(String sourceFileName){
        AtomicInteger flag = new AtomicInteger();
        String path = customProperties.getImagePath()+"十年老员工人物";
        File dirFile = new File(path);
        List<File> files = PathUtil.loopFiles(dirFile.toPath(), null);

        Optional<File> first = files.stream().filter(file -> {
            String fileName = file.getName();
            String filePrefix = getFilePrefix(fileName);
            //查询
            return sourceFileName.contains(filePrefix);
        }).findFirst();
        if(first.isPresent()){
            flag.set(1);
        }
        String path2 = customProperties.getImagePath()+"特殊头像";
        File dir2File = new File(path2);
        List<File> files2 = PathUtil.loopFiles(dir2File.toPath(), null);

        Optional<File> first2 = files2.stream().filter(file -> {
            String fileName = file.getName();
            String filePrefix = getFilePrefix(fileName);
            //查询
            return sourceFileName.contains(filePrefix);
        }).findFirst();
        if(first2.isPresent()){
            flag.set(2);
        }
        return flag.get();
    }

    /**
     * 读取头像图片的属性
     * @return
     */
    private Optional<AvatarPartAttr> findAvatarPartAttr(String type,String fileName){
        List<AvatarPartAttr> avatarPartAttrs = null;
        if(avatarPartAttrs == null){
            ExcelReader reader = ExcelUtil.getReader(customProperties.getImagePath()+"素材描述.xlsx",0);
            avatarPartAttrs = reader.readAll(AvatarPartAttr.class);
        }
        return avatarPartAttrs.stream().filter(p -> p.getPartPosition().equals(type) && p.getPartName().equals(fileName)).findFirst();
    }

    @ApiOperation("补发nft")
    @GetMapping("replenish")
    public JsonResult<Void> replenish(String metaId,String mobile,Integer reduceShowCount) {

        NftUser user = userService.findUserByMobile(mobile);
        NftMetadata metadata = nftMetadataService.getById(metaId);
        //检查是否可售
        NftSeriesClaim seriesClaim = nftSeriesClaimService.getBySeriesId(metadata.getSeriesId());
        //Integer count = ChainWrappers.lambdaQueryChain(recordService.getBaseMapper())
        //        .eq(NftRecord::getUserId, user.getUserId())
        //        .eq(NftRecord::getMetaId, metadata.getMetaId())
        //        .in(NftRecord::getBuyStatus,2,7)
        //        .count();
        //if (seriesClaim.getMetaType()!=3) {
        //    if (count>0) {
        //        return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(), "不能重复领取");
        //    }
        //}
        //检查是否可售
        if (seriesClaim != null) {
            String beginTime = seriesClaim.getBeginTime();
            DateTime beginDate = DateUtil.parseDateTime(beginTime);
            Date now = new Date();

            if (DateUtil.compare(beginDate, now) > 0) {
                return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(), "作品未到发售时间");
            }

            if (reduceShowCount==null || reduceShowCount!=1) {
                if (metadata.getShowCount() >= metadata.getRestCount()) {
                    return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"可供下发库存不足");
                }
            } else {
                if (metadata.getShowCount() <= 0 || metadata.getRestCount() <= 0) {
                    return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"可供下发库存不足");
                }
            }

            String taskId = orderService.replenish(metadata, user.getUserId(),seriesClaim.getMetaType(),reduceShowCount,seriesClaim);
            if (taskId == null) {
                return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"NFT下发失败");
            }
            return JsonResult.success();
        }
        return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(), "未找到所属系列");
    }

    @GetMapping("replenishBatch")
    @ApiOperation("批量补发藏品")
    public JsonResult<Void> replenishBatch(String date){
        //ExcelReader reader = ExcelUtil.getReader(IntegralController.class.getResourceAsStream("/replenish"+date+".xlsx"));
        ExcelReader reader = ExcelUtil.getReader(nftProperties.getTempFilePath()+"replenish"+date+".xlsx");
        List<List<Object>> readAll = reader.read(1);
        readAll.forEach( r -> {
            int count = Integer.parseInt(r.get(1) + "");
            NftUser user = userService.findUserByMobile(r.get(0) + "");
            if (user==null) {
                log.error("用户不存在"+r.get(0));
                return ;
            }
            Integer replenishCount = recordService.lambdaQuery()
                    .eq(NftRecord::getUserId, user.getUserId())
                    .eq(NftRecord::getMetaId, r.get(2) + "")
                    .between(NftRecord::getCreateTime, date + " 00:00:00", date + " 23:59:59")
                    .count();
            if (replenishCount==null) {
                replenishCount = 0;
            }
            count = count-replenishCount;
            for (int i = 0; i < count; i++) {
                JsonResult<Void> replenish = replenish(r.get(2) + "", r.get(0) + "", 1);
                log.info(r.get(0) + "第"+i+"次空投藏品："+r.get(2) );
                log.info(replenish.toString());
            }
        });
        return JsonResult.success();
    }


    @GetMapping("transfer2Platform")
    @ApiOperation("用户转移到平台")
    public JsonResult<Void> transfer2Platform(String id) {
        NftRecord one = ChainWrappers.lambdaQueryChain(recordService.getBaseMapper())
                .eq(NftRecord::getId,id)
                .one();
        Map<String,String> res = new HashMap<>(2);

        NftUserPlatform userPlatform = userPlatformService.getById(one.getUserId());
        SdkResponseBase<NftInfoResultResponse> infoResponse = nftService.nftInfo(one.getActualNftId());
        if (infoResponse==null || infoResponse.getRetCode()!=0) {
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),infoResponse.getRetMsg() );
        }
        if (StrUtil.equalsIgnoreCase(infoResponse.getData().getNftInfo().getPublisherAddr(),infoResponse.getData().getNftInfo().getOwnerAddr())) {
            recordService.deleteBak(one);
            return JsonResult.success();
        }
        if (!StrUtil.equalsIgnoreCase(userPlatform.getAddr(),infoResponse.getData().getNftInfo().getOwnerAddr())) {
            NftUserPlatform owner = userPlatformService.findByAddr(infoResponse.getData().getNftInfo().getOwnerAddr());
            one.setUserId(owner.getUserId());
            recordService.updateById(one);
            return JsonResult.success();
        }
        NftTransferRequest request = new NftTransferRequest();
        request.setNftId(one.getActualNftId());
        request.setOperateId(IdUtil.objectId());
        request.setReceiverAddr(nftProperties.getPlatformAddr());
        request.setPubKey(userPlatform.getPubkey());

        String str = "{}_{}_{}_{}_{}";
        String signData = StrUtil.format(str,userPlatform.getPubkey(), nftProperties.getPlatformAddr(),"nft_transfer"
                , request.getNftId(), request.getOperateId());
        SignByPriKeyResponse userSignResponse = nftCommonUtil.signByPriKey(userPlatform.getPrikey(), signData);
        request.setSignature(userSignResponse.getSignedData());
        log.info("nft {} 转移:{}->{}",one.getActualNftId(),one.getUserId(),"平台");
        SdkResponseBase<TaskResponse> taskResponse = nftService.nftTransfer(request);
        if (taskResponse.getRetCode()==0) {
            res.put("taskId", taskResponse.getData().getTaskId());
            Map<String, Object> extData = new HashMap<>();
            extData.put("nftId", one.getActualNftId());
            extData.put("recordId", one.getId());
            extData.put("transferUserId", one.getUserId());
            extData.put("receiveUserId", "平台");

            NftTask task = new NftTask();
            task.setStatus(2);
            task.setType(TaskEnum.NFT_TRANSFER.getCode());
            task.setOperateId(request.getOperateId());
            task.setTaskId(taskResponse.getData().getTaskId());
            task.setExtend1(one.getId());
            task.setExtend2("平台");
            task.setExtend3(JSON.toJSONString(extData));
            taskService.save(task);
        }
        return JsonResult.success();
    }

    @GetMapping("bak2Mobile")
    @ApiOperation("平台转移到用户")
    public JsonResult<Void> platform2Mobile(String mobile,Integer metaId,String backId) {
        NftUser user = userService.findUserByMobile(mobile);
        int count = ChainWrappers.lambdaQueryChain(recordService.getBaseMapper())
                .eq(NftRecord::getUserId,user.getUserId())
                .eq(NftRecord::getMetaId,metaId)
                .count();
        if (count>0) {
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(), "已拥有该nft");
        }

        NftUserPlatform userPlatform = userPlatformService.getById(user.getUserId());

        NftRecord record = recordService.findFromBak(backId);
        SdkResponseBase<NftInfoResultResponse> infoResponse = nftService.nftInfo(record.getActualNftId());
        if (infoResponse==null || infoResponse.getRetCode()!=0) {
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(), "查询nft错误");
        }
        if (!StrUtil.equalsIgnoreCase(nftProperties.getPlatformAddr(),infoResponse.getData().getNftInfo().getOwnerAddr())) {            NftUserPlatform owner = userPlatformService.findByAddr(infoResponse.getData().getNftInfo().getOwnerAddr());
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(), "该nft的拥有者不是平台");
        }
        NftTransferRequest request = new NftTransferRequest();
        request.setNftId(record.getActualNftId());
        request.setOperateId(IdUtil.objectId());
        request.setReceiverAddr(userPlatform.getAddr());
        request.setPubKey(nftProperties.getPubKey());

        String str = "{}_{}_{}_{}_{}";
        String signData = StrUtil.format(str,nftProperties.getPubKey(), userPlatform.getAddr(),"nft_transfer"
                , request.getNftId(), request.getOperateId());
        SignByPriKeyResponse userSignResponse = nftCommonUtil.signByPriKey(nftProperties.getPriKey(), signData);
        request.setSignature(userSignResponse.getSignedData());
        log.info("nft {} 转移:平台->{}",record.getActualNftId(),userPlatform.getUserId());
        SdkResponseBase<TaskResponse> taskResponse = nftService.nftTransfer(request);
        if (taskResponse.getRetCode()==0) {
            NftRecord newRecord = new NftRecord();
            newRecord.setActualNftId(record.getActualNftId());
            newRecord.setNftId(record.getNftId());
            newRecord.setObtainType(2);
            //2 执行中
            newRecord.setBuyStatus(2);
            newRecord.setMetaId(metaId);
            newRecord.setOwnerTime(new Date());
            newRecord.setUserId(user.getUserId());
            newRecord.setMetaType(record.getMetaType());
            newRecord.setCreateTime(new Date());
            newRecord.setOwnerAddr(userPlatform.getAddr());
            newRecord.setTxHash("");
            recordService.save(newRecord);
            Map<String,Object> extData = new HashMap<>();
            extData.put("nftId",record.getActualNftId());
            extData.put("recordId",newRecord.getId());
            extData.put("transferUserId","平台");
            extData.put("receiveUserId",userPlatform.getUserId());

            NftTask task = new NftTask();
            task.setStatus(2);
            task.setType(TaskEnum.NFT_TRANSFER.getCode());
            task.setOperateId(request.getOperateId());
            task.setTaskId(taskResponse.getData().getTaskId());
            task.setExtend1(record.getId());
            task.setExtend2(user.getUserId()+"");
            task.setExtend3(JSON.toJSONString(extData));
            taskService.save(task);
            //标记转移状态
            recordService.updateBak(record.getId());
        }
        return JsonResult.success();
    }

    @AnonymousGetMapping("setLeadTime")
    @ApiOperation("设置提前购买时间")
    public JsonResult<Void> setLeadTime(Integer leadTime,Integer adLeadTime){
        if (leadTime!=null) {
            redisService.hset(RedisKeyFactory.getLeadTimeKey(),"leadTime",leadTime);
        }
        if (adLeadTime!=null) {
            redisService.hset(RedisKeyFactory.getLeadTimeKey(),"adLeadTime",adLeadTime);
        }
        return  JsonResult.success();
    }

    @AnonymousGetMapping("setTransferTime")
    @ApiOperation("设置转赠时间")
    public JsonResult<Void> setTransferTime(Integer firstTransferTime,Integer manyTransferTime){
        //if (firstTransferTime!=null) {
        //    redisService.hset(RedisKeyFactory.getLeadTimeKey(),"firstTransferTime",firstTransferTime);
        //}
        //if (manyTransferTime!=null) {
        //    redisService.hset(RedisKeyFactory.getLeadTimeKey(),"manyTransferTime",manyTransferTime);
        //}
        return  JsonResult.success();
    }

    @AnonymousGetMapping("sendNotice")
    @ApiOperation("发送短信通知")
    public JsonResult<Void> sendNotice(String notice,Integer isPrimary) throws Exception{
        int count = userService.count(new LambdaQueryWrapper<NftUser>().isNotNull(NftUser::getMobile).eq(NftUser::getStatus,0));
        if (isPrimary!=null && isPrimary==1) {
            count = userService.findPrimaryUserCount();
        }
        int size = 200;
        int page = count/size +1;

        int finalCount = count;
        CompletableFuture.runAsync(() -> {
            Integer num = (Integer) redisService.get(RedisKeyFactory.getNoticePageKey());
            if (num==null) {
                num = 0;
            }
            if (finalCount >0) {
                for (int i = num; i < page; i++) {
                    List<NftUser> list = null;
                    if (isPrimary!=null && isPrimary==1) {
                        list = userService.findPrimaryUser(i,size);
                    } else {
                        list = userService.list(new LambdaQueryWrapper<NftUser>()
                                .isNotNull(NftUser::getMobile)
                                .eq(NftUser::getStatus,0)
                                .last("limit " + i * size + "," + size)
                                .select(NftUser::getMobile,NftUser::getUserName));
                    }
                    SendMsgResponse sendMsgResponse = messageService.sendNotice(list, notice);
                    if (sendMsgResponse!=null) {
                        if ("1".equals(sendMsgResponse.getStatusCode())) {
                            log.info("短信发送结果:{}",sendMsgResponse);
                            redisService.set(RedisKeyFactory.getNoticePageKey(),i);
                        } else {
                            log.info("短信发送结果:{}",sendMsgResponse);
                        }
                    } else {
                        log.info("短信发送失败");
                    }
                }
            }
            redisService.del(RedisKeyFactory.getNoticePageKey());
        });

        return JsonResult.success();
    }

    @AnonymousGetMapping("sendNotice/v2")
    @ApiOperation("发送短信通知")
    public JsonResult<Void> sendNoticeV2(String templateId,String mobile,String[] params) throws Exception{
        SendMsgV2Response sendMsgResponse = messageService.sendNoticeV2(templateId,mobile, params);
        if (sendMsgResponse!=null) {
            if ("1".equals(sendMsgResponse.getStatusCode())) {
                log.info("短信发送结果:{}",sendMsgResponse);
            } else {
                log.info("短信发送结果:{}",sendMsgResponse);
                return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),sendMsgResponse.getMessage());
            }
        } else {
            log.info("短信发送失败");
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"短信发送失败");
        }
        return JsonResult.success();
    }

    @AnonymousGetMapping("sendNoticeByMobiles")
    @ApiOperation("传递手机号发送短信通知")
    public JsonResult<Void> sendNoticeByMobiles(String mobiles,String content){
        SendMsgResponse sendMsgResponse;
        if (mobiles.length()<12) {
            sendMsgResponse = messageService.sendMessage(mobiles,content);
        } else {
            sendMsgResponse = messageService.sendNotice(mobiles, content);
        }
        if (sendMsgResponse!=null) {
            if ("1".equals(sendMsgResponse.getStatusCode())) {
                log.info("短信发送结果:{}",sendMsgResponse);
            } else {
                log.info("短信发送结果:{}",sendMsgResponse);
            }
        } else {
            log.info("短信发送失败");
        }
        return JsonResult.success();
    }

    @AnonymousGetMapping("sendExchangeNotice")
    @ApiOperation("兑换码短信通知")
    public JsonResult<Void> sendExchangeNotice(String mobile,String code){

        String template = "%s";
        String format = String.format(template, code);

        SendMsgResponse sendMsgResponse = messageService.sendMessage(mobile,format);

        if (sendMsgResponse!=null) {
            if ("1".equals(sendMsgResponse.getStatusCode())) {
                log.info("短信发送结果:{}",sendMsgResponse);
            } else {
                log.info("短信发送结果:{}",sendMsgResponse);
            }
        } else {
            log.info("短信发送失败");
        }
        return JsonResult.success();
    }

    @ApiOperation("真实剩余数量")
    @GetMapping("realRestCount")
    public JsonResult<?> realRestCount(String metaId) {
        NftMetadata metadata = nftMetadataService.getById(metaId);
        if (metadata==null) {
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(), "未知的藏品");
        }
        String setKey = RedisKeyFactory.getNftIdKey(metadata.getNftId());
        Long size = redisService.zSetSize(setKey, 0);
        Map<String,Integer> map = new HashMap<>();
        map.put("realRestCount", Math.toIntExact(size));
        map.put("restCount",metadata.getRestCount());
        map.put("showCount",metadata.getShowCount());
        return JsonResult.success(map);
    }

    @ApiOperation("对库存进行操作")
    @PostMapping("operationRestCount")
    public JsonResult<?> restCount(String metaId,int count) {
        NftMetadata metadata = nftMetadataService.getById(metaId);

        if (metadata==null) {
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(), "未知的藏品");
        }

        String setKey = RedisKeyFactory.getNftIdKey(metadata.getNftId());
        Long size = redisService.zSetSize(setKey, 0);

        LambdaUpdateChainWrapper<NftMetadata> wrapper = ChainWrappers.lambdaUpdateChain(nftMetadataService.getBaseMapper())
                .eq(NftMetadata::getMetaId, metaId)
                .gt(NftMetadata::getRestCount, 0);
        if (count>0) {
            wrapper.setSql("rest_count=rest_count-" + count)
                    .setSql("show_count=show_count-" + count);
        } else if (count<0) {
            if (metadata.getRestCount()>=size) {
                return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(), "展示库存不能比真实库存多");
            }
            wrapper.setSql("rest_count=rest_count-" + count)
                    .setSql("show_count=show_count-" + count);
        } else {
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(), "count不能为0");
        }

        wrapper.update();
        NftMetadata newMetadata = nftMetadataService.getById(metaId);
        Map<String,Integer> map = new HashMap<>();
        map.put("restCount",newMetadata.getRestCount());
        map.put("showCount",newMetadata.getShowCount());
        return JsonResult.success(map);
    }

    @ApiOperation("初始化盲盒showCount")
    @PostMapping("initBlindBoxShowCount")
    public JsonResult<Void> initBlindBoxShowCount(){
        List<NftSeriesClaim> list = nftSeriesClaimService.lambdaQuery()
                .eq(NftSeriesClaim::getMetaType, 3)
                .list();
        for (NftSeriesClaim seriesClaim : list) {
            List<NftMetadata> metadatas = nftMetadataService.lambdaQuery()
                    .eq(NftMetadata::getSeriesId, seriesClaim.getSeriesId())
                    .list();
            metadatas.forEach(metadata -> {
                redisService.hset(RedisKeyFactory.getBlindBoxShowCountKey(),metadata.getMetaId()+"",metadata.getShowCount());
            });
        }
        return JsonResult.success();
    }

    @ApiOperation("初始化老用户积分")
    @PostMapping("initOldUserIntegral")
    public JsonResult<Void> initOldUserIntegral() throws InterruptedException {
        log.info("初始化老用户积分");
        int totalCount = userPlatformService.count();
        int size = 100;
        int totalPage = totalCount/size +1;
        log.info("总数据{}总页码{}",totalCount,totalPage);
        if (totalCount>0) {
//            CompletableFuture.runAsync(()->{

                for (int i = 0; i < totalPage; i++) {
                    log.info("第{}页",i);
                    Page<NftUserPlatform> page = new Page<>(i,size);
                    List<NftUserPlatform> userList = userPlatformService.selectNoIntegralUser(page);
                    log.info("userList:{}",userList.size());
                    List<Integral> list = new ArrayList<>();
                    List<IntegralRecord> records = new ArrayList<>();
                    userList.forEach( user -> {
                        Integral integral = new Integral();
                        integral.setUserId(user.getUserId());
                        integral.setUsableIntegral(2);
                        integral.setFrozenIntegral(0);
                        list.add(integral);

                        IntegralRecord integralRecord = new IntegralRecord();
                        integralRecord.setUserId(user.getUserId());
                        integralRecord.setIntegral(2);
                        integralRecord.setSourceId(user.getUserId()+"");
                        integralRecord.setSourceType(IntegralTypeEnum.REAL_NAME_AUTH.getType());
                        integralRecord.setSymbol("in");
                        integralRecord.setRestUsableIntegral(0);
                        records.add(integralRecord);
                    });
                    integralService.saveOrUpdateBatch(list);
                    integralRecordService.saveOrUpdateBatch(records);
                    log.info("插入成功{}条",list.size());
                }
//            });
        }
        return JsonResult.success();
    }


    @ApiOperation("补发盲盒")
    @PostMapping("blindBoxReplenish")
    public JsonResult<String> blindBoxReplenish(String seriesId,String mobiles,Integer count,Integer reduceShowCount) {

        NftSeriesClaim seriesClaim = nftSeriesClaimService.getById(seriesId);
        String[] mobileArray = mobiles.split(",");

        String noExistMobile = "";
        String noAuthMobile = "";
        String failReplenish = "";
        if (seriesClaim==null) {
            throw new BusException("系列不存在");
        }

        if (seriesClaim.getMetaType() != 3) {
            throw new BusException("系列不是盲盒类型");
        }

        String beginTime = seriesClaim.getBeginTime();
        DateTime beginDate = DateUtil.parseDateTime(beginTime);
        Date now = new Date();

        if (DateUtil.compare(beginDate, now) > 0) {
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(), "藏品未到发售时间");
        }

        if (count == null || count < 1) {
            throw new BusException("发放数量错误");
        }

        for (String mobile : mobileArray) {
            NftUser user = userService.findUserByMobile(mobile);
            if (user==null) {
                noExistMobile += mobile+" ";
                continue;
            }
            NftUserPlatform userPlatform = userPlatformService.getById(user.getUserId());
            if (userPlatform==null) {
                noAuthMobile += mobile+" ";
                continue;
            }

            Map<String, String> actualNftIds = orderService.blindBoxReplenish(seriesClaim, user.getUserId(), reduceShowCount, count);
            if (CollectionUtil.isEmpty(actualNftIds)) {
                failReplenish += mobile +" ";
            }

        }

        String returnMsg = "";
        if (StrUtil.isNotBlank(noExistMobile)) {
            returnMsg = "不存在的用户：" + noExistMobile;
        }
        if (StrUtil.isNotBlank(noAuthMobile)) {
            returnMsg = returnMsg + "未实名的用户：" + noAuthMobile;
        }
        if (StrUtil.isNotBlank(failReplenish)) {
            returnMsg = returnMsg + "发放失败的用户：" + failReplenish;
        }

        return JsonResult.success(returnMsg);
    }

    @ApiOperation("调整藏品空投数量")
    @PostMapping("readjustAirdropCount")
    public JsonResult<String> readjustAirdropCount(Integer metaId,Integer count){
        NftMetadata metadata = nftMetadataService.getById(metaId);
        if (metadata==null) {
            throw new BusException("不存在的藏品");
        }
        int airdropCount=0;
        NftSeriesClaim seriesClaim = nftSeriesClaimService.getById(metadata.getShortSeriesId());
        if (seriesClaim.getMetaType()==3) {
            airdropCount = orderService.readjustAirdropCount(metadata,seriesClaim.getId(),count);
        } else {
            airdropCount = orderService.readjustAirdropCount(metadata,count);
        }
        return JsonResult.success("藏品"+metaId+"空投数修改为："+airdropCount);
    }

    @ApiOperation("批量补发盲盒")
    @PostMapping("blindBoxReplenish/batch")
    public JsonResult<String> blindBoxReplenishBatch(String seriesId,String dateTime) {
        //ExcelReader reader = ExcelUtil.getReader(IntegralController.class.getResourceAsStream("/blindBoxReplenishBatch"+dateTime+".xlsx"));
        ExcelReader reader = ExcelUtil.getReader(nftProperties.getTempFilePath()+"blindBoxReplenishBatch"+dateTime+".xlsx");
        List<List<Object>> readAll = reader.read(1);
        readAll.forEach( r -> {
            NftUser user = userService.findUserByMobile(r.get(0) + "");
            if (user==null) {
                log.info(r.get(0)+"用户不存在");
                return;
            }
            Integer count = orderService.lambdaQuery()
                    .eq(NftOrder::getUserId, user.getUserId())
                    .eq(NftOrder::getShortSeriesId, seriesId)
                    .eq(NftOrder::getPayType, "FREEACCESS")
                    .between(NftOrder::getPayTime,dateTime+" 00:00:00",dateTime+" 23:59:59")
                    .count();
            if (count>0) {
                log.info(r.get(0)+"用户已投放");
                return;
            }
            JsonResult<String> result = blindBoxReplenish(seriesId, r.get(0) + "", Integer.parseInt(r.get(1) + ""), 1);
            log.info(result.toString());
        });
        return JsonResult.success();
    }

    @ApiOperation("回收多余牛头")
    @PostMapping("destroyAvatar")
    public JsonResult<Void> destroyAvatar(String date){
        //ExcelReader reader = ExcelUtil.getReader(IntegralController.class.getResourceAsStream("/avatarLottery"+date+".xlsx"));
        ExcelReader reader = ExcelUtil.getReader(nftProperties.getTempFilePath()+"avatarLottery"+date+".xlsx");
        List<List<Object>> readAll = reader.read(1);
        readAll.forEach( r -> {
            NftUser user = userService.findUserByMobile(r.get(0) + "");
            if (user==null) {
                log.info(r.get(0)+"用户不存在");
                return;
            }
            Integer count = recordService.lambdaQuery()
                    .eq(NftRecord::getUserId, user.getUserId())
                    .eq(NftRecord::getMetaType, 2)
                    .like(NftRecord::getNftId, "2778d7063f6ff8be22e5beb412abda24ce33d326f4fde51781c35e5d8f180b59")
                    .between(NftRecord::getCreateTime, date + " 00:00:00", date + " 23:59:59")
                    .count();
            if (count>1) {
                NftRecord one = recordService.lambdaQuery()
                        .eq(NftRecord::getUserId, user.getUserId())
                        .eq(NftRecord::getMetaType, 2)
                        .like(NftRecord::getNftId, "2778d7063f6ff8be22e5beb412abda24ce33d326f4fde51781c35e5d8f180b59")
                        .between(NftRecord::getCreateTime, date + " 00:00:00", date + " 23:59:59")
                        .last("limit 1")
                        .one();
                JsonResult<Void> result = transfer2Platform(one.getId());
                log.info(result.toString());
            }
        });
        return JsonResult.success();
    }

    @ApiOperation("初始化总数量")
    @PostMapping("initTotalCount")
    public JsonResult<Void> initTotalCount(){
        List<NftSeriesClaim> list = nftSeriesClaimService.lambdaQuery()
                .ne(NftSeriesClaim::getId,1)
                .eq(NftSeriesClaim::getTaskStatus,7)
                .orderByDesc(NftSeriesClaim::getId)
                .list();
        list.forEach( seriesClaim -> {
            QueryWrapper<NftMetadata> wrapper = new QueryWrapper<>();
            wrapper.eq("short_series_id",seriesClaim.getId());
            wrapper.eq("show_status",1);
            wrapper.select("ifnull(sum(publish_count),0) as totalCount");
            Map<String, Object> map = nftMetadataService.getMap(wrapper);
            Integer totalCount = Integer.valueOf(String.valueOf(map.get("totalCount")));
            seriesClaim.setTotalCount(totalCount);
            nftSeriesClaimService.updateById(seriesClaim);
            redisService.del(RedisKeyFactory.getSeriesPriceInfoKey(seriesClaim.getSeriesId()));
        });
        return JsonResult.success();
    }

    @ApiOperation("切换苹果内功")
    @PostMapping("changeAppleSubType")
    public JsonResult<String> changeAppleSubType() {

        String subType = (String)redisService.get(RedisKeyFactory.getAppleSubTypeKey());
        if (Objects.equals("h5",subType)) {
            redisService.set(RedisKeyFactory.getAppleSubTypeKey(),"app");
            return JsonResult.success("app");
        } else if (Objects.equals("app",subType)){
            redisService.set(RedisKeyFactory.getAppleSubTypeKey(),"h5");
            return JsonResult.success("h5");
        } else {
            redisService.set(RedisKeyFactory.getAppleSubTypeKey(),"h5");
            return JsonResult.success("h5");
        }
    }

    @ApiOperation("获取苹果内功支付方式")
    @GetMapping("getAppleSubType")
    public JsonResult<String> getAppleSubType() {

        String subType = (String)redisService.get(RedisKeyFactory.getAppleSubTypeKey());
        if (StrUtil.isBlank(subType)) {
            subType = "app";
            redisService.set(RedisKeyFactory.getAppleSubTypeKey(),"app");
        }
        return JsonResult.success(subType);
    }
}
