#!/bin/bash

#开始部署---
echo "开始部署\n"

basepath=$(cd `dirname $0`; pwd)
source ${basepath}/vars.sh

#拷贝程序其他服务器
for host in ${apiHosts[@]}
do

   if [ ${host} != ${SELF_HOST} ];then
          ssh root@${host} "sed -i 's#license_key=.*#license_key=PdsQxGCmkeAdgi65#g'  /data0/tingyun/tingyun.properties"
          ssh root@${host} "sed -i 's#app_name=.*#app_name=GW-TXY-WLSC-API#g'  /data0/tingyun/tingyun.properties"
#          ssh root@${host} "sed -i 's#collector.addresses=.*#collector.addresses=${host}:4057#g'  /data0/tingyun/tingyun.properties"
          ssh root@${host} "sh ${packagePath}/run.sh newtv-nft-api restart"
    else
          sed -i "s#license_key=.*#license_key=PdsQxGCmkeAdgi65#g"  /data0/tingyun/tingyun.properties
          sed -i "s#app_name=.*#nbs.app_name=GW-TXY-WLSC-API#g"  /data0/tingyun/tingyun.properties
#          sed -i "s#collector.addresses=.*#collector.addresses=${host}:4057#g"  /data0/tingyun/tingyun.properties
          sh ${packagePath}/run.sh newtv-nft-api restart
    fi
done

