#!/usr/bin/env bash
source /etc/profile

basepath=$(cd `dirname $0`; pwd)
source ${basepath}/vars.sh

#自定义变量 begin
logPath=/data0/logs
tingyunPath=/data0/tingyun
#===end
set -x
if [ ! -e ${packagePath} ];then
    mkdir -p $packagePath
fi
if [ ! -e ${logPath} ];then
    mkdir -p $logPath
fi

echo "current host ip is ${SELF_HOST}"

cd ${basepath}
git pull
#必须要输入模块名称
if [[ "${1}" =  "" ]];then
    cd .
    servers=(newtv-nft-api newtv-nft-cms)
    #打包
    for server in ${servers[@]}
    do
        mvn clean -Dmaven.repo.local=/data0/temp/  -U -Dmaven.test.skip=true -pl com.foundao:${server} -am install
    done
#    mvn clean -Dmaven.repo.local=/data0/temp/  -U -Dmaven.test.skip=true -am install
    #包同步到部署目录
    for jarPackage in `find . -name newtv-nft*.jar `
    do
      rsync ${jarPackage} $packagePath
    done

    #同步脚本
    rsync -az ${basepath}/apideploy.sh ${basepath}/cmsdeploy.sh ${basepath}/run.sh ${basepath}/vars.sh $packagePath

    #拷贝程序其他服务器
    for host in ${hosts[@]}
    do
        if [ ${host} != ${SELF_HOST} ];then
              #新建目录
              ssh root@${host} "[ -e ${logPath}/ ] && echo 'log path exist' || mkdir -p ${logPath}/"
              ssh root@${host} "[ -e ${packagePath}/ ] && echo 'package path exist' || mkdir -p ${packagePath}/"
              ssh root@${host} "[ -e ${tingyunPath}/ ] && echo 'tingyun path exist' || mkdir -p ${tingyunPath}"
              #拷贝包
              scp ${packagePath}/* root@${host}:${packagePath}
              rsync -az  ${tingyunPath}/* root@${host}:${tingyunPath}
        fi
    done
    ls -l  ${packagePath}
else

    mvn clean -Dmaven.repo.local=/data0/temp/  -U -Dmaven.test.skip=true -pl com.foundao:${1} -am install
    for jarPackage in `find . -name ${1}.jar `
    do
     rsync ${jarPackage} $packagePath
    done

    #同步脚本
    rsync -az ${basepath}/apideploy.sh ${basepath}/cmsdeploy.sh ${basepath}/run.sh ${basepath}/vars.sh $packagePath

    #拷贝程序其他服务器
    for host in ${hosts[@]}
    do
     if [ ${host} != ${SELF_HOST} ];then
              #新建目录
              ssh root@${host} "[ -e ${logPath}/ ] && echo 'log path exist' || mkdir -p ${logPath}"
              ssh root@${host} "[ -e ${packagePath}/ ] && echo 'package path exist' || mkdir -p ${packagePath}"
              ssh root@${host} "[ -e ${tingyunPath}/ ] && echo 'tingyun path exist' || mkdir -p ${tingyunPath}"
              #拷贝包
              scp ${packagePath}/* root@${host}:${packagePath}
              rsync -az  ${tingyunPath}/* root@${host}:${tingyunPath}
        fi
    done
    ls -l  ${packagePath}
fi

