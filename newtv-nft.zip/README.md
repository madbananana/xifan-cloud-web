#自信链测试环境相关资料
##nft平台appId和key
* appId: 211130000100001
* appKey: 63a43c8f29b047039cdec6f335716533


#自信链生产环境相关资料
##nft平台公私钥
* appId: **
* appKey: *



#支付相关
##微信小程序
* appid: d7e2dbc00eb670a066f8934ed4fd3845
* key: 69bec040927192519391acd29552074f
    `
* `
nft:
  app-id: wx02dfb58241d9fa65
  appKey: e8cae07cf7543ac74e3e2b8e0b0668fc
  sdk-url:

#介绍文档地址
https://docs.qq.com/doc/DYm1aeXpDT21uaWNo


#服务器相关
 * 服务器账号 tianmai 
 * 密码: kQ@6.]3eFJ}d
 * 服务器列表见 doc/server_list.txt
