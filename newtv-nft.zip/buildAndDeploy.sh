#!/usr/bin/env bash
source /etc/profile
if [ "${ENV}" = "" ]
then
  echo "please config env var:\n"
  echo "1.ENV,2.MYSQL_HOST,3.REDIS_HOST,4,MONGO_HOST\n"
fi
basepath=$(cd `dirname $0`; pwd)
cd ${basepath}
git pull
#必须要输入模块名称
if [[ "${1}" =  "" ]];then
    cd .
    servers=(newtv-nft-api newtv-nft-cms)
#    servers=`ls . | egrep 'liveblockchain' | xargs`
    for server in ${servers[@]}
    do
        mvn clean -Dmaven.repo.local=/data0/temp/  -U -Dmaven.test.skip=true -pl com.foundao:${server} -am install

    done
    for jarPackage in `find . -name newtv-nft*.jar `
    do
     rsync ${jarPackage} /data0/package/newtv-nft
    done
    ls -l  /data0/package/newtv-nft/
    #开始部署---
    echo "开始部署\n"
     cd ${basepath}
    /usr/local/bin/docker-compose -f docker-compose.yml stop
    /usr/local/bin/docker-compose -f docker-compose.yml up -d
else
    #创建docker-compose部署jar的目录,部署单个服务
    if [ ! -e /data0/package/newtv-nft/ ]
    then
    mkdir -p /data0/package/newtv-nft/
    fi

    mvn clean -Dmaven.repo.local=/data0/temp/  -U -Dmaven.test.skip=true -pl com.foundao:${1} -am install
    for jarPackage in `find . -name ${1}.jar `
    do
     rsync ${jarPackage} /data0/package/newtv-nft
    done
    cd ${basepath}

    /usr/local/bin/docker-compose -f docker-compose.yml stop ${1}
    /usr/local/bin/docker-compose -f docker-compose.yml up -d   ${1}
    docker logs -f --tail=10 ${1}
fi

