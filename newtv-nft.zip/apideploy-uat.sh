#!/bin/bash

#开始部署---
echo "开始部署\n"

basepath=$(cd `dirname $0`; pwd)
source ${basepath}/vars-uat.sh

#拷贝程序其他服务器
for host in ${apiHosts[@]}
do
    if [ ${host} != ${SELF_HOST} ];then
          ssh root@${host} "sh ${packagePath}/run-uat.sh newtv-nft-api restart"
    else
          sh ${packagePath}/run-uat.sh newtv-nft-api restart
    fi
done
