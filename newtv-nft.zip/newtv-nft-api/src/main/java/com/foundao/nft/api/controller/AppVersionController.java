package com.foundao.nft.api.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.foundao.nft.api.service.impl.AppVersionService;
import com.foundao.nft.common.model.AppVersion;
import com.tx.core.beans.JsonResult;
import com.tx.core.enums.errcode.ParamErrorEnum;
import com.tx.security.annotation.AnonymousGetMapping;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

/**
 * @Package: com.foundao.nft.api.controller
 * @ClassName: AppVersionController
 * @Author: chenli
 * @CreateTime: 2022/4/29 6:15 下午
 * @Description:
 */
@RequestMapping("/app")
@Slf4j
@RestController
@RequiredArgsConstructor
@Api(tags = "更新相关")
public class AppVersionController {

    private final AppVersionService appVersionService;

    @ApiOperation("获取最新版本app")
    @AnonymousGetMapping("/update")
    public JsonResult<AppVersion> update(String deviceType){
        if (deviceType==null) {
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"设备类型不能为空");
        } else {
            if (!deviceType.equals("1") && !deviceType.equals("2")) {
                return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"设备类型参数错误");
            }
            LambdaQueryWrapper<AppVersion> queryWrapper = new LambdaQueryWrapper<>();
            queryWrapper.eq(AppVersion::getDeviceType,deviceType)
                    .orderByDesc(AppVersion::getId)
                    .lt(AppVersion::getBeginTime,new Date())
                    .last("limit 1");
            return JsonResult.success(appVersionService.getOne(queryWrapper));
        }
    }
}
