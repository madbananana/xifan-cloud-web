package com.foundao.nft.api;

import com.tx.base.ratelimiter.annotation.EnableTokenBucketRateLimiter;
import com.tx.redis.annotation.EnableRedisCache;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.Transactional;

/**
 * @ClassName NftApiApplication
 * @Description TODO
 * @Author xifan
 * @Date 2021/12/19 11:05
 * @Version 1.0
 */
@SpringBootApplication
@Transactional
@EnableScheduling
@EnableRedisCache
@EnableTokenBucketRateLimiter
public class NftApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(NftApiApplication.class,args);
    }

}
