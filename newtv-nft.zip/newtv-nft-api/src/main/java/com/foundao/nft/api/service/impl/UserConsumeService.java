package com.foundao.nft.api.service.impl;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.foundao.nft.common.model.AwardInfo;
import com.foundao.nft.common.model.AwardRecord;
import com.foundao.nft.common.model.NftUser;
import com.foundao.nft.common.model.vo.H5ActivityInfoVO;
import com.foundao.nft.common.model.vo.H5ActivityLevelInfoVO;
import com.foundao.nft.common.model.vo.UserConsumeRankVO;
import com.foundao.nft.common.util.RedisKeyFactory;
import com.tx.core.exception.BusException;
import com.tx.redis.annotation.FdRedisCache;
import com.tx.redis.service.RedisLockService;
import com.tx.redis.service.RedisService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.api.mapper.UserConsumeMapper;
import com.foundao.nft.common.model.UserConsume;
/**
    @Package: com.foundao.nft.api.service.impl
    @ClassName: UserConsumeService
    @Author: chenli
    @CreateTime: 2022/11/3 11:17 AM
    @Description:
*/
@Service
@RequiredArgsConstructor
public class UserConsumeService extends ServiceImpl<UserConsumeMapper, UserConsume> {

    private final RedisService redisService;

    private final RedisLockService redisLockService;
    private final NftUserService userService;

    private final AwardInfoService awardInfoService;

    private final AwardRecordService awardRecordService;

    public void incrUserConsume(Integer userId,Integer fee) {
        String beginDateStr = (String) redisService.hget(RedisKeyFactory.getH5ActivityInfoKey(), "beginDate");
        String endDateStr = (String) redisService.hget(RedisKeyFactory.getH5ActivityInfoKey(), "endDate");
        String activityId = (String) redisService.hget(RedisKeyFactory.getH5ActivityInfoKey(), "activityId");

        //利用分布式锁扣除库存
        String awardLockKey = RedisKeyFactory.getPlaceAwardLock(activityId);
        boolean isSuccess = redisLockService.tryLock(awardLockKey, 5);
        if (isSuccess) {
            try {
                DateTime beginDate = DateUtil.parse(beginDateStr);
                DateTime endDate = DateUtil.parse(endDateStr);
                DateTime now = DateUtil.date();
                
                NftUser user = userService.getById(userId);
                if (StrUtil.isNotBlank(activityId) && DateUtil.compare(now, beginDate) >= 0 && DateUtil.compare(endDate, now) >= 0) {
                    UserConsume userConsume = this.lambdaQuery()
                            .eq(UserConsume::getUserId, user.getUserId())
                            .eq(UserConsume::getActivityId, activityId)
                            .one();

                    if (userConsume == null) {
                        userConsume = new UserConsume();
                        userConsume.setUserId(user.getUserId());
                        userConsume.setActivityId(Integer.valueOf(activityId));
                        userConsume.setTotalCostFee(0);
                    }
                    userConsume.setTotalCostFee(userConsume.getTotalCostFee() + fee);
                    this.saveOrUpdate(userConsume);

                    List<AwardInfo> list = awardInfoService.lambdaQuery()
                            .eq(AwardInfo::getActivityId, activityId)
                            .orderByAsc(AwardInfo::getLevel)
                            .orderByDesc(AwardInfo::getIsGoldAward)
                            .list();
                    for (AwardInfo awardInfo : list) {
                        if (userConsume.getTotalCostFee()>=awardInfo.getLevel()) {
                            if (awardInfo.getIsGoldAward()==1) {
                                if (user.getRightLevel()!=2) {
                                    continue;
                                }
                            }
                            Integer count = awardRecordService.lambdaQuery()
                                    .eq(AwardRecord::getUserId, userId)
                                    .eq(AwardRecord::getActivityId, activityId)
                                    .eq(AwardRecord::getLevel,awardInfo.getLevel())
                                    .count();
                            if (count==0) {
                                if (awardInfo.getRestCount()>0) {
                                    AwardRecord record = new AwardRecord();
                                    record.setIsGoldAward(awardInfo.getIsGoldAward());
                                    record.setAwardId(awardInfo.getAwardId());
                                    record.setLevel(awardInfo.getLevel());
                                    record.setUserId(userId);
                                    record.setActivityId(Integer.valueOf(activityId));
                                    awardRecordService.save(record);
                                    awardInfo.setRestCount(awardInfo.getRestCount()-1);
                                    awardInfoService.updateById(awardInfo);
                                }
                            }
                        }
                    }


                }
            } finally {
                redisLockService.unlock(awardLockKey);
            }
        }



    }

    public H5ActivityInfoVO h5ActivityInfo(Long userId) {

        H5ActivityInfoVO vo = new H5ActivityInfoVO();

        String beginDate = (String) redisService.hget(RedisKeyFactory.getH5ActivityInfoKey(), "beginDate");
        String endDate = (String) redisService.hget(RedisKeyFactory.getH5ActivityInfoKey(), "endDate");
        String activityId = (String) redisService.hget(RedisKeyFactory.getH5ActivityInfoKey(), "activityId");
        if (StrUtil.isNotBlank(beginDate) && StrUtil.isNotBlank(endDate)) {

            List<AwardInfo> list = awardInfoService.lambdaQuery()
                    .eq(AwardInfo::getActivityId, activityId)
                    .orderByAsc(AwardInfo::getLevel,AwardInfo::getIsGoldAward)
                    .list();
            List<H5ActivityLevelInfoVO> levelInfos = new ArrayList<>();
            list.forEach( info -> {
                H5ActivityLevelInfoVO levelInfo = new H5ActivityLevelInfoVO();
                levelInfo.setLevel(info.getLevel());
                levelInfo.setRestCount(info.getRestCount());
                levelInfo.setTotalCount(info.getTotalCount());
                levelInfo.setIsGoldAward(info.getIsGoldAward());
                levelInfo.setEarn(0);
                if (userId!=null) {
                    Integer count = awardRecordService.lambdaQuery()
                            .eq(AwardRecord::getUserId, userId)
                            .eq(AwardRecord::getActivityId, activityId)
                            .eq(AwardRecord::getLevel, info.getLevel())
                            .eq(AwardRecord::getIsGoldAward, info.getIsGoldAward())
                            .count();
                    if (count>0) {
                        levelInfo.setEarn(1);
                    }
                }
                levelInfos.add(levelInfo);
            });
            if (userId!=null) {
                UserConsume userConsume = this.lambdaQuery()
                        .eq(UserConsume::getUserId, userId)
                        .eq(UserConsume::getActivityId, activityId)
                        .select(UserConsume::getTotalCostFee)
                        .one();
                if (userConsume!=null) {
                    vo.setTotalCostFee(userConsume.getTotalCostFee());
                } else {
                    vo.setTotalCostFee(0);
                }
            } else {
                vo.setTotalCostFee(0);
            }
            vo.setLevelInfos(levelInfos);
        } else {
            throw new BusException("系统异常");
        }
        return vo;
    }

    public List<UserConsumeRankVO> consumeTop50() {
        String activityId = (String) redisService.hget(RedisKeyFactory.getH5ActivityInfoKey(), "activityId");
        return baseMapper.consumeTop50(activityId);
    }
}
