package com.foundao.nft.api.vo;

import lombok.Builder;
import lombok.Data;

/**
 * @Package: com.foundao.nft.api.vo
 * @ClassName: SendMsgRequest
 * @Author: chenli
 * @CreateTime: 2022/2/18 5:32 下午
 * @Description:
 */
@Data
@Builder
public class SendMsgRequest {

    private String appKey;

    private String channel;

    private String content;

    private String mobile;

    private String purpose;

    private String sign;
}
