package com.foundao.nft.api.service;

import com.foundao.nft.common.model.NftOrder;

/**
 * 用于处理订单
 */
public interface OrderPostHandler {

    /**
     * 处理订单完成
     * @param tradeNo 订单号
     * @param orderType 订单类型
     */
    void handleOrderFinish(String tradeNo,Integer orderType);

    /**
     * 是否支持该订单类型
     * @param orderType 订单类型
     */
    boolean supportOrderType(Integer orderType);

    /**
     * 释放库存
     * @param order 订单信息
     */
    void cancelOrder(NftOrder order);
}
