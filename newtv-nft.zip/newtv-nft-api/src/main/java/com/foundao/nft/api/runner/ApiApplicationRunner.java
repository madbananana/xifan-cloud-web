package com.foundao.nft.api.runner;

import cn.hutool.core.io.FileUtil;
import cn.hutool.core.io.IoUtil;
import cn.hutool.core.io.file.FileReader;
import cn.hutool.core.net.NetUtil;
import cn.hutool.core.util.CharsetUtil;
import cn.hutool.dfa.SensitiveUtil;
import com.baomidou.mybatisplus.extension.toolkit.ChainWrappers;
import com.foundao.nft.api.service.impl.NftRecordService;
import com.foundao.nft.api.service.impl.NftUserService;
import com.foundao.nft.api.service.impl.TransferRecordService;
import com.foundao.nft.common.properties.WeChatProperties;
import com.foundao.nft.common.util.WeChatUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.io.FileNotFoundException;
import java.nio.charset.Charset;
import java.util.LinkedHashSet;

/**
 * @ClassName ApiApplicationRunner
 * @Description TODO
 * @Author xifan
 * @Date 2021/12/19 11:41
 * @Version 1.0
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class ApiApplicationRunner implements ApplicationRunner {

    private final WeChatProperties properties;
    @Value("${task.execute-ip}")
    private String executeIp;
    private final NftUserService userService;

    @Override
    public void run(ApplicationArguments args) throws Exception {
        initWeChatAppConfig();
        initSensitiveUtil();
        initRightUser();
    }

    private void initWeChatAppConfig() {
        log.info("初始化微信小程序工具类");
        WeChatUtil.APPID = properties.getAppId();
        WeChatUtil.SECRET = properties.getSecret();
        WeChatUtil.ACCESSTOKENURL = properties.getAccessTokenUrl();
        WeChatUtil.CODE2SESSIONURL = properties.getCode2SessionUrl();
        WeChatUtil.GETUNLIMITEDURL = properties.getUnlimitedUrl();
    }

    private void initSensitiveUtil() throws FileNotFoundException {
        log.info("初始化敏感词工具");
        String sensitives = IoUtil.readUtf8(ApiApplicationRunner.class.getResourceAsStream("/sensitive.txt"));
        SensitiveUtil.init(sensitives,',',true);
    }

    private void initRightUser() {
        LinkedHashSet<String> strings = NetUtil.localIpv4s();
        if (!strings.contains(executeIp)) {
            return ;
        }
        log.info("初始化权益用户工具");
        userService.initRightUser();
    }

}
