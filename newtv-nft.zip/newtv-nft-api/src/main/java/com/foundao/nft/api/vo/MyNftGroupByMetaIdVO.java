package com.foundao.nft.api.vo;

import lombok.Data;

import java.util.List;

/**
 * @Package: com.foundao.nft.api.vo
 * @ClassName: MyNftGroupByMetaIdVO
 * @Author: chenli
 * @CreateTime: 2022/7/19 4:22 下午
 * @Description:
 */
@Data
public class MyNftGroupByMetaIdVO {
    private List<MyNftVO> nfts;
    private Integer metaId;
    private Integer count;
    private Integer metaType;
    private Integer maxId;
    private Integer waitReceive;
    private Integer transferTime;
}
