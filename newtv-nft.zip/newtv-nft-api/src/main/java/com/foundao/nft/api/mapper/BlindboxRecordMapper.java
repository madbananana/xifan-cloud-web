package com.foundao.nft.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.api.vo.BlindBoxGroupVO;
import com.foundao.nft.common.model.BlindboxRecord;
import com.foundao.nft.common.model.vo.BlindBoxVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
    @Package: com.foundao.nft.api.mapper
    @ClassName: BlindboxRecordMapper
    @Author: chenli
    @CreateTime: 2022/7/14 5:08 下午
    @Description:
*/
@Mapper
public interface BlindboxRecordMapper extends BaseMapper<BlindboxRecord> {

    List<BlindBoxVO> listBlindBox(Page<BlindBoxVO> page, @Param("status") Integer status,@Param("userId") Long userId);

    List<BlindBoxGroupVO> listBlindGroupBySeriesId(Page<BlindBoxGroupVO> page, @Param("status") Integer status, @Param("userId") Long userId);

    List<BlindBoxVO> selectBySeriesId(@Param("seriesId") Integer seriesId,@Param("userId") Long userId);
}
