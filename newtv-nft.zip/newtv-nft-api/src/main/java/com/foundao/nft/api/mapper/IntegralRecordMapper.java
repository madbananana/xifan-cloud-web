package com.foundao.nft.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.common.model.IntegralRecord;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface IntegralRecordMapper extends BaseMapper<IntegralRecord> {

    @Select("select * from nft_integral_record where user_id=#{userId} order by create_time desc")
    List<IntegralRecord> pageIntegral(Page<IntegralRecord> page, @Param("userId") Long userId);
}
