package com.foundao.nft.api.service.impl;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.extension.toolkit.ChainWrappers;
import com.foundao.nft.api.mapper.NftMetadataMapper;
import com.foundao.nft.api.vo.NftInfoVO;
import com.foundao.nft.common.constant.FoundaoConstant;
import com.foundao.nft.common.model.Goods;
import com.foundao.nft.common.model.NftMetadata;
import com.foundao.nft.common.model.NftSeriesClaim;
import com.foundao.nft.common.model.vo.CollectionBrandAndIssuerInfoVO;
import com.foundao.nft.common.model.vo.NftRecordVO;
import com.foundao.nft.common.util.RedisKeyFactory;
import com.foundao.nft.common.util.SortUtil;
import com.tx.core.beans.BaseRequestVo;
import com.tx.redis.annotation.FdRedisCache;
import com.tx.redis.service.RedisService;
import org.springframework.aop.framework.AopContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@EnableAspectJAutoProxy(exposeProxy = true)
public class NftMetadataService extends ServiceImpl<NftMetadataMapper, NftMetadata> {
    @Autowired
    private NftRecordService recordService;
    @Autowired
    private RedisService redisService;
    @Autowired
    private RecipeCollectionService collectionService;

    public NftMetadata getByTaskId(String taskId){
        return ChainWrappers.lambdaQueryChain(baseMapper)
                .eq(NftMetadata::getTaskId,taskId)
                .one();
    }


    public Goods getRelateGoodsByNftId(String nftId) {
        return baseMapper.getRelateGoodsByNftId(nftId);
    }

    /**
     * 通过nftId获取nft
     * @param nftId nftId
     * @return
     */
    public NftMetadata getByNftId(String nftId){
        return ChainWrappers.lambdaQueryChain(baseMapper)
                .like(NftMetadata::getNftId,nftId)
                .last("limit 1")
                .one();
    }

    /**
     * 增加nft的库存
     * @param metaId nft的自增id
     * @param count 增加库存数量
     * @return
     */
    public boolean incrementNftStock(Integer metaId,int count){
        return  ChainWrappers.lambdaUpdateChain(baseMapper)
                .eq(NftMetadata::getMetaId, metaId)
                .setSql("rest_count=rest_count+" + count)
                .setSql("show_count=show_count+" + count)
                .update();
    }

    /**
     * 减少库存
     * @param metaId 自增id
     * @param version 版本号
     * @param reduceCount 减少数量
     */
    public boolean reduceNftStock(Integer metaId, Integer version, int reduceCount){
        return  ChainWrappers.lambdaUpdateChain(baseMapper)
                .eq(NftMetadata::getMetaId, metaId)
                .gt(NftMetadata::getRestCount, 0)
                .setSql("rest_count=rest_count-" + reduceCount)
                .setSql("show_count=show_count-" + reduceCount)
                .update();
    }


    /**
     * 获取该系列下面还有多少未售完的记录
     * @param seriesId 系列id
     * @return
     */
    public int countRestCount(String seriesId){
        return Optional.ofNullable(baseMapper.countRestCount(seriesId)).orElse(0);
    }

    /**
     * 获取该系列下面还有多少未售完的记录
     * @param seriesId 系列id
     * @return
     */
    public int countShowRestCount(String seriesId) {
        return Optional.ofNullable(baseMapper.countShowRestCount(seriesId)).orElse(0);
    }

    /**
     * 获取一个系列下面第一个作品
     */
    public NftInfoVO firstNftOfSeries(String seriesId,Integer userId) {
        NftInfoVO infoVO = baseMapper.firstNftInfo(seriesId);
        if(infoVO == null){
            return null;
        }
        infoVO.setBuy(recordService.isPayProductId(userId,infoVO.getMetaId()));
        return infoVO;
    }

    /**
     * 获取一个系列下面的作品
     * @param seriesId 系列id
     */
    public List<NftInfoVO> listNftOfSeries(String seriesId, Integer userId, NftSeriesClaim seriesClaim,boolean isBlindBox) {
        List<NftInfoVO> nftInfoVOS;
        if(null != AopContext.currentProxy()){
            NftMetadataService proxy = (NftMetadataService) AopContext.currentProxy();
            nftInfoVOS = proxy.listNftInfo(seriesId,isBlindBox);
        }else{
            nftInfoVOS = listNftInfo(seriesId,isBlindBox);
        }
        nftInfoVOS.forEach(nftInfoVO -> {
            //Integer count = (Integer) redisService.hget(RedisKeyFactory.getShowCountKey(), nftInfoVO.getMetaId() + "");
            //if (count!=null && count!=0) {
            //    nftInfoVO.setPublishCount(count);
            //}
            if (StrUtil.isNotBlank(seriesClaim.getRareCover())) {
                if (nftInfoVO.getMetaType()==3) {
                    nftInfoVO.setDisplayUrl(seriesClaim.getRareCover());
                }
            }
            if (userId!=null){
                nftInfoVO.setBuy(recordService.isPayProductId(userId,nftInfoVO.getMetaId()));
            }
        });

        return nftInfoVOS;
    }

    @FdRedisCache(expireTime = 10,key = "'listNft:'+#seriesId")
    public List<NftInfoVO> listNftInfo(String seriesId,boolean isBlindBox) {
        return baseMapper.listNftInfo(seriesId,isBlindBox);
    }

    /**
     * 获取nft详情
     * @param nftId nftid
     * @param userId 用户id
     * @param ownerUserId 拥有此nft的用户id
     * @return
     */
    public NftInfoVO nftInfo(String nftId, Integer userId,Integer ownerUserId,String actualNftId) {
        NftInfoVO infoVO;
        if(null != AopContext.currentProxy()){
            NftMetadataService proxy = (NftMetadataService) AopContext.currentProxy();
            infoVO = proxy.nftInfoByNftId(nftId);
        }else{
            infoVO = nftInfoByNftId(nftId);
        }
        if (infoVO==null) {
            return null;
        }
        infoVO.setServerCurTime(DateUtil.now());
        int leadTime = (int) redisService.hget(RedisKeyFactory.getLeadTimeKey(), "leadTime");
        int adLeadTime = (int) redisService.hget(RedisKeyFactory.getLeadTimeKey(), "adLeadTime");
        infoVO.setLeadTime(leadTime);
        infoVO.setAdUserLeadTime(adLeadTime);

        NftRecordVO record = null;
        if(ownerUserId != null){
            //获取该nft购买/赠送信息
//            if(infoVO.getMetaType() == 2){
//                record = recordService.isPaySeriesId(ownerUserId,infoVO.getSeriesId());
//            } else {
//                record = recordService.getRecordVOByNftIdAndUserId(nftId, ownerUserId,actualNftId);
//            }
            record = recordService.getRecordVOByNftIdAndUserId(nftId, ownerUserId,actualNftId);
            if(record != null){
                infoVO.setGiverUserName(record.getGiverUserName());
                infoVO.setOwnerAddr(record.getOwnerAddr());
                infoVO.setObtainType(record.getObtainType());
                infoVO.setOwnerName(record.getOwnerName());
                infoVO.setOwnerTime(DateUtil.formatDateTime(record.getOwnerTime()));
                infoVO.setTxHash(record.getTxHash());
                infoVO.setActualNftId(record.getActualNftId());
            }
        }
        infoVO.setAppointment(0);
        if (userId!=null) {
            if(infoVO.getMetaType() == 2){
                record = recordService.isPaySeriesId(userId,infoVO.getSeriesId());
                if(record != null){
                    infoVO.setBuy(true);
                }
            } else {
                infoVO.setBuy(recordService.isPayProductId(userId,infoVO.getMetaId()));
                Integer status = (Integer) redisService.hget(RedisKeyFactory.getAppointmentKey(infoVO.getSeriesId()), userId + "");
                if (status!=null) {
                    infoVO.setAppointment(1);
                }
                Integer metaId = (Integer) redisService.hget(RedisKeyFactory.getCategoryMetaIdKey(), infoVO.getCategoryId() + "");
                Boolean exist = redisService.hHasKey(RedisKeyFactory.getStarUserIdKey(metaId), userId+"");
                if (exist) {
                    infoVO.setAdvancedUser(1);
                }
            }
        }
        return infoVO;
    }

    @FdRedisCache(expireTime = 10,key = "'nftInfo:'+#nftId")
    public NftInfoVO nftInfoByNftId(String nftId){
        return baseMapper.nftInfo(nftId);
    }


    @FdRedisCache(expireTime = 6000,key = "'nftMetaData:'+#metaId")
    public NftMetadata getByMetaId(String metaId) {
        return getById(metaId);
    }

    @FdRedisCache(expireTime = 10,key = "'pageNftInfoBySeriesId:'+#seriesId+'-'+#request.page+'-'+#request.num")
    public List<NftInfoVO> pageNftInfoBySeriesId(BaseRequestVo request, String seriesId) {
        Page<NftInfoVO> page = new Page<>(request.getPage(),request.getNum());
        IPage<NftInfoVO> result = baseMapper.pageNftInfoBySeriesId(page,seriesId);
        return result.getRecords();
    }
}
