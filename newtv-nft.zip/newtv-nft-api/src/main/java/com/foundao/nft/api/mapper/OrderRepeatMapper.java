package com.foundao.nft.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.foundao.nft.common.model.OrderRepeat;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface OrderRepeatMapper extends BaseMapper<OrderRepeat> {
}
