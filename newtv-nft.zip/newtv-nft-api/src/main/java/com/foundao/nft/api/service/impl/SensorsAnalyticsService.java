package com.foundao.nft.api.service.impl;

import cn.hutool.core.util.StrUtil;
import com.foundao.nft.api.mapper.OrderExtMapper;
import com.foundao.nft.common.constant.PayTypeEnum;
import com.foundao.nft.common.model.NftOrder;
import com.foundao.nft.common.model.OrderExt;
import com.sensorsdata.analytics.javasdk.ISensorsAnalytics;
import com.sensorsdata.analytics.javasdk.bean.EventRecord;
import com.sensorsdata.analytics.javasdk.exceptions.InvalidArgumentException;
import com.tx.core.util.HttpRequestUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.concurrent.CompletableFuture;

/**
 * @Package: com.foundao.nft.api.service.impl
 * @ClassName: SensorsAnalyticsService
 * @Author: chenli
 * @CreateTime: 2022/12/5 16:35
 * @Description:
 */
@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class SensorsAnalyticsService {

    private final ISensorsAnalytics sensorsAnalytics;
    private final OrderExtMapper orderExtMapper;


    private void sendEvent(EventRecord eventRecord) {
        try {
            sensorsAnalytics.track(eventRecord);
        } catch (InvalidArgumentException e) {
            log.error("上报数据异常",e);
        }
    }

    public void signUpEvent(String userId,boolean result,String reason,String mobile) {
        String uuid = HttpRequestUtil.getHeader("uuid");
        String appVersion = HttpRequestUtil.getHeader("appVersion");
        String packageName = HttpRequestUtil.getHeader("packageName");
        if (uuid==null) {
            uuid = "";
        }
        if (appVersion==null) {
            appVersion = "";
        }
        if (packageName==null) {
            packageName = "";
        }
        String finalUuid = uuid;
        String finalAppVersion = appVersion;
        String finalPackageName = packageName;
        CompletableFuture.runAsync(()->{
            try {
                EventRecord eventRecord = EventRecord.builder()
                        .setDistinctId(userId)
                        .isLoginId(true)
                        .setEventName("signUp")
                        .addProperty("appKey","未来数藏")
                        .addProperty("uuid", finalUuid)
                        .addProperty("userid",userId)
                        .addProperty("isLogin",true)
                        .addProperty("appVersion", finalAppVersion)
                        .addProperty("macAddress","")
                        .addProperty("packageName", finalPackageName)
                        .addProperty("loginFailReason",reason)
                        .addProperty("result",result)
                        .addProperty("method","sms_code")
                        .build();
                sendEvent(eventRecord);
                log.info("上报注册事件：{}",eventRecord);
            } catch (Exception e) {
                log.error("构建事件对象异常",e);
            }
        });
    }

    public void nameIdentityEvent(String userId,boolean result,String uuid,String appVersion,String packageName){
        try {
            EventRecord eventRecord = EventRecord.builder()
                    .setDistinctId(userId)
                    .isLoginId(true)
                    .setEventName("nameIdentity")
                    .addProperty("appKey","未来数藏")
                    .addProperty("uuid",uuid==null?"":uuid)
                    .addProperty("userid",userId)
                    .addProperty("isLogin",true)
                    .addProperty("appVersion",appVersion==null?"":appVersion)
                    .addProperty("macAddress","")
                    .addProperty("packageName",packageName==null?"":packageName)
                    .addProperty("result",result)
                    .build();
            sendEvent(eventRecord);
            log.info("上报实名事件：{}",eventRecord);
        } catch (InvalidArgumentException e) {
            log.error("构建事件对象异常",e);
        }
    }

    public void payOrderEvent(NftOrder order, String seriesID, String seriesName, String collectId, String metaName){
        try {
            OrderExt orderExt = orderExtMapper.getOrderExtByOrderId(order.getOrderId());
            if (orderExt.getPackageName()==null) {
                orderExt.setPackageName("");
            }
            if (orderExt.getAppVersion()==null) {
                orderExt.setAppVersion("");
            }
            if (orderExt.getUuid()==null) {
                orderExt.setUuid("");
            }
            EventRecord eventRecord = EventRecord.builder()
                    .setEventName("PayOrder")
                    .setDistinctId(order.getUserId()+"")
                    .isLoginId(true)
                    .addProperty("appKey","未来数藏")
                    .addProperty("uuid",orderExt.getUuid())
                    .addProperty("userid",order.getUserId()+"")
                    .addProperty("isLogin",true)
                    .addProperty("appVersion",orderExt.getAppVersion())
                    .addProperty("macAddress","")
                    .addProperty("packageName",orderExt.getPackageName())
                    .addProperty("seriesID",seriesID)
                    .addProperty("seriesName",seriesName)
                    .addProperty("collectID",collectId)
                    .addProperty("collectName",metaName)
                    .addProperty("orderCode",order.getTradeNo())
                    .addProperty("orderAmount",order.getOrderFee()+"")
                    .addProperty("paidAmount",order.getFee()+"")
                    .addProperty("paidMethod",getPayTypeText(order.getPayType()))
                    .build();
            sendEvent(eventRecord);
            log.info("上报完成支付事件：{}",eventRecord);
        } catch (Exception e) {
            log.error("构建事件对象异常",e);
        }
    }

    public String getPayTypeText(String payType){
        if(StrUtil.isBlank(payType)){
            return "";
        }
        if(payType.equalsIgnoreCase(PayTypeEnum.APPLE_PAY.getCode())){
            return "IOS支付";
        }else if(payType.equalsIgnoreCase(PayTypeEnum.ALI_PAY.getCode())){
            return "支付宝支付";
        }else if(payType.equalsIgnoreCase(PayTypeEnum.WX_PAY.getCode())){
            return "微信支付";
        }else if(payType.equalsIgnoreCase(PayTypeEnum.INTEGRAL_PAY.getCode())){
            return "积分兑换";
        }else{
            return "";
        }
    }
}
