package com.foundao.nft.api.controller;

import com.foundao.nft.api.service.impl.IntegralRecordService;
import com.foundao.nft.api.service.impl.IntegralService;
import com.foundao.nft.common.model.Integral;
import com.foundao.nft.common.model.IntegralRecord;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.JsonResult;
import com.tx.security.annotation.AnonymousPostMapping;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @ClassName IntegralController
 * @Description TODO
 * @Author xifan
 * @Date 2022/8/22 19:50
 * @Version 1.0
 */
@RestController
@RequiredArgsConstructor
@Api(tags = "积分")
@RequestMapping("integral")
@Slf4j
@Validated
public class IntegralController {

    private final IntegralRecordService integralRecordService;

    @PostMapping("/page")
    @ApiOperation("积分列表")
    public JsonResult<List<IntegralRecord>> pageIntegral(BaseRequestVo request){
        return JsonResult.success(integralRecordService.pageIntegral(request));
    }
}
