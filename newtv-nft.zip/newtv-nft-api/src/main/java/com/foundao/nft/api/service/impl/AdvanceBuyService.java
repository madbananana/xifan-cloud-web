package com.foundao.nft.api.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.extension.toolkit.ChainWrappers;
import com.foundao.nft.api.mapper.AdvanceBuyMapper;
import com.foundao.nft.common.model.AdvanceBuy;
import org.springframework.stereotype.Service;

import java.util.List;
/**
    @Package: com.foundao.nft.api.service.impl
    @ClassName: AdvanceBuyService
    @Author: chenli
    @CreateTime: 2022/3/25 3:31 下午
    @Description:
*/
@Service
public class AdvanceBuyService extends ServiceImpl<AdvanceBuyMapper, AdvanceBuy> {

    public List<AdvanceBuy> getByUserId(Long userId) {
        return baseMapper.listAllByUserId(userId);
    }

    /**
     * 清除预约
     * @param userId
     */
    public void clearUserAdvance(Integer userId,String seriesId) {
        baseMapper.clearAdvance(userId,seriesId);
    }

    public List<AdvanceBuy> findAllWaiteNotice(String seriesId) {
        return baseMapper.findAllWaiteNotice(seriesId);
    }

    public String findAllNoticeSeriesId(){
        return baseMapper.findAllNoticeSeriesId();
    }
}
