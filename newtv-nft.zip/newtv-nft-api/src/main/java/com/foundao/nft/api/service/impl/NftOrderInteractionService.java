package com.foundao.nft.api.service.impl;

import com.alibaba.fastjson.JSON;
import com.foundao.nft.common.constant.TaskEnum;
import com.foundao.nft.common.model.NftRecord;
import com.foundao.nft.common.model.NftTask;
import com.foundao.nft.common.model.sdk.client.NftService;
import com.foundao.nft.common.model.sdk.request.NftBuyRequest;
import com.foundao.nft.common.model.sdk.response.SdkResponseBase;
import com.foundao.nft.common.model.sdk.response.TaskResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class NftOrderInteractionService {
    private final NftService nftService;
    private final NftRecordService recordService;
    private final NftTaskService taskService;

    /**
     * 购买nft逻辑
     * @param request nft购买请求
     * @param userPriKey 用户私钥key
     * @param extData 扩展数据
     * @return boolean
     */
    @Transactional(rollbackFor = Exception.class)
    public NftTask doBuyNft(NftBuyRequest request,String userPriKey,NftTask.NftBuyExtInfo extData){
        SdkResponseBase<TaskResponse> taskResponse = nftService.nftBuy(request,userPriKey);
        if (taskResponse.getRetCode()==0) {

            //提前给用户新增nft购买记录
            NftRecord record = recordService.addBuyRecord(extData);
            extData.setRecordId(Integer.valueOf(record.getId()));
            //新增任务
            String taskId = taskResponse.getData().getTaskId();
            NftTask task = new NftTask();
            task.setStatus(2);
            task.setType(TaskEnum.NFT_BUY.getCode());
            task.setExtend1(request.getNftId());
            task.setExtend2(extData.getUserId() + "");
            task.setExtend3(JSON.toJSONString(extData));
            task.setTaskId(taskId);
            task.setRecordId(record.getId());
            taskService.save(task);

            return task;
        }
        return null;
    }
}
