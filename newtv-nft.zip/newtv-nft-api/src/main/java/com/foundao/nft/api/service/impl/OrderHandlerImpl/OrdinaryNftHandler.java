package com.foundao.nft.api.service.impl.OrderHandlerImpl;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.IdUtil;
import cn.hutool.core.util.StrUtil;
import com.foundao.nft.api.mapper.OrderRepeatMapper;
import com.foundao.nft.api.service.OrderPostHandler;
import com.foundao.nft.api.service.impl.*;
import com.foundao.nft.common.constant.IntegralTypeEnum;
import com.foundao.nft.common.constant.OrderStatusEnum;
import com.foundao.nft.common.constant.PayTypeEnum;
import com.foundao.nft.common.model.*;
import com.foundao.nft.common.model.sdk.request.NftBuyRequest;
import com.foundao.nft.common.properties.NftProperties;
import com.foundao.nft.common.util.RedisKeyFactory;
import com.tx.redis.service.RedisService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

/**
 * 普通nft购买
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class OrdinaryNftHandler implements OrderPostHandler {
    private final NftOrderService orderService;
    private final NftRecordService nftRecordService;
    private final NftUserPlatformService userPlatformService;
    private final NftProperties nftProperties;
    private final NftMetadataService metadataService;
    private final NftIdHelper nftIdHelper;
    private final NftSeriesClaimService seriesClaimService;
    private final NftOrderInteractionService orderInteractionService;
    private final OrderRepeatMapper orderRepeatMapper;
    private final RedisService redisService;
    private final BlindboxRecordService blindboxRecordService;
    private final UserConsumeService userConsumeService;

    private final SensorsAnalyticsService sensorsAnalyticsService;
    private final WaitChainUpService waitChainUpService;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void handleOrderFinish(String tradeNo, Integer orderType) {
        //if(!supportOrderType(orderType)){
        //    return;
        //}
        NftOrder order = orderService.getByTradeNo(tradeNo);
        NftSeriesClaim seriesClaim = seriesClaimService.getByIdCache(order.getShortSeriesId() + "");

        String seriesId = seriesClaim.getId()+"";
        String seriesName = seriesClaim.getSeriesName();
        String acMetaId = "";
        String metaName = "";
        if (order.getOrderType()==11) {
            Map<String, String> nftIds = orderService.lockActualNftStock(order);
            List<BlindboxRecord> records = new ArrayList<>();
            nftIds.forEach((id,metaId) -> {
                BlindboxRecord record = new BlindboxRecord();
                record.setUserId(order.getUserId());
                record.setStatus(0);
                record.setActualNftId(id);
                record.setShortSeriesId(order.getShortSeriesId());
                record.setMetaId(Integer.valueOf(metaId));
                record.setOrderId(order.getOrderId());
                record.setBlindBoxIcon(seriesClaim.getBlindBoxIcon());
                record.setOpenTime(seriesClaim.getOpenTime());
                records.add(record);
            });
            blindboxRecordService.saveBatch(records);
            if (PayTypeEnum.INTEGRAL_PAY.getCode().equals(order.getPayType())) {
                orderService.integralOperation(order.getUserId(),order.getTradeNo(),IntegralTypeEnum.BUY_NFT.getType(),"out",(int) Math.ceil((order.getOrderFee()/100.0)),seriesClaim.getSeriesName(), DateUtil.formatDateTime(order.getPayTime()));
            }
        } else {
            //判断该藏品是否已经持有，如果持有该藏品，不能继续上链
            NftRecord oriRecord = nftRecordService.getRecordByMetaIdAndUserId(order.getProductId(), order.getUserId(),order.getProductId2());
            if(oriRecord != null){
                //如果该用户已经拥有该藏品，执行到此处又表示已经再次付款了，那么把该数据全部存储在单独的数据表中存放做退款提示或补偿操作
                OrderRepeat orderRepeat = OrderRepeat.builder().orderId(order.getOrderId()).userId(order.getUserId())
                        .metaId(order.getProductId()).mark("已拥有藏品,再次付款").build();
                orderRepeatMapper.insert(orderRepeat);
                return ;
            }
            //获取nft元信息
            NftMetadata nftMetadata = metadataService.getById(order.getProductId());
            //获取用户认证信息
            NftUserPlatform userPlatform = userPlatformService.getById(order.getUserId());

            NftTask.NftBuyExtInfo extData = new NftTask.NftBuyExtInfo();
//            extData.setNftId(request.getNftId());//nft开始id
            extData.setNftId(order.getProductId2());
            extData.setMetaId(nftMetadata.getMetaId());
            extData.setMetaType(1);
            extData.setUserId(order.getUserId());
            extData.setOrderId(order.getOrderId());

            //如果用户未实名
            if (userPlatform==null) {
                NftRecord nftRecord = nftRecordService.addBuyRecord(extData);
                WaitChainUp waitChainUp = new WaitChainUp();
                waitChainUp.setOrderId(order.getOrderId());
                waitChainUp.setUserId(order.getUserId());
                waitChainUp.setRecordId(Integer.valueOf(nftRecord.getId()));
                waitChainUpService.save(waitChainUp);
            } else {
                NftBuyRequest request = new NftBuyRequest();
                request.setApplyScore(order.getOrderFee()/order.getCount());
                request.setNftId(order.getProductId2());
                request.setOfferCount(order.getOrderFee()/order.getCount());
                request.setOperateId(IdUtil.fastUUID());
                request.setPointReceiverAddr(userPlatform.getAddr());
                request.setReceiverPubKey(userPlatform.getPubkey());
                request.setPlatformPubKey(nftProperties.getPubKey());


                NftTask task = orderInteractionService.doBuyNft(request, userPlatform.getPrikey(), extData);
                if (task == null || task.getTaskId()==null) {
                    if ("".equals(order.getPayType())) {
                        orderService.integralUnfrozen(order.getUserId(),(int) Math.ceil((order.getOrderFee()/100.0)));
                    }
                    log.error("内部购买nft失败");
                }
            }
            acMetaId = nftMetadata.getMetaId()+"";
            metaName = nftMetadata.getName();
        }
        String finalMetaName = metaName;
        String finalMetaId = acMetaId;
        CompletableFuture.runAsync(()->{
            userConsumeService.incrUserConsume(order.getUserId(),order.getFee());
            sensorsAnalyticsService.payOrderEvent(order,seriesId,seriesName, finalMetaId, finalMetaName);
        });

    }

    @Override
    public boolean supportOrderType(Integer orderType) {
        return orderType == 1 || orderType == 11;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void cancelOrder(NftOrder order) {
        //订单标记废弃,并释放库存
        NftOrder updateOrder = new NftOrder();
        updateOrder.setOrderId(order.getOrderId());
        updateOrder.setIsAbandon(1);
        updateOrder.setStatus(OrderStatusEnum.PAY_CANCEL.getCode());
        orderService.updateById(updateOrder);

        if (order.getOrderType()!=11) {
            //更新库存
            metadataService.incrementNftStock(order.getProductId(),1);
            //释放redis zset的nft标记
            NftMetadata nftMetadata = metadataService.getById(order.getProductId());
            nftIdHelper.releaseNftFlag(nftMetadata.getNftId(),order.getProductId2());
            redisService.hdecr(RedisKeyFactory.getNftBuyCountKey(order.getProductId()), order.getUserId()+ "", Long.valueOf(order.getCount()));
        } else {
            redisService.incr(RedisKeyFactory.getSeriesStockKey(order.getShortSeriesId()), Long.valueOf(order.getCount()));
            redisService.hdecr(RedisKeyFactory.getBuyCountKey(order.getShortSeriesId()), order.getUserId()+ "", Long.valueOf(order.getCount()));
        }


    }
}
