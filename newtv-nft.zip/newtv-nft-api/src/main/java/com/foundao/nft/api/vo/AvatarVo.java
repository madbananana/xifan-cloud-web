package com.foundao.nft.api.vo;

import com.foundao.nft.common.model.AvatarFull;
import com.foundao.nft.common.model.AvatarPart;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class AvatarVo implements Serializable {


    @ApiModelProperty(value="头像id")
    private Integer id;
    /**
     * 文件访问地址
     */
    @ApiModelProperty(value="文件访问地址")
    private String url;

    /**
     * 构成头像的部件
     */
    @ApiModelProperty(value="构成头像的部件")
    private List<AvatarPart> partsList;

    @ApiModelProperty(value="完整头像的列表")
    private List<AvatarFull> fullAvatarList;

    @ApiModelProperty(value="nft至信链Id")
    private String nftId;

    @ApiModelProperty(value="抽奖任务id，抽奖结果需要前端轮询查询，频率1s/次")
    private String taskId;

    @ApiModelProperty(value="是否特殊头像")
    private boolean specialAvatar;

}
