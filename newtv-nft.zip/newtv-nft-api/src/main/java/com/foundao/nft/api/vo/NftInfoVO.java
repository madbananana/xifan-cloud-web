package com.foundao.nft.api.vo;

import com.foundao.nft.common.model.NftMetaDataPartAttr;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @Package: com.foundao.nft.common.model.vo
 * @ClassName: MyNftVO
 * @Author: chenli
 * @CreateTime: 2021/12/23 5:42 下午
 * @Description:
 */
@Data
@ApiModel("nft详情vo")
public class NftInfoVO {
    @ApiModelProperty("metaId")
    private Integer metaId;

    @ApiModelProperty("nftId")
    private String nftId;

    @ApiModelProperty("系列名")
    private String seriesName;

    @ApiModelProperty("系列id")
    private String seriesId;

    @ApiModelProperty("获取时间")
    private String ownerTime;

    @ApiModelProperty("预览图")
    private String displayUrl;

    @ApiModelProperty("拥有者姓名")
    private String ownerName;

    @ApiModelProperty("拥有者头像")
    private String avatar;

    @ApiModelProperty("作品链接")
    private String url;

    @ApiModelProperty(value = "原始作品地址")
    private String oriUrl;

    @ApiModelProperty("nft名称")
    private String name;

    @ApiModelProperty("描述")
    private String desc;

    @ApiModelProperty("hash")
    private String hash;

    @ApiModelProperty("藏品地址")
    private String txHash;

    @ApiModelProperty("作者")
    private String author;

    @ApiModelProperty("剩余未售卖份数")
    private Integer restCount;

    @ApiModelProperty("前端展示剩余份数")
    private Integer showCount;

    @ApiModelProperty("发行分数")
    private Integer publishCount;

    @ApiModelProperty("扩展信息")
    private String metaData;

    @ApiModelProperty("图片描述列表")
    private String imageDesc;

    @ApiModelProperty(value = "1普通资源 2 牛头资源 3盲盒资源")
    private Integer metaType;

    @ApiModelProperty("1普通款 3隐藏款")
    private Integer seriesMetaType;

    @ApiModelProperty("获取类型 1:购买 2:获赠")
    private int obtainType;

    @ApiModelProperty("是否购买过该此作品")
    private boolean isBuy=false;

    @ApiModelProperty("作品拥有人的钱包地址")
    private String ownerAddr;

    @ApiModelProperty("赠送人名称")
    private String giverUserName;

    @ApiModelProperty("可售状态下表示出售多少积分")
    private Integer sellCount;

    @ApiModelProperty("售价，单位分，如果是免费 该字段为0")
    private Integer sellFee;

    @ApiModelProperty("发行时间")
    private String createTime;

    @ApiModelProperty("品牌方名称")
    private String brandName;

    @ApiModelProperty("品牌方图标")
    private String brandIcon;

    @ApiModelProperty("发行方名称")
    private String issuerName;

    @ApiModelProperty("发行方图标")
    private String issuerIcon;

    @ApiModelProperty("牛头属性数据")
    private List<NftMetaDataPartAttr> avatarAttrs;

    @ApiModelProperty(value="苹果内购名称")
    private String appleName;

    @ApiModelProperty(value="实际nftId")
    private String actualNftId;

    @ApiModelProperty(value="作品类型 0：图片 1：视频")
    private String type;

    @ApiModelProperty(value = "是否预约 0未预约 1已预约")
    private Integer appointment;

    @ApiModelProperty(value = "开始发售时间")
    private String beginTime;

    @ApiModelProperty(value = "结束发售时间")
    private String endTime;

    @ApiModelProperty(value = "是否免费 0收费1免费")
    private Integer charge;

    /**
     * 是否有预览图url
     */
    @ApiModelProperty(value = "是否自定义ntf预览图 0：否 1：是",required = true)
    private Integer hasDisplayUrl;

    @ApiModelProperty(value="服务器当前时间")
    private String serverCurTime;

    @ApiModelProperty(value = "是否为高级用户 0：不是 1：是")
    private Integer advancedUser = 0;

    @ApiModelProperty(value = "高级用户可提前购买时间 单位分")
    private Integer adUserLeadTime;

    @ApiModelProperty(value = "预约用户可提前购买时间 单位分")
    private Integer leadTime;

    @ApiModelProperty(value = "类型id")
    private Integer categoryId;

    @ApiModelProperty(value = "能否提前购买 0不能 1可以")
    private Integer advanceBuy;

    @ApiModelProperty(value = "能否通过积分购买 0：不能 1：能")
    private Integer canIntegralBuy;

    @ApiModelProperty(value = "合成id号")
    private Integer mergeId;

    @ApiModelProperty(value = "转赠时间")
    private Integer transferTime;

    @ApiModelProperty(value = "可转赠时间")
    private String canTransferTime;

    @ApiModelProperty(value = "是否显示流通信息 0不显示 1显示")
    private Integer showCountInfo;

    @ApiModelProperty(value = "流通数量")
    private Integer circulationCount;

    @ApiModelProperty(value = "是否显示发行数量 0：不显示 1：显示")
    private Integer showPublishCount;

    @ApiModelProperty(value = "可买份数")
    private Integer buyCount;

    @ApiModelProperty(value = "是否包含实物 0不包含 1包含")
    private Integer hasGoods;

    @ApiModelProperty(value = "苹果支付类型 0：微信支付宝 1：苹果内购")
    private Integer iosPayType;

    @ApiModelProperty(value = "系列短id")
    private Integer shortSeriesId;
}
