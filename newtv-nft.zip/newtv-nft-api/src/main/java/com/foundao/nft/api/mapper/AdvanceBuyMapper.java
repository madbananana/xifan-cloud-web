package com.foundao.nft.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.foundao.nft.common.model.AdvanceBuy;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
    @Package: com.foundao.nft.api.mapper
    @ClassName: AdvanceBuyMapper
    @Author: chenli
    @CreateTime: 2022/3/25 3:31 下午
    @Description:
*/
@Mapper
public interface AdvanceBuyMapper extends BaseMapper<AdvanceBuy> {

    @Delete("delete from nft_advance_buy where user_id = #{userId} and series_id = #{seriesId}")
    int clearAdvance(@Param("userId") Integer userId,@Param("seriesId") String seriesId);

    @Select("select a.*,b.cover_url,c.brand_name,i.issuer_name from nft_advance_buy as a join nft_series_claim as b on a.series_id=b.series_id" +
            " left join nft_brand as c on b.brand_id=c.id " +
            " left join nft_issuer i on i.id=b.issuer_id where user_id=#{userId} order by a.id desc")
    List<AdvanceBuy> listAllByUserId(@Param("userId") Long userId);

    @Select("select a.*,u.mobile from nft_advance_buy a left join nft_user u on u.user_id=a.user_id where notice_status=0 and series_id=#{seriesId} order by advanced_user desc limit 100")
    List<AdvanceBuy> findAllWaiteNotice(String seriesId);

    @Select("select series_id from nft_advance_buy where notice_status=0  ORDER BY begin_time,advanced_user desc limit 1")
    String findAllNoticeSeriesId();
}
