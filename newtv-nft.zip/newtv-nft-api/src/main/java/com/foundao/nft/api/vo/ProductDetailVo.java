package com.foundao.nft.api.vo;

import lombok.Data;

import java.util.List;

@Data
public class ProductDetailVo extends ProductListVo {
    private String desc;
    private List<NftInfoVO> nfts;
    private Integer nftCount;
}
