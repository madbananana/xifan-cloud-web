package com.foundao.nft.api.vo;

import lombok.Data;

/**
 * @Package: com.foundao.nft.api.vo
 * @ClassName: AppointmentResponse
 * @Author: chenli
 * @CreateTime: 2022/4/15 10:08 上午
 * @Description:
 */
@Data
public class AppointmentResponseVO {

    private String seriesName;
    private String seriesId;
}
