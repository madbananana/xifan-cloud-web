package com.foundao.nft.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.foundao.nft.common.model.Brand;
import org.apache.ibatis.annotations.Mapper;

/**
    @Package: com.foundao.nft.api.mapper
    @ClassName: BrandMapper
    @Author: chenli
    @CreateTime: 2022/2/22 2:26 下午
    @Description:
*/
@Mapper
public interface BrandMapper extends BaseMapper<Brand> {
}