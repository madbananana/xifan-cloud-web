package com.foundao.nft.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.foundao.nft.common.model.AwardInfo;
import org.apache.ibatis.annotations.Mapper;

/**
    @Package: com.foundao.nft.api.mapper
    @ClassName: AwardInfoMapper
    @Author: chenli
    @CreateTime: 2022/11/3 11:17 AM
    @Description:
*/
@Mapper
public interface AwardInfoMapper extends BaseMapper<AwardInfo> {
}