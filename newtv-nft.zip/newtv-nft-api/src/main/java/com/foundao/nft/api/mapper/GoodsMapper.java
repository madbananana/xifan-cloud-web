package com.foundao.nft.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.foundao.nft.common.model.Goods;
import org.apache.ibatis.annotations.Mapper;

/**
    @Package: com.foundao.nft.api.mapper
    @ClassName: GoodsMapper
    @Author: chenli
    @CreateTime: 2022/2/22 2:22 下午
    @Description:
*/
@Mapper
public interface GoodsMapper extends BaseMapper<Goods> {
}