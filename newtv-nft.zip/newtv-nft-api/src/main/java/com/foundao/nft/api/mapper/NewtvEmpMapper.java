package com.foundao.nft.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.foundao.nft.common.model.NewtvEmp;
import org.apache.ibatis.annotations.Mapper;

/**
    @Package: com.foundao.nft.api.mapper
    @ClassName: NewtvEmpMapper
    @Author: chenli
    @CreateTime: 2021/12/20 6:17 下午
    @Description:
*/
@Mapper
public interface NewtvEmpMapper extends BaseMapper<NewtvEmp> {
}