package com.foundao.nft.api.service.impl;

import cn.hutool.core.util.IdUtil;
import com.foundao.nft.common.model.NftOrder;
import com.foundao.nft.common.model.NftRecord;
import com.foundao.nft.common.model.NftTask;
import com.foundao.nft.common.model.NftUserPlatform;
import com.foundao.nft.common.model.sdk.request.NftBuyRequest;
import com.foundao.nft.common.properties.NftProperties;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.common.model.WaitChainUp;
import com.foundao.nft.api.mapper.WaitChainUpMapper;
/**
    @Author: chenli
    @CreateTime: 2023/2/3 11:45
    @Description:
*/
@Service
@RequiredArgsConstructor
public class WaitChainUpService extends ServiceImpl<WaitChainUpMapper, WaitChainUp> {

    private final NftRecordService recordService;
    private final NftOrderService orderService;
    private final NftProperties nftProperties;
    private final NftOrderInteractionService orderInteractionService;

    public void executeWaitChainUp(NftUserPlatform userPlatform) {
        CompletableFuture.runAsync(()->{
            List<WaitChainUp> list = lambdaQuery().eq(WaitChainUp::getUserId, userPlatform.getUserId())
                    .list();
            list.forEach(r -> {
                NftRecord record = recordService.getById(r.getRecordId());
                NftOrder order = orderService.getById(r.getOrderId());
                NftTask.NftBuyExtInfo extData = new NftTask.NftBuyExtInfo();
                extData.setNftId(order.getProductId2());
                extData.setMetaId(record.getMetaId());
                extData.setMetaType(1);
                extData.setUserId(order.getUserId());
                extData.setOrderId(order.getOrderId());
                extData.setRecordId(r.getRecordId());

                NftBuyRequest request = new NftBuyRequest();
                request.setApplyScore(order.getOrderFee()/order.getCount());
                request.setNftId(order.getProductId2());
                request.setOfferCount(order.getOrderFee()/order.getCount());
                request.setOperateId(IdUtil.fastUUID());
                request.setPointReceiverAddr(userPlatform.getAddr());
                request.setReceiverPubKey(userPlatform.getPubkey());
                request.setPlatformPubKey(nftProperties.getPubKey());


                NftTask task = orderInteractionService.doBuyNft(request, userPlatform.getPrikey(), extData);
                if (task == null || task.getTaskId()==null) {
                    if ("".equals(order.getPayType())) {
                        orderService.integralUnfrozen(order.getUserId(),(int) Math.ceil((order.getOrderFee()/100.0)));
                    }
                    log.error("内部购买nft失败");
                }
                r.setStatus(1);
                this.updateById(r);
            });
        });
    }
}
