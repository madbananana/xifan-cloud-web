package com.foundao.nft.api.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
public class ProductListVo implements Serializable {
    @ApiModelProperty(value="id")
    private Integer id;

    @ApiModelProperty(value="系列id")
    private String seriesId;


    @ApiModelProperty(value="系列名")
    private String seriesName;

    @ApiModelProperty(value="系列总发行数量")
    private Integer totalCount;

    @ApiModelProperty(value="发行数量")
    private Integer restCount;

    @ApiModelProperty(value="开始时间")
    private String beginTime;

    @ApiModelProperty(value="截止时间")
    private String endTime;

    @ApiModelProperty(value="服务器当前时间")
    private String serverCurTime;

    @ApiModelProperty(value="如果未开始售卖，此字段表示还剩余多少秒开售，如果在售或售完，此字段为0")
    private Integer restSellTime = 0 ;

    @ApiModelProperty(value="是否在售")
    private boolean isSell;

    @ApiModelProperty(value = "1普通资源 2 牛头资源 3盲盒资源")
    private Integer metaType;


    @ApiModelProperty(value="系列封面")
    private String coverUrl;

    @ApiModelProperty(value="是否免费 0收费1免费")
    private Integer charge;

    @ApiModelProperty(value="品牌方名称")
    private String brandName;

    @ApiModelProperty(value="品牌方图标")
    private String brandIcon;

    @ApiModelProperty(value="发行方名称")
    private String issuerName;

    @ApiModelProperty(value="发行方图标")
    private String issuerIcon;

    @ApiModelProperty(value="描述图片列表")
    private String imageDesc;

    @ApiModelProperty(value = "能否提前购买 0不能 1可以")
    private String advanceBuy;

    @ApiModelProperty(value = "是否预约 0未预约 1已预约")
    private Integer appointment;

    @ApiModelProperty(value = "价格信息")
    private SeriesPriceInfoVO priceInfoVO;

    @ApiModelProperty(value = "是否为高级用户 0：不是 1：是")
    private Integer advancedUser = 0;

    @ApiModelProperty(value = "高级用户可提前购买时间 单位分")
    private Integer adUserLeadTime;

    @ApiModelProperty(value = "预约用户可提前购买时间 单位分")
    private Integer leadTime;

    @ApiModelProperty(value = "类型id")
    private Integer categoryId;

    @ApiModelProperty(value = "预约人数")
    private Integer appointmentCount;

    @ApiModelProperty(value = "盲盒开始时间")
    private String openTime;

    @ApiModelProperty(value = "盲盒封面")
    private String blindBoxIcon;

    @ApiModelProperty(value = "苹果内购id")
    private String appleName;

    @ApiModelProperty(value = "开启动画特效")
    private String openSpecialEffects;

    @ApiModelProperty(value = "能否通过积分购买 0：不能 1：能")
    private Integer canIntegralBuy;

    @ApiModelProperty(value = "是否包含实物 0不包含 1包含")
    private Integer hasGoods;

    @ApiModelProperty(value = "苹果支付类型 0：微信支付宝 1：苹果内购")
    private Integer iosPayType;
}
