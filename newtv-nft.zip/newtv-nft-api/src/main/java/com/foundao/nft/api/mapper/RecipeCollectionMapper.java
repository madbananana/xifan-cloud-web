package com.foundao.nft.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.common.model.RecipeCollection;
import com.foundao.nft.common.model.vo.CollectionBrandAndIssuerInfoVO;
import com.foundao.nft.common.model.vo.RecipeCollectionDetailsVO;
import com.foundao.nft.common.model.vo.RecipeCollectionListVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface RecipeCollectionMapper extends BaseMapper<RecipeCollection> {
    List<RecipeCollectionListVO> collectionList(Page<RecipeCollectionListVO> page);

    RecipeCollectionDetailsVO collectionDetails(@Param("collectionId") Integer collectionId);

    CollectionBrandAndIssuerInfoVO getBrandAndIssuerInfo(@Param("metaId") Integer metaId);
}
