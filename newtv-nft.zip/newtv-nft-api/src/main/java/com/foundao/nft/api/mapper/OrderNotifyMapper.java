package com.foundao.nft.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.foundao.nft.common.model.OrderNotify;
import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface OrderNotifyMapper extends BaseMapper<OrderNotify> {
    //int deleteByPrimaryKey(Integer notifyId);
    //
    //int insert(OrderNotify record);
    //
    //int insertSelective(OrderNotify record);
    //
    //OrderNotify selectByPrimaryKey(Integer notifyId);
    //
    //int updateByPrimaryKeySelective(OrderNotify record);
    //
    //int updateByPrimaryKey(OrderNotify record);
}