package com.foundao.nft.api.service.impl;

import cn.hutool.core.date.DateUtil;
import com.foundao.nft.api.mapper.OrderNotifyMapper;
import com.foundao.nft.api.service.OrderNotifyService;
import com.foundao.nft.common.model.OrderNotify;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;


@Service
@Slf4j
@RequiredArgsConstructor
public class OrderNotifyServiceImpl implements OrderNotifyService {
    private final OrderNotifyMapper orderNotifyMapper;

    @Override
    public void addNotify(String notifyData,Integer notifyType,String thirdTradeNo,String tradeNo) {
        //分析订单数据
        OrderNotify orderNotify = new OrderNotify();
        orderNotify.setCreateTime(DateUtil.now());
        orderNotify.setNotifyData(notifyData);
        orderNotify.setNotifyType(notifyType);
        orderNotify.setTradeNo(tradeNo);
        orderNotify.setThirdTradeNo(thirdTradeNo);

        orderNotifyMapper.insert(orderNotify);
    }
}
