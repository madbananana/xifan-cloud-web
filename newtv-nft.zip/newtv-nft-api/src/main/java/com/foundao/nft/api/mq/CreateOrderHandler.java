package com.foundao.nft.api.mq;

import cn.hutool.core.date.DateUtil;
import com.alibaba.fastjson.JSON;
import com.foundao.nft.api.service.OrderPostHandler;
import com.foundao.nft.api.service.impl.NftOrderService;
import com.foundao.nft.api.service.impl.PayService;
import com.foundao.nft.common.constant.OrderStatusEnum;
import com.foundao.nft.common.constant.PayTypeEnum;
import com.foundao.nft.common.constant.RabbitmqConst;
import com.foundao.nft.common.model.NftOrder;
import com.foundao.nft.common.model.mq.CreateOrderMqDto;
import com.foundao.nft.common.model.sdk.response.OrderQueryResponse;
import com.foundao.nft.common.model.sdk.response.OrderResponseWrapper;
import com.rabbitmq.client.Channel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Slf4j
@RabbitListener(queues = RabbitmqConst.CREATE_ORDER_DELAY_QUEUE)
@Component
public class CreateOrderHandler {

    @Autowired
    private NftOrderService orderService;
    @Autowired
    private PayService payService;

    @RabbitHandler
    public void createOrderListener(CreateOrderMqDto orderMqDto, Message message, Channel channel) {
        //  如果手动ACK,消息会被监听消费,但是消息在队列中依旧存在,如果 未配置 acknowledge-mode 默认是会在消费完毕后自动ACK掉
        final long deliveryTag = message.getMessageProperties().getDeliveryTag();
        try {
            log.info("队列:{},手动ACK，接收消息：{}", RabbitmqConst.CREATE_ORDER_DELAY_QUEUE,JSON.toJSON(orderMqDto));
            //查看订单是否已经支付，如果未支付，或者支付失败那么直接释放库存
            NftOrder order = orderService.getById(orderMqDto.getOrderId());
            //判断是否处理过，消费消息冥等性判断
            if(order != null
                    && OrderStatusEnum.isWaitPay(order.getStatus())
                    && order.getIsAbandon() == 0 ){
                //再次判断是否已经过期
                if(order.getExpireTime() - 10 < DateUtil.currentSeconds()){
                    //判断该订单是否是微信和支付宝订单，并且是否是支付中
                    if(!order.getPayType().equals(PayTypeEnum.APPLE_PAY.getCode()) && OrderStatusEnum.isWaitPay(order.getStatus()) ){
                        //如果是支付中的状态，那么去第三方查询是否支付成功，如果支付成功了那么进行数据更新
                        OrderResponseWrapper<OrderQueryResponse> orderResponseWrapper = payService.orderQuery(order.getTradeNo());
                        if(orderResponseWrapper.getErrorCode() == 0 && orderResponseWrapper.getData().getPay_status() == OrderStatusEnum.PAY_SUCCESS.getCode()){
                            //触发订单信息更新
                            orderService.finishOrder(order.getTradeNo(),OrderStatusEnum.PAY_SUCCESS.getCode(),orderResponseWrapper.getData().getTransid());
                        }else{
                            //订单标记废弃，释放库存
                            cancelOrder(order);
                        }
                    }else{
                        //订单标记废弃，释放库存
                        cancelOrder(order);
                    }
                }
            }
            channel.basicAck(deliveryTag, false);
        } catch (IOException e) {
            try {
                // 处理失败,重新压入MQ
                channel.basicRecover();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        }
    }

    /**
     *  订单标记废弃,并释放库存
     * @param order 订单
     */
    private void cancelOrder(NftOrder order){
        OrderPostHandler orderPostHandler = orderService.getOrderPostHandler(order.getOrderType());
        if(orderPostHandler != null){
            orderPostHandler.cancelOrder(order);
        }
    }
}
