package com.foundao.nft.api.service.impl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.common.model.RedCodes;
import com.foundao.nft.api.mapper.RedCodesMapper;
/**
    @Package: com.foundao.nft.api.service.impl
    @ClassName: RedCodesService
    @Author: chenli
    @CreateTime: 2022/11/23 9:47 AM
    @Description:
*/
@Service
public class RedCodesService extends ServiceImpl<RedCodesMapper, RedCodes> {

}
