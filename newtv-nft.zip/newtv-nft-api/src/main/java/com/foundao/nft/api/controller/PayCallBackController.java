package com.foundao.nft.api.controller;

import com.alibaba.fastjson.JSON;
import com.foundao.nft.api.service.OrderNotifyService;
import com.foundao.nft.api.service.impl.NftOrderService;
import com.foundao.nft.api.service.impl.OrderNotifyAppleServiceImpl;
import com.foundao.nft.common.model.sdk.request.PayNotifyRequest;
import com.foundao.nft.common.properties.PayProperties;
import com.foundao.nft.common.util.newtv.UnifyPayUtil;
import com.tx.core.beans.JsonResult;
import com.tx.core.util.HttpRequestUtil;
import com.tx.security.annotation.AnonymousPostMapping;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @ClassName PayCallBackController
 * @Description TODO
 * @Author xifan
 * @Date 2021/12/23 0:37
 * @Version 1.0
 */
@RestController
@RequiredArgsConstructor
@RequestMapping("callback")
@Slf4j
@Api(tags = "通知回调")
public class PayCallBackController {

    private final NftOrderService orderService;
    private final OrderNotifyService notifyService;
    private final PayProperties payProperties;
    private final OrderNotifyAppleServiceImpl orderNotifyAppleService;

    /**
     * 支付回调
     * @return
     */
    @AnonymousPostMapping(value = "/wxa_notify")
    @ApiOperation("腾讯订单通知")
    public void notify(@Validated PayNotifyRequest request, HttpServletRequest servletRequest , HttpServletResponse response) throws IOException {
        log.info("腾讯订单通知："+ JSON.toJSONString(request));
        //0.验证数据是否垃圾数据
        //1.记录通知
        Object params = HttpRequestUtil.getRequestMap().get("param");
        notifyService.addNotify(JSON.toJSONString(params),request.getPay_status(),request.getTransid(),request.getOut_trade_no());
        //2.校验通知
        if(UnifyPayUtil.validateSign(servletRequest, payProperties.getAppKey())){
            log.info("订单通知校验通过,{}",request.getOut_trade_no());
            //3.更新订单
            try {
                orderService.finishOrder(request.getOut_trade_no(), request.getPay_status(), request.getTransid());
            } catch (Exception e) {
                response.getWriter().write("fail");
                return;
            }
            response.getWriter().write("success");
            return;
        } else {
            log.warn("校验失败,thirdTransId:{},tradeNo:{}",request.getTransid(),request.getOut_trade_no());
        }
        response.getWriter().write("fail");
    }

    /**
     * 创建订单
     *
     * @param data
     * @return
     */
    @AnonymousPostMapping("/apple/notify")
    @ApiOperation("苹果通知")
    public JsonResult<?> notify(@RequestBody String data) {
        orderNotifyAppleService.doNotify(data);
        return JsonResult.success();
    }
}
