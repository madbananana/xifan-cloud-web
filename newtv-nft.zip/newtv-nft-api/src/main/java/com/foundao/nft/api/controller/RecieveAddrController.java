package com.foundao.nft.api.controller;

import cn.hutool.core.bean.BeanUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.extension.toolkit.ChainWrappers;
import com.foundao.nft.api.service.impl.RecieveAddrService;
import com.foundao.nft.api.vo.MyNftVO;
import com.foundao.nft.common.model.RecieveAddr;
import com.foundao.nft.common.model.vo.RecieveAddrVO;
import com.foundao.nft.common.model.vo.UserVo;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.JsonResult;
import com.tx.core.enums.errcode.ParamErrorEnum;
import com.tx.security.bean.AuthUser;
import com.tx.security.util.SecurityUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Objects;

/**
 * @Package: com.foundao.nft.api.controller
 * @ClassName: RecieveAddrController
 * @Author: chenli
 * @CreateTime: 2022/7/12 3:12 下午
 * @Description:
 */
@RestController
@RequiredArgsConstructor
@RequestMapping("addr")
@Slf4j
@Api(tags = "收货地址")
@Validated
public class RecieveAddrController {

    private final RecieveAddrService addrService;

    @ApiOperation("我的收货地址")
    @GetMapping("my")
    public JsonResult<List<RecieveAddr>> my(){
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        List<RecieveAddr> list = ChainWrappers.lambdaQueryChain(addrService.getBaseMapper())
                .eq(RecieveAddr::getUserId, currentUser.getUserId())
                .orderByDesc(RecieveAddr::getIsDefault,RecieveAddr::getAddrId)
                .list();
        return JsonResult.success(list);
    }

    @ApiOperation("新增/修改收货地址")
    @GetMapping("save")
    public JsonResult<Void> save(@Validated RecieveAddrVO vo){
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        RecieveAddr addr = new RecieveAddr();
        BeanUtil.copyProperties(vo,addr);
        addr.setUserId(Math.toIntExact(currentUser.getUserId()));
        if (vo.getAddrId()!=null) {
            RecieveAddr one = addrService.getOne(new LambdaQueryWrapper<RecieveAddr>()
                    .eq(RecieveAddr::getUserId, currentUser.getUserId())
                    .eq(RecieveAddr::getAddrId, vo.getAddrId()));
            if (one==null) {
                return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"修改的记录不存在");
            }
        } else {
            int count = addrService.count(new LambdaUpdateWrapper<RecieveAddr>()
                    .eq(RecieveAddr::getUserId, currentUser.getUserId()));
            if (count==0) {
                addr.setIsDefault(1);
            }
        }
        if (vo.getIsDefault()!=null && vo.getIsDefault()==1) {
            addrService.update(new LambdaUpdateWrapper<RecieveAddr>()
                    .eq(RecieveAddr::getUserId, currentUser.getUserId())
                    .set(RecieveAddr::getIsDefault, 0));
        }
        addrService.saveOrUpdate(addr);
        return JsonResult.success();
    }

    @ApiOperation("删除收货地址")
    @GetMapping("delete")
    public JsonResult<Void> delete(String addrId){
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        RecieveAddr one = addrService.getOne(new LambdaQueryWrapper<RecieveAddr>()
                .eq(RecieveAddr::getUserId, currentUser.getUserId())
                .eq(RecieveAddr::getAddrId, addrId));
        if (one!=null) {
            addrService.removeById(addrId);
        } else {
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"删除的记录不存在");
        }
        return JsonResult.success();
    }
}
