package com.foundao.nft.api.controller;


import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.crypto.SecureUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.foundao.nft.api.service.impl.*;
import com.foundao.nft.api.vo.PayOrderInfoVo;
import com.foundao.nft.common.constant.OrderStatusEnum;
import com.foundao.nft.common.constant.PayTypeEnum;
import com.foundao.nft.common.model.NftMetadata;
import com.foundao.nft.common.model.NftOrder;
import com.foundao.nft.common.model.NftRecord;
import com.foundao.nft.common.model.NftSeriesClaim;
import com.foundao.nft.common.model.sdk.response.OrderQueryResponse;
import com.foundao.nft.common.model.sdk.response.OrderResponseWrapper;
import com.foundao.nft.common.model.vo.H5ActivityInfoVO;
import com.foundao.nft.common.model.vo.H5ActivityLevelInfoVO;
import com.foundao.nft.common.model.vo.NftOrderVo;
import com.foundao.nft.common.model.vo.UserConsumeRankVO;
import com.foundao.nft.common.model.vo.UserConsumeVO;
import com.foundao.nft.common.model.vo.UserVo;
import com.foundao.nft.common.util.RedisKeyFactory;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import com.tx.base.ratelimiter.annotation.TokenBucketRateLimiter;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.JsonResult;
import com.tx.core.enums.errcode.ApiStatusErrorEnum;
import com.tx.core.enums.errcode.ParamErrorEnum;
import com.tx.core.exception.BusException;
import com.tx.redis.service.RedisService;
import com.tx.security.annotation.AnonymousGetMapping;
import com.tx.security.bean.AuthUser;
import com.tx.security.util.SecurityUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.EnvironmentAware;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@RequestMapping("/nft")
@Slf4j
@RestController
@RequiredArgsConstructor
@Api(tags = "订单相关")
public class OrderController implements EnvironmentAware {
    //用于开启或关闭内购失败的开关
    private final static  String IAP_FAIL_SWITCH_KEY = "newtv-nft:order:receiptDelay";

    private final PayService payService;
    private final AvatarServiceImpl avatarService;
    private final NftOrderService orderService;
    private final NftMetadataService nftMetadataService;
    private final OrderServiceApplePayImpl orderServiceApplePay;
    private final NftSeriesClaimService seriesClaimService;
    private final NftRecordService nftRecordService;
    private final RedisService redisService;
    private final LeadTimeService leadTimeService;
    private final NftRecordService recordService;
    private final ExchangeCodeService exchangeCodeService;

    private final UserConsumeService userConsumeService;

    private final List<String> activeProfile = CollUtil.newArrayList();

    @Override
    public void setEnvironment(Environment environment) {
        List<String> collect = Stream.of(environment.getActiveProfiles()).collect(Collectors.toList());
        if(CollUtil.isNotEmpty(collect)){
            activeProfile.addAll(collect);
        }
    }

    private <T> JsonResult<T> preCheckSeriesBuy(NftSeriesClaim seriesClaim,Integer count) {

        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        //if (!currentUser.getUserDetails().isAuth()) {
        //    return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"请先完成实名认证");
        //}

        boolean isWhiteUser = false;
        if (StrUtil.isNotBlank(currentUser.getUserId()+"")) {
            List<String> whiteList = (List<String>) redisService.get(RedisKeyFactory.getWhiteUserKey());
            if (whiteList!=null) {
                if (whiteList.contains(currentUser.getUserDetails().getMobile())) {
                    isWhiteUser = true;
                }
            }
        }

        if(seriesClaim == null){
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"未知的作品");
        }

        if (seriesClaim.getMetaType()!=3) {
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"购买错误的类型");
        }

        if (!isWhiteUser && seriesClaim.getShowStatus()!=1) {
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"当前藏品状态不允许购买");
        }

        Integer buyCount = (Integer) redisService.hget(RedisKeyFactory.getBuyCountKey(seriesClaim.getId()), currentUser.getUserId() + "");
        if (buyCount==null) {
            buyCount=0;
        }
        if (buyCount+count>seriesClaim.getBuyCount()) {
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),String.format("该盲盒每人限购%s份",seriesClaim.getBuyCount()));
        }

        //校验重复提交
        Map<String,Object> hashData = new HashMap<>(3);
        hashData.put("id",seriesClaim.getId());
        hashData.put("userId",currentUser.getUserDetails().getUserId());

        String orderRepeatLimitKey = RedisKeyFactory.getOrderRepeatLimitKey(SecureUtil.md5(JSON.toJSONString(hashData)));
        if(redisService.get(orderRepeatLimitKey) != null){
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"操作过于频繁,请稍后再试");
        }

        Integer leadTimeOffset = 0;
        if (seriesClaim.getAdvanceBuy()==0) {
            leadTimeOffset = leadTimeService.getLeadTimeOffset(Math.toIntExact(currentUser.getUserId()), seriesClaim.getCategoryId(), null);
        } else {
            leadTimeOffset = leadTimeService.getLeadTimeOffset(Math.toIntExact(currentUser.getUserId()), seriesClaim.getCategoryId(), seriesClaim.getSeriesId());
        }

        String beginTime = seriesClaim.getBeginTime();
        String endTime = seriesClaim.getEndTime();
        DateTime beginDate = DateUtil.parseDateTime(beginTime);
        beginDate = DateUtil.offsetMinute(beginDate,-1 * leadTimeOffset);
        DateTime endDate = DateUtil.parseDateTime(endTime);
        Date now = new Date();

        if (DateUtil.compare(beginDate,now)>0) {
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"作品未到发售时间");
        }

        if (DateUtil.compare(endDate,now)<0) {
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"作品发售已结束");
        }

        redisService.set(orderRepeatLimitKey,seriesClaim.getId(),3L);
        return null;
    }

    private <T> JsonResult<T> preCheckBuy(NftMetadata nftMetadata,boolean isFree){

        String buyOrFreeText = isFree ?"领取":"购买";


        //获取nft信息
        if(nftMetadata == null){
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"未知的作品");
        }

        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        //if (!currentUser.getUserDetails().isAuth()) {
        //    return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"请先完成实名认证");
        //}

        String userId = currentUser.getUserId()+"";
        boolean isWhiteUser = false;
        if (StrUtil.isNotBlank(userId)) {
            List<String> whiteList = (List<String>) redisService.get(RedisKeyFactory.getWhiteUserKey());
            if (whiteList!=null) {
                if (whiteList.contains(currentUser.getUserDetails().getMobile())) {
                    isWhiteUser = true;
                }
            }
        }

        //校验重复提交
        Map<String,Object> hashData = new HashMap<>(3);
        hashData.put("nftId",nftMetadata.getNftId());
        hashData.put("userId",currentUser.getUserDetails().getUserId());

        String orderRepeatLimitKey = RedisKeyFactory.getOrderRepeatLimitKey(SecureUtil.md5(JSON.toJSONString(hashData)));
        if(redisService.get(orderRepeatLimitKey) != null){
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"操作过于频繁,请稍后再试");
        }

        if(nftMetadata.getShowStatus() != 1 ){
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"当前藏品状态不允许"+buyOrFreeText);
        }

        if(nftMetadata.getMetaType() == 3 ){
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"隐藏款不能直接"+buyOrFreeText);
        }

        if(!isWhiteUser && nftMetadata.getSellStatus() != 1){
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"该作品目前为不可售状态");
        }

        if(nftMetadata.getShowCount() <= 0 ){
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"该作品目前已售罄");
        }

        if(nftMetadata.getRestCount() <= 0 ){
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"该作品目前已售罄");
        }
        //检查是否可售
        NftSeriesClaim seriesClaim = seriesClaimService.getBySeriesId(nftMetadata.getSeriesId());
        if (seriesClaim!=null ) {

            if (!isWhiteUser && seriesClaim.getShowStatus()!=1) {
                return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"当前藏品状态不允许"+buyOrFreeText);
            }

            if (seriesClaim.getMetaType()==3) {
                return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"不能直接"+buyOrFreeText+"盲盒系列藏品");
            }

            Integer buyCount = (Integer) redisService.hget(RedisKeyFactory.getNftBuyCountKey(nftMetadata.getMetaId()), currentUser.getUserId() + "");
            if (buyCount==null) {
                buyCount=0;
            }
            if (buyCount+1>seriesClaim.getBuyCount()) {
                return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),String.format("该藏品每人限购%s份",seriesClaim.getBuyCount()));
            }

            Integer leadTimeOffset = 0;
            if (seriesClaim.getAdvanceBuy()==0) {
                leadTimeOffset = leadTimeService.getLeadTimeOffset(Math.toIntExact(currentUser.getUserId()), seriesClaim.getCategoryId(), null);
            } else {
                leadTimeOffset = leadTimeService.getLeadTimeOffset(Math.toIntExact(currentUser.getUserId()), seriesClaim.getCategoryId(), seriesClaim.getSeriesId());
            }

            String beginTime = seriesClaim.getBeginTime();
            String endTime = seriesClaim.getEndTime();
            DateTime beginDate = DateUtil.parseDateTime(beginTime);
            beginDate = DateUtil.offsetMinute(beginDate,-1 * leadTimeOffset);
            DateTime endDate = DateUtil.parseDateTime(endTime);
            Date now = new Date();

            if (DateUtil.compare(beginDate,now)>0) {
                return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"作品未到发售时间");
            }

            //if (DateUtil.compare(beginDate,now)>0) {
            //    if (seriesClaim.getAdvanceBuy()==null || seriesClaim.getAdvanceBuy()==0) {//不可提前购买
            //        return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"作品未到发售时间");
            //    }
            //    if (DateUtil.compare(DateUtil.offsetHour(beginDate,-1),now)>0) {
            //        return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"作品未到发售时间");
            //    } else {
            //        Integer flag = (Integer) redisService.hget(RedisKeyFactory.getAppointmentKey(seriesClaim.getSeriesId()), currentUser.getUserId() + "");
            //        if (flag ==null) {
            //            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"作品未到发售时间");
            //        }
            //    }
            //}
            if (DateUtil.compare(endDate,now)<0) {
                return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"作品发售已结束");
            }
        } else {
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"系列还未发行");
        }
        if(!isFree){
            //检查金额
            if(nftMetadata.getSellFee() <= 0 ){
                return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"该藏品不是付费类型");
            }
        }
        //检查用户是否已经拥有该NFT
        //boolean isHave = nftRecordService.isPayProductId(currentUser.getUserDetails().getUserId(), nftMetadata.getMetaId());
        //if(isHave){
        //    return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"您已经拥有该藏品,请在藏品列表查看");
        //}
        redisService.set(orderRepeatLimitKey,nftMetadata.getNftId(),3L);
        return null;
    }

    @ApiOperation("创建订单")
    @PostMapping("/createOrder")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "nftId",value = "nftId",required = true),
            @ApiImplicitParam(name = "pt",value = "是否苹果内购,1是 0 否",required = false),
            @ApiImplicitParam(name = "addrId",value = "是否苹果内购,1是 0 否",required = false),
    })
    @TokenBucketRateLimiter(key = "'newtv-nft:limit:createOrder'",capacity=1000,rate=1000,limitNote = "当前购买人数过多，请稍后再试")
    public JsonResult<?> createOrder(@RequestParam(name = "nftId") String nftId,@RequestParam(required = false) Integer pt,Integer addrId){
        pt = pt == null ? 0 : (pt > 0 ? 1 : 0);
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        NftMetadata nftMetadata = nftMetadataService.getByNftId(nftId);
        JsonResult<?> err = preCheckBuy(nftMetadata,false);
        if(err != null){
            return err;
        }
        return JsonResult.success(orderService.createOrder(nftMetadata,currentUser.getUserDetails(),pt > 0,addrId));
    }

    @ApiOperation("提交订单支付")
    @PostMapping("/payOrder")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "tradeNo",value = "创建订单返回的订单号",required = true),
            @ApiImplicitParam(name = "payType",value = "支付类型可选值为,WX_PAY,ALI_PAY,INTEGRAL_PAY",required = false)
    })
    public JsonResult<?> payOrder(@RequestParam(name = "tradeNo") String tradeNo, String payType,String subPayType){
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        log.info("用户{}提交支付,订单号:{},支付方式:{}",currentUser.getUserId(),tradeNo,payType);
        //校验参数
        if (StrUtil.isBlank(subPayType)) {
            subPayType = "app";
        }

        if ("13911229370".equals(currentUser.getUserDetails().getMobile())) {
            subPayType = "app";
        }

        if(!payType.equals(PayTypeEnum.WX_PAY.getCode()) &&  !payType.equals(PayTypeEnum.ALI_PAY.getCode()) && !payType.equals(PayTypeEnum.INTEGRAL_PAY.getCode())){
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"不支持的支付方式");
        }

        if (!"app".equals(subPayType) && !"h5".equals(subPayType)) {
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"不支持的支付方式");
        }

        if (payType.equals(PayTypeEnum.INTEGRAL_PAY.getCode())) {
            orderService.integralPay(tradeNo,payType,"app",currentUser.getUserDetails());
            return JsonResult.success();
        }
        return JsonResult.success(orderService.payOrder(tradeNo,payType,subPayType,currentUser.getUserDetails()));
    }

    @ApiOperation("IOS-修改订单状态为支付中")
    @PostMapping("/modifyStatus")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "tradeNo",value = "创建订单返回的订单号",required = true),
    })
    public JsonResult<PayOrderInfoVo> updateOrderStatus(@RequestParam(name = "tradeNo") String tradeNo){
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        //校验参数
        NftOrder order = orderService.getByTradeNo(tradeNo);
        if(order != null
                && OrderStatusEnum.isWaitPay(order.getStatus())
                && currentUser.getUserId().intValue() == order.getUserId()
        ){
            NftOrder updateOrder = new NftOrder();
            updateOrder.setOrderId(order.getOrderId());
            updateOrder.setStatus(OrderStatusEnum.PAYING.getCode());
            orderService.updateById(updateOrder);
        }
        return JsonResult.success();
    }


    @ApiOperation("订单支付查询")
    @GetMapping("/orderQuery")
    public JsonResult<?> orderQuery(@RequestParam("tradeNo") String tradeNo){
        log.info("订单支付查询:{}",tradeNo);
        //1.没有购买过，过期时间
        Map<String,Object> res  = new HashMap<>(3);
        boolean paySuccess = false;
        //1.查询订单信息
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        NftOrder nftOrder = orderService.getOrderByTradeNoAndUserId(currentUser.getUserId(), tradeNo);
        if(nftOrder == null){
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"未知的订单");
        }
        if(OrderStatusEnum.isWaitPay(nftOrder.getStatus())){
            //如果是待支付状态，那么去第三方查询
            OrderResponseWrapper<OrderQueryResponse> orderResponseWrapper = payService.orderQuery(tradeNo);
            if(orderResponseWrapper.getErrorCode() != 0 ){
                return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"订单异常");
            }
            OrderQueryResponse orderQueryResponse = orderResponseWrapper.getData();
            if(orderQueryResponse.getPay_status() == OrderStatusEnum.PAY_SUCCESS.getCode()){
                //触发订单信息更新
                orderService.finishOrder(tradeNo,OrderStatusEnum.PAY_SUCCESS.getCode(),orderQueryResponse.getTransid());
                paySuccess = true;
            }
        }else{
            if(nftOrder.getStatus() == OrderStatusEnum.PAY_SUCCESS.getCode()){
                paySuccess = true;
            }
        }
        res.put("status",paySuccess);
        if(paySuccess && nftOrder.getOrderType() == 10){
            //如果安卓支付成功，并且是头像的抽奖，那么直接锁定并抽奖
            avatarService.lockAvatar(currentUser.getUserDetails().getUserId(), currentUser.getUserDetails().isSpecial());
        }
        return JsonResult.success(res);
    }

    @ApiOperation("订单列表")
    @GetMapping("/orderList")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "orderStatus",value = "支付状态 1：初始状态 2：成功 3失败 11 付款中 20 已取消,为空表示全部",required = false)
    })
    @ApiOperationSupport(includeParameters = {"page","orderStatus"})
    public JsonResult<List<NftOrderVo>> orderList(BaseRequestVo baseRequestVo, @RequestParam(required = false) Integer orderStatus){
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        List<Integer> supportOrderStatus = Stream.of(OrderStatusEnum.values()).map(OrderStatusEnum::getCode).collect(Collectors.toList());
        if(orderStatus != null && !supportOrderStatus.contains(orderStatus)){
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"未知订单状态");
        }
        baseRequestVo.getMultiValueSearch().put("orderStatus",orderStatus);
        baseRequestVo.getMultiValueSearch().put("userId",currentUser.getUserId());
        return JsonResult.success(orderService.orderList(baseRequestVo));
    }

    @ApiOperation("订单详情")
    @GetMapping("/orderDetail")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "tradeNo",value = "创建订单返回的订单号",required = true),
    })
    public JsonResult<NftOrderVo> orderDetail(@RequestParam(name = "tradeNo") String tradeNo){
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();

        //校验参数
        NftOrderVo orderVo = orderService.getOrderDetail(tradeNo,currentUser.getUserId().intValue());
        if(orderVo == null){
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"无效的订单");
        }
        if (orderVo.getOrderType()==11) {
            NftSeriesClaim nftSeriesClaim = seriesClaimService.getByIdCache(orderVo.getShortSeriesId() + "");
            orderVo.setName(nftSeriesClaim.getSeriesName());
            orderVo.setDisplayUrl(nftSeriesClaim.getCoverUrl());
            orderVo.setUrl(nftSeriesClaim.getCoverUrl());
        } else {
            if (orderVo.getStatus()==2) {
                if (StrUtil.isNotBlank(orderVo.getProductId2())) {
                    Integer count = recordService.lambdaQuery()
                            .eq(NftRecord::getUserId, currentUser.getUserId())
                            .eq(NftRecord::getActualNftId, orderVo.getProductId2())
                            .count();
                    if (count==0) {
                        orderVo.setMsg("该藏品已转赠，暂不支持查看");
                    }
                }
            }
        }
        orderVo.setServerCurTime(DateUtil.now());
        return JsonResult.success(orderVo);
    }

    /**
     * 苹果票据回传
     * @param tradeNo 订单号
     * @param receipt 票据
     * @return
     */
    @ApiOperation("苹果订单确认支付-票据回传")
    @PostMapping("/apple/pay")
    public JsonResult<?> applePay(String tradeNo, @RequestParam("receipt") String receipt,String appleGoodsId,String payTime) {
        log.info("苹果票据回传：{} {} {} {}",tradeNo,receipt,appleGoodsId,payTime);
        String isDelay = (String) redisService.get(IAP_FAIL_SWITCH_KEY);
        if(!activeProfile.contains("pro") && StrUtil.isNotBlank(isDelay) ){
            try {
                TimeUnit.SECONDS.sleep(2);
            } catch (InterruptedException e) {
            }
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"票据回传失败模拟-仅支持测试环境");
        }
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        NftOrder nftOrder = null;
        if (StrUtil.isBlank(tradeNo)) {
            nftOrder = orderService.getByNoTradeNo(currentUser.getUserId(),appleGoodsId,payTime);
        } else {
            nftOrder = orderService.getByTradeNo(tradeNo);
        }
        if(nftOrder == null || nftOrder.getUserId() != currentUser.getUserId().intValue()){
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"该系统订单不存在");
        }
        if(nftOrder.getStatus() == OrderStatusEnum.PAY_SUCCESS.getCode()){
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"该系统订单已经处理");
        }

        orderService.updateExtInfo(nftOrder.getTradeNo(), receipt);
        orderServiceApplePay.checkReceiptByTradeNo(nftOrder.getTradeNo());
        return JsonResult.success();
    }

    /**
     * 免费领取接口
     * @return
     */
    @ApiOperation("免费领取接口")
    @PostMapping("/free")
    @TokenBucketRateLimiter(key = "'newtv-nft:limit:free'",capacity=1000,rate=1000,limitNote = "当前领取人数过多，请稍后再试")
    public JsonResult<?> free(@RequestParam(name = "nftId") String nftId){
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        log.info("用户{}免费领取{}",currentUser.getUserId(),nftId);
        //获取nft信息
        NftMetadata nftMetadata = nftMetadataService.getByNftId(nftId);

        JsonResult<?> err = preCheckBuy(nftMetadata,true);
        if(err != null){
            return err;
        }
        if(nftMetadata.getSellFee() != 0 ){
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"禁止直接领取付费藏品");
        }
        if (!currentUser.getUserDetails().isAuth()) {
            return JsonResult.error(HttpStatus.INTERNAL_SERVER_ERROR.value(),"请先完成实名认证");
        }
        orderService.freeAccess(nftMetadata,currentUser.getUserDetails());
        return JsonResult.success();
    }

    @ApiOperation("开启/关闭-内购失败功能")
    @AnonymousGetMapping("modifyIapFail")
    public JsonResult<String> modifyIapFail(@RequestParam Integer k){
        if(activeProfile.contains("pro")){
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"权限不足");
        }
        if(k != 0 && k != 1){
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"无效的参数");
        }
        if(k == 1){
            redisService.set(IAP_FAIL_SWITCH_KEY,"enable");
        }else{
            redisService.del(IAP_FAIL_SWITCH_KEY);
        }
        return JsonResult.success(k == 1 ? "开启成功" : "关闭成功");
    }

    @ApiOperation("创建盲盒订单")
    @PostMapping("/createBlindBoxOrder")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "shortSeriesId",value = "系列短ID，不再使用系列长id",required = true),
            @ApiImplicitParam(name = "pt",value = "是否苹果内购,1是 0 否",required = false),
            @ApiImplicitParam(name = "count",value = "购买数量，不传默认为1",required = false)
    })
    @TokenBucketRateLimiter(key = "'newtv-nft:limit:createBlindBoxOrder'",capacity=1000,rate=1000,limitNote = "当前购买人数过多，请稍后再试")
    public JsonResult<?> createBlindBoxOrder(@RequestParam(name = "shortSeriesId") String shortSeriesId,@RequestParam(required = false) Integer pt,Integer count,Integer addrId){
        pt = pt == null ? 0 : (pt > 0 ? 1 : 0);
        if (count==null || count==0) {
            count=1;
        }
        if (count<0) {
            throw new BusException("数量输入错误");
        }
        if (count>20) {
            throw new BusException("每次最多购买20份");
        }
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        NftSeriesClaim seriesClaim = seriesClaimService.getByIdCache(shortSeriesId);
        JsonResult<?> err = preCheckSeriesBuy(seriesClaim,count);
        if(err != null){
            return err;
        }
        return JsonResult.success(orderService.createBlindBoxOrder(seriesClaim,currentUser.getUserDetails(),pt > 0,count,addrId));
    }

    @ApiOperation("兑换nft")
    @PostMapping("/exchange")
    @TokenBucketRateLimiter(key = "'newtv-nft:limit:exchange'",capacity=50,rate=50,limitNote = "系统繁忙，请稍后再试")
    public JsonResult<?> exchange(String exchangeCode){
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        //校验重复提交
        Map<String,Object> hashData = new HashMap<>(3);
        hashData.put("exchangeCode",exchangeCode);
        hashData.put("userId",currentUser.getUserId());

        String orderRepeatLimitKey = RedisKeyFactory.getOrderRepeatLimitKey(SecureUtil.md5(JSON.toJSONString(hashData)));
        if(redisService.get(orderRepeatLimitKey) != null){
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"操作过于频繁,请稍后再试");
        }

        if (!currentUser.getUserDetails().isAuth()) {
            return JsonResult.error(HttpStatus.INTERNAL_SERVER_ERROR.value(),"请先完成实名认证");
        }

        redisService.set(orderRepeatLimitKey,exchangeCode,3L);
        JSONObject exchange = exchangeCodeService.exchange(exchangeCode, currentUser.getUserDetails());
        return JsonResult.success(exchange);
    }

    @ApiOperation("是否展示兑换按钮")
    @GetMapping("/showExchange")
    public JsonResult<Integer> showExchangeMenu(){
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        if ("13911229370".equals(currentUser.getUserDetails().getMobile())) {
            return JsonResult.success(1);
        } else {
            return JsonResult.success(0);
        }
    }

    @ApiOperation("h5活动信息")
    @AnonymousGetMapping("/h5ActivityInfo")
    public JsonResult<H5ActivityInfoVO> h5ActivityInfo(){
        AuthUser<UserVo> currentUser = null;
        try {
            currentUser = SecurityUtil.getCurrentUser();
        } catch (Exception ignored) {
        }
        H5ActivityInfoVO vo = null;
        if (currentUser!=null) {
            vo = userConsumeService.h5ActivityInfo(currentUser.getUserId());
        } else {
            vo = userConsumeService.h5ActivityInfo(null);
        }
        return JsonResult.success(vo);
    }

    @ApiOperation("h5消费排行前50")
    @AnonymousGetMapping("/consumeTop50")
    public JsonResult<List<UserConsumeRankVO>> consumeTop50(){
        return JsonResult.success(userConsumeService.consumeTop50());
    }

    @GetMapping("/blindBox/waitPay")
    public JsonResult<NftOrderVo> waitPayOrderByNftId(String shortSeriesId){
        return JsonResult.success(orderService.waiPayOrder(shortSeriesId));
    }
}
