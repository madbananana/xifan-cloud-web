package com.foundao.nft.api.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.text.StrJoiner;
import cn.hutool.core.util.RandomUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.foundao.nft.common.model.vo.SendMessageVO;
import com.foundao.nft.common.model.vo.SendMsgRequest;
import com.foundao.nft.common.model.vo.SendMsgResponse;
import com.foundao.nft.common.model.AdvanceBuy;
import com.foundao.nft.common.model.mq.SendMessageMqDto;
import com.foundao.nft.common.model.sdk.response.DeriveKeyPairResponse;
import com.foundao.nft.common.model.vo.SendMsgV2Response;
import com.foundao.nft.common.properties.MsgProperties;
import com.foundao.nft.common.util.RedisKeyFactory;
import com.foundao.nft.common.util.newtv.UnifyPayUtil;
import com.tx.core.beans.JsonResult;
import com.tx.core.enums.errcode.ApiStatusErrorEnum;
import com.tx.redis.service.RedisService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.EnvironmentAware;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * @Package: com.foundao.nft.api.service.impl
 * @ClassName: MessageService
 * @Author: chenli
 * @CreateTime: 2022/2/18 3:48 下午
 * @Description:
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class MessageService implements EnvironmentAware {

    private final RedisService redisService;
    private final RestTemplate restTemplate;
    private final MsgProperties properties;

    private final List<String> activeProfile = CollUtil.newArrayList();

    @Override
    public void setEnvironment(Environment environment) {
        List<String> collect = Stream.of(environment.getActiveProfiles()).collect(Collectors.toList());
        if(CollUtil.isNotEmpty(collect)){
            activeProfile.addAll(collect);
        }
    }

    public SendMsgResponse sendMessage(String phone,String template) throws Exception {
        SendMsgResponse response ;
        String verificationCode = RandomUtil.randomNumbers(6);
        if(!activeProfile.contains("prod")){
            verificationCode = "123456";
            response = new SendMsgResponse();
            response.setStatusCode("1");
        } else {
            String url = properties.getRequestUrl()+"/api/sms/open/sendtext";
            // 配置参数
            MultiValueMap<String, String> param = new LinkedMultiValueMap<>(5);
            param.add("appKey", properties.getAppKey());
            param.add("channel", "USER_CENTER");
            param.add("content", String.format(template,verificationCode));
            param.add("mobile", phone);
            param.add("purpose", "VERIFY_CODE");
            String signValue = UnifyPayUtil.buildMapMsgSign(param,properties.getAppSecret());
            param.add("sign", signValue);

            response = restTemplate.postForObject(url,param,SendMsgResponse.class);
            log.info("短信发送，请求：{},响应：{}",param,response);
        }
        if (response!=null) {
            if ("1".equals(response.getStatusCode())) {
                redisService.set(RedisKeyFactory.getVerificationCodeKey(phone), verificationCode, 5*60L);
            }
        }
        return response;
    }

    public SendMsgV2Response sendMessageV2(SendMessageVO vo) throws Exception {
        SendMsgV2Response response ;
        String url = properties.getRequestUrl()+"/service/sms/send";
        // 配置参数
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        vo.setAppKey(properties.getAppKey());

        String signValue = UnifyPayUtil.buildMapMsgSignByJSON((JSONObject)JSONObject.toJSON(vo),properties.getAppSecret());
        vo.setSign(signValue);
        HttpEntity<?> requestEntity = new HttpEntity<>(vo,headers);
        response = restTemplate.postForObject(url,requestEntity,SendMsgV2Response.class);
        log.info("短信发送，请求：{},响应：{}",vo,response);
        return response;
    }

    public SendMsgResponse sendAppointmentNoticeMessage(SendMessageMqDto messageMqDto) throws Exception {
        SendMsgResponse response ;
//        String verificationCode = StrJoiner.of("").append(RandomUtil.randomInts(6)).toString();
        String url = properties.getRequestUrl()+"/api/sms/open/batchSend";
        // 配置参数
        MultiValueMap<String, String> param = new LinkedMultiValueMap<>(5);
        param.add("appKey", properties.getAppKey());
        param.add("channel", "USER_CENTER");
        param.add("content", String.format("【未来数藏】预约提醒：未来数藏平台首期藏品上线，您预约的藏品将于今日%s准时开售，预约用户可提前1个小时购买，不要错过哦！抢购须提前完成实名认证，请及时前往未来数藏APP查看。",messageMqDto.getBeginTimeHour()));
        param.add("mobile", messageMqDto.getMobile());
        param.add("purpose", "NOTIFICATION");
        String signValue = UnifyPayUtil.buildMapMsgSign(param,properties.getAppSecret());
        param.add("sign", signValue);

        response = restTemplate.postForObject(url,param,SendMsgResponse.class);
        return response;
    }

    public SendMsgResponse sendAppointmentNoticeMessage(List<AdvanceBuy> advanceBuys,String beginTimeHour) throws NoSuchAlgorithmException, InvalidKeyException, UnsupportedEncodingException {
        log.info("短信群发："+advanceBuys.size());
        List<String> mobileList = advanceBuys.stream().filter((v)->v.getNoticeStatus()==0).map(AdvanceBuy::getMobile).collect(Collectors.toList());
        SendMsgResponse response = null;
        if (mobileList.size()>0) {
            String mobiles = StrUtil.join(",", mobileList);
            String url = properties.getRequestUrl()+"/api/sms/open/batchSend";
            // 配置参数
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            Map<String, String> param = new HashMap<>(5);
            param.put("appKey", properties.getAppKey());
            param.put("channel", "USER_CENTER");
            param.put("content", String.format("【未来数藏】开售提醒：您在平台预约的藏品 %s 即将开售，请提前完成实名认证，并及时前往未来数藏APP查看及购买。",advanceBuys.get(0).getSeriesName()));
            param.put("mobile", mobiles);
            param.put("purpose", "NOTIFICATION");
            HttpEntity<?> requestEntity = new HttpEntity<>(param,headers);
            String signValue = UnifyPayUtil.buildMapMsgSign(param,properties.getAppSecret());
            param.put("sign", signValue);
            try {
                response = restTemplate.postForObject(url,requestEntity,SendMsgResponse.class);
            } catch (Exception e) {
                log.error("短信群发失败",e);
            }
        } else {
            response = new SendMsgResponse();
            response.setMessage("未发送通知");
        }

        return response;
    }
}
