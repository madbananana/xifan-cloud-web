package com.foundao.nft.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.common.model.TransferRecord;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
    @Package: com.foundao.nft.api.mapper
    @ClassName: TransferRecordMapper
    @Author: chenli
    @CreateTime: 2022/7/28 2:50 下午
    @Description:
*/
@Mapper
public interface TransferRecordMapper extends BaseMapper<TransferRecord> {
    List<TransferRecord> myTransfer(Page<TransferRecord> page, @Param("userId") Long userId,@Param("status") Integer status);
}
