package com.foundao.nft.api.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.comparator.CompareUtil;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.IdUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.extension.toolkit.ChainWrappers;
import com.foundao.nft.api.mapper.NftRecordMapper;
import com.foundao.nft.api.vo.MyNftGroupByMetaIdVO;
import com.foundao.nft.api.vo.MyNftVO;
import com.foundao.nft.api.vo.NftInfoVO;
import com.foundao.nft.api.vo.TransferConfirmVO;
import com.foundao.nft.common.constant.*;
import com.foundao.nft.common.model.*;
import com.foundao.nft.common.model.mq.SendMessageMqDto;
import com.foundao.nft.common.model.mq.TransferCancelMqDto;
import com.foundao.nft.common.model.sdk.client.NftService;
import com.foundao.nft.common.model.sdk.request.NftTransferRequest;
import com.foundao.nft.common.model.sdk.response.SdkResponseBase;
import com.foundao.nft.common.model.sdk.response.SignByPriKeyResponse;
import com.foundao.nft.common.model.sdk.response.TaskResponse;
import com.foundao.nft.common.model.vo.NftRecordVO;
import com.foundao.nft.common.model.vo.UserVo;
import com.foundao.nft.common.util.NftCommonUtil;
import com.foundao.nft.common.util.RedisKeyFactory;
import com.foundao.nft.common.util.SortUtil;
import com.google.gson.JsonObject;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.JsonResult;
import com.tx.core.enums.errcode.ApiStatusErrorEnum;
import com.tx.core.exception.BusException;
import com.tx.redis.annotation.FdRedisCache;
import com.tx.redis.service.RedisService;
import com.tx.security.bean.AuthUser;
import com.tx.security.util.SecurityUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import static com.sun.jmx.snmp.EnumRowStatus.destroy;

@Service
@Slf4j
@Transactional
public class NftRecordService extends ServiceImpl<NftRecordMapper, NftRecord> {

    @Autowired
    private NftCommonUtil nftCommonUtil;
    @Autowired
    private NftMetadataService nftMetadataService;
    @Autowired
    private NftUserPlatformService nftUserPlatformService;
    @Autowired
    private NftSeriesClaimService nftSeriesClaimService;
    @Autowired
    private NftOrderService orderService;
    @Autowired
    private TransferRecordService transferRecordService;
    @Autowired
    private NftUserService userService;
    @Autowired
    private NftService nftService;
    @Autowired
    private NftTaskService taskService;
    @Autowired
    private RabbitTemplate rabbitTemplate;
    @Autowired
    private RedisService redisService;
    @Autowired
    private MergeService mergeService;
    @Autowired
    private RecipeCollectionService collectionService;

    @Value("${spring.profiles.active}")
    private String env;

    public NftRecord getRecordByNftIdAndUserId(String nftId,Integer userId){
        return ChainWrappers.lambdaQueryChain(baseMapper)
                .eq(NftRecord::getActualNftId,nftId)
                .eq(NftRecord::getUserId,userId)
                .one();
    }

    public NftRecord getRecordByMetaIdAndUserId(Integer metaId,Integer userId,String actualNftId){
        return ChainWrappers.lambdaQueryChain(baseMapper)
                .eq(NftRecord::getMetaId,metaId)
                .eq(NftRecord::getUserId,userId)
                .eq(NftRecord::getActualNftId,actualNftId)
                .last("limit 1")
                .one();
    }

    public NftRecord getRecordByMetaIdAndUserId(Integer metaId,Integer userId){
        return ChainWrappers.lambdaQueryChain(baseMapper)
                .eq(NftRecord::getMetaId,metaId)
                .eq(NftRecord::getUserId,userId)
                .last("limit 1")
                .one();
    }


    @FdRedisCache(expireTime = 10,key = "'recordByUser:'+#nftId+'-'+#userId+'-'+#actualNftId")
    public NftRecordVO getRecordVOByNftIdAndUserId(String nftId, Integer userId,String actualNftId){
        return baseMapper.getRecordVOByNftIdAndUserId(nftId,userId,actualNftId);
    }

    public NftRecordVO getRecordVOByActualNftIdAndUserId(Integer userId,String actualNftId){
        return baseMapper.getRecordVOByActualNftIdAndUserId(userId,actualNftId);
    }

    /**
     * 判断用户是否已经购买过产品
     * @param userId 用户id
     * @param metaId 产品自增id
     * @return
     */
    public boolean isPayProductId(Integer userId,Integer metaId){
        Integer count = ChainWrappers.lambdaQueryChain(baseMapper)
                .eq(NftRecord::getMetaId, metaId)
                .eq(NftRecord::getUserId, userId)
                .count();
        return  count > 0;
    }

    /**
     * 判断用户是否已经购买过产品
     * @param userId 用户id
     * @param productId 产品的NFTid
     * @return
     */
    public boolean isPayProductId(Integer userId,String productId){
        NftMetadata nftMetadata = nftMetadataService.getByNftId(productId);
        return isPayProductId(userId,nftMetadata.getMetaId());
    }

    /**
     * 判断用户是否已经购买过该系列
     * @param userId 用户id
     * @param seriesId 系列id
     * @return
     */
    public NftRecordVO isPaySeriesId(Integer userId,String seriesId){
        NftRecordVO record = baseMapper.isPaySeriesId(userId,seriesId);
        return record;
    }

    /**
     * 获取我的收藏列表
     * @param requestVo 请求v
     * @return
     */
    public List<MyNftVO> listMyNft(BaseRequestVo requestVo) {
        Page<MyNftVO> page = new Page<>(requestVo.getPage(),requestVo.getNum(),false);
        SortUtil.handlePageSort(requestVo, page, "id", FoundaoConstant.ORDER_DESC, true);
        IPage<MyNftVO> myNftVOIPage = baseMapper.listMyNft(page,requestVo);
        return myNftVOIPage.getRecords();
    }

    /**
     *
     * @param requestVo
     * @return
     */
    public List<MyNftGroupByMetaIdVO> listMyNftGroupByMetaId(BaseRequestVo requestVo,UserVo user) {
        Page<MyNftGroupByMetaIdVO> page = new Page<>(requestVo.getPage(),requestVo.getNum(),false);
        boolean exist = redisService.hHasKey(RedisKeyFactory.getPrimaryUserIdKey(), user.getUserId()+"");
        IPage<MyNftGroupByMetaIdVO> myNftVOIPage = baseMapper.listMyNftGroupByMetaId(page,user.getUserId());
        myNftVOIPage.getRecords().forEach(v -> {
            List<MyNftVO> list = baseMapper.selectByMetaId(v.getMetaId(),user.getUserId());
            v.setNfts(list);
            list.forEach( vo -> {
                if (v.getWaitReceive()==null || v.getWaitReceive()==0) {
                    if (vo.getBuyStatus()==12) {
                        v.setWaitReceive(1);
                    } else if (vo.getBuyStatus()==11) {
                        v.setWaitReceive(2);
                    } else if (vo.getBuyStatus()==14) {
                        v.setWaitReceive(4);
                    } else if (vo.getBuyStatus()==2 && vo.getMergeId()!=null) {
                        v.setWaitReceive(3);
                    }
                }
                vo.setCanTrans(1);

                Integer rightLevel = user.getRightLevel();
                if (rightLevel==null) {
                    rightLevel = 0;
                }

                Integer transferTime = null;

                if (v.getTransferTime()!=null && v.getTransferTime()>0) {
                    transferTime = v.getTransferTime();
                } else {
                    transferTime = (Integer) redisService.hget(RedisKeyFactory.getLeadTimeKey(), "level"+rightLevel);
                    if (transferTime==null) {
                        transferTime = 40;
                    }
                }

                if (env.contains("prod")) {
                    transferTime = transferTime * 24 * 60;
                }

                Date now = new Date();
                Date buyTime = DateUtil.parseDateTime(vo.getCreateTime());

                DateTime canTransferTime = DateUtil.offsetMinute(buyTime, transferTime);
                if (DateUtil.compare(canTransferTime,now)>0) {
                    vo.setTransMsg("未到规定转赠时间");
                    vo.setCanTrans(0);
                }

                if (vo.getBuyStatus()==2) {
                    vo.setTransMsg("转赠失败\n请联系客服：400-046-3366");
                    vo.setCanTrans(0);
                }

//                if (vo.getBuyStatus()==11) {
//                    vo.setTransMsg("转赠中，不能再次转赠");
//                    vo.setCanTrans(0);
//                }
//
//                if (vo.getBuyStatus()==12) {
//                    vo.setTransMsg("待领取的藏品，不能进行转赠");
//                    vo.setCanTrans(0);
//                }
//
//                if (vo.getBuyStatus()==13) {
//                    vo.setTransMsg("领取中的藏品，不能进行转赠");
//                    vo.setCanTrans(0);
//                }
            });
        });
        myNftVOIPage.setRecords(myNftVOIPage.getRecords().stream().sorted(Comparator.comparing(MyNftGroupByMetaIdVO::getMaxId).reversed()).collect(Collectors.toList()))  ;
        return myNftVOIPage.getRecords();
    }

    /**
     * 获取nft详情
     * @param nftId nftid
     * @param ownerUserId 拥有者用户id 可空
     * @return
     */
    public NftInfoVO nftInfo(String nftId, Integer ownerUserId) {
        NftInfoVO infoVO = baseMapper.nftInfo(nftId,ownerUserId);
        if(infoVO.getMetaType() == 2){
            String metaData = infoVO.getMetaData();
            if(StrUtil.isNotBlank(metaData)){
                JSONObject jsonObject = JSON.parseObject(metaData);
                String partAttr = jsonObject.getString("partAttr");
                infoVO.setAvatarAttrs(JSON.parseArray(partAttr, NftMetaDataPartAttr.class));
            }
            //如果是牛头资源特殊处理，把描述设置成系列的描述
            NftSeriesClaim seriesClaim = nftSeriesClaimService.getBySeriesId(infoVO.getSeriesId());
            infoVO.setDesc(seriesClaim.getDesc());
        }
        return infoVO;
    }



    /**
     * 新增购买记录
     * @param extData extData
     */
    public NftRecord addBuyRecord(NftTask.NftBuyExtInfo extData){
        NftRecord nftRecord = null;
        if(extData.getRecordId()!=null) {
            nftRecord = getById(extData.getRecordId());
            if (nftRecord!=null && nftRecord.getBuyStatus()==2 && Objects.equals(nftRecord.getUserId(),extData.getUserId())) {
                return nftRecord;
            }
        }

        //获取meta信息
        NftMetadata nftMetadata = nftMetadataService.getById(extData.getMetaId());
        NftUserPlatform userPlatform = nftUserPlatformService.getById(extData.getUserId());
        nftRecord = new NftRecord();
        nftRecord.setNftId(nftMetadata.getNftId());
        nftRecord.setActualNftId(extData.getNftId());
        nftRecord.setObtainType(1);
        //2 执行中
        nftRecord.setBuyStatus(2);
        nftRecord.setMetaId(extData.getMetaId());
        nftRecord.setOwnerTime(new Date());
        nftRecord.setUserId(extData.getUserId());
        nftRecord.setMetaType(nftMetadata.getMetaType());
        nftRecord.setCreateTime(new Date());
        nftRecord.setOwnerAddr(userPlatform==null?null:userPlatform.getAddr());
        nftRecord.setTxHash("");
        if (extData.getMetaType()==4) {
            if (extData.getMergeId()!=null) {
                nftRecord.setMergeId(extData.getMergeId());
            }
        }
        save(nftRecord);
        return nftRecord;
    }

    public void updateBuyRecord(NftTask task,NftTask.NftBuyExtInfo extInfo){
        log.info("更新nft购买记录");
        NftMetadata nftMetadata = nftMetadataService.getById(extInfo.getMetaId());
//        NftRecord oldNftRecord = getRecordByMetaIdAndUserId(metaId, userId,actualNftId);
        NftRecord oldNftRecord = getById(extInfo.getRecordId());
        NftRecord updateNftRecord = new NftRecord();
        updateNftRecord.setId(oldNftRecord.getId());
        updateNftRecord.setTxHash(task.getTxHash());
        updateNftRecord.setBuyStatus(task.getStatus());
        updateById(updateNftRecord);
        if (nftMetadata.getSellFee()==0 || extInfo.getOrderId() == null) {
            orderService.createFreeOrder(extInfo.getUserId(),extInfo.getMetaId(),oldNftRecord.getActualNftId(),task.getTxHash(),extInfo.getShortSeriesId());
        }else{
            NftOrder order = orderService.getById(extInfo.getOrderId());
            if (order.getOrderType()!=11) {
                if (order.getPayType().equals(PayTypeEnum.INTEGRAL_PAY.getCode())) {
                    orderService.integralOperation(order.getUserId(),order.getTradeNo(), IntegralTypeEnum.BUY_NFT.getType(),"out",(int) Math.ceil((order.getOrderFee()/100.0)),nftMetadata.getName(),DateUtil.formatDateTime(order.getPayTime()));
                }
            }
            order.setTxHash(task.getTxHash());
            orderService.updateById(order);
        }

    }

    public void updateReplenishRecord(NftTask task,NftTask.NftBuyExtInfo extInfo){
        log.info("添加nft下发记录");
        NftMetadata nftMetadata = nftMetadataService.getById(extInfo.getMetaId());
//        NftRecord oldNftRecord = getRecordByMetaIdAndUserId(metaId, userId,actualNftId);
        NftRecord oldNftRecord = getById(extInfo.getRecordId());
        NftRecord updateNftRecord = new NftRecord();
        updateNftRecord.setId(oldNftRecord.getId());
        updateNftRecord.setTxHash(task.getTxHash());
        updateNftRecord.setBuyStatus(task.getStatus());
        updateById(updateNftRecord);
        if (nftMetadata.getSellFee()==0 || extInfo.getOrderId() == null) {
            orderService.createReplenishOrder(extInfo.getUserId(),extInfo.getMetaId(),oldNftRecord.getActualNftId(),task.getTxHash(),extInfo.getShortSeriesId(), extInfo.getIsReplenish());
        }else{
            NftOrder order = orderService.getById(extInfo.getOrderId());
            order.setTxHash(task.getTxHash());
            orderService.updateById(order);
        }

    }

    public void deleteBak(Integer recordId) {
        baseMapper.deleteBak(recordId);
        baseMapper.deleteById(recordId);
    }

    public NftInfoVO nftDetails(String metaId,String actualNftId) {
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        NftInfoVO vo = baseMapper.nftDetails(metaId, actualNftId, Math.toIntExact(currentUser.getUserId()));
        Date createTime = DateUtil.parse(vo.getCreateTime());
        Integer transferTime = null;
        if (vo.getTransferTime() == null) {
            transferTime = (Integer) redisService.hget(RedisKeyFactory.getLeadTimeKey(), "level"+currentUser.getUserDetails().getRightLevel());
            if (transferTime==null) {
                transferTime = 40;
            }
            vo.setTransferTime(transferTime);
        } else {
            transferTime = vo.getTransferTime();
        }
        if (env.contains("prod")) {
            transferTime = transferTime * 24 * 60;
        }
        if (vo.getShowCountInfo()!=null && vo.getShowCountInfo()==1) {
            Integer count = lambdaQuery()
                    .eq(NftRecord::getMetaId, metaId)
                    .in(NftRecord::getBuyStatus, 7, 11)
                    .count();
            vo.setCirculationCount(count);
        }

        Date canTransferTime = DateUtil.offsetMinute(createTime,transferTime);
        vo.setCanTransferTime(DateUtil.formatDateTime(canTransferTime));
        return vo;
    }

    public NftInfoVO shareDetails(String metaId,String actualNftId,Integer userId) {
        NftInfoVO vo = baseMapper.shareDetails(metaId, actualNftId, userId);
        if (vo!=null) {
            Date createTime = DateUtil.parse(vo.getCreateTime());
            if (vo.getShowCountInfo()!=null && vo.getShowCountInfo()==1) {
                Integer count = lambdaQuery()
                        .eq(NftRecord::getMetaId, metaId)
                        .in(NftRecord::getBuyStatus, 7, 11)
                        .count();
                vo.setCirculationCount(count);
            }
        }
        return vo;
    }

    @Transactional(rollbackFor = Exception.class)
    public JsonResult<?> transfer(String actualNftId, Long owner, Integer receiver) {
        NftRecord record = ChainWrappers.lambdaQueryChain(baseMapper)
                .eq(NftRecord::getUserId, owner)
                .in(NftRecord::getBuyStatus, 2,7)
                .eq(NftRecord::getActualNftId, actualNftId)
                .orderByDesc(NftRecord::getBuyStatus)
                .last("limit 1")
                .one();
        if (record==null) {
            throw new BusException("不存在的藏品");
        }

        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        NftMetadata metadata = nftMetadataService.getByMetaId(record.getMetaId()+"");
        NftSeriesClaim seriesClaim = nftSeriesClaimService.getBySeriesId(metadata.getSeriesId());
        Integer rightLevel = currentUser.getUserDetails().getRightLevel();
        if (rightLevel==null) {
            rightLevel = 0;
        }

        Integer transferTime = null;

        if (seriesClaim.getTransferTime()!=null && seriesClaim.getTransferTime()>0) {
            transferTime = seriesClaim.getTransferTime();
        } else {
            transferTime = (Integer) redisService.hget(RedisKeyFactory.getLeadTimeKey(), "level"+rightLevel);
            if (transferTime==null) {
                transferTime = 40;
            }
        }

        if (env.contains("prod")) {
            transferTime = transferTime * 24 * 60;
        }

        Date now = new Date();
        Date buyTime = record.getCreateTime();

        DateTime canTransferTime = DateUtil.offsetMinute(buyTime, transferTime);
        if (DateUtil.compare(canTransferTime,now)>0) {
            throw new BusException("未到规定转赠时间");
        }


        if (record.getBuyStatus()==2) {
            throw new BusException("转赠失败\n请联系客服：400-046-3366");
        }

        NftUser receiveUser = userService.getById(receiver);
        TransferRecord transferRecord = new TransferRecord();
        transferRecord.setStatus(0);
        transferRecord.setGiveUserId(owner.intValue());
        transferRecord.setReceiveUserId(receiver);
        if (StrUtil.isNotBlank(currentUser.getUserDetails().getNickName())) {
            transferRecord.setGiveName(currentUser.getUserDetails().getNickName());
        } else {
            transferRecord.setGiveName(currentUser.getUserDetails().getUserName());
        }
        transferRecord.setReceiveMobile(receiveUser.getMobile());
        if (StrUtil.isNotBlank(receiveUser.getNickName())) {
            transferRecord.setReceiveName(receiveUser.getNickName());
        } else {
            transferRecord.setReceiveName(receiveUser.getUserName());
        }

        transferRecord.setName(metadata.getName());
        transferRecord.setMetaId(record.getMetaId());
        transferRecord.setSeriesName(seriesClaim.getSeriesName());
        transferRecord.setShortSeriesId(seriesClaim.getId());
        transferRecord.setDisplayUrl(metadata.getDisplayUrl());
        transferRecord.setActualNftId(actualNftId);
        transferRecord.setCreateTime(DateUtil.formatDateTime(now));
        transferRecord.setExpireTime(DateUtil.formatDateTime(DateUtil.offsetDay( now,1)));
        transferRecordService.save(transferRecord);
        record.setBuyStatus(11);
        record.setUpdateTime(DateUtil.now());
        updateById(record);
        NftRecord newRecord = new NftRecord();
        newRecord.setBuyStatus(12);
        newRecord.setObtainType(2);
        newRecord.setActualNftId(actualNftId);
        newRecord.setNftId(record.getNftId());
        newRecord.setGiverUserId(owner.intValue());
        newRecord.setMetaType(record.getMetaType());
        if (currentUser.getUserDetails().getNickName()!=null) {
            newRecord.setGiverUserName(currentUser.getUserDetails().getNickName());
        } else {
            newRecord.setGiverUserName(currentUser.getUserDetails().getUserName());
        }
        newRecord.setUserId(receiver);
        newRecord.setCreateTime(now);
        newRecord.setMetaId(metadata.getMetaId());
        save(newRecord);

        TransferCancelMqDto dto = new TransferCancelMqDto();
        dto.setActualNftId(actualNftId);
        dto.setGiveRecordId(record.getId());
        dto.setGiveUserId(transferRecord.getGiveUserId());
        dto.setReceiveUserId(transferRecord.getReceiveUserId());
        dto.setTransId(transferRecord.getTransId());

        //DateTime date = DateUtil.parse(transferRecord.getExpireTime());
        Integer transferExpireTime = (Integer) redisService.hget(RedisKeyFactory.getLeadTimeKey(), "transferExpireTime");
        if (transferExpireTime==null) {
            transferExpireTime = 5;
        }
        DateTime date = DateUtil.offsetMinute(now,transferExpireTime);
        long delay = date.getTime() - now.getTime();
        log.info("转赠队列新增记录：{},延时时间：{}",dto,delay);
        if (delay>0) {//如果通知时间大于当前时间才进行通知
            //把此订单发送到消息队列的延迟队列中
            rabbitTemplate.convertAndSend(RabbitmqConst.CREATE_ORDER_DELAY_EXCHANGE, RabbitmqConst.TRANSFER_CANCEL_DELAY_QUEUE, dto, message -> {
                message.getMessageProperties().setDelay((int) (delay));
                return message;
            });
        }

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("createTime",DateUtil.formatDateTime(newRecord.getCreateTime()));
        jsonObject.put("expireTime",transferRecord.getExpireTime());
        jsonObject.put("displayUrl",transferRecord.getDisplayUrl());
        jsonObject.put("name",transferRecord.getName());
        return JsonResult.success(jsonObject);
    }

    @Transactional(rollbackFor = Exception.class)
    public JsonResult<Void> transferConfirm(TransferConfirmVO confirm) {
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        TransferRecord transferRecord = ChainWrappers.lambdaQueryChain(transferRecordService.getBaseMapper())
                .eq(TransferRecord::getReceiveUserId, currentUser.getUserId())
                .eq(TransferRecord::getActualNftId, confirm.getActualNftId())
                .eq(TransferRecord::getStatus, 0)
                .last("limit 1")
                .one();
        if (transferRecord==null) {
            throw new BusException("不存在未领取的藏品");
        }
        NftRecord record = ChainWrappers.lambdaQueryChain(baseMapper)
                .eq(NftRecord::getUserId, transferRecord.getGiveUserId())
                .eq(NftRecord::getActualNftId, confirm.getActualNftId())
                .eq(NftRecord::getBuyStatus, 11)
                .last("limit 1")
                .one();
        if (record==null) {
            throw new BusException("转赠数据异常");
        }
        boolean result = true;
        String msg = "";
        if (confirm.getConfirmStatus()==1) {
            NftUserPlatform giver = nftUserPlatformService.getById(transferRecord.getGiveUserId());
            NftUserPlatform receiver = nftUserPlatformService.getById(currentUser.getUserId());

            NftTransferRequest request = new NftTransferRequest();
            request.setNftId(confirm.getActualNftId());
            request.setOperateId(IdUtil.objectId());
            request.setReceiverAddr(receiver.getAddr());
            request.setPubKey(giver.getPubkey());

            String str = "{}_{}_{}_{}_{}";
            String signData = StrUtil.format(str,giver.getPubkey(), receiver.getAddr(),"nft_transfer"
                    , request.getNftId(), request.getOperateId());
            SignByPriKeyResponse userSignResponse = nftCommonUtil.signByPriKey(giver.getPrikey(), signData);
            request.setSignature(userSignResponse.getSignedData());
            SdkResponseBase<TaskResponse> taskResponse = nftService.nftTransfer(request);
            if (taskResponse == null) {
                result = false;
                msg = "区块链异常";
            } else {
                if (taskResponse.getRetCode()==0) {

                    Map<String,Object> extData = new HashMap<>();
                    extData.put("nftId",transferRecord.getActualNftId());
                    extData.put("recordId",record.getId());
                    extData.put("transferUserId",transferRecord.getGiveUserId());
                    extData.put("receiveUserId",receiver.getUserId());

                    NftTask task = new NftTask();
                    task.setStatus(2);
                    task.setType(TaskEnum.NFT_TRANSFER.getCode());
                    task.setOperateId(request.getOperateId());
                    task.setTaskId(taskResponse.getData().getTaskId());
                    task.setExtend1(record.getId());
                    task.setExtend2(receiver.getUserId()+"");
                    task.setExtend3(JSON.toJSONString(extData));
                    taskService.save(task);
                    transferRecord.setTaskId(task.getId());
                    transferRecordService.updateById(transferRecord);
                    ChainWrappers.lambdaUpdateChain(baseMapper)
                            .eq(NftRecord::getUserId, transferRecord.getReceiveUserId())
                            .eq(NftRecord::getActualNftId, confirm.getActualNftId())
                            .eq(NftRecord::getBuyStatus, 12)
                            .set(NftRecord::getBuyStatus, 13)
                            .update();
                } else {
                    result = false;
                    msg = "区块链执行转赠失败";
                }
            }
        } else if (confirm.getConfirmStatus()==2) {
            result = false;
            msg = "受赠人拒绝";
        }

        if (!result) {
            transferRecord.setStatus(2);
            transferRecord.setMsg(msg);
            transferRecordService.updateById(transferRecord);
            record.setBuyStatus(7);
            record.setUpdateTime(DateUtil.now());
            updateById(record);
            ChainWrappers.lambdaUpdateChain(baseMapper)
                    .eq(NftRecord::getUserId, transferRecord.getReceiveUserId())
                    .eq(NftRecord::getActualNftId, confirm.getActualNftId())
                    .eq(NftRecord::getBuyStatus, 12)
                    .remove();
            if (confirm.getConfirmStatus()!=2) {
                return JsonResult.error(ApiStatusErrorEnum.INTERNAL_ERROR.getCode(),msg);
            }
        }
        return JsonResult.success();
    }

    @Transactional(rollbackFor = Exception.class)
    public void finishTransfer(NftRecord record, boolean result,NftTask task) {
        TransferRecord transferRecord = ChainWrappers.lambdaQueryChain(transferRecordService.getBaseMapper())
                .eq(TransferRecord::getGiveUserId, record.getUserId())
                .eq(TransferRecord::getActualNftId, record.getActualNftId())
                .eq(TransferRecord::getStatus, 0)
                .last("limit 1")
                .one();
        if (result) {
            if (transferRecord!=null) {
                NftUserPlatform receivePlatform = nftUserPlatformService.getById(transferRecord.getReceiveUserId());
                ChainWrappers.lambdaUpdateChain(baseMapper)
                        .eq(NftRecord::getUserId,transferRecord.getReceiveUserId())
                        .eq(NftRecord::getActualNftId,record.getActualNftId())
                        .eq(NftRecord::getBuyStatus,13)
                        .set(NftRecord::getBuyStatus,7)
                        .set(NftRecord::getOwnerAddr,receivePlatform.getAddr())
                        .set(NftRecord::getOwnerTime,DateUtil.now())
                        .set(NftRecord::getTxHash,task.getTxHash())
                        .update();
                removeById(record.getId());
                transferRecord.setStatus(1);
                transferRecord.setReceiveTime(DateUtil.now());
                transferRecordService.updateById(transferRecord);
                userService.addRightUser(transferRecord.getReceiveUserId()+"",transferRecord.getMetaId());
                userService.removeRightUser(transferRecord.getGiveUserId()+"",transferRecord.getMetaId());
            }
        } else {
            if (transferRecord!=null) {
                transferCancel(record.getId(),transferRecord.getReceiveUserId(),transferRecord.getTransId(),transferRecord.getActualNftId(),"区块链上链失败");
            }
        }
    }

    public void transferCancel(String giveRecordId,Integer receiver,Integer transferId,String actualNftId,String msg) {
        //删除新增的领取记录
        ChainWrappers.lambdaUpdateChain(baseMapper)
                .eq(NftRecord::getUserId,receiver)
                .eq(NftRecord::getActualNftId,actualNftId)
                .in(NftRecord::getBuyStatus,12,13)
                .remove();
        //还原之前的记录
        ChainWrappers.lambdaUpdateChain(baseMapper)
                .eq(NftRecord::getId,giveRecordId)
                .set(NftRecord::getBuyStatus,7)
                .update();
        ChainWrappers.lambdaUpdateChain(transferRecordService.getBaseMapper())
                .eq(TransferRecord::getTransId,transferId)
                .set(TransferRecord::getStatus,2)
                .set(TransferRecord::getMsg,msg)
                .update();
    }

    public int updateMaterial(Integer mergeId,Integer userId, Integer metaId, Integer count) {
        return baseMapper.updateMaterial(mergeId,userId,metaId,count);
    }

    @Transactional(rollbackFor = Exception.class)
    public void updateMergeRecord(NftTask task, NftTask.NftBuyExtInfo extInfo) {
        log.info("更新nft合成记录");

        NftMetadata nftMetadata = nftMetadataService.getById(extInfo.getMetaId());
        NftRecord oldNftRecord = getById(extInfo.getRecordId());
        Merge merge = mergeService.getById(oldNftRecord.getMergeId());
        if (task.getStatus()==7) {
            NftRecord updateNftRecord = new NftRecord();
            updateNftRecord.setId(oldNftRecord.getId());
            updateNftRecord.setTxHash(task.getTxHash());
            updateNftRecord.setBuyStatus(task.getStatus());
            updateNftRecord.setMetaType(1);
            updateById(updateNftRecord);

            merge.setStatus(1);
            mergeService.updateById(merge);

            List<NftRecord> destroyRecords = findByMergeId(extInfo.getUserId(),merge.getMergeId());
            destroyNft(destroyRecords,extInfo.getUserId());

            if (nftMetadata.getSellFee()==0 || extInfo.getOrderId() == null) {
                orderService.createReplenishOrder(extInfo.getUserId(),extInfo.getMetaId(),oldNftRecord.getActualNftId(),task.getTxHash(),extInfo.getShortSeriesId(), extInfo.getIsReplenish());
            }else{
                NftOrder order = orderService.getById(extInfo.getOrderId());
                order.setTxHash(task.getTxHash());
                orderService.updateById(order);
            }
        } else if (task.getStatus()==10) {
            merge.setStatus(2);
            mergeService.updateById(merge);
            collectionService.incrementCollectionStock(merge.getCollectionId(),1);
            restoreByMergeId(extInfo.getUserId(),merge.getMergeId());
            deleteBak(Integer.valueOf(oldNftRecord.getId()));
        }
    }

    private void restoreByMergeId(Integer userId, Integer mergeId) {
        this.lambdaUpdate()
                .eq(NftRecord::getUserId,userId)
                .eq(NftRecord::getMergeId,mergeId)
                .eq(NftRecord::getBuyStatus,14)
                .set(NftRecord::getBuyStatus,7)
                .set(NftRecord::getMergeId,null)
                .update();
    }

    private void destroyNft(List<NftRecord> destroyRecords,Integer userId) {
        //销毁地址 ZX0000000000000000000000000000000000000000
        destroyRecords.forEach( record -> {
            NftUserPlatform operater = nftUserPlatformService.getById(userId);

            NftTransferRequest request = new NftTransferRequest();
            request.setNftId(record.getActualNftId());
            request.setOperateId(IdUtil.objectId());
            request.setReceiverAddr("ZX0000000000000000000000000000000000000000");
            request.setPubKey(operater.getPubkey());

            String str = "{}_{}_{}_{}_{}";
            String signData = StrUtil.format(str,operater.getPubkey(), request.getReceiverAddr(),"nft_transfer"
                    , request.getNftId(), request.getOperateId());
            SignByPriKeyResponse userSignResponse = nftCommonUtil.signByPriKey(operater.getPrikey(), signData);
            request.setSignature(userSignResponse.getSignedData());
            SdkResponseBase<TaskResponse> taskResponse = nftService.nftTransfer(request);
            if (taskResponse == null) {
                log.error("销毁nft异常");
            } else {
                if (taskResponse.getRetCode()==0) {
                    Map<String,Object> extData = new HashMap<>();
                    extData.put("nftId",record.getActualNftId());
                    extData.put("recordId",record.getId());
                    extData.put("transferUserId",userId);
                    extData.put("receiveUserId","destroy");

                    NftTask task = new NftTask();
                    task.setStatus(2);
                    task.setType(TaskEnum.NFT_TRANSFER.getCode());
                    task.setOperateId(request.getOperateId());
                    task.setTaskId(taskResponse.getData().getTaskId());
                    task.setExtend1(record.getId());
                    task.setExtend2("destroy");
                    task.setExtend3(JSON.toJSONString(extData));
                    taskService.save(task);
                    ChainWrappers.lambdaUpdateChain(baseMapper)
                            .eq(NftRecord::getUserId,record.getUserId())
                            .eq(NftRecord::getActualNftId, record.getActualNftId())
                            .eq(NftRecord::getBuyStatus, 12)
                            .set(NftRecord::getBuyStatus, 15)
                            .update();
                }
            }
        });
    }

    private List<NftRecord> findByMergeId(Integer userId,Integer mergeId) {
        return lambdaQuery()
                .eq(NftRecord::getUserId, userId)
                .eq(NftRecord::getMergeId, mergeId)
                .eq(NftRecord::getBuyStatus,14)
                .list();
    }
}
