package com.foundao.nft.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.foundao.nft.common.model.NftUser;
import com.foundao.nft.common.model.vo.NftUserVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
    @Package: com.foundao.nft.api.mapper
    @ClassName: NftUserMapper
    @Author: chenli
    @CreateTime: 2021/12/20 11:41 上午
    @Description:
*/
@Mapper
public interface NftUserMapper extends BaseMapper<NftUser> {
    NftUser findUserByMobile(String mobile);

    NftUser findUserBySocial(@Param("source") String source,@Param("uuid") String uuid);

    NftUser findUserByUserName(String username);

    @Select("select DISTINCT user_id from nft_record where meta_id=#{primaryMetaId} and buy_status=7")
    List<String> findUserIdByMetaIdDistinct(Integer primaryMetaId);

    NftUser findUserByInviteUserId(Integer inviteUserId);
}