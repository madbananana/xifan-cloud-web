package com.foundao.nft.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.foundao.nft.common.model.RecipeMaterial;
import com.foundao.nft.common.model.vo.RecipeMaterialVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface RecipeMaterialMapper extends BaseMapper<RecipeMaterial> {
    List<RecipeMaterialVO> listMaterialVOByUser(@Param("recipeId") Integer recipeId,@Param("userId") Integer userId);
}
