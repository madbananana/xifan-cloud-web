package com.foundao.nft.api.task;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import com.foundao.nft.api.service.impl.AdvanceBuyService;
import com.foundao.nft.api.service.impl.MessageService;
import com.foundao.nft.api.service.impl.NftSeriesClaimService;
import com.foundao.nft.common.model.vo.SendMsgResponse;
import com.foundao.nft.common.model.AdvanceBuy;
import com.foundao.nft.common.model.NftSeriesClaim;
import com.foundao.nft.common.util.RedisKeyFactory;
import com.tx.redis.service.RedisLockService;
import com.tx.redis.service.RedisService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @Package: com.foundao.nft.api.task
 * @ClassName: AppointmentNoticeTaskHandler
 * @Author: chenli
 * @CreateTime: 2022/4/27 2:45 下午
 * @Description:
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class AppointmentNoticeTaskHandler {

    private final AdvanceBuyService advanceBuyService;
    private final MessageService messageService;
    private final RedisLockService lockService;
    private final RedisService redisService;
    private final NftSeriesClaimService seriesClaimService;

    private static final String LOCK = "lock:newtv-nft:sendMsgTask";

    @Scheduled(initialDelay = 5 * 1000, fixedDelay = 5 * 1000)
    public void scanTask() {
        String lockName = LOCK;
        boolean isObtainLock = lockService.tryLock(lockName, 5);
        if (isObtainLock) {
            try {
                String seriesId = advanceBuyService.findAllNoticeSeriesId();
                if (seriesId != null) {
                    int timeOffset = 60;
                    Integer leadTime = (Integer) redisService.hget(RedisKeyFactory.getLeadTimeKey(), "leadTime");
                    if (leadTime!=null) {
                        timeOffset = leadTime;
                    }
                    List<AdvanceBuy> advanceBuys = advanceBuyService.findAllWaiteNotice(seriesId);
                    List<AdvanceBuy> noticeList = new ArrayList<>();
                    int finalTimeOffset = timeOffset;
                    DateTime date ;
                    //预约通知时间
                   if (advanceBuys!=null && advanceBuys.size()>0) {
                       NftSeriesClaim seriesClaim = seriesClaimService.getBySeriesId(seriesId);
                       Integer categoryMetaId = (Integer) redisService.hget(RedisKeyFactory.getCategoryMetaIdKey(), seriesClaim.getCategoryId() + "");
                       date = DateUtil.parse(advanceBuys.get(0).getBeginTime());
                        advanceBuys.forEach(advanceBuy -> {
                            DateTime beginDate = DateUtil.parse(advanceBuy.getBeginTime());
                            DateTime createTime = DateUtil.parse(advanceBuy.getCreateTime());

                            int adTimeOffset = 0;
                            //预约通知时间
                            if (categoryMetaId!=null) {
//                                Boolean exist = redisService.sHasKey(RedisKeyFactory.getAboriginesKey(categoryMetaId+""),advanceBuy.getUserId()+"");
                                Boolean exist = redisService.hHasKey(RedisKeyFactory.getStarUserIdKey(categoryMetaId), advanceBuy.getUserId()+"");
                                if (exist) {
                                    Integer adLeadTime = (Integer) redisService.hget(RedisKeyFactory.getLeadTimeKey(), "adLeadTime");
                                    if (adLeadTime!=null) {
                                        adTimeOffset += adLeadTime;
                                    }

                                }
                            }
                            //预约开售时间
                            Date realBeginTime = DateUtil.offsetMinute(beginDate, -1 * (finalTimeOffset+adTimeOffset));
                            Date noticeStartTime = DateUtil.offsetMinute(realBeginTime, -10);
                            //判断是否是通知时间10分钟内创建的预约
                            long outTime = noticeStartTime.getTime() - createTime.getTime();
                            if (outTime > 0) {
                                Date now = new Date();
                                long delay = noticeStartTime.getTime() - now.getTime();
                                if (delay >= 0){
                                    return;
                                }
                                long stopNotice = realBeginTime.getTime() - now.getTime();
                                if ( stopNotice<0 ) {
                                    //已经过了通知时间
                                    advanceBuy.setNoticeStatus(1);
                                }
                            } else {
                                //通知时间之后预约的
                                advanceBuy.setNoticeStatus(1);
                            }
                            noticeList.add(advanceBuy);
                        });
                        SendMsgResponse response = null;
                        if (noticeList.size()>0) {
                            response = messageService.sendAppointmentNoticeMessage(noticeList, DateUtil.format(date, "HH:mm"));
                            log.info("短信群发通知结果：{}", response);
                            noticeList.forEach(v->v.setNoticeStatus(1));
                        }
                        advanceBuyService.updateBatchById(noticeList);
                    }
                }
            } catch (Exception e) {
                log.error("发送通知短信异常",e);
            } finally {
                lockService.unlock(lockName);
            }

        }
    }
}
