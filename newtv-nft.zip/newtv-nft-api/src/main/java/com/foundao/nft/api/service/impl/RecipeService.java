package com.foundao.nft.api.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.foundao.nft.common.model.NftMetadata;
import com.foundao.nft.common.model.RecipeMaterial;
import com.foundao.nft.common.model.sdk.response.OrderQueryResponse;
import com.foundao.nft.common.model.sdk.response.OrderResponseWrapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.common.model.Recipe;
import com.foundao.nft.api.mapper.RecipeMapper;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class RecipeService extends ServiceImpl<RecipeMapper, Recipe> {

    private final RecipeMaterialService recipeMaterialService;

    @Transactional(rollbackFor = Exception.class)
    public void creatRecipe(NftMetadata metadata) {
        Recipe recipe = new Recipe();
        recipe.setRecipeName(metadata.getName());
        recipe.setResultMetaId(metadata.getMetaId());
        recipe.setResultSeriesId(metadata.getShortSeriesId());
        save(recipe);
        List<RecipeMaterial> recipeMaterials = JSON.parseObject(metadata.getMetaData(), new TypeReference<List<RecipeMaterial>>() {
        });
        recipeMaterials.forEach(material -> {
            material.setRecipeId(recipe.getRecipeId());
        });
        recipeMaterialService.saveBatch(recipeMaterials);
    }
}
