package com.foundao.nft.api.mq;

import cn.hutool.core.date.DateUtil;
import com.alibaba.fastjson.JSON;
import com.foundao.nft.api.service.OrderPostHandler;
import com.foundao.nft.api.service.impl.MessageService;
import com.foundao.nft.common.model.vo.SendMsgResponse;
import com.foundao.nft.common.constant.OrderStatusEnum;
import com.foundao.nft.common.constant.RabbitmqConst;
import com.foundao.nft.common.model.AdvanceBuy;
import com.foundao.nft.common.model.NftOrder;
import com.foundao.nft.common.model.mq.CreateOrderMqDto;
import com.foundao.nft.common.model.mq.SendMessageMqDto;
import com.rabbitmq.client.Channel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;

/**
 * @Package: com.foundao.nft.api.mq
 * @ClassName: AppointmentSendMessageHandler
 * @Author: chenli
 * @CreateTime: 2022/4/26 12:01 下午
 * @Description:
 */
@Slf4j
//@RabbitListener(queues = RabbitmqConst.APPOINTMENT_MESSAGE_DELAY_QUEUE)
//@Component
public class AppointmentSendMessageHandler {

    //@Autowired
    private MessageService messageService;

    //@RabbitHandler
    public void appointmentSendMessageListener(SendMessageMqDto messageMqDto, Message message, Channel channel) {
        //  如果手动ACK,消息会被监听消费,但是消息在队列中依旧存在,如果 未配置 acknowledge-mode 默认是会在消费完毕后自动ACK掉
        final long deliveryTag = message.getMessageProperties().getDeliveryTag();
        try {
            log.info("短信队列:{},手动ACK，接收消息：{}", RabbitmqConst.APPOINTMENT_MESSAGE_DELAY_QUEUE, JSON.toJSON(messageMqDto));
            SendMsgResponse response = messageService.sendAppointmentNoticeMessage(messageMqDto);
            log.info("短信发送结果：{}",response);
            channel.basicAck(deliveryTag, false);

        } catch (Exception e) {
            try {
                // 处理失败,重新压入MQ
                channel.basicRecover();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        }
    }
}
