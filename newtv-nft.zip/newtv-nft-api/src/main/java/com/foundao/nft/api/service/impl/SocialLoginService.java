package com.foundao.nft.api.service.impl;

import com.foundao.nft.common.model.sdk.request.WeAppLoginRequest;
import com.foundao.nft.common.model.sdk.response.WeAppLoginResponse;
import com.foundao.nft.common.util.WeChatUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

/**
 * @ClassName SocialLoginServiceImpl
 * @Description TODO
 * @Author xifan
 * @Date 2021/12/19 11:47
 * @Version 1.0
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class SocialLoginService {

    private final RestTemplate restTemplate;

    public WeAppLoginResponse wechat(WeAppLoginRequest request){
        String reqUrl = WeChatUtil.getCode2SessionReqUrl(request.getCode());
        ResponseEntity<WeAppLoginResponse> response = restTemplate.getForEntity(reqUrl, WeAppLoginResponse.class);
        WeAppLoginResponse respBody = response.getBody();
        log.info("腾讯返回信息："+respBody);
        if (HttpStatus.OK.equals(response.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }

}
