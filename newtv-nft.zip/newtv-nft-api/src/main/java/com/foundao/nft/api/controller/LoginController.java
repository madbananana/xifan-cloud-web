package com.foundao.nft.api.controller;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.RandomUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.dfa.SensitiveUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.foundao.nft.api.service.impl.*;
import com.foundao.nft.api.vo.RegisterVO;
import com.foundao.nft.common.model.vo.SendMessageBaseVO;
import com.foundao.nft.common.model.vo.SendMessageVO;
import com.foundao.nft.common.model.vo.SendMsgResponse;
import com.foundao.nft.common.model.vo.SendMsgV2Response;
import com.foundao.nft.common.model.vo.UserVo;
import com.foundao.nft.common.model.NewtvEmp;
import com.foundao.nft.common.model.NftUser;
import com.foundao.nft.common.model.sdk.request.PhoneInfoRequest;
import com.foundao.nft.common.model.sdk.request.WeAppLoginRequest;
import com.foundao.nft.common.model.sdk.response.WeAppLoginResponse;
import com.foundao.nft.common.model.vo.WxUserInfo;
import com.foundao.nft.common.util.AES;
import com.foundao.nft.common.util.RedisKeyFactory;
import com.foundao.nft.common.util.WeChatUtil;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import com.tx.core.beans.JsonResult;
import com.tx.core.enums.errcode.ApiStatusErrorEnum;
import com.tx.core.enums.errcode.ParamErrorEnum;
import com.tx.core.exception.BusException;
import com.tx.core.util.HttpRequestUtil;
import com.tx.redis.service.RedisService;
import com.tx.security.annotation.AnonymousGetMapping;
import com.tx.security.annotation.AnonymousPostMapping;
import com.tx.security.bean.AuthUser;
import com.tx.security.bean.JwtUserDto;
import com.tx.security.service.OnlineUserService;
import com.tx.security.util.SecurityUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.validator.constraints.Length;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @ClassName LoginController
 * @Description TODO
 * @Author xifan
 * @Date 2021/12/18 22:55
 * @Version 1.0
 */
@RestController
@RequiredArgsConstructor
@Api(tags = "登录")
@RequestMapping("login")
@Slf4j
@SuppressWarnings("unchecked")
@Validated
public class LoginController {

    private final SocialLoginService socialLoginService;
    private final UserDetailServiceImpl userDetailService;
    private final OnlineUserService onlineUserService;
    private final NftUserService userService;
    private final RedisService redisService;
    private final NewtvEmpService empService;
    private final MessageService messageService;
    private final PasswordEncoder passwordEncoder;
    private final SensorsAnalyticsService sensorsAnalyticsService;



    @ApiOperation("微信小程序登录")
    @AnonymousPostMapping("wechat")
    public JsonResult<JwtUserDto<UserVo>> wechat(WeAppLoginRequest request){
        log.info("微信登录，请求信息："+request);
        WeAppLoginResponse respBody = socialLoginService.wechat(request);
        if (respBody!=null) {
            // 判断请求是否成功 返回openid则表示返回成功
            if (null==respBody.getOpenid()) {
                return JsonResult.error(HttpStatus.INTERNAL_SERVER_ERROR.value(),respBody.getErrmsg());
            }

            WxUserInfo userInfo = new WxUserInfo();
            //userInfo.setNickName(respBody.getOpenid());

            // 验证签名
            if (request.getRaw_user_data()!=null) {
                String signature = WeChatUtil.sha1(request.getRaw_user_data() + respBody.getSession_key());
                if (signature==null || !signature.equals(request.getWx_sign())) {
                    return JsonResult.error(HttpStatus.INTERNAL_SERVER_ERROR.value(),"验签失败");
                }
                userInfo = JSONObject.parseObject(request.getUserInfo(), WxUserInfo.class);
            }

            NftUser user = userService.thirdUserLogin(respBody.getOpenid(), userInfo.getNickName(), userInfo.getAvatarUrl(), "wechat");
            JsonResult<JwtUserDto<UserVo>> rsp = authenticate(respBody.getOpenid(), "wechat");
            redisService.set(RedisKeyFactory.getSessionKey()+user.getUserId(),respBody.getSession_key());
            return rsp;
        }
        return JsonResult.success();
    }

    @ApiOperation("解密电话号码")
    @PostMapping("phone")
    public JsonResult<JwtUserDto<UserVo>> phoneInfo(PhoneInfoRequest request){
        log.info("解密手机号，请求数据："+request);
        String sessionKey = (String) redisService.get(RedisKeyFactory.getSessionKey()+SecurityUtil.getCurrentUser().getUserId());
        JSONObject jsonObject = AES.wxDecrypt(request.getEncryptedData(), sessionKey, request.getIv());
        String phoneNumber = null;
        if (StrUtil.isNotBlank((String) jsonObject.get("phoneNumber"))){
            phoneNumber = (String) jsonObject.get("phoneNumber");
        }
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        UserVo userDetails = currentUser.getUserDetails();
        userDetails.setMobile(phoneNumber);
        NftUser user = userService.findUserByMobile(phoneNumber);
        if (user!=null) {
            if (!userDetails.getUserId().equals(user.getUserId())){
                userService.bindMobileUser(user,userDetails.getUserName(),currentUser.getUserId()+"");
                //return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"手机号已绑定，请更换手机号");
                JwtUserDto<UserVo> one = onlineUserService.getOne(Long.valueOf(user.getUserId()));
                //return authenticate(phoneNumber, null);
                return JsonResult.success(one);
            }
        }
        NewtvEmp emp = empService.getById(phoneNumber);
        if (emp!=null) {
            userDetails.setInternalEmp(1);
            userDetails.setSpecial(emp.getSpecialType() == 1);
        }

        //更新数据库
        NftUser upUser = new NftUser();
        upUser.setUserId(userDetails.getUserId());
        upUser.setInternalEmp(userDetails.getInternalEmp());
        upUser.setMobile(phoneNumber);
        //upUser.setNickName(phoneNumber);
        //if(phoneNumber.length()>=4) {
        //    upUser.setNickName("用户"+phoneNumber.substring(phoneNumber.length()-4));
        //}
        if (currentUser.getUserDetails().getNickName()==null) {
            if(phoneNumber!=null && phoneNumber.length()>=4) {
                upUser.setNickName("用户"+phoneNumber.substring(phoneNumber.length()-4));
            }
        }
        upUser.setUserName(phoneNumber);
        userService.updateById(upUser);
        //userDetails.setNickName(upUser.getNickName());
        //更新redis
        JwtUserDto<UserVo> jwtUserDto = onlineUserService.updateUser(currentUser);
        return JsonResult.success(jwtUserDto);

    }

    private JsonResult<JwtUserDto<UserVo>> authenticate(String username, String from){
        Map<String,Object> usernameMap = new HashMap<>(3);
        usernameMap.put("userName", username);
        usernameMap.put("from", from);
        UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(username,"");
        NftUser user = userService.findUser(from, username);
        if (user!=null) {
            user.setLastLoginIp(HttpRequestUtil.getClientIp());
            if (user.getStatus() == 2 || user.getStatus() == 3) {
                user.setStatus(0);
                redisService.del(RedisKeyFactory.getUserCancellationKey(user.getUserId()+""));
            }
            userService.updateById(user);
            JwtUserDto<UserVo> one = onlineUserService.getOne(Long.valueOf(user.getUserId()));
            if (one!=null) {
                return JsonResult.success(one);
            }
        }



        JwtUserDto<UserVo> jwtUserDto = (JwtUserDto<UserVo>) userDetailService.loadUserByUsername(JSON.toJSONString(usernameMap));
        authentication.setDetails(jwtUserDto);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        onlineUserService.createTokenAndSave(jwtUserDto);
        return JsonResult.success(jwtUserDto);
    }

    @AnonymousGetMapping("/getServerInfo")
    public JsonResult<?> getServerInfo(HttpServletRequest request){
        log.info("getServerInfo: {}",JSON.toJSONString(HttpRequestUtil.getRequestMap()));
        return JsonResult.success(HttpRequestUtil.getRequestMap());
    }

    @AnonymousPostMapping("/postServerInfo")
    public JsonResult<?> postServerInfo(HttpServletRequest request){
        log.info("postServerInfo: {}",JSON.toJSONString(HttpRequestUtil.getRequestMap()));
        return JsonResult.success(HttpRequestUtil.getRequestMap());
    }

    @ApiOperation("短信验证码登录")
    @AnonymousPostMapping("mobile")
    public JsonResult<JwtUserDto<UserVo>> phone(String phone,String verificationCode){
        log.info("短信登录，电话号码：{} 验证码：{}",phone,verificationCode);
        NftUser user = userService.mobileUserLogin(phone);
        if ("13911229370".equals(phone) && verificationCode.equals("123456")){
            return authenticate(phone, null);
        }
        //
        //if (verificationCode.equals("123456")){
        //    return authenticate(phone, null);
        //}
        String code = (String) redisService.get(RedisKeyFactory.getVerificationCodeKey(phone));
        if (StrUtil.isNotBlank(code)) {
            if (code.equals(verificationCode)) {
                redisService.del(RedisKeyFactory.getVerificationCodeKey(phone));
                return authenticate(phone, null);
            }
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"验证码输入错误");
        } else {
            //return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"验证码超时，请稍后再试");
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"验证码输入错误");
        }
    }

    @ApiOperation("发送短信验证码")
    @AnonymousPostMapping("sendMsg")
    public JsonResult<JwtUserDto<UserVo>> sendMsg(@Validated @RequestParam @Pattern(regexp = "^(13[0-9]|14[01456879]|15[0-35-9]|16[2567]|17[0-8]|18[0-9]|19[0-35-9])\\d{8}$",message = "手机号格式错误")String phone) throws Exception{
        log.info("发送短信验证码，电话{}",phone);
        if (phone!=null) {
            throw new BusException("请升级最新版");
        }
        String content = "【未来数藏】您正在登录账号，验证码%s。5分钟内有效，如非本人操作，请忽略本短信。";
        SendMsgResponse response = messageService.sendMessage(phone,content);
        if (response!=null) {
            if ("1".equals(response.getStatusCode())) {
                return JsonResult.success();
            }
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),response.getMessage());
        }
        return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"短信发送失败");
    }

    @ApiOperation("发送短信验证码V2")
    @AnonymousPostMapping("sendMsg/v2")
    public JsonResult<JwtUserDto<UserVo>> sendMsg(SendMessageBaseVO baseVO) throws Exception{
        log.info("发送短信验证码，电话{}",baseVO.getMobile());
        if ("13911229370".equals(baseVO.getMobile())) {
            return JsonResult.success();
        }
        SendMessageVO vo = new SendMessageVO();
        BeanUtil.copyProperties(baseVO,vo);
        vo.setUserIp(HttpRequestUtil.getClientIp());
        vo.setTemplateId("da38466fa2b49759284a8bb653824c53ac71b8d8");
        String verificationCode = RandomUtil.randomNumbers(6);
        vo.setTemplateParamSet(CollUtil.newArrayList(verificationCode));
        SendMsgV2Response response = messageService.sendMessageV2(vo);
        if (response!=null) {
            if ("0".equals(response.getStatusCode())) {
                if (CollectionUtil.isNotEmpty(response.getResponse())) {
                    if (CollectionUtil.isNotEmpty(response.getResponse())) {
                        if ("0".equals(response.getResponse().get(0).getCode())) {
                            redisService.set(RedisKeyFactory.getVerificationCodeKey(response.getResponse().get(0).getMobile()), verificationCode, 5*60L);
                            return JsonResult.success();
                        } else {
                            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),response.getResponse().get(0).getMessage());
                        }
                    }
                }
            }
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),response.getMessage());
        }
        return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"短信发送失败");
    }

    @ApiOperation("修改用户信息")
    @PostMapping("userInfo")
    @ApiOperationSupport(includeParameters = {"nickname","avatar"})
    public JsonResult<JwtUserDto<UserVo>> userInfo(@Validated @Length(max = 10,message = "昵称长度不能超过10个字符") String nickname, String avatar,HttpServletRequest request){
        log.info("用户修改信息，昵称{},头像{}",nickname,avatar);
        if(StrUtil.isBlank(nickname) && StrUtil.isBlank(avatar)){
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"昵称和头像不能为空");
        }

        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        NftUser user = userService.getById(currentUser.getUserId());
        String from = request.getHeader("from");
        //更新用户信息
        UserVo userDetails = currentUser.getUserDetails();

        Integer status = (Integer) redisService.get(RedisKeyFactory.getGlobalInhibitKey());
        if (status!=null && status==1) {
            if (!"wx".equals(from)) {
                return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"系统禁止修改用户信息");
            }
        }

        if (user.getModifyInhibit()!=null && user.getModifyInhibit()==1) {
            if (!"wx".equals(from)) {
                return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"系统禁止修改用户信息");
            }
        }

        if (StrUtil.isNotBlank(nickname)) {
            boolean flag = false;
            if (!"wx".equals(from)) {
                flag = SensitiveUtil.containsSensitive(nickname);
            }
            if (flag) {
                return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"昵称包含敏感词");
            }
            userDetails.setNickName(nickname);
            user.setNickName(nickname);
        }

        if (StrUtil.isNotBlank(avatar)) {
            userDetails.setAvatar(avatar);
            user.setAvatar(avatar);
        }

        userService.updateById(user);
        JwtUserDto<UserVo> jwtUserDto = onlineUserService.updateUser(currentUser);
        return JsonResult.success(jwtUserDto);
    }

    @GetMapping("/cancellation")
    @ApiOperation("用户注销")
    public JsonResult<?> cancellation(){
        userService.setCancellationFlag();
        return JsonResult.success();
    }

    @AnonymousGetMapping("/password")
    @ApiOperation("密码加密")
    public JsonResult<String> password(String password){
        return JsonResult.success(passwordEncoder.encode(password));
    }

    @AnonymousPostMapping("/register")
    @ApiOperation("用户注册")
    public JsonResult<JwtUserDto<UserVo>> register(@Validated RegisterVO vo) {
        log.info("用户注册，电话号码：{} 验证码：{} 邀请码：{}",vo.getMobile(),vo.getVerificationCode(),vo.getInviteCode());
        String code = (String) redisService.get(RedisKeyFactory.getVerificationCodeKey(vo.getMobile()));
        if (StrUtil.isNotBlank(code)) {
            if (code.equals(vo.getVerificationCode())) {
                redisService.del(RedisKeyFactory.getVerificationCodeKey(vo.getMobile()));
                NftUser user = userService.findUserByMobile(vo.getMobile());
                if (user!=null) {
                    return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"该手机已注册");
                }
                if (vo.getInviteCode()!=null) {
                    NftUser inviteUser = userService.lambdaQuery()
                            .eq(NftUser::getInviteCode, vo.getInviteCode())
                            .last("limit 1")
                            .one();
                    if (inviteUser==null) {
                        return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"邀请码错误");
                    }
                }
                NftUser nftUser = userService.registerMobileUser(vo.getMobile(), vo.getInviteCode());
                //sensorsAnalyticsService.signUpEvent(nftUser.getUserId()+"",true,"", vo.getMobile());
                return authenticate(vo.getMobile(), null);
            }
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"验证码输入错误");
        } else {
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"验证码输入错误");
        }
    }
}
