package com.foundao.nft.api.service.impl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.api.mapper.MergeMapper;
import com.foundao.nft.common.model.Merge;
@Service
public class MergeService extends ServiceImpl<MergeMapper, Merge> {

}
