package com.foundao.nft.api.controller;

import com.foundao.nft.api.service.impl.NftUserService;
import com.foundao.nft.common.model.NftUser;
import com.foundao.nft.common.model.vo.CheckChainUserVO;
import com.foundao.nft.common.model.vo.UserVo;
import com.tx.core.beans.JsonResult;
import com.tx.security.bean.AuthUser;
import com.tx.security.util.SecurityUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Package: com.foundao.nft.api.controller
 * @ClassName: SocialController
 * @Author: chenli
 * @CreateTime: 2022/11/18 9:53 AM
 * @Description:
 */
@RequestMapping("/social")
@Slf4j
@RestController
@RequiredArgsConstructor
@Api(tags = "外部接口")
@Validated
public class SocialController {

    private final NftUserService userService;

    @PostMapping("/check")
    @ApiOperation("核查token")
    public JsonResult<CheckChainUserVO> check(){
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        CheckChainUserVO vo = new CheckChainUserVO();
        vo.setMobile(currentUser.getUserDetails().getMobile());
        vo.setNickname(currentUser.getUserDetails().getNickName());
        vo.setAvatarUrl(currentUser.getUserDetails().getAvatar());
        return JsonResult.success(vo);
    }

    @PostMapping("/user/chain")
    @ApiOperation("用户链")
    public JsonResult<CheckChainUserVO> userChain(){
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        CheckChainUserVO vo = new CheckChainUserVO();
        vo.setMobile(currentUser.getUserDetails().getMobile());
        vo.setNickname(currentUser.getUserDetails().getNickName());
        vo.setAvatarUrl(currentUser.getUserDetails().getAvatar());
        CheckChainUserVO modifyVO = vo;
        Integer inviteUserId = currentUser.getUserDetails().getInviteUserId();
        while (inviteUserId!=null) {
            NftUser user = userService.findUserByInviteUserId(inviteUserId);
            CheckChainUserVO parent = new CheckChainUserVO();
            parent.setMobile(user.getMobile());
            parent.setNickname(user.getNickName());
            parent.setAvatarUrl(user.getAvatar());
            modifyVO.setParent(parent);
            inviteUserId=user.getInviteUserId();
            modifyVO = parent;
        }

        return JsonResult.success(vo);
    }
}
