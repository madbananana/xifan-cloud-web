package com.foundao.nft.api.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUnit;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.conditions.query.LambdaQueryChainWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.extension.toolkit.ChainWrappers;
import com.foundao.nft.api.mapper.NftSeriesClaimMapper;
import com.foundao.nft.api.vo.NftInfoVO;
import com.foundao.nft.api.vo.ProductDetailVo;
import com.foundao.nft.api.vo.ProductListVo;
import com.foundao.nft.api.vo.SeriesPriceInfoVO;
import com.foundao.nft.common.constant.NftTypeMetaIdEnum;
import com.foundao.nft.common.model.Issuer;
import com.foundao.nft.common.model.NftMetadata;
import com.foundao.nft.common.model.vo.UserVo;
import com.foundao.nft.common.constant.FoundaoConstant;
import com.foundao.nft.common.model.Brand;
import com.foundao.nft.common.model.NftSeriesClaim;
import com.foundao.nft.common.util.RedisKeyFactory;
import com.foundao.nft.common.util.SortUtil;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.exception.BusException;
import com.tx.redis.annotation.FdRedisCache;
import com.tx.redis.service.RedisService;
import com.tx.security.bean.AuthUser;
import com.tx.security.util.SecurityUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.aop.framework.AopContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
@EnableAspectJAutoProxy(exposeProxy = true)
@Slf4j
public class NftSeriesClaimService extends ServiceImpl<NftSeriesClaimMapper, NftSeriesClaim> {
    @Autowired
    private NftMetadataService metadataService;
    @Autowired
    private AvatarServiceImpl avatarService;
    @Autowired
    private BrandService brandService;
    @Autowired
    private RedisService redisService;
    @Autowired
    private IssuerService issuerService;

    public NftSeriesClaim getByTaskId(String taskId){
        return ChainWrappers.lambdaQueryChain(baseMapper)
                .eq(NftSeriesClaim::getTaskId,taskId)
                .one();
    }

    /**
     * 通过系列id获取系列
     * @param id 系列id
     * @return
     */
    @FdRedisCache(expireTime = 60,key = "'series:short:'+#id")
    public NftSeriesClaim getByIdCache(String id){
        return ChainWrappers.lambdaQueryChain(baseMapper)
                .eq(NftSeriesClaim::getId,id)
                .one();
    }

    /**
     * 通过系列id获取系列
     * @param seriesId 系列id
     * @return
     */
    @FdRedisCache(expireTime = 10,key = "'series:'+#seriesId")
    public NftSeriesClaim getBySeriesId(String seriesId){
        return ChainWrappers.lambdaQueryChain(baseMapper)
                .eq(NftSeriesClaim::getSeriesId,seriesId)
                .or()
                .eq(NftSeriesClaim::getId,seriesId)
                .one();
    }

    /**
     * 系列产品信息
     * @param request 请求
     * @return
     */

    public List<ProductListVo> listSeries(BaseRequestVo request) {
        Page<ProductListVo> page = new Page<>(request.getPage(),request.getNum(),false);
        SortUtil.handlePageSort(request, page, "create_time", FoundaoConstant.ORDER_DESC, true);
        AuthUser<UserVo> currentUser = null;
        try {
            currentUser = SecurityUtil.getCurrentUser();
        }catch (Exception e) {
        }
        final String userId = currentUser==null?null:currentUser.getUserId()+"";
        boolean isWhiteUser = false;
        if (StrUtil.isNotBlank(userId)) {
            List<String> whiteList = (List<String>) redisService.get(RedisKeyFactory.getWhiteUserKey());
            if (whiteList!=null) {
                if (whiteList.contains(currentUser.getUserDetails().getMobile())) {
                    isWhiteUser = true;
                }
            }
        }

        int leadTime = (int) redisService.hget(RedisKeyFactory.getLeadTimeKey(), "leadTime");
        int adLeadTime = (int) redisService.hget(RedisKeyFactory.getLeadTimeKey(), "adLeadTime");


        IPage<ProductListVo> resultList = null;
        if(null != AopContext.currentProxy()){
            NftSeriesClaimService proxy = (NftSeriesClaimService) AopContext.currentProxy();
            resultList = proxy.pageSeries(page,request,isWhiteUser);
        }else{
            resultList = pageSeries(page,request,isWhiteUser);
        }

        resultList.getRecords().forEach(productListVo -> {
            productListVo.setLeadTime(leadTime);
            productListVo.setAdUserLeadTime(adLeadTime);
            int offsetTime = 0;

            //获取系列下面剩余nft份数
            productListVo.setAppointment(0);
            if (null != userId) {
                Integer status = (Integer) redisService.hget(RedisKeyFactory.getAppointmentKey(productListVo.getSeriesId()), userId);
                if (status!=null) {
                    productListVo.setAppointment(1);
                }
                Integer metaId = (Integer) redisService.hget(RedisKeyFactory.getCategoryMetaIdKey(), productListVo.getCategoryId() + "");
                //Boolean exist = redisService.sHasKey(RedisKeyFactory.getAboriginesKey(metaId+""),userId+"");

                Boolean exist = redisService.hHasKey(RedisKeyFactory.getStarUserIdKey(metaId), userId);

                if (exist) {
                    productListVo.setAdvancedUser(1);
                    offsetTime = adLeadTime;
                }
            }

            Date beginTime = DateUtil.offsetMinute(DateUtil.parse(productListVo.getBeginTime()),-offsetTime);
            Date date = new Date();

            //Integer showStatus = (Integer) redisService.get(RedisKeyFactory.getSeriesShowAppointCountKey(productListVo.getId()));
            //if (showStatus==null || showStatus==0) {
            //}
            if (DateUtil.compare(beginTime,date)<0) {
                productListVo.setAppointmentCount(0);
            } else {
                Integer num = (Integer) redisService.get(RedisKeyFactory.getAppointmentNumKey(productListVo.getSeriesId()));
                Integer delta = (Integer) redisService.get(RedisKeyFactory.getAppointmentDeltaKey(productListVo.getSeriesId()));
                if (num==null) {
                    num = 0;
                }
                if (delta == null) {
                    delta = 0;
                }
                productListVo.setAppointmentCount(num+delta);
            }
            setSellInfo(productListVo);

            //productListVo.setRestCount(metadataService.countRestCount(productListVo.getSeriesId()));
            if (productListVo.getMetaType()==3) {
                //查询库存
                Integer restCount = (Integer) redisService.get(RedisKeyFactory.getSeriesStockKey(productListVo.getId()));
                if (restCount==null) {
                    restCount=0;
                }
                productListVo.setRestCount(restCount);
            } else {
                productListVo.setRestCount(metadataService.countShowRestCount(productListVo.getSeriesId()));
            }
            SeriesPriceInfoVO seriesPriceInfo = null;
            if(null != AopContext.currentProxy()){
                NftSeriesClaimService proxy = (NftSeriesClaimService) AopContext.currentProxy();
                seriesPriceInfo = proxy.findSeriesPriceInfo(productListVo.getSeriesId());
            }else{
                seriesPriceInfo = findSeriesPriceInfo(productListVo.getSeriesId());
            }
            productListVo.setPriceInfoVO(seriesPriceInfo);
        });
        return  resultList.getRecords();
    }

    @FdRedisCache(expireTime = 3,key = "'listSeries:'+#request.page+'-'+#request.num+'-'+#isWhiteUser")
    public IPage<ProductListVo> pageSeries(IPage<?> page, BaseRequestVo request, Boolean isWhiteUser){
        return baseMapper.pageSeries(page,request,isWhiteUser);
    }

    /**
     * 系列详情信息
     * @param seriesId 系列id
     * @param userId 用户id
     * @return 系列详情vo
     */
    public ProductDetailVo seriesDetail(String seriesId,Integer userId){
        ProductDetailVo productDetailVo = new ProductDetailVo();
        //获取系列信息
        NftSeriesClaim seriesClaim ;
        if(null != AopContext.currentProxy()){
            NftSeriesClaimService proxy = (NftSeriesClaimService) AopContext.currentProxy();
            seriesClaim = proxy.getBySeriesId(seriesId);
        }else{
            seriesClaim = getBySeriesId(seriesId);
        }
        //NftSeriesClaim seriesClaim = getBySeriesId(seriesId);
        if(seriesClaim == null){
            throw new BusException("产品信息未知");
        }
        int leadTime = (int) redisService.hget(RedisKeyFactory.getLeadTimeKey(), "leadTime");
        int adLeadTime = (int) redisService.hget(RedisKeyFactory.getLeadTimeKey(), "adLeadTime");
        int offsetTime = 0;
        productDetailVo.setLeadTime(leadTime);
        productDetailVo.setAdUserLeadTime(adLeadTime);
        //初始化基本信息
        BeanUtil.copyProperties(seriesClaim,productDetailVo);
        //设置出售信息
        setSellInfo(productDetailVo);
        //普通作品
        if(seriesClaim.getMetaType() == 1 || seriesClaim.getMetaType() == 3){
            //设置剩余份数,通过计算nft作品的剩余发售数
            //获取系列下面的发行的作品,目前就取第一个
            //NftInfoVO nftInfoVO = metadataService.firstNftOfSeries(seriesId,userId);
            //if(nftInfoVO == null){
            //    nftInfoVO = new NftInfoVO();
            //}
            productDetailVo.setAppointment(0);
            if (userId!=null) {
                Integer status = (Integer) redisService.hget(RedisKeyFactory.getAppointmentKey(seriesClaim.getSeriesId()), userId + "");
                if (status!=null) {
                    productDetailVo.setAppointment(1);
                }
                Integer metaId = (Integer) redisService.hget(RedisKeyFactory.getCategoryMetaIdKey(), productDetailVo.getCategoryId() + "");
                //Boolean exist = redisService.sHasKey(RedisKeyFactory.getAboriginesKey(metaId+""),userId+"");
                Boolean exist = redisService.hHasKey(RedisKeyFactory.getStarUserIdKey(metaId), userId+"");
                if (exist) {
                    productDetailVo.setAdvancedUser(1);
                    offsetTime = adLeadTime;
                }
            }
            boolean isBlindBox = seriesClaim.getMetaType() == 3;

            List<NftInfoVO> list = metadataService.listNftOfSeries(seriesId,userId,seriesClaim,isBlindBox);
            //productDetailVo.setRestCount(metadataService.countRestCount(seriesId));
            if (isBlindBox) {
                //查询库存
                Integer num = (Integer) redisService.get(RedisKeyFactory.getSeriesStockKey(seriesClaim.getId()));
                if (num==null) {
                    num=0;
                }
                productDetailVo.setRestCount(num);
            } else {
                productDetailVo.setRestCount(metadataService.countShowRestCount(seriesId));
            }
            productDetailVo.setNfts(list);
            Integer count = metadataService.lambdaQuery()
                    .eq(NftMetadata::getSeriesId, seriesClaim.getSeriesId())
                    .eq(NftMetadata::getShowStatus, 1)
                    .eq(NftMetadata::getTaskStatus, 7)
                    .count();
            productDetailVo.setNftCount(count);
        }else{
            //设置剩余份数，牛头比较特殊，直接获取头像的分数
            Integer restCount = avatarService.restAvatarWaitLottery(null);
            productDetailVo.setRestCount(restCount);
        }
        Brand brand = brandService.getById(seriesClaim.getBrandId());
        if (brand!=null) {
            productDetailVo.setBrandName(brand.getBrandName());
            productDetailVo.setBrandIcon(brand.getBrandIcon());
        }
        Issuer issuer = issuerService.getById(seriesClaim.getIssuerId());
        if (brand!=null) {
            productDetailVo.setIssuerName(issuer.getIssuerName());
            productDetailVo.setIssuerIcon(issuer.getIssuerIcon());
        }

        SeriesPriceInfoVO seriesPriceInfo = null;
        if(null != AopContext.currentProxy()){
            NftSeriesClaimService proxy = (NftSeriesClaimService) AopContext.currentProxy();
            seriesPriceInfo = proxy.findSeriesPriceInfo(productDetailVo.getSeriesId());
        }else{
            seriesPriceInfo = findSeriesPriceInfo(productDetailVo.getSeriesId());
        }
        productDetailVo.setPriceInfoVO(seriesPriceInfo);

        Date beginTime = DateUtil.offsetMinute(DateUtil.parse(productDetailVo.getBeginTime()),-offsetTime);
        Date date = new Date();

        Integer status = (Integer) redisService.get(RedisKeyFactory.getSeriesShowAppointCountKey(seriesClaim.getId()));
        if (status==null || status==0) {
            if (DateUtil.compare(beginTime,date)<0) {
                productDetailVo.setAppointmentCount(0);
            } else {
                Integer num = (Integer) redisService.get(RedisKeyFactory.getAppointmentNumKey(productDetailVo.getSeriesId()));
                Integer delta = (Integer) redisService.get(RedisKeyFactory.getAppointmentDeltaKey(seriesClaim.getSeriesId()));
                if (num==null) {
                    num = 0;
                }
                if (delta == null) {
                    delta = 0;
                }
                productDetailVo.setAppointmentCount(num+delta);
            }
        }

        return productDetailVo;
    }

    /**
     * 给系列配置开售信息
     * @param productVo 系列信息
     */
    private void setSellInfo(ProductListVo productVo){
        String beginTime = productVo.getBeginTime();
        DateTime beginDateTime = DateUtil.parse(beginTime);
        DateTime nowDateTime = new DateTime();
        if(beginDateTime.isAfter(nowDateTime)){
            productVo.setSell(false);
            long diffSecond = DateUtil.between(beginDateTime, nowDateTime, DateUnit.SECOND);
            productVo.setRestSellTime((int) diffSecond);
        }else{
            productVo.setSell(true);
            productVo.setRestSellTime(0);
        }

        productVo.setServerCurTime(DateUtil.now());

    }


    @FdRedisCache(expireTime = 6000,key = "'priceInfo:'+#seriesId")
    public SeriesPriceInfoVO findSeriesPriceInfo(String seriesId){
        List<NftMetadata> list = ChainWrappers.lambdaQueryChain(metadataService.getBaseMapper())
                .select(NftMetadata::getSellFee, NftMetadata::getNftId)
                .eq(NftMetadata::getShowStatus,1)
                .eq(NftMetadata::getTaskStatus,7)
                .eq(NftMetadata::getSeriesId,seriesId)
                .orderByAsc(NftMetadata::getSellFee)
                .list();
        SeriesPriceInfoVO priceInfoVO = new SeriesPriceInfoVO();
        priceInfoVO.setMinPrice(0);
        priceInfoVO.setMaxPrice(0);
        if (list!=null ) {
            if (list.size()==1) {
                NftMetadata metadata = list.get(0);
                priceInfoVO.setMinPrice(metadata.getSellFee());
                priceInfoVO.setMaxPrice(metadata.getSellFee());
                priceInfoVO.setSingleton(true);
                priceInfoVO.setNftId(metadata.getNftId());
            } else if (list.size()>1) {
                priceInfoVO.setMinPrice(list.get(0).getSellFee());
                priceInfoVO.setMaxPrice(list.get(list.size()-1).getSellFee());
                priceInfoVO.setSingleton(false);
            }
        }
        return priceInfoVO;
    }

}
