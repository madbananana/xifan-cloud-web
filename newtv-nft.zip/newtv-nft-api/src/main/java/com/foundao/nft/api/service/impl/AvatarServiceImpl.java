package com.foundao.nft.api.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.RandomUtil;
import com.alibaba.fastjson.JSON;
import com.foundao.nft.api.mapper.AvatarFullMapper;
import com.foundao.nft.api.mapper.AvatarPartMapper;
import com.foundao.nft.common.model.*;
import com.foundao.nft.common.model.vo.AvatarVo;
import com.foundao.nft.common.model.vo.UserVo;
import com.foundao.nft.common.properties.CustomProperties;
import com.foundao.nft.common.util.RedisKeyFactory;
import com.tx.core.exception.BusException;
import com.tx.redis.service.RedisLockService;
import com.tx.security.bean.AuthUser;
import com.tx.security.util.SecurityUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class AvatarServiceImpl  {
    private final AvatarFullMapper avatarFullMapper;
    private final AvatarPartMapper avatarPartMapper;
    private final RedisLockService redisLockService;
    private final CustomProperties customProperties;


    public AvatarFull getAvatarFullById(Integer id){
        return avatarFullMapper.selectById(id);
    }


    public AvatarPart getAvatarPartById(Integer id){
        return avatarPartMapper.selectById(id);
    }

    public AvatarVo lotteryPartInfo(Long id){
        if(id == null || id <= 0 ){
            return null;
        }
        AvatarPart selectAvatarPart = avatarPartMapper.selectById(id);
        //获取状态
        List<AvatarFull> avatarFullList = avatarFullMapper.listAvatarFullByAvatarPartId(id.intValue());
        avatarFullList.forEach(avatarFull -> {
            if (avatarFull.getSpecialType()==2) {
                return ;
            }
            //获取背景图片
            List<Integer> partIds = JSON.parseArray(avatarFull.getParts(), Integer.class);
            AvatarPart avatarPartById = getAvatarPartById(partIds.get(5));
            avatarFull.setBackendGroundUrl(avatarPartById.getUrl());
            if (partIds.size()>6) {
                AvatarPart fullBackendGround = getAvatarPartById(partIds.get(6));
                avatarFull.setFullBackendGroundUrl(fullBackendGround.getUrl());
            }
        });
        //获取头像的部件和背景
        AvatarFull avatarFull = avatarFullList.get(0);
        String parts = avatarFull.getParts();
        List<Integer> partIds = JSON.parseArray(parts, Integer.class);
        List<AvatarPart> avatarParts = CollUtil.newArrayList();
        for (Integer partId : partIds) {
            AvatarPart avatarPart = avatarPartMapper.selectById(partId);
            if(avatarPart != null){
                if(avatarPart.getPartType() == 1 || avatarPart.getPartType() == 7){
                    continue;
                }
                avatarParts.add(avatarPart);
            }
        }
        AvatarVo avatarVo = new AvatarVo();
        avatarVo.setId(selectAvatarPart.getPartId());
        avatarVo.setUrl(selectAvatarPart.getUrl());
        avatarVo.setPartsList(avatarParts);
        avatarVo.setFullAvatarList(avatarFullList);
        if (avatarFull.getSpecialType()==2||avatarFull.getSpecialType()==3) {
            avatarVo.setSpecialAvatar(true);
        }
        return avatarVo;
    }

    /**
     * 还有多少头像可以抽取
     * @return
     */
    public Integer restAvatarWaitLottery(Boolean isSpecialType ){
        Integer specialType = null;
        if(isSpecialType != null){
            specialType =  isSpecialType ? 1 : 0;
        }
        List<Long> avatarPartIdList = avatarPartMapper.listCanLotteryAvatarIdList(specialType);
        return avatarPartIdList.size();
    }

    /**
     * 用户锁定头像
     * @return
     */
    public Long lockAvatar(Integer userId, boolean isSpecialType){
        //先简单的加全局锁处理，后续如果有性能问题，需要优化，建议优化放在内存中抽取
        String simpleLotteryLock = RedisKeyFactory.getSimpleLotteryLock();
        boolean lockSuccess = redisLockService.tryLock(simpleLotteryLock,10);
        if(lockSuccess){
            Long id ;
            try{
                AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
                String mobile = currentUser.getUserDetails().getMobile();
                AvatarPart userLockAvatarPart = avatarPartMapper.getUserLockAvatarPart(userId);
                if (userLockAvatarPart!=null) {
                    return Long.valueOf(userLockAvatarPart.getPartId());
                }
                List<Long> avatarPartIdList = null;
                String sourceFileName = null;
                if (customProperties.getExclusiveAvatars()!=null) {
                    sourceFileName = customProperties.getExclusiveAvatars().get(mobile);
                }
                if (sourceFileName!=null) {
                    avatarPartIdList = avatarPartMapper.listCanLotteryAvatarIdListBySourceFileName(sourceFileName);
                } else {
                    avatarPartIdList = avatarPartMapper.listCanLotteryAvatarIdList(isSpecialType ? 1 : 0);
                }
                if(avatarPartIdList.size() == 0 ){
                    //抽完了
                    return 0L;
                }
                //随机取其中一个数
                int index = RandomUtil.randomInt(0,avatarPartIdList.size());
                id = avatarPartIdList.get(index);
                //更新并获取状态
                AvatarPart avatarPart = new AvatarPart();
                avatarPart.setPartId(id.intValue());
                avatarPart.setStatus(1);
                avatarPart.setLockUserId(userId);
                avatarPartMapper.updateById(avatarPart);
            }finally {
                redisLockService.unlock(simpleLotteryLock);
            }
            return id;
        }else{
            throw new BusException("系统繁忙，请稍后再试");
        }

    }

    /**
     * 获取用户领取的头像信息
     * @return
     */
    public AvatarPart getUserLockAvatarPart(Integer userId){
        AvatarPart userLockAvatarPart = avatarPartMapper.getUserLockAvatarPart(userId);
        return userLockAvatarPart;
    }
    /**
     * 用户抽取头像
     * @param isSpecialType 是否十年老员工
     * @return
     */
    public AvatarVo lottery(Integer userId, boolean isSpecialType){
        //1.首先判断用户是否已经在抽奖阶段，如果是在抽奖阶段，直接返回当前所在抽信息
        AvatarPart userLockAvatarPart = avatarPartMapper.getUserLockAvatarPart(userId);
        if(userLockAvatarPart != null){
            if(userLockAvatarPart.getStatus() == 1){
                return lotteryPartInfo(userLockAvatarPart.getPartId().longValue());
            }else if(userLockAvatarPart.getStatus() == 2){
                throw new BusException("您已经参与过头像领取，请不要重复参与");
            }
        }
        return lotteryPartInfo(lockAvatar(userId, isSpecialType));
    }

    /**
     * 释放头像到奖池，主要针对购买失败的情况
     * @param id 头像id
     * @param nftId nftid
     */
    public void releaseAvatarToLotteryPool(Integer id ,String nftId){
        AvatarPart avatarPart = new AvatarPart();
        avatarPart.setPartId(id);
        avatarPart.setStatus(0);
        avatarPart.setLockUserId(0);
        avatarPartMapper.updateById(avatarPart);
    }

    public void consumeLotteryPool(Integer id){
        AvatarPart avatarPart = new AvatarPart();
        avatarPart.setPartId(id);
        avatarPart.setStatus(2);
        avatarPartMapper.updateById(avatarPart);
    }

    @Transactional(rollbackFor = Exception.class)
    public void releaseFullAvatarToLotteryPool(Integer fullAvatarId) {
        AvatarFull avatarFull = new AvatarFull();
        avatarFull.setId(fullAvatarId);
        avatarFull.setStatus(0);
        avatarFull.setLockUserId(0);
        avatarFullMapper.updateById(avatarFull);
    }
}
