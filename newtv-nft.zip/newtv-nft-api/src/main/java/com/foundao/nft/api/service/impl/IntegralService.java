package com.foundao.nft.api.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.common.constant.IntegralTypeEnum;
import com.foundao.nft.common.model.IntegralRecord;
import com.foundao.nft.common.model.NftMetadata;
import com.foundao.nft.common.model.vo.UserVo;
import com.foundao.nft.common.util.RedisKeyFactory;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.exception.BusException;
import com.tx.core.util.RedisLuaScriptUtil;
import com.tx.redis.service.RedisService;
import com.tx.security.bean.AuthUser;
import com.tx.security.util.SecurityUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.script.DefaultRedisScript;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.api.mapper.IntegralMapper;
import com.foundao.nft.common.model.Integral;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional
@Slf4j
public class IntegralService extends ServiceImpl<IntegralMapper, Integral> {

    private final IntegralRecordService integralRecordService;
    private final RedisService redisService;
    private final RedisTemplate<String,Object> redisTemplate;

    /**
     * 给用户增加或减少积分
     * @param userId 用户
     * @param sourceId 资源id
     * @param sourceType 类型
     */
    public void integralOperation(Integer userId,String sourceId,String sourceType,String symbol,Integer count,String remark,String txTime){
        if (userId!=null) {
            Integer insertCount = integralRecordService.lambdaQuery()
                    .eq(IntegralRecord::getUserId, userId)
                    .eq(IntegralRecord::getSourceId, sourceId)
                    .eq(IntegralRecord::getSourceType, sourceType)
                    .eq(IntegralRecord::getSymbol, symbol)
                    .count();
            if (insertCount>0) {
                return;
            }

            Integral integralModel = getById(userId);
            if (integralModel==null) {
                integralModel = new Integral();
                integralModel.setUserId(userId);
                integralModel.setFrozenIntegral(0);
                integralModel.setUsableIntegral(0);
            }
            if (IntegralTypeEnum.BUY_NFT.getType().equals(sourceType)) {
                if (integralModel.getFrozenIntegral()>=count) {
                    integralModel.setFrozenIntegral(integralModel.getFrozenIntegral()-count);
                } else {
                    log.error("{}积分购买NFT，冻结积分不足",userId);
                }
            } else {
                count = (Integer) redisService.hget(RedisKeyFactory.getIntegralKey(), sourceType);
                if (count!=null && count>0) {
                    if ("in".equals(symbol)) {

                        if (IntegralTypeEnum.INVITE_REAL_NAME_AUTH.getType().equals(sourceType)) {
                            //当前用户投票数记录
                            String todayGainIntegralKey = RedisKeyFactory.inviteGainIntegralKey(userId);
                            Integer todayGainIntegral = (Integer)redisService.get(todayGainIntegralKey);
                            todayGainIntegral = todayGainIntegral == null ? 0 : todayGainIntegral;
                            Integer limitCount = (Integer) redisService.hget(RedisKeyFactory.getIntegralKey(), "gainLimit");
                            limitCount = limitCount == null ? 20 : limitCount;
                            if(todayGainIntegral >= limitCount){
                                //剩余投票数量
                                count = 0;
                            } else {
                                int restGainIntegral = limitCount-todayGainIntegral;
                                if (restGainIntegral<count) {
                                    count = restGainIntegral;
                                }
                            }
                            //每天限制获取多少积分，通过lua脚本执行
                            long currentDayRestTime = (DateUtil.endOfDay(new Date()).getTime() - System.currentTimeMillis()) / 1000;
                            DefaultRedisScript<Long> todayGainIntegralLuaScript = new DefaultRedisScript<>();
                            todayGainIntegralLuaScript.setScriptSource(RedisLuaScriptUtil.getScriptSourceByScriptName("integral"));
                            todayGainIntegralLuaScript.setResultType(Long.class);
                            redisTemplate.execute(todayGainIntegralLuaScript, CollUtil.newArrayList(todayGainIntegralKey), currentDayRestTime,count);
                        }

                        integralModel.setUsableIntegral(integralModel.getUsableIntegral()+count);
                    }else if ("out".equals(symbol)) {
                        integralModel.setUsableIntegral(integralModel.getUsableIntegral()-count);
                    }
                }
            }
            if (count!=null) {
                IntegralRecord integralRecord = new IntegralRecord();
                integralRecord.setUserId(userId);
                integralRecord.setSourceId(sourceId);
                integralRecord.setSourceType(sourceType);
                integralRecord.setSymbol(symbol);
                integralRecord.setIntegral(count);
                integralRecord.setRemark(remark);
                integralRecord.setRestUsableIntegral(integralModel.getUsableIntegral());
                integralRecord.setCreateTime(txTime);
                integralRecordService.save(integralRecord);
            }
            saveOrUpdate(integralModel);
        }

    }

    /**
     * 冻结用户积分
     * @param userId 用户id
     * @param integral 冻结积分数
     */
    public boolean frozen(Integer userId,Integer integral){
        Integral integralModel = getById(userId);
        if (integralModel!=null && integralModel.getUsableIntegral()>=integral) {
            integralModel.setFrozenIntegral(integralModel.getFrozenIntegral()+integral);
            integralModel.setUsableIntegral(integralModel.getUsableIntegral()-integral);
            return updateById(integralModel);
        } else {
            throw new BusException("积分扣除异常");
        }
    }

    /**
     * 解冻用户积分
     * @param userId 用户id
     * @param integral 冻结积分数
     */
    public boolean unfrozen(Integer userId,Integer integral){
        Integral integralModel = getById(userId);
        if (integralModel!=null && integralModel.getFrozenIntegral()>integral) {
            integralModel.setFrozenIntegral(integralModel.getFrozenIntegral()-integral);
            integralModel.setUsableIntegral(integralModel.getUsableIntegral()+integral);
            return updateById(integralModel);
        } else {
            log.error("用户 {} 释放 {} 积分失败",userId,integral);
            throw new BusException("积分扣除异常");
        }
    }
}
