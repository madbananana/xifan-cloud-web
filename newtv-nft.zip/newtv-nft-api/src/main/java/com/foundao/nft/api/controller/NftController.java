package com.foundao.nft.api.controller;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.foundao.nft.api.dto.PosterQrCodeDto;
import com.foundao.nft.api.service.impl.*;
import com.foundao.nft.api.vo.AppointmentResponseVO;
import com.foundao.nft.api.vo.NftInfoVO;
import com.foundao.nft.api.vo.ProductDetailVo;
import com.foundao.nft.api.vo.ProductListVo;
import com.foundao.nft.api.vo.TransferConfirmVO;
import com.foundao.nft.common.constant.RabbitmqConst;
import com.foundao.nft.common.model.*;
import com.foundao.nft.common.model.mq.SendMessageMqDto;
import com.foundao.nft.common.model.vo.UserVo;
import com.foundao.nft.common.constant.NftErrorEnum;
import com.foundao.nft.common.model.sdk.client.NftService;
import com.foundao.nft.common.model.sdk.response.NftTaskResultResponse;
import com.foundao.nft.common.model.sdk.response.SdkResponseBase;
import com.foundao.nft.common.model.vo.NftTransferVO;
import com.foundao.nft.common.properties.WeChatProperties;
import com.foundao.nft.common.util.RedisKeyFactory;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.JsonResult;
import com.tx.core.enums.errcode.ApiStatusErrorEnum;
import com.tx.core.enums.errcode.ParamErrorEnum;
import com.tx.redis.service.RedisService;
import com.tx.security.annotation.AnonymousGetMapping;
import com.tx.security.annotation.AnonymousPostMapping;
import com.tx.security.bean.AuthUser;
import com.tx.security.util.SecurityUtil;
import com.tx.third.weixin.WeiXinSdk;
import com.tx.third.weixin.dto.QrCodeDto;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotBlank;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * @Package: com.foundao.nft.api.controller
 * @ClassName: NftController
 * @Author: chenli
 * @CreateTime: 2021/12/9 3:41 下午
 * @Description:
 */
@RestController
@RequiredArgsConstructor
@Api(tags = "nft通用")
@RequestMapping("nft")
@Slf4j
@Validated
public class NftController {

    @Autowired
    private NftUserPlatformService userPlatformService;
    @Autowired
    private NftSeriesClaimService seriesClaimService;
    @Autowired
    private NftMetadataService metadataService;
    @Autowired
    private NftService nftService;
    @Autowired
    private NftTaskService taskService;
    @Autowired
    private NftRecordService recordService;
    @Autowired
    private StringRedisTemplate stringRedisTemplate;
    @Autowired
    private WeChatProperties weChatProperties;
    @Autowired
    private RedisService redisService;
    @Autowired
    private AdvanceBuyService advanceBuyService;
    @Autowired
    private RabbitTemplate rabbitTemplate;
    @Autowired
    private PasswordEncoder passwordEncoder;
    @Autowired
    private NftUserService userService;

    @ApiOperation("根据地址查询用户信息")
    @GetMapping("queryByAddr")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "addr",required = true,value = "钱包地址"),
            @ApiImplicitParam(name = "mobile",required = true,value = "手机号")
    })
    public JsonResult<?> queryByAddr(String addr,String mobile) {
        if (StrUtil.isBlank(addr) && StrUtil.isBlank(mobile)) {
            return JsonResult.error(HttpStatus.INTERNAL_SERVER_ERROR.value(),"地址和手机号不能同时为空");
        }
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        if (StrUtil.equalsIgnoreCase(addr,currentUser.getUserDetails().getAddr())) {
            return JsonResult.error(HttpStatus.INTERNAL_SERVER_ERROR.value(),"不能转赠给自己");
        }
        NftUserPlatform userPlatform = null;
        if (StrUtil.isNotBlank(mobile)) {
            userPlatform = userPlatformService.getByMobile(mobile);
        } else {
            userPlatform = userPlatformService.getByAddr(addr);
        }
        if (userPlatform == null) {
            if (mobile!=null) {
                return JsonResult.error(HttpStatus.INTERNAL_SERVER_ERROR.value(),"请再次确认对方手机号是否正确");
            } else {
                return JsonResult.error(HttpStatus.INTERNAL_SERVER_ERROR.value(),"请再次确认对方钱包地址是否正确");
            }
        }
        NftUser user = userService.getById(userPlatform.getUserId());
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("nickname",StrUtil.isBlank(user.getNickName())?user.getUserName():user.getNickName());
        jsonObject.put("addr",userPlatform.getAddr());
        return JsonResult.success(jsonObject);
    }

    @ApiOperation("转赠接收或拒绝")
    @PostMapping("transfer/confirm")
    public JsonResult<Void> transferConfirm(@Validated TransferConfirmVO confirm) {
        return recordService.transferConfirm(confirm);
    }

    @ApiOperation("nft转赠")
    @PostMapping("transfer")
    public JsonResult<?> transfer(@Validated NftTransferVO transfer){
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        if (StrUtil.equalsIgnoreCase(transfer.getReceiverAddr(),currentUser.getUserDetails().getAddr())) {
            return JsonResult.error(HttpStatus.INTERNAL_SERVER_ERROR.value(),"不能转赠给自己");
        }
        NftUserPlatform userPlatform = userPlatformService.getById(currentUser.getUserId());
        if (userPlatform == null) {
            return JsonResult.error(HttpStatus.INTERNAL_SERVER_ERROR.value(),"用户未进行实名");
        }
        if (userPlatform.getTradePass() == null) {
            return JsonResult.error(HttpStatus.INTERNAL_SERVER_ERROR.value(),"用户未设置转赠密码，请先设置转赠密码");
        }
        if (!passwordEncoder.matches(transfer.getTradePass(), userPlatform.getTradePass())) {
            return JsonResult.error(HttpStatus.INTERNAL_SERVER_ERROR.value(),"转赠密码错误");
        }
        NftUserPlatform receiver = userPlatformService.getByAddr(transfer.getReceiverAddr());
        if(receiver == null){
            return JsonResult.error(HttpStatus.INTERNAL_SERVER_ERROR.value(),"该钱包地址不存在");
        }

        return recordService.transfer(transfer.getActualNftId(),currentUser.getUserId(),receiver.getUserId());

        //NftRecord record = recordService.getRecordByNftIdAndUserId(transfer.getActualNftId(),currentUser.getUserId().intValue());
        //if (record==null) {
        //    return JsonResult.error(HttpStatus.INTERNAL_SERVER_ERROR.value(),"该NFT不存在");
        //}
        //Map<String,String> res = new HashMap<>(2);
        //
        //NftTransferRequest request = new NftTransferRequest();
        //request.setNftId(transfer.getActualNftId());
        //request.setOperateId(IdUtil.objectId());
        //request.setReceiverAddr(receiver.getAddr());
        //request.setPubKey(userPlatform.getPubkey());
        //
        //String str = "{}_{}_{}_{}_{}";
        //String signData = StrUtil.format(str,userPlatform.getPubkey(), receiver.getAddr(),"nft_transfer"
        //        , request.getNftId(), request.getOperateId());
        //SignByPriKeyResponse userSignResponse = nftCommonUtil.signByPriKey(userPlatform.getPrikey(), signData);
        //request.setSignature(userSignResponse.getSignedData());
        //SdkResponseBase<TaskResponse> taskResponse = nftService.nftTransfer(request);
        //if (taskResponse.getRetCode()==0) {
        //    res.put("taskId",taskResponse.getData().getTaskId());
        //    Map<String,Object> extData = new HashMap<>();
        //    extData.put("nftId",transfer.getActualNftId());
        //    extData.put("recordId",record.getId());
        //    extData.put("transferUserId",currentUser.getUserId());
        //    extData.put("receiveUserId",receiver.getUserId());
        //
        //    NftTask task = new NftTask();
        //    task.setStatus(2);
        //    task.setType(TaskEnum.NFT_TRANSFER.getCode());
        //    task.setOperateId(request.getOperateId());
        //    task.setTaskId(taskResponse.getData().getTaskId());
        //    task.setExtend1(record.getId());
        //    task.setExtend2(receiver.getUserId()+"");
        //    task.setExtend3(JSON.toJSONString(extData));
        //    taskService.save(task);
        //    return JsonResult.success(res);
        //}

    }

    @ApiOperation("查询转赠结果")
    @GetMapping("/queryTransferResult")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "taskId",required = true,value = "任务id,转赠时返回")
    })
    public JsonResult<NftTaskResultResponse> queryTransferResult(@RequestParam(name = "taskId") String taskId){
        //查询任务是否存在
        NftTask task = taskService.getTaskByTaskId(taskId);
        if(task == null){
            return JsonResult.error(ApiStatusErrorEnum.INTERNAL_ERROR.getCode(),"无效的请求");
        }
        //用户id
        JSONObject extData = JSON.parseObject(task.getExtend3());
        Integer transferUserId = extData.getInteger("transferUserId");//赠送人id
        //查询任务
        NftUserPlatform userPlatform = userPlatformService.getById(transferUserId);

        SdkResponseBase<NftTaskResultResponse> taskResult = nftService.nftTransferResult(userPlatform.getPubkey(),taskId);
        if(taskResult.getRetCode() != 0){
            return JsonResult.error(ApiStatusErrorEnum.INTERNAL_ERROR.getCode(),"赠送失败");
        }
        NftTaskResultResponse resultResponse = taskResult.getData();

        task.setStatus(resultResponse.getTaskStatus());
        task.setChainTimestamp(new Date(resultResponse.getChainTimestamp()));
        task.setTxHash(resultResponse.getTxHash());
        task.setTaskMsg(resultResponse.getTaskMsg());

        taskService.updateNftTransferTask(task);
        return JsonResult.success(resultResponse);
    }


    @ApiOperation("nft详情信息")
    @AnonymousGetMapping("/nftInfo")
    @ApiImplicitParams({
     @ApiImplicitParam(name = "nftId",value = "nftId",required = true),
     @ApiImplicitParam(name = "ownerUserId",value = "收藏者用户id,非收藏页进入为空",required = false),
     @ApiImplicitParam(name = "actualNftId",value = "真实藏品id",required = false),
    })
    public JsonResult<NftInfoVO> nftInfo(@RequestParam("nftId") String nftId,@RequestParam(value = "ownerUserId",required = false) Integer ownerUserId,String actualNftId){
        AuthUser<UserVo> currentUser = null;
        try {
            currentUser = SecurityUtil.getCurrentUser();
            return JsonResult.success(metadataService.nftInfo(nftId,currentUser.getUserDetails().getUserId(),ownerUserId,actualNftId));
        } catch (Exception e){
            log.info("用户未登录");
        }
        NftInfoVO infoVO = metadataService.nftInfo(nftId,null,ownerUserId,actualNftId);
        return JsonResult.success(infoVO);
    }


    @ApiOperation("系列详情信息")
    @AnonymousGetMapping("/seriesInfo")
    public JsonResult<ProductDetailVo> seriesInfo(@RequestParam("seriesId") String seriesId){
        AuthUser<UserVo> currentUser = null;
        try {
            if (StrUtil.isBlank(seriesId)) {
                return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"系列id不能为空");
            }
            currentUser = SecurityUtil.getCurrentUser();
            return JsonResult.success(seriesClaimService.seriesDetail(seriesId, Math.toIntExact(currentUser.getUserId())));
        } catch (Exception e){
            log.info("用户未登录");
        }
        return JsonResult.success(seriesClaimService.seriesDetail(seriesId,null));
    }

    @ApiOperation("根据系列id查询nft分页信息")
    @AnonymousGetMapping("/nftInfoBySeriesId")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "num",value = "每页数量"),
            @ApiImplicitParam(name = "page",value = "页码"),
            @ApiImplicitParam(name = "seriesId",value = "系列id"),
    })
    public JsonResult<List<NftInfoVO>> pageNftInfoBySeriesId(BaseRequestVo request,@RequestParam String seriesId){
        List<NftInfoVO> list = metadataService.pageNftInfoBySeriesId(request,seriesId);
        return JsonResult.success(list);
    }


    @ApiOperation("小程序NFT海报二维码")
    @AnonymousPostMapping("posterQrcode")
    public JsonResult<?> posterQrcode(@RequestBody PosterQrCodeDto posterQrCodeDto){
        QrCodeDto qrCodeDto  = new QrCodeDto();
        BeanUtils.copyProperties(posterQrCodeDto,qrCodeDto);
        WeiXinSdk weiXinSdk = new WeiXinSdk(weChatProperties.getAppId(), weChatProperties.getSecret(), stringRedisTemplate);
        String accessToken = weiXinSdk.getAccessToken();
        String qrCodeBase64 = weiXinSdk.createQrCodeBase64(accessToken, qrCodeDto);

        Map<String,Object> res = new HashMap<>(2);
        res.put("qrcodeBase64",qrCodeBase64);
        return JsonResult.success(res);
    }


    @ApiOperation("首页作品系列列表")
    @AnonymousGetMapping("/productList")
    @ApiOperationSupport(includeParameters = {"page"})
    public JsonResult<List<ProductListVo>> productList(BaseRequestVo requestVo){
        List<ProductListVo> productListVos = seriesClaimService.listSeries(requestVo);
        return JsonResult.success(productListVos);
    }

    @ApiOperation("预约")
    @GetMapping("/appointment")
    public JsonResult<?> appointment(String seriesId){
        AuthUser<UserVo> user = SecurityUtil.getCurrentUser();
        Date now = new Date();
        Integer status = (Integer) redisService.hget(RedisKeyFactory.getAppointmentKey(seriesId), user.getUserId() + "");
        NftSeriesClaim seriesClaim = seriesClaimService.getBySeriesId(seriesId);
        if (seriesClaim==null) {
            return JsonResult.error(NftErrorEnum.APPOINTMENT_SERIES_EXIST_ERROR);
        }
        AppointmentResponseVO vo = new AppointmentResponseVO();
        vo.setSeriesId(seriesClaim.getSeriesId());
        vo.setSeriesName(seriesClaim.getSeriesName());
        if (status!=null) {
            return JsonResult.error(NftErrorEnum.APPOINTMENT_DUPLICATE_ERROR,vo);
        }

        if (seriesClaim.getAdvanceBuy()==null || seriesClaim.getAdvanceBuy()!=1) {
            return JsonResult.error(NftErrorEnum.APPOINTMENT_NO_ERROR,vo);
        }
        DateTime startTime = DateUtil.parse(seriesClaim.getBeginTime());
        DateTime endTime = DateUtil.parse(seriesClaim.getEndTime());
        if (endTime.compareTo(now)<0) {
            return JsonResult.error(NftErrorEnum.APPOINTMENT_START_ERROR.getCode(),"系列已停售，不能进行预约",vo);
        }
        if (startTime.compareTo(now)<0) {
            return JsonResult.error(NftErrorEnum.APPOINTMENT_START_ERROR,vo);
        }

        long expire = startTime.getTime() - now.getTime();
        Integer appointmentOffset = 0;
        Integer leadTime = (Integer) redisService.hget(RedisKeyFactory.getLeadTimeKey(), "leadTime");
        if(leadTime!=null) {
            appointmentOffset += leadTime;
        }
        Integer adLeadTime = (Integer) redisService.hget(RedisKeyFactory.getLeadTimeKey(), "adLeadTime");
        //if(adLeadTime!=null) {
        //    appointmentOffset += adLeadTime;
        //}
        if (expire < appointmentOffset*60*1000) {
            return JsonResult.error(NftErrorEnum.APPOINTMENT_TIMEOUT_ERROR,vo);
        }
        Long num = redisService.incr(RedisKeyFactory.getAppointmentNumKey(seriesId), 1L);

        Integer metaId = (Integer) redisService.hget(RedisKeyFactory.getCategoryMetaIdKey(), seriesClaim.getCategoryId() + "");
        //Boolean exist = redisService.sHasKey(RedisKeyFactory.getAboriginesKey(metaId+""),user.getUserId()+"");
        Boolean exist = redisService.hHasKey(RedisKeyFactory.getStarUserIdKey(metaId), user.getUserId()+"");
        AdvanceBuy advanceBuy = new AdvanceBuy();
        advanceBuy.setCreateTime(DateUtil.now());
        advanceBuy.setBeginTime(seriesClaim.getBeginTime());
        advanceBuy.setSeriesId(seriesId);
        advanceBuy.setUserId(user.getUserId());
        advanceBuy.setSeriesName(seriesClaim.getSeriesName());
        advanceBuy.setAppointmentNum(Math.toIntExact(num));
        advanceBuy.setNoticeStatus(0);
        advanceBuy.setAdvancedUser(exist?1:0);
        advanceBuyService.save(advanceBuy);

        redisService.setExpire(RedisKeyFactory.getAppointmentNumKey(seriesId),expire,TimeUnit.MILLISECONDS);
        redisService.hset(RedisKeyFactory.getAppointmentKey(seriesId),user.getUserId()+"",num);
        redisService.setExpire(RedisKeyFactory.getAppointmentKey(seriesId),expire, TimeUnit.MILLISECONDS);

        //sendAppointmentMessageToMq(advanceBuy,user.getUserDetails().getMobile());


        Map<String,Object> res = new HashMap<>(4);
        res.put("seriesName",seriesClaim.getSeriesName());
        res.put("beginTime",seriesClaim.getBeginTime());
        res.put("serialNum",Math.toIntExact(num));
        res.put("leadTime",leadTime);
        res.put("adLeadTime",adLeadTime);
        res.put("advancedUser",exist?1:0);

        return JsonResult.success(res);
    }

    /**
     * 发送短信通知消息到消息队列
     *
     * @param advanceBuy 预约信息
     */
    private void sendAppointmentMessageToMq(AdvanceBuy advanceBuy,String mobile) {
        SendMessageMqDto dto = new SendMessageMqDto();
        DateTime date = DateUtil.parse(advanceBuy.getBeginTime());
        dto.setRealBeginTime(DateUtil.offsetHour(date,-1));
        dto.setMobile(mobile);
        dto.setSeriesName(advanceBuy.getSeriesName());
        dto.setBeginTimeHour(DateUtil.format(dto.getRealBeginTime(),"HH:mm"));
        Date noticeTime = DateUtil.offsetMinute(dto.getRealBeginTime(),-10);
        Date now = new Date();
        long delay = noticeTime.getTime() - now.getTime();
        log.info("发送预约通知短信队列新增记录：{},通知时间：{}，延时时间：{}",dto,noticeTime,delay);
        if (delay>0) {//如果通知时间大于当前时间才进行通知
            //把此订单发送到消息队列的延迟队列中
            rabbitTemplate.convertAndSend(RabbitmqConst.CREATE_ORDER_DELAY_EXCHANGE, RabbitmqConst.APPOINTMENT_MESSAGE_DELAY_QUEUE, dto, message -> {
                message.getMessageProperties().setDelay((int) (delay));
                return message;
            });
        }
    }

}
