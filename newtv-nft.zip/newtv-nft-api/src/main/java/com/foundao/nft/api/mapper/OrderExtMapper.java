package com.foundao.nft.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.foundao.nft.common.model.OrderExt;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;


@Mapper
public interface OrderExtMapper extends BaseMapper<OrderExt> {

    @Select("select * from nft_order_ext where order_id = #{orderId}")
    OrderExt getOrderExtByOrderId(@Param("orderId") Integer orderId);

    @Select("select * from nft_order as a join nft_order_ext as b on  a.order_id=b.order_id where a.trade_no=#{tradeNo} limit 1")
    OrderExt getOrderExByOrderTradeNo(@Param("tradeNo") String tradeNo);
}
