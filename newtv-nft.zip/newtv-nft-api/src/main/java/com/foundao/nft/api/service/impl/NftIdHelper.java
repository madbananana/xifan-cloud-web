package com.foundao.nft.api.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.RandomUtil;
import com.foundao.nft.common.model.NftMetadata;
import com.foundao.nft.common.util.RedisKeyFactory;
import com.tx.redis.service.RedisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.DefaultTypedTuple;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Component
public class NftIdHelper {
    @Autowired
    private RedisTemplate<String,Object> redisTemplate;
    @Autowired
    private NftMetadataService metadataService;
    @Autowired
    private RedisService redisService;


    /**
     * nft发布完成之后需要把nftid写入有序集合
     * @param nftBeginId nft开始id
     * @param publishCount 发布数量
     */
    public void entryNftIdToZSet(String nftBeginId,int publishCount,int showCount){
        //根据个数以及开始索引生成nftId
        Set<ZSetOperations.TypedTuple<Object>> sets = new HashSet<>();
        int beginNftIndex = Integer.parseInt(nftBeginId.split("_")[1]);
        for (int i = beginNftIndex; i < beginNftIndex+showCount; i++){
            DefaultTypedTuple<Object> defaultTypedTuple = new DefaultTypedTuple<>(i, 0d);
            sets.add(defaultTypedTuple);
        }

        for (int i = beginNftIndex+showCount; i < beginNftIndex+publishCount; i++){
            DefaultTypedTuple<Object> defaultTypedTuple = new DefaultTypedTuple<>(i, -1d);
            sets.add(defaultTypedTuple);
        }
        redisTemplate.opsForZSet().add(RedisKeyFactory.getNftIdKey(nftBeginId),sets);
    }

    /**
     * 盲盒nft发布完成之后需要把nftid写入有序集合
     * @param nftBeginId nft开始id
     * @param publishCount 发布数量
     */
    public void entryNftIdToZSet(Integer shortSeriesId,String nftBeginId,int publishCount,int metaId,int showCount){
        //根据个数以及开始索引生成nftId
        Set<ZSetOperations.TypedTuple<Object>> sets = new HashSet<>();
        int beginNftIndex = Integer.parseInt(nftBeginId.split("_")[1]);
        for (int i = beginNftIndex; i < beginNftIndex+showCount; i++){
            DefaultTypedTuple<Object> defaultTypedTuple = new DefaultTypedTuple<>(metaId+"-"+i, 0d);
            sets.add(defaultTypedTuple);
        }
        for (int i = beginNftIndex+showCount; i < beginNftIndex+publishCount; i++){
            DefaultTypedTuple<Object> defaultTypedTuple = new DefaultTypedTuple<>(metaId+"-"+i, -1d);
            sets.add(defaultTypedTuple);
        }
        redisTemplate.opsForZSet().add(RedisKeyFactory.getSeriesNftIdKey(shortSeriesId+""),sets);
    }

    /**
     * 从redis中获取未被使用的nftId
     * @param nftBeginId 原始nft开始id
     * @return String 新的nft
     */
    public String popActualNftId(String nftBeginId) {
        String setKey = RedisKeyFactory.getNftIdKey(nftBeginId);
        Set<Object> sets =  redisTemplate.opsForZSet().rangeByScore(setKey, 0, 0);
        if(sets == null || sets.size() == 0){
            return null;
        }
        List<Object> lists = CollUtil.newArrayList(sets);
        int selectedIndex = RandomUtil.randomInt(0, lists.size());
        String newNftId = nftBeginId.split("_")[0]+"_"+lists.get(selectedIndex);
        redisTemplate.opsForZSet().incrementScore(setKey,lists.get(selectedIndex),10);
        return newNftId;
    }

    /**
     * 从redis中获取未被使用的nftId
     * @param shortSeriesId 系列短id
     * @param count 个数
     * @return String 新的nft
     */
    public Map<String,String> popBlindBoxActualNftId(String shortSeriesId,Integer count) {
        Map<String,String> newNftIds = new HashMap<>();
        String setKey = RedisKeyFactory.getSeriesNftIdKey(shortSeriesId);
        Set<Object> sets =  redisTemplate.opsForZSet().rangeByScore(setKey, 0, 0);
        if(sets == null || sets.size() < count){
            return null;
        }
        List<Object> lists = CollUtil.newArrayList(sets);
        for (int i=0;i<count;i++) {
            int selectedIndex = RandomUtil.randomInt(0, lists.size());
            String info = (String) lists.get(selectedIndex);
            String[] metaIdAndIndex = info.split("-");
            String metaId = metaIdAndIndex[0];
            NftMetadata metadata = metadataService.getByMetaId(metaId);
            String newNftId = metadata.getNftId().split("_")[0]+"_"+metaIdAndIndex[1];
            redisTemplate.opsForZSet().incrementScore(setKey,lists.get(selectedIndex),10);
            lists.remove(selectedIndex);
            newNftIds.put(newNftId,metaId);
        }
        return newNftIds;
    }

    /**
     * 释放nftId标记
     * @param nftBeginId nft开始id
     * @param productId2 商品id
     */
    public void releaseNftFlag(String nftBeginId,String productId2) {
        String setKey = RedisKeyFactory.getNftIdKey(nftBeginId);
        int releaseNftIndex = Integer.parseInt(productId2.split("_")[1]);
        redisTemplate.opsForZSet().incrementScore(setKey,releaseNftIndex,-10);
    }

}
