package com.foundao.nft.api.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Package: com.foundao.nft.api.vo
 * @ClassName: SeriesPriceInfoVO
 * @Author: chenli
 * @CreateTime: 2022/6/15 4:44 下午
 * @Description:
 */
@Data
@ApiModel
public class SeriesPriceInfoVO {

    @ApiModelProperty("最低价格")
    private Integer minPrice;

    @ApiModelProperty("最高价格")
    private Integer maxPrice;

    @ApiModelProperty("是否只有一个藏品")
    private boolean isSingleton;

    @ApiModelProperty("nftId")
    private String nftId;
}
