package com.foundao.nft.api.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @Package: com.foundao.nft.api.vo
 * @ClassName: ModMobileConfirmVO
 * @Author: chenli
 * @CreateTime: 2022/8/9 5:17 下午
 * @Description:
 */
@Data
@Validated
public class ModMobileConfirmVO {

    @NotBlank(message = "电话号码")
    @ApiModelProperty(value = "新电话号码",required = true)
    private String newMobile;

    @ApiModelProperty(value = "验证码",required = true)
    @NotBlank(message = "验证码")
    private String verificationCode;

    @ApiModelProperty(value = "用户姓名",required = true)
    @NotBlank(message = "用户姓名")
    private String personName;

    @ApiModelProperty(value = "证件号",required = true)
    @NotBlank(message = "证件号")
    private String idCard;

    @ApiModelProperty(value = "证件类型 1身份证2护照3港澳通行证4台胞证5外国人永居证6港澳台居民居住证7其他",required = true)
    @NotNull(message = "证件类型")
    private Integer cardType = 1;
}
