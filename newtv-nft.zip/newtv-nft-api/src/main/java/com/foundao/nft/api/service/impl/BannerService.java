package com.foundao.nft.api.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.toolkit.ChainWrappers;
import com.tx.redis.annotation.FdRedisCache;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.api.mapper.BannerMapper;
import com.foundao.nft.common.model.Banner;
/**
    @Package: com.foundao.nft.api.service.impl
    @ClassName: BannerService
    @Author: chenli
    @CreateTime: 2022/6/7 11:07 上午
    @Description:
*/
@Service
public class BannerService extends ServiceImpl<BannerMapper, Banner> {

    @FdRedisCache(expireTime = 600,key = "'banner'")
    public List<Banner> bannerList() {
        return ChainWrappers.lambdaQueryChain(baseMapper)
                .eq(Banner::getShowStatus, 1)
                .last("limit 3")
                .list();
    }
}
