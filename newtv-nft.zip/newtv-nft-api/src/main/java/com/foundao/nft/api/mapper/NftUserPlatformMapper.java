package com.foundao.nft.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.foundao.nft.common.model.NftUserPlatform;
import org.apache.ibatis.annotations.Mapper;

/**
    @Package: com.foundao.nft.cms.mapper
    @ClassName: NftUserPlatformMapper
    @Author: chenli
    @CreateTime: 2021/12/21 3:24 下午
    @Description:
*/
@Mapper
public interface NftUserPlatformMapper extends BaseMapper<NftUserPlatform> {
    NftUserPlatform getByMobile(String mobile);
}
