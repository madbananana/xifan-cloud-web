package com.foundao.nft.api.service.impl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.api.mapper.GoodsMapper;
import com.foundao.nft.common.model.Goods;
/**
    @Package: com.foundao.nft.api.service.impl
    @ClassName: GoodsService
    @Author: chenli
    @CreateTime: 2022/2/22 2:22 下午
    @Description:
*/
@Service
public class GoodsService extends ServiceImpl<GoodsMapper, Goods> {

}
