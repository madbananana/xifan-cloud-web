package com.foundao.nft.api.service.impl;

import cn.hutool.core.util.IdUtil;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.api.vo.BlindBoxGroupVO;
import com.foundao.nft.api.vo.ProductListVo;
import com.foundao.nft.common.constant.FoundaoConstant;
import com.foundao.nft.common.model.*;
import com.foundao.nft.common.model.sdk.request.NftBuyRequest;
import com.foundao.nft.common.model.vo.BlindBoxOpenVO;
import com.foundao.nft.common.model.vo.BlindBoxVO;
import com.foundao.nft.common.model.vo.UserVo;
import com.foundao.nft.common.properties.NftProperties;
import com.foundao.nft.common.util.SortUtil;
import com.tx.core.beans.BaseRequestVo;
import com.tx.security.bean.AuthUser;
import com.tx.security.util.SecurityUtil;
import lombok.RequiredArgsConstructor;
import org.aspectj.weaver.ast.Var;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.api.mapper.BlindboxRecordMapper;
import org.springframework.transaction.annotation.Transactional;

/**
    @Package: com.foundao.nft.api.service.impl
    @ClassName: BlindboxRecordService
    @Author: chenli
    @CreateTime: 2022/7/14 5:08 下午
    @Description:
*/
@Service
@Transactional
@RequiredArgsConstructor
public class BlindboxRecordService extends ServiceImpl<BlindboxRecordMapper, BlindboxRecord> {

    private final NftOrderInteractionService orderInteractionService;
    private final NftMetadataService metadataService;
    private final NftUserPlatformService userPlatformService;
    private final NftProperties nftProperties;


    public List<BlindBoxVO> listBlindBox(BaseRequestVo request, Integer status) {
        Page<BlindBoxVO> page = new Page<>(request.getPage(),request.getNum(),false);
        SortUtil.handlePageSort(request, page, "create_time", FoundaoConstant.ORDER_DESC, true);
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        List<BlindBoxVO> blindBoxs = baseMapper.listBlindBox(page, status, currentUser.getUserId());
        blindBoxs.forEach(box -> {
            if (box.getStatus()==1) {
                box.setName(metadataService.getByMetaId(box.getMetaId()+"").getName());
            }
        });
        return blindBoxs;
    }

    @Transactional(rollbackFor = Exception.class)
    public BlindBoxOpenVO open(BlindboxRecord blindboxRecord) {
        //获取nft元信息
        NftMetadata nftMetadata = metadataService.getByMetaId(blindboxRecord.getMetaId()+"");
        //获取用户认证信息
        NftUserPlatform userPlatform = userPlatformService.getById(blindboxRecord.getUserId());
        NftBuyRequest request = new NftBuyRequest();
        request.setApplyScore(nftMetadata.getSellFee());
        request.setNftId(blindboxRecord.getActualNftId());
        request.setOfferCount(nftMetadata.getSellFee());
        request.setOperateId(IdUtil.fastUUID());
        request.setPointReceiverAddr(userPlatform.getAddr());
        request.setReceiverPubKey(userPlatform.getPubkey());
        request.setPlatformPubKey(nftProperties.getPubKey());

        NftTask.NftBuyExtInfo extData = new NftTask.NftBuyExtInfo();
//            extData.setNftId(request.getNftId());//nft开始id
        extData.setNftId(blindboxRecord.getActualNftId());
        extData.setMetaId(nftMetadata.getMetaId());
        extData.setMetaType(nftMetadata.getMetaType());
        extData.setUserId(blindboxRecord.getUserId());
        extData.setOrderId(blindboxRecord.getOrderId());

        NftTask task = orderInteractionService.doBuyNft(request, userPlatform.getPrikey(), extData);
        if (task == null || task.getTaskId()==null) {
            log.error("内部购买nft失败:"+blindboxRecord);
            return null;
        } else {
            blindboxRecord.setStatus(1);
            updateById(blindboxRecord);
            BlindBoxOpenVO vo = new BlindBoxOpenVO();
            vo.setBoxId(blindboxRecord.getBoxId());
            vo.setMetaId(blindboxRecord.getMetaId());
            vo.setName(nftMetadata.getName());
            vo.setUrl(nftMetadata.getUrl());
            vo.setDisplayUrl(nftMetadata.getDisplayUrl());
            return vo;
        }
    }

    public List<BlindBoxGroupVO> listBlindGroupBySeriesId(BaseRequestVo request, Integer status) {
        Page<BlindBoxGroupVO> page = new Page<>(request.getPage(),request.getNum(),false);
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        List<BlindBoxGroupVO> blindBoxs = baseMapper.listBlindGroupBySeriesId(page, status, currentUser.getUserId());
        blindBoxs.forEach(box -> {
            List<BlindBoxVO> list = baseMapper.selectBySeriesId(box.getShortSeriesId(),currentUser.getUserId());
            box.setBoxs(list);
        });
        return blindBoxs;
    }
}
