package com.foundao.nft.api.service.impl;

import com.foundao.nft.common.model.vo.RecipeMaterialVO;
import com.tx.redis.annotation.FdRedisCache;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.common.model.RecipeMaterial;
import com.foundao.nft.api.mapper.RecipeMaterialMapper;
@Service
@RequiredArgsConstructor
public class RecipeMaterialService extends ServiceImpl<RecipeMaterialMapper, RecipeMaterial> {

    @FdRedisCache(expireTime = 3,key = "'listMaterialVOByUser:'+#recipeId+'-'+#userId")
    public List<RecipeMaterialVO> listMaterialVOByUser(Integer recipeId, Integer userId) {
        return baseMapper.listMaterialVOByUser(recipeId,userId);
    }

    public List<RecipeMaterialVO> listMaterialVOByUserNoCache(Integer recipeId, int userId) {
        return baseMapper.listMaterialVOByUser(recipeId,userId);
    }
}
