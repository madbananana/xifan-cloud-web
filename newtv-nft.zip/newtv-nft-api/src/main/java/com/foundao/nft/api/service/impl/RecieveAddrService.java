package com.foundao.nft.api.service.impl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.common.model.RecieveAddr;
import com.foundao.nft.api.mapper.RecieveAddrMapper;
/**
    @Package: com.foundao.nft.api.service.impl
    @ClassName: RecieveAddrService
    @Author: chenli
    @CreateTime: 2022/7/12 3:12 下午
    @Description:
*/
@Service
public class RecieveAddrService extends ServiceImpl<RecieveAddrMapper, RecieveAddr> {

    public RecieveAddr getPrimaryAddr(Integer userId){
        return lambdaQuery().eq(RecieveAddr::getUserId,userId)
                .last("limit 1")
                .orderByDesc(RecieveAddr::getIsDefault)
                .one();
    }

}
