package com.foundao.nft.api.service.impl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.common.model.Invite;
import com.foundao.nft.api.mapper.InviteMapper;
@Service
public class InviteService extends ServiceImpl<InviteMapper, Invite> {

}
