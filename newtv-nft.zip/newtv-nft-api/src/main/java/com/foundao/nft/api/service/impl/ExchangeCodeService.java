package com.foundao.nft.api.service.impl;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.IdUtil;
import cn.hutool.core.util.RandomUtil;
import com.alibaba.fastjson.JSONObject;
import com.foundao.nft.common.model.NftMetadata;
import com.foundao.nft.common.model.NftSeriesClaim;
import com.foundao.nft.common.model.vo.UserVo;
import com.foundao.nft.common.util.RedisKeyFactory;
import com.tx.core.beans.JsonResult;
import com.tx.core.enums.errcode.ApiStatusErrorEnum;
import com.tx.core.enums.errcode.ParamErrorEnum;
import com.tx.core.exception.BusException;
import com.tx.redis.service.RedisLockService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.api.mapper.ExchangeCodeMapper;
import com.foundao.nft.common.model.ExchangeCode;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
@RequiredArgsConstructor
public class ExchangeCodeService extends ServiceImpl<ExchangeCodeMapper, ExchangeCode> {

    private final NftMetadataService metadataService;
    private final NftSeriesClaimService seriesClaimService;
    private final NftOrderService orderService;
    private final RedisLockService redisLockService;

    @Transactional(rollbackFor = Exception.class)
    public void entryExchangeCode(Integer metaId, Integer shortSeriesId, Integer publishCount) {
        List<ExchangeCode> list = new ArrayList<>();
        for (int i = 0; i < publishCount; i++) {
            ExchangeCode exchangeCode = new ExchangeCode();
            exchangeCode.setCode(RandomUtil.randomString(10));
            exchangeCode.setMetaId(metaId);
            exchangeCode.setShortSeriesId(shortSeriesId);
            exchangeCode.setStatus(0);
            list.add(exchangeCode);
        }
        saveBatch(list);
    }

    @Transactional(rollbackFor = Exception.class)
    public JSONObject exchange(String exchangeCode, UserVo user) {
        //利用分布式锁扣除库存
        String exchangeLockKey = RedisKeyFactory.getExchangeCodeLock(exchangeCode);
        boolean isSuccess = redisLockService.tryLock(exchangeLockKey, 5);
        NftMetadata nftMetadata = null;
        boolean lockExchangeCode = false;
        JSONObject jsonObject = new JSONObject();
        if (isSuccess) {
            try {
                ExchangeCode one = lambdaQuery()
                        .eq(ExchangeCode::getCode, exchangeCode)
                        .one();
                if (one==null) {
                    throw new BusException("兑换码错误或已经被兑换，请重新输入");
                }
                if (one.getStatus()!=0) {
                    throw new BusException("兑换码错误或已经被兑换，请重新输入");
                }
//                Integer count = lambdaQuery()
//                        .eq(ExchangeCode::getUsedUserId, user.getUserId())
//                        .eq(ExchangeCode::getMetaId, one.getMetaId())
//                        .count();
//                if (count>0) {
//                    throw new BusException("您已使用过同类型的兑换码");
//                }
                NftSeriesClaim seriesClaim = seriesClaimService.getByIdCache(one.getShortSeriesId() + "");
                String beginTime = seriesClaim.getBeginTime();
                DateTime beginDate = DateUtil.parseDateTime(beginTime);
                Date now = new Date();

                if (DateUtil.compare(beginDate,now)>0) {
                    throw new BusException("该藏品未到兑换时间");
                }

                nftMetadata = metadataService.getByMetaId(one.getMetaId()+"");
                if(nftMetadata.getShowCount() <= 0 ){
                    throw new BusException("该藏品库存不足");
                }

                if(nftMetadata.getRestCount() <= 0 ){
                    throw new BusException("该藏品库存不足");
                }

                one.setStatus(1);
                one.setUsedUserId(user.getUserId());
                lockExchangeCode = updateById(one);
            } finally {
                redisLockService.unlock(exchangeLockKey);
            }
        }
        if (lockExchangeCode) {
            String actualNftId = orderService.exchange(nftMetadata, user);
            jsonObject.put("actualNftId",actualNftId);
            jsonObject.put("name",nftMetadata.getName());
            jsonObject.put("displayUrl",nftMetadata.getDisplayUrl());
        }
        return jsonObject;
    }
}
