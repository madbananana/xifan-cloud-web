package com.foundao.nft.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.foundao.nft.common.model.NftUserConnection;
import org.apache.ibatis.annotations.Mapper;

/**
    @Package: com.foundao.nft.api.mapper
    @ClassName: NftUserConnectionMapper
    @Author: chenli
    @CreateTime: 2021/12/20 3:58 下午
    @Description:
*/
@Mapper
public interface NftUserConnectionMapper extends BaseMapper<NftUserConnection> {
}