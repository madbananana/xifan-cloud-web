package com.foundao.nft.api.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @Package: com.foundao.nft.api.vo
 * @ClassName: TransferConfirmVO
 * @Author: chenli
 * @CreateTime: 2022/7/28 3:18 下午
 * @Description:
 */
@Data
@ApiModel
public class TransferConfirmVO {

    @ApiModelProperty("实际nftId")
    @NotBlank(message = "实际nftId不能为空")
    private String actualNftId;

    @ApiModelProperty("确认状态 1：接收 2：拒绝")
    @NotNull(message = "确认状态不能为空")
    private Integer confirmStatus;
}
