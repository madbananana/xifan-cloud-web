package com.foundao.nft.api.controller;

import com.foundao.nft.api.service.impl.RedCodesService;
import com.foundao.nft.common.model.RedCodes;
import com.foundao.nft.common.model.vo.UserVo;
import com.tx.core.beans.JsonResult;
import com.tx.security.bean.AuthUser;
import com.tx.security.util.SecurityUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @Package: com.foundao.nft.api.controller
 * @ClassName: RedCodesController
 * @Author: chenli
 * @CreateTime: 2022/11/23 9:47 AM
 * @Description:
 */
@RequestMapping("/redCodes")
@Slf4j
@RestController
@RequiredArgsConstructor
@Api(tags = "红包兑换码相关")
@Validated
public class RedCodesController {


    private final RedCodesService redCodesService;


    @GetMapping("list")
    @ApiOperation("兑换码列表")
    public JsonResult<List<RedCodes>> list(){
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        List<RedCodes> list = redCodesService.lambdaQuery()
                .eq(RedCodes::getUserId, currentUser.getUserId())
                .list();
        return JsonResult.success(list);
    }
}
