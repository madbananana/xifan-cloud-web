package com.foundao.nft.api.service.impl;

import cn.hutool.core.date.DateUtil;
import cn.hutool.http.HttpUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.foundao.nft.common.model.sdk.request.BasePayRequest;
import com.foundao.nft.common.model.sdk.request.WechatMiniPayRequest;
import com.foundao.nft.common.model.sdk.response.OrderQueryResponse;
import com.foundao.nft.common.model.sdk.response.OrderResponseWrapper;
import com.foundao.nft.common.model.sdk.response.WechatAppPayData;
import com.foundao.nft.common.model.sdk.response.WechatMiniPayData;
import com.foundao.nft.common.properties.PayProperties;
import com.foundao.nft.common.util.newtv.UnifyPayUtil;
import com.tx.core.exception.BusException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

/**
 * @Package: com.foundao.nft.api.service.impl
 * @ClassName: PayService
 * @Author: chenli
 * @CreateTime: 2021/12/22 2:56 下午
 * @Description:
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class PayService {
    private final static Integer TIMEOUT = 5000;

    private final PayProperties payProperties;

    /**
     * 调用网关小程序支付
     * @param request
     * @return
     */
    public WechatMiniPayData wechatMiniPay(WechatMiniPayRequest request){
        String path = "/pay/weixin/wxa";

        Map<String, String> params = JSON.parseObject(JSON.toJSONString(request), new TypeReference<Map<String, String>>() {});
        //签名
        addSignToMap(params);

        String payUrl = payProperties.getReqUrl()+path;

        Map<String, Object> params1 = JSON.parseObject(JSON.toJSONString(params), new TypeReference<Map<String, Object>>() {});
//        String respBody = HttpUtil.post(payUrl,params1);
        String respBody = HttpUtil.createPost(payUrl).form(params1).timeout(TIMEOUT).execute().body();
        log.info("调用网关小程序支付，请求:{},返回:{}",JSON.toJSONString(params1),respBody);
        JSONObject jsonObject = JSON.parseObject(respBody);
        Integer errorCode = jsonObject.getInteger("errorCode");
        if(errorCode == 0){
            WechatMiniPayData wechatMiniPayData = JSON.parseObject(JSON.toJSONString(jsonObject.getJSONObject("data")), WechatMiniPayData.class);
            wechatMiniPayData.setPackage(jsonObject.getJSONObject("data").getString("package"));
            return wechatMiniPayData;
        }else{
            throw new BusException("发起支付失败");
        }
    }

    /**
     * 调用网app微信支付
     * @param request
     * @return
     */
    public WechatAppPayData wechatAppPay(BasePayRequest request){
        String path = "/pay/weixin/app";

        Map<String, String> params = JSON.parseObject(JSON.toJSONString(request), new TypeReference<Map<String, String>>() {});
        //签名
        addSignToMap(params);

        String payUrl = payProperties.getReqUrl()+path;

        Map<String, Object> params1 = JSON.parseObject(JSON.toJSONString(params), new TypeReference<Map<String, Object>>() {});
//        String respBody = HttpUtil.post(payUrl,params1);
        String respBody = HttpUtil.createPost(payUrl).form(params1).timeout(TIMEOUT).execute().body();
        log.info("调用微信APP支付，请求:{},返回:{}",JSON.toJSONString(params1),respBody);
        JSONObject jsonObject = JSON.parseObject(respBody);
        Integer errorCode = jsonObject.getInteger("errorCode");
        if(errorCode == 0){
            WechatAppPayData wechatAppPayData = JSON.parseObject(JSON.toJSONString(jsonObject.getJSONObject("data")), WechatAppPayData.class);
            wechatAppPayData.setPackage(jsonObject.getJSONObject("data").getString("package"));
            return wechatAppPayData;
        }else{
            throw new BusException("发起支付失败");
        }
    }

    /**
     * 调用网支付宝APP支付
     * @param request 请求
     * @return
     */
    public Map<String,Object> aliAppPay(BasePayRequest request){
        String path = "/pay/alipay/app";

        Map<String, String> params = JSON.parseObject(JSON.toJSONString(request), new TypeReference<Map<String, String>>() {});
        //签名
        addSignToMap(params);

        String payUrl = payProperties.getReqUrl()+path;

        Map<String, Object> params1 = JSON.parseObject(JSON.toJSONString(params), new TypeReference<Map<String, Object>>() {});
//        String respBody = HttpUtil.post(payUrl,params1);
        String respBody = HttpUtil.createPost(payUrl).form(params1).timeout(TIMEOUT).execute().body();
        log.info("调用支付宝APP支付，请求:{},返回:{}",JSON.toJSONString(params1),respBody);
        JSONObject jsonObject = JSON.parseObject(respBody);
        Integer errorCode = jsonObject.getInteger("errorCode");
        if(errorCode == 0){
            return JSON.parseObject(JSON.toJSONString(jsonObject.getJSONObject("data")), new TypeReference<Map<String, Object>>() {});
        }else{
            throw new BusException("发起支付失败");
        }
    }

    public String aliH5Pay(BasePayRequest request){
        String path = "/pay/alipay/h5";
        Map<String, String> params = JSON.parseObject(JSON.toJSONString(request), new TypeReference<Map<String, String>>() {});
        //签名
        addSignToMap(params);
        StringBuffer bf = new StringBuffer();
        bf.append(payProperties.getReqUrl()).append(path).append("?");
        params.forEach( (k,v) -> {
            bf.append(k).append("=").append(v).append("&");
        });
        return bf.substring(0,bf.length()-1);
    }

    public String wechatH5Pay(BasePayRequest request){
        String path = "/pay/weixin/h5";
        Map<String, String> params = JSON.parseObject(JSON.toJSONString(request), new TypeReference<Map<String, String>>() {});
        //签名
        addSignToMap(params);
        StringBuffer bf = new StringBuffer();
        bf.append(payProperties.getReqUrl()).append(path).append("?");
        params.forEach( (k,v) -> {
            bf.append(k).append("=").append(v).append("&");
        });
        return bf.substring(0,bf.length()-1);
    }

    private void addSignToMap(Map<String,String> params){
        params.put("appid",payProperties.getAppId());
        params.put("timestamp", String.valueOf(DateUtil.current()));
        String signValue = UnifyPayUtil.buildSign(params,payProperties.getAppKey());
        params.put("sign",signValue);
        //MapUtils.mapValueUrlEncode(params);
    }

    /**
     * 查询订单状态
     * @param tradeNo 订单号
     * @return
     */
    public OrderResponseWrapper<OrderQueryResponse> orderQuery(String tradeNo){
        String path = "/query/orderInfo";
        // 配置参数
        Map<String, String> params = new HashMap<>(5);
        params.put("out_trade_no", tradeNo);
        addSignToMap(params);

        String payUrl = payProperties.getReqUrl()+path;

        Map<String, Object> params1 = JSON.parseObject(JSON.toJSONString(params), new TypeReference<Map<String, Object>>() {});
        String respBody = HttpUtil.post(payUrl,params1);
        log.info("调用网关小程序支付，请求:{},返回:{}",JSON.toJSONString(params1),respBody);
        return JSON.parseObject(respBody, new TypeReference<OrderResponseWrapper<OrderQueryResponse>>() {});
    }
}
