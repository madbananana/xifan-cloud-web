package com.foundao.nft.api.service.impl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.common.model.Issuer;
import com.foundao.nft.api.mapper.IssuerMapper;
@Service
public class IssuerService extends ServiceImpl<IssuerMapper, Issuer> {

}
