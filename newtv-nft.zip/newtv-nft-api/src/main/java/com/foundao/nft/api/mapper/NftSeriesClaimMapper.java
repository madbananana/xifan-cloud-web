package com.foundao.nft.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.foundao.nft.api.vo.ProductListVo;
import com.foundao.nft.common.model.NftSeriesClaim;
import com.tx.core.beans.BaseRequestVo;
import com.tx.redis.annotation.FdRedisCache;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface NftSeriesClaimMapper extends BaseMapper<NftSeriesClaim> {

    IPage<ProductListVo> pageSeries(IPage<?> page, @Param("requestVo") BaseRequestVo requestVo,@Param("isWhiteUser") Boolean isWhiteUser);
}