package com.foundao.nft.api.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.extension.toolkit.ChainWrappers;
import com.foundao.nft.api.mapper.NftUserPlatformMapper;
import com.foundao.nft.common.model.NftUserPlatform;
import com.tx.core.exception.BusException;
import org.springframework.stereotype.Service;

/**
    @Package: com.foundao.nft.cms.service.impl
    @ClassName: NftUserPlatformService
    @Author: chenli
    @CreateTime: 2021/12/21 3:24 下午
    @Description:
*/
@Service
public class NftUserPlatformService extends ServiceImpl<NftUserPlatformMapper, NftUserPlatform> {

    public NftUserPlatform getByAddr(String receiverAddr) {
        return ChainWrappers.lambdaQueryChain(baseMapper)
                .eq(NftUserPlatform::getAddr,receiverAddr)
                .one();
    }

    public void saveNftUserPlatformInfo(NftUserPlatform userPlatform){
        if(userPlatform.getUserId() == null){
            throw new BusException("内部用户信息错误");
        }

        NftUserPlatform oldUserPlatform = getById(userPlatform.getUserId());
        if(oldUserPlatform == null){
            save(userPlatform);
        }else{
            updateById(userPlatform);
        }
    }

    public NftUserPlatform getByMobile(String mobile) {
        return baseMapper.getByMobile(mobile);
    }
}
