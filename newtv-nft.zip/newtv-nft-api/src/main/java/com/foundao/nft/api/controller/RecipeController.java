package com.foundao.nft.api.controller;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import com.foundao.nft.api.service.impl.NftMetadataService;
import com.foundao.nft.api.service.impl.NftRecordService;
import com.foundao.nft.api.service.impl.RecipeCollectionService;
import com.foundao.nft.api.service.impl.RecipeMaterialService;
import com.foundao.nft.common.model.NftMetadata;
import com.foundao.nft.common.model.NftRecord;
import com.foundao.nft.common.model.RecipeCollection;
import com.foundao.nft.common.model.vo.RecipeCollectionDetailsVO;
import com.foundao.nft.common.model.vo.RecipeCollectionListVO;
import com.foundao.nft.common.model.vo.RecipeMaterialVO;
import com.foundao.nft.common.model.vo.UserVo;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.JsonResult;
import com.tx.core.exception.BusException;
import com.tx.security.bean.AuthUser;
import com.tx.security.util.SecurityUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @ClassName RecipeController
 * @Description TODO
 * @Author xifan
 * @Date 2022/9/12 21:18
 * @Version 1.0
 */
@RequestMapping("/recipe")
@Slf4j
@RestController
@RequiredArgsConstructor
@Api(tags = "合成相关")
@Validated
public class RecipeController {

    private final RecipeCollectionService collectionService;
    private final RecipeMaterialService materialService;
    private final NftMetadataService metadataService;

    @PostMapping("/collection/list")
    @ApiOperation("活动列表")
    public JsonResult<List<RecipeCollectionListVO>> collectionList(BaseRequestVo request){
        List<RecipeCollectionListVO> list = collectionService.collectionList(request);
        String now = DateUtil.now();
        list.forEach( vo -> {
            vo.setServerCurTime(now);
        });
        return JsonResult.success(list);
    }

    @GetMapping("/collection/details")
    @ApiOperation("活动详情")
    public JsonResult<RecipeCollectionDetailsVO> collectionDetails(@RequestParam Integer collectionId){
        //先查询活动详情
        RecipeCollectionDetailsVO details = collectionService.collectionDetails(collectionId);
        if (details==null) {
            throw new BusException("不存在的活动");
        }
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        //再查询原料信息
        List<RecipeMaterialVO> materials = materialService.listMaterialVOByUser(details.getRecipeId(), Math.toIntExact(currentUser.getUserId()));

        //查询用户拥有情况
//        materials.forEach( material -> {
//            Integer count = recordService.lambdaQuery()
//                    .eq(NftRecord::getUserId, currentUser.getUserId())
//                    .eq(NftRecord::getMetaId, material.getMetaId())
//                    .eq(NftRecord::getBuyStatus, 7)
//                    .count();
//            material.setOwnCount(count);
//        } );
        details.setMaterials(materials);
        String now = DateUtil.now();
        details.setServerCurTime(now);
        return JsonResult.success(details);
    }

    @PostMapping("/merge")
    @ApiOperation("合成")
    public JsonResult<Void> merge(@RequestParam Integer metaId,@RequestParam String collectionId){

        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();

        RecipeCollection collection = collectionService.getById(collectionId);
        if (collection==null) {
            throw new BusException("活动不存在");
        }
        DateTime beginTime = DateUtil.parseDateTime(collection.getBeginTime());
        DateTime endTime = DateUtil.parseDateTime(collection.getEndTime());
        DateTime now = DateUtil.date();
        if (DateUtil.compare(beginTime,now)>0) {
            throw new BusException("活动未开始");
        }
        if (DateUtil.compare(endTime,now)<0) {
            throw new BusException("活动已结束");
        }

        if (collection.getRestMergeCount()<=0) {
            throw new BusException("合成库存不足");
        }

        NftMetadata metadata = metadataService.getById(metaId);
        if (metadata==null) {
            throw new BusException("藏品不存在");
        }
        if (metadata.getShowCount()<=0) {
            throw new BusException("藏品库存不足");
        }

        collectionService.merge(collection, Math.toIntExact(currentUser.getUserId()));
        return JsonResult.success();

    }
}
