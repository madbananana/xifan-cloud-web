package com.foundao.nft.api.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Map;

@Data
public class PosterQrCodeDto implements Serializable {
    @ApiModelProperty(value = "场景",required = true)
    private String  scene;
    @ApiModelProperty(value = "路径",required = true)
    private String page;
    @ApiModelProperty("check_path")
    private boolean check_path;
    @ApiModelProperty("env_version")
    private String env_version;
    @ApiModelProperty("width")
    private Integer width;
    @ApiModelProperty("auto_color")
    private boolean auto_color;
    @ApiModelProperty("line_color")
    private Map<String,String> line_color;
    @ApiModelProperty("is_hyaline")
    private boolean is_hyaline;
}
