package com.foundao.nft.api.service.impl;

import cn.hutool.core.date.DateUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.foundao.nft.api.mapper.OrderNotifyMapper;
import com.foundao.nft.common.model.OrderNotify;
import com.foundao.nft.common.model.apple.AppleOrderItem;
import com.foundao.nft.common.util.apple.OrderUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class OrderNotifyAppleServiceImpl {

    @Autowired
    private OrderNotifyMapper orderNotifyMapper;

    /**
     * 处理通知，主要是记录通知数据
     *
     * @param notifyData
     */
    public void doNotify(String notifyData) {
        notifyData = notifyData.replace("\\x22", "\"").replace("\\x0A", "");
        JSONObject root;
        try {
            root = JSON.parseObject(notifyData);
        } catch (Exception e) {
            e.printStackTrace();
            log.error(e.getMessage());
            return;
        }
        String notificationType = root.getString("notification_type");
        if (notificationType == null) {
            log.error("notificationType Error notifyData => {}", notifyData);
            return;
        }
        OrderNotify orderNotify = new OrderNotify();
        orderNotify.setNotifyData(JSON.toJSONString(root));
        orderNotify.setEnv(OrderUtils.getEnvFromReceiptData(root));
        orderNotify.setAppleNotifyType(root.getString("notification_type"));
        orderNotify.setStatus("NOTIFY");
        orderNotify.setCreateTime(DateUtil.now());
        AppleOrderItem latestAppleOrderItem = getLatestAppleOrderItemByNotifyData(root);
        if(latestAppleOrderItem != null){
            orderNotify.setThirdTradeNo(latestAppleOrderItem.getTransactionId());
        }
        orderNotifyMapper.insert(orderNotify);
//        CompletableFuture.runAsync(()->doNotifyCore(orderNotify));
    }

//    /**
//     * 扫描通知的数据并做处理
//     */
//    @Scheduled(fixedDelay = 100000, initialDelay = 200000)
//    public void doNotifyCoreScan() {
//        List<OrderNotify> list = orderNotifyMapper.listLatestPending();
//        for (OrderNotify orderNotify : list) {
//            doNotifyCore(orderNotify);
//        }
//    }

//    /**
//     * 处理一条通知
//     *
//     * @param orderNotify 订单通知
//     */
//    private void doNotifyCore(OrderNotify orderNotify) {
//        DistributedLockServiceRedisImpl distributedLockServiceRedis = new DistributedLockServiceRedisImpl(redisService, "OrderNotifyAppleServiceImpl:doNotifyCoreScan:" + orderNotify.getId());
//        if (distributedLockServiceRedis.tryLock(3600)) {
//            try{
//                log.info("doNotifyCore => {}", orderNotify.getId());
//                JSONObject root = JSON.parseObject(orderNotify.getBody());
//                String notificationType = root.getString("notification_type");
//                if (notificationType == null) {
//                    log.error("notificationType Error notifyData => {}", orderNotify);
//                    return;
//                }
//                if (notificationType.equalsIgnoreCase(IapNotificationTypeEnum.INITIAL_BUY.getValue())) {
//                    updateOrderNotifyStatus(orderNotify.getId(), IapNotificationTypeEnum.INITIAL_BUY.getValue());
//                } else if (notificationType.equalsIgnoreCase(IapNotificationTypeEnum.INTERACTIVE_RENEWAL.getValue())) {
//                    //需要立即扫描,让服务立即可用
//                    immediatelyScanNotifyAppleOrder(orderNotify,root);
//                } else if (notificationType.equalsIgnoreCase(IapNotificationTypeEnum.DID_CHANGE_RENEWAL_PREF.getValue())) {
//                    //用户更换了订阅项，下次生效,有新订单生成，需要重新扫描
////            updateOrderNotifyStatus(orderNotify.getId(), IapNotificationTypeEnum.DID_CHANGE_RENEWAL_PREF.getValue());
//                    immediatelyScanNotifyAppleOrder(orderNotify,root);
//                } else if (notificationType.equalsIgnoreCase(IapNotificationTypeEnum.DID_CHANGE_RENEWAL_STATUS.getValue())) {
//                    //更改用户订阅状态
//                    doNotifyChangeRenewalStatus(orderNotify, root);
//                } else if (notificationType.equalsIgnoreCase(IapNotificationTypeEnum.DID_RENEW.getValue())) {
//                    //续费成功,需要立即扫描并续费
//                    immediatelyScanNotifyAppleOrder(orderNotify,root);
//                } else if (notificationType.equalsIgnoreCase(IapNotificationTypeEnum.CANCEL.getValue())) {
//                    //用户退单了,需要立即扫描
//                    immediatelyScanNotifyAppleOrder(orderNotify,root);
//                }else if (notificationType.equalsIgnoreCase(IapNotificationTypeEnum.REFUND.getValue())) {
//                    //退款
//                    immediatelyScanNotifyAppleOrder(orderNotify,root);
//                } else if (notificationType.equalsIgnoreCase(IapNotificationTypeEnum.DID_RECOVER.getValue())) {
//                    //表示成功续订。这个是针对过去续订失败的订阅。需要立即扫描并续费
////            doNotifyCoreInitialCancel(orderNotify, root);
//                    immediatelyScanNotifyAppleOrder(orderNotify,root);
//                }  else if(notificationType.equalsIgnoreCase(IapNotificationTypeEnum.DID_FAIL_TO_RENEW.getValue())){
//                    doNotifyFailRenewalStatus(orderNotify,root);
//                }else {
//                    updateOrderNotifyStatus(orderNotify.getId(), notificationType);
//                }
//            }finally {
//                distributedLockServiceRedis.unlock();
//            }
//
//        }
//    }
//
//
//
//    /**
//     * 失败续订，扣费失败
//     * @param orderNotify 订单通知信息
//     * @param root 苹果通知数据
//     */
//    private void doNotifyFailRenewalStatus(OrderNotify orderNotify, JSONObject root) {
//        AppleOrderItem appleOrderItem =  getLatestAppleOrderItemByNotifyData(root);
//        Order nowOrder = orderMapper.getRowByThirdTradeNo(appleOrderItem.getTransactionId());
//        if (nowOrder != null) {
//            updateOrderNotifyStatus(orderNotify.getId(), root.getString("notification_type"));
//            orderService.onlyUpdateOrderStatus(nowOrder.getId(), OrderStatusEnum.PAY_FAIL);
//        } else {
//            log.warn("【doNotifyFailRenewalStatus】 Notify Order has Not Exists orderNotify => {}", orderNotify);
//        }
//    }
//
//    /**
//     * 处理用户改变订阅状态
//     * @param orderNotify 订单通知信息
//     * @param root 苹果通知数据
//     */
//    private void doNotifyChangeRenewalStatus(OrderNotify orderNotify, JSONObject root) {
//        AppleOrderItem appleOrderItem =  getLatestAppleOrderItemByNotifyData(root);
//        Order nowOrder = orderMapper.getRowByThirdTradeNo(appleOrderItem.getTransactionId());
//        if (nowOrder != null) {
//            updateOrderNotifyStatus(orderNotify.getId(), root.getString("notification_type"));
//            UserSubscribe userSubscribe = new UserSubscribe();
//            userSubscribe.setUserId(nowOrder.getUserId());
//            userSubscribe.setAddTime(new Date());
//            userSubscribe.setEnv(OrderUtils.getEnvFromReceiptData(root));
//            userSubscribe.setOriginalTransactionId(appleOrderItem.getOriginalTransactionId());
//            userSubscribe.setAutoRenewStatusChangeDatePst(root.getString("auto_renew_status_change_date_pst"));
//            userSubscribe.setAutoRenewProductId(root.getString("auto_renew_product_id"));
//            if (Const.TRUE.equalsIgnoreCase(root.getString("auto_renew_status"))) {
//                userSubscribe.setType(Const.SUBSCRIBE);
//            } else {
//                userSubscribe.setType(Const.UNSUBSCRIBE);
//            }
//            userSubscribeService.userSubscribeTryInsert(userSubscribe);
//        } else {
//            //可能订单还没有生成,交由下次轮询
////            orderNotify.setBody("");
//            log.warn("【doNotifyChangeRenewalStatus】 Notify Order has Not Exists orderNotify => {}", orderNotify);
////            updateOrderNotifyStatus(orderNotify.getId(), "CHECKED_INVALID");
//        }
//    }
//
//
//    /**
//     * 更新通知表的状态
//     *
//     * @param id id
//     * @param status 状态值
//     */
//    private void updateOrderNotifyStatus(Integer id, String status) {
//        OrderNotify orderNotify = new OrderNotify();
//        orderNotify.setId(id);
//        orderNotify.setStatus(status);
//        orderNotifyMapper.updateByPrimaryKeySelective(orderNotify);
//    }
//
//
//    /**
//     * 立刻扫描用户订单信息
//     * @param root
//     */
//    private void immediatelyScanNotifyAppleOrder(OrderNotify orderNotify,JSONObject root){
//        JSONObject unifiedReceipt = root.getJSONObject("unified_receipt");
//        if(unifiedReceipt != null){
//            JSONArray receiptArray = unifiedReceipt.getJSONArray("latest_receipt_info");
//            boolean isAllSuccess = orderServiceApplePay.doLatestReceiptInfo(receiptArray,OrderUtils.getEnvFromReceiptData(root));
//            if(isAllSuccess){
//                String notificationType = root.getString("notification_type");
//                updateOrderNotifyStatus(orderNotify.getId(), notificationType);
//            }
//        }else{
//            updateOrderNotifyStatus(orderNotify.getId(), "FAIL_RECEIPT");
//        }
//
//    }
//
//
    private AppleOrderItem getLatestAppleOrderItemByNotifyData(JSONObject root){
        JSONObject unifiedReceipt = root.getJSONObject("unified_receipt");
        return OrderUtils.getLatestReceiptInfo(unifiedReceipt.getJSONArray("latest_receipt_info"));
    }


}
