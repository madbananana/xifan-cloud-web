package com.foundao.nft.api.controller;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.RandomUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.crypto.SecureUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.foundao.nft.api.service.impl.*;
import com.foundao.nft.api.vo.ModMobileConfirmVO;
import com.foundao.nft.api.vo.ModTradePassVO;
import com.foundao.nft.api.vo.MyNftGroupByMetaIdVO;
import com.foundao.nft.api.vo.MyNftVO;
import com.foundao.nft.api.vo.NftInfoVO;
import com.foundao.nft.common.constant.IntegralTypeEnum;
import com.foundao.nft.common.model.*;
import com.foundao.nft.common.model.vo.NftRecordVO;
import com.foundao.nft.common.model.vo.SendMessageBaseVO;
import com.foundao.nft.common.model.vo.SendMessageProVO;
import com.foundao.nft.common.model.vo.SendMessageVO;
import com.foundao.nft.common.model.vo.SendMsgResponse;
import com.foundao.nft.common.model.vo.SendMsgV2Response;
import com.foundao.nft.common.model.vo.UserVo;
import com.foundao.nft.common.model.sdk.client.NftService;
import com.foundao.nft.common.model.sdk.request.IdentityBindSubmitPlatformRequest;
import com.foundao.nft.common.model.sdk.request.NftAddressListRequest;
import com.foundao.nft.common.model.sdk.request.PersonRegPlatformRequest;
import com.foundao.nft.common.model.sdk.response.*;
import com.foundao.nft.common.model.vo.PersonRegPlatformVO;
import com.foundao.nft.common.properties.NftProperties;
import com.foundao.nft.common.util.NftCommonUtil;
import com.foundao.nft.common.util.RedisKeyFactory;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.JsonResult;
import com.tx.core.enums.errcode.ApiStatusErrorEnum;
import com.tx.core.enums.errcode.ParamErrorEnum;
import com.tx.core.exception.BusException;
import com.tx.core.util.HttpRequestUtil;
import com.tx.redis.service.RedisService;
import com.tx.security.annotation.AnonymousGetMapping;
import com.tx.security.annotation.AnonymousPostMapping;
import com.tx.security.bean.AuthUser;
import com.tx.security.bean.JwtUserDto;
import com.tx.security.service.OnlineUserService;
import com.tx.security.util.SecurityUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.validator.constraints.Range;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotBlank;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@RequestMapping("/nft")
@Slf4j
@RestController
@RequiredArgsConstructor
@Api(tags = "用户相关")
@Validated
public class UserController {
    private final NftRecordService recordService;
    private final NftService nftService;
    private final NftUserPlatformService userPlatformService;
    private final NftProperties nftProperties;
    private final NftCommonUtil nftCommonUtil;
    private final NftUserService userService;
    private final OnlineUserService onlineUserService;
    private final AdvanceBuyService advanceBuyService;
    private final RedisService redisService;
    private final MessageService messageService;
    private final TransferRecordService transferRecordService;
    private final PasswordEncoder passwordEncoder;
    private final IntegralService integralService;
    private final InviteService inviteService;
    private final NftMetadataService metadataService;
    private final NftSeriesClaimService seriesClaimService;

    private final SensorsAnalyticsService sensorsAnalyticsService;

    private final WaitChainUpService waitChainUpService;

    @Value("${spring.profiles.active}")
    private String env;


    @ApiOperation("自然人注册实名-平台签名")
    @PostMapping("reg/person/platform")
    public JsonResult<NftUserPlatform> personRegPlatform(@Validated PersonRegPlatformVO person){
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        if (StrUtil.isBlank(person.getMobile())) {
            person.setMobile(currentUser.getUserDetails().getMobile());
        }
        String uuid = HttpRequestUtil.getHeader("uuid");
        String appVersion = HttpRequestUtil.getHeader("appVersion");
        String packageName = HttpRequestUtil.getHeader("packageName");
        if (uuid==null) {
            uuid = "";
        }
        if (appVersion==null) {
            appVersion = "";
        }
        if (packageName==null) {
            packageName = "";
        }

        if (!person.getMobile().equals(currentUser.getUserDetails().getMobile())) {
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"实名手机号和登录手机号不一致");
        }

        //校验重复提交
        Map<String,Object> hashData = new HashMap<>(3);
        hashData.put("mobile",currentUser.getUserDetails().getMobile());
        hashData.put("userId",currentUser.getUserDetails().getUserId());

        String orderRepeatLimitKey = RedisKeyFactory.getOrderRepeatLimitKey(SecureUtil.md5(JSON.toJSONString(hashData)));
        if(redisService.get(orderRepeatLimitKey) != null){
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"操作过于频繁,请稍后再试");
        }

        if (person.getCardType()==1) {
            if (person.getIdCard().length()==18) {
                String birthday = person.getIdCard().substring(6,14);
                try {
                    DateTime parse = DateUtil.parse(birthday, DatePattern.PURE_DATE_PATTERN);
                    DateTime offsetDate = DateUtil.offsetMonth(parse, 12 * 18);
                    if (offsetDate.compareTo(new Date())>0) {
                        sensorsAnalyticsService.nameIdentityEvent(currentUser.getUserId()+"",false,uuid,appVersion,packageName);
                        return JsonResult.error(HttpStatus.INTERNAL_SERVER_ERROR.value(),"本产品暂不向18岁以下用户开放！");
                    }
                } catch (Exception e) {
                    sensorsAnalyticsService.nameIdentityEvent(currentUser.getUserId()+"",false,uuid,appVersion,packageName);
                    return JsonResult.error(HttpStatus.INTERNAL_SERVER_ERROR.value(),"实名认证未通过，请仔细核对您的姓名、身份证信息与当前登录手机号是否匹配！");
                }
            }
        }
        redisService.set(orderRepeatLimitKey,currentUser.getUserId(),3L);
        PersonRegPlatformRequest regRequest = new PersonRegPlatformRequest();
        BeanUtil.copyProperties(person,regRequest);
        NftUserPlatform userPlatform = userPlatformService.getById(currentUser.getUserId());
        //如果该用户已经 绑定，那么直接返回成功
        if(userPlatform != null && ( userPlatform.getStatus() == 2 || userPlatform.getStatus() == 1) ){
            return JsonResult.success(userPlatform);
        }
        if(userPlatform == null){
            userPlatform = new NftUserPlatform();
            userPlatform.setUserId(currentUser.getUserId().intValue());
        }

        String signData = person.getPersonName()+"_"+person.getMobile()+"_"+person.getIdCard();
        SignByPriKeyResponse platformSignResponse = nftCommonUtil.signByPriKey(nftProperties.getPriKey(), signData);
        if ( platformSignResponse!=null ) {
            regRequest.setPlatformPubKey(nftProperties.getPubKey());
            regRequest.setPlatformSignData(platformSignResponse.getSignedData());
            //1.调用nft平台自然人注册
            SdkResponseBase<PersonRegResponse> personRegResponse = nftService.personRegPlatform(regRequest);
            //log.info("nft平台自然人注册,请求：{},响应：{}",regRequest,personRegResponse);
            if (personRegResponse!=null && personRegResponse.getRetCode()==0) {

                //2.生成助记词
                MnemonicResponse mnemonic = nftCommonUtil.createMnemonic();
                userPlatform.setMnemonic(mnemonic.getMnemonic());

                //3.派生公私钥
                DeriveKeyPairResponse keyPairResponse = nftCommonUtil.deriveKeyPair(mnemonic.getMnemonic(), 66);
                userPlatform.setPrikey(keyPairResponse.getPriKey());
                userPlatform.setPubkey(keyPairResponse.getPubKey());
                userPlatform.setUserIdentification(personRegResponse.getData().getUserIdentification());

                //4.授信自然人地址绑定
                IdentityBindSubmitPlatformRequest bindSubmit = new IdentityBindSubmitPlatformRequest();
                bindSubmit.setPlatformPubKey(nftProperties.getPubKey());
                bindSubmit.setUserPubKey(userPlatform.getPubkey());
                bindSubmit.setUserSignData(nftCommonUtil.signByPriKey(userPlatform.getPrikey(),userPlatform.getUserIdentification()).getSignedData());
                bindSubmit.setPlatformSignData(nftCommonUtil.signByPriKey(nftProperties.getPriKey(),bindSubmit.getUserSignData()).getSignedData());
                bindSubmit.setUserIdentification(userPlatform.getUserIdentification());
                SdkResponseBase<String> addressResponse = nftService.identityBindSubmitPlatform(bindSubmit);
                //log.info("授信自然人地址绑定,请求：{},响应：{}",bindSubmit,addressResponse);
                if (addressResponse!=null && addressResponse.getRetCode()==0) {
                    userPlatform.setAddr(addressResponse.getData());
                    userPlatform.setStatus(1);
                    userPlatformService.saveNftUserPlatformInfo(userPlatform);

                    //更新用户信息
                    NftUser newUser = new NftUser();
                    newUser.setUserId(currentUser.getUserId().intValue());
                    newUser.setUserName(person.getPersonName());
                    //newUser.setNickName(person.getPersonName());
                    userService.updateById(newUser);
                    //刷新redis
                    UserVo userDetails = currentUser.getUserDetails();
                    userDetails.setUserName(person.getPersonName());
                    //userDetails.setNickName(person.getPersonName());
                    userDetails.setAuth(true);
                    userDetails.setAddr(userPlatform.getAddr());
                    onlineUserService.updateUser(currentUser);
                    String now = DateUtil.now();
                    Integer realNameAuthCount = (Integer) redisService.hget(RedisKeyFactory.getIntegralKey(), IntegralTypeEnum.REAL_NAME_AUTH.getType());
                    integralService.integralOperation(userDetails.getUserId(),userDetails.getUserId()+"", IntegralTypeEnum.REAL_NAME_AUTH.getType(),"in",realNameAuthCount,null,now);
                    Integer inviteRealNameAuthCount = (Integer) redisService.hget(RedisKeyFactory.getIntegralKey(), IntegralTypeEnum.REAL_NAME_AUTH.getType());
                    integralService.integralOperation(userDetails.getInviteUserId(),userDetails.getUserId()+"", IntegralTypeEnum.INVITE_REAL_NAME_AUTH.getType(),"in",inviteRealNameAuthCount,null,now);
                    if (userDetails.getInviteUserId()!=null) {
                        inviteService.lambdaUpdate()
                                .eq(Invite::getUserId,userDetails.getUserId())
                                .eq(Invite::getInviteUserId,userDetails.getInviteUserId())
                                .set(Invite::getAuth,1)
                                .set(Invite::getAuthTime,now)
                                .update();
                    }
                    sensorsAnalyticsService.nameIdentityEvent(userDetails.getUserId()+"",true,uuid,appVersion,packageName);
                    waitChainUpService.executeWaitChainUp(userPlatform);
                    return JsonResult.success(userPlatform);
                }

            }
        }
        sensorsAnalyticsService.nameIdentityEvent(currentUser.getUserId()+"",false,uuid,appVersion,packageName);
        return JsonResult.error(HttpStatus.INTERNAL_SERVER_ERROR.value(),"实名认证未通过，请仔细核对您的姓名、身份证信息与当前登录手机号是否匹配！");
    }

    @ApiOperation("我的转赠列表")
    @PostMapping("myTransfer")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "page",value = "page"),
            @ApiImplicitParam(name = "num",value = "num"),
            @ApiImplicitParam(name = "status",value = "状态 0：转赠中 1：转赠成功 2：转赠失败，不传表示查询所有"),
    })
    public JsonResult<List<TransferRecord>> myTransfer(BaseRequestVo requestVo, Integer status){
        List<TransferRecord> list = transferRecordService.myTransfer(requestVo,status);
        return JsonResult.success(list);
    }

    @ApiOperation("我的")
    @PostMapping("mynft")
    @ApiOperationSupport(includeParameters = {"page","num"})
    public JsonResult<List<MyNftVO>> myNft(BaseRequestVo requestVo){
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        UserVo user = currentUser.getUserDetails();
        requestVo.getMultiValueSearch().put("userId",user.getUserId());
        List<MyNftVO> myNftVOS = recordService.listMyNft(requestVo);
        return JsonResult.success(myNftVOS);
    }

    @ApiOperation("我的nft列表分类")
    @PostMapping("mynft/group")
    @ApiOperationSupport(includeParameters = {"page","num"})
    public JsonResult<List<MyNftGroupByMetaIdVO>> myNftGroupByMetaId(BaseRequestVo requestVo){
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        UserVo user = currentUser.getUserDetails();
        List<MyNftGroupByMetaIdVO> myNftVOS = recordService.listMyNftGroupByMetaId(requestVo,user);
        return JsonResult.success(myNftVOS);
    }

    @ApiOperation("我的nft详情")
    @GetMapping("/details")
    @ApiImplicitParams({
    })
    public JsonResult<NftInfoVO> details(@RequestParam String metaId,@RequestParam String actualNftId){
        NftInfoVO vo = recordService.nftDetails(metaId,actualNftId);
        return JsonResult.success(vo);
    }

    @ApiOperation("分享详情")
    @AnonymousGetMapping("/shareDetails")
    @ApiImplicitParams({
    })
    public JsonResult<NftInfoVO> shareDetails(@RequestParam String metaId,@RequestParam String actualNftId,@RequestParam Integer userId){
        NftInfoVO vo = recordService.shareDetails(metaId,actualNftId,userId);
        return JsonResult.success(vo);
    }


    @PostMapping("mynftSdk")
    public JsonResult<NftInfoListResponse> mynftSdk(BaseRequestVo requestVo){
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        UserVo user = currentUser.getUserDetails();
        if(StrUtil.isBlank(user.getAddr())){
            NftInfoListResponse nftInfoListResponse = new NftInfoListResponse();
            return JsonResult.success(nftInfoListResponse);
        }
        int offset = (requestVo.getPage() -1 ) * requestVo.getNum();
        NftAddressListRequest request = new NftAddressListRequest();
        request.setAddr(user.getAddr());
        request.setLimit(requestVo.getNum());
        request.setOffset(offset);
        SdkResponseBase<NftInfoListResponse> responseSdkResponseBase = nftService.nftAddressList(request);
        if(responseSdkResponseBase.getRetCode() != 0 ){
            log.warn("调用账户的nft数据失败:{}", JSON.toJSONString(responseSdkResponseBase));
            return JsonResult.error(ApiStatusErrorEnum.INTERNAL_ERROR.getCode(),"获取数据失败");
        }
        return JsonResult.success(responseSdkResponseBase.getData());
    }


    @GetMapping("/userInfo")
    @ApiOperation("用户信息")
    public JsonResult<?> userInfo(){
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        Object principal = authentication.getPrincipal();
        JwtUserDto<UserVo> userInfo = ((JwtUserDto)principal);
        NftUserPlatform userPlatform = userPlatformService.getById(userInfo.getUser().getUserId());
        JSONObject jsonObject = (JSONObject) JSONObject.toJSON(userInfo);
        boolean hasPass = false;
        if (userPlatform!=null && userPlatform.getTradePass()!=null) {
            hasPass = true;
        }
        jsonObject.put("hasPass",hasPass);
        Integral integral = integralService.getById(userInfo.getUser().getUserId());
        if (integral==null) {
            integral = new Integral();
            integral.setUserId(Math.toIntExact(userInfo.getUser().getUserId()));
            integral.setFrozenIntegral(0);
            integral.setUsableIntegral(0);
            integralService.save(integral);
        }
        jsonObject.put("usableIntegral",integral.getUsableIntegral());

        Integer checkSign = (Integer)redisService.get(RedisKeyFactory.getCheckSignKey(Math.toIntExact(userInfo.getUser().getUserId())));
        jsonObject.put("checkSign",checkSign==null?0:1);
        //0 app 1 h5
        Integer iSubPayType = 0;
        String subType = (String)redisService.get(RedisKeyFactory.getAppleSubTypeKey());
        if (StrUtil.isBlank(subType)) {
            subType = "app";
        }
        if (Objects.equals("app",subType)) {
            iSubPayType = 0;
        } else {
            iSubPayType = 1;
        }
        if ("13911229370".equals(userInfo.getUser().getUserDetails().getMobile())) {
            iSubPayType = 0;
        }
        jsonObject.put("iSubPayType",iSubPayType);
        return JsonResult.success(jsonObject);
    }

    @PostMapping("/checkSign")
    @ApiOperation("签到")
    public JsonResult<Void> checkSign(){
        userService.checkSign();
        return JsonResult.success();
    }

    @GetMapping("/usableIntegral")
    @ApiOperation("查询积分")
    public JsonResult<?> usableIntegral(){
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        Integral integral = integralService.getById(currentUser.getUserId());
        if (integral==null) {
            integral = new Integral();
            integral.setUserId(Math.toIntExact(currentUser.getUserId()));
            integral.setFrozenIntegral(0);
            integral.setUsableIntegral(0);
            integralService.save(integral);
        }
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("usableIntegral",integral.getUsableIntegral());
        return JsonResult.success(jsonObject);
    }

    @GetMapping("/sendModPassMessage")
    @ApiOperation("发送修改密码验证码")
    public JsonResult<Void> sendModPassMessage() throws Exception {
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        String mobile = currentUser.getUserDetails().getMobile();
        if (mobile == null) {
            return JsonResult.error(ApiStatusErrorEnum.INTERNAL_ERROR.getCode(),"用户未绑定手机号");
        }
        String content = "【未来数藏】安全提醒：您正在设置自己的转赠密码，验证码是%s。";
        SendMsgResponse response = messageService.sendMessage(mobile,content);
        if (response!=null) {
            if ("1".equals(response.getStatusCode())) {
                return JsonResult.success();
            }
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),response.getMessage());
        }
        return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"短信发送失败");
    }

    @GetMapping("/sendMessage")
    @ApiOperation("发送短信验证码")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "type",value = "短信类型 1：修改转赠密码 2：换绑验证短信 3：换绑确认短信（传手机号）",required = true),
            @ApiImplicitParam(name = "phone",value = "电话号码，只有类型为3的时候才需要传"),
    })
    public JsonResult<Void> sendMessage(@RequestParam @Validated @NotBlank(message = "短信类型不能为空") @Range(min = 1,max = 3,message = "类型范围只能为1-2") String type,String phone) throws Exception {
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        String mobile = currentUser.getUserDetails().getMobile();
        if (mobile == null) {
            return JsonResult.error(ApiStatusErrorEnum.INTERNAL_ERROR.getCode(),"用户未绑定手机号");
        }
        String content = "";
        if ("1".equals(type)) {
            content = "【未来数藏】安全提醒：您正在设置自己的转赠密码，验证码是%s。";
        } else if ("2".equals(type)) {
            content = "【未来数藏】你正在绑定新手机号，验证码%s。5分钟内有效，请勿提供给他人。";
        } else if ("3".equals(type)) {
            content = "【未来数藏】你正在更换未来数藏绑定的手机号，验证码%s。5分钟内有效，转发可能导致账号被盗。";
            if (StrUtil.isBlank(mobile)) {
                return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"手机号不能为空");
            }
            Integer flag = (Integer) redisService.get(RedisKeyFactory.getModMobileFlagKey(mobile));
            if (flag==null || flag!=1) {
                return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"请先验证初始手机号");
            }
            mobile = phone;
        }
        if (StrUtil.isBlank(content)) {
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"错误的短信类型");
        }
        SendMsgResponse response = messageService.sendMessage(mobile,content);
        if (response!=null) {
            if ("1".equals(response.getStatusCode())) {
                return JsonResult.success();
            }
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),response.getMessage());
        }
        return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"短信发送失败");
    }

    @ApiOperation("发送短信验证码V2")
    @AnonymousPostMapping("/sendMessage/v2")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "type",value = "短信类型 1：修改转赠密码 2：换绑验证短信 3：换绑确认短信（传手机号）",required = true),
            @ApiImplicitParam(name = "phone",value = "电话号码，只有类型为3的时候才需要传"),
    })
    @ApiOperationSupport(includeParameters = {"type","phone"})
    public JsonResult<JwtUserDto<UserVo>> sendMsg(@Validated SendMessageProVO baseVO) throws Exception{
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        String mobile = currentUser.getUserDetails().getMobile();
        if (mobile == null) {
            return JsonResult.error(ApiStatusErrorEnum.INTERNAL_ERROR.getCode(),"用户未绑定手机号");
        }

        String templateId = "";
        if ("1".equals(baseVO.getType())) {
            templateId = "b023aedaca80835c5a62e7195982fb064dcdffc1";
        } else if ("2".equals(baseVO.getType())) {
            templateId = "609a54dab50c94db063f22c3ab6308fa311371a5";
        } else if ("3".equals(baseVO.getType())) {
            templateId = "267a53060d8cae2413ceca808e14de0585893065";
            if (StrUtil.isBlank(mobile)) {
                return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"手机号不能为空");
            }
            Integer flag = (Integer) redisService.get(RedisKeyFactory.getModMobileFlagKey(mobile));
            if (flag==null || flag!=1) {
                return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"请先验证初始手机号");
            }
            mobile = baseVO.getPhone();
        }
        if (StrUtil.isBlank(templateId)) {
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"错误的短信类型");
        }

        SendMessageVO vo = new SendMessageVO();
        BeanUtil.copyProperties(baseVO,vo);
        vo.setMobile(mobile);
        vo.setUserIp(HttpRequestUtil.getClientIp());
        vo.setTemplateId(templateId);
        String verificationCode = RandomUtil.randomNumbers(6);
        vo.setTemplateParamSet(CollUtil.newArrayList(verificationCode));
        SendMsgV2Response response = messageService.sendMessageV2(vo);
        if (response!=null) {
            if ("0".equals(response.getStatusCode())) {
                if (CollectionUtil.isNotEmpty(response.getResponse())) {
                    if (CollectionUtil.isNotEmpty(response.getResponse())) {
                        if ("0".equals(response.getResponse().get(0).getCode())) {
                            redisService.set(RedisKeyFactory.getVerificationCodeKey(response.getResponse().get(0).getMobile()), verificationCode, 5*60L);
                            return JsonResult.success();
                        } else {
                            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),response.getResponse().get(0).getMessage());
                        }
                    }
                }
            }
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),response.getMessage());
        }
        return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"短信发送失败");
    }

    @PostMapping("/modMobileVerify")
    @ApiOperation("换绑验证码校验")
    public JsonResult<Void> modMobileVerify(@RequestParam @Validated @NotBlank(message = "验证码不能为空") String verificationCode){
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        String mobile = currentUser.getUserDetails().getMobile();
        if (mobile == null) {
            return JsonResult.error(ApiStatusErrorEnum.INTERNAL_ERROR.getCode(),"用户未绑定手机号");
        }

        String code = (String) redisService.get(RedisKeyFactory.getVerificationCodeKey(mobile));
        if (StrUtil.isNotBlank(code)) {
            if (code.equals(verificationCode)) {
                redisService.del(RedisKeyFactory.getVerificationCodeKey(mobile));
                redisService.set(RedisKeyFactory.getModMobileFlagKey(mobile),1,5*60L);
                return JsonResult.success();
            }
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"验证码输入错误");
        } else {
            //return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"验证码超时，请稍后再试");
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"验证码输入错误");
        }
    }

    @PostMapping("/modMobileConfirm")
    @ApiOperation("换绑确认")
    public JsonResult<?> modMobileConfirm(@Validated ModMobileConfirmVO vo){
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        String mobile = currentUser.getUserDetails().getMobile();
        if (mobile == null) {
            return JsonResult.error(ApiStatusErrorEnum.INTERNAL_ERROR.getCode(),"用户未绑定手机号");
        }

        String code = (String) redisService.get(RedisKeyFactory.getVerificationCodeKey(vo.getNewMobile()));
        if (StrUtil.isNotBlank(code)) {
            if (code.equals(vo.getVerificationCode())) {
                Integer flag = (Integer) redisService.get(RedisKeyFactory.getModMobileFlagKey(mobile));
                if (flag==null || flag!=1) {
                    return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"请先验证初始手机号");
                }
                Integer count = userService.lambdaQuery()
                        .eq(NftUser::getMobile, vo.getNewMobile())
                        .count();
                if (count>0) {
                    return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"该手机号已被绑定");
                }
                NftUserPlatform userPlatform = userPlatformService.getById(currentUser.getUserId());
                PersonRegPlatformRequest regRequest = new PersonRegPlatformRequest();
                regRequest.setCardType(vo.getCardType());
                regRequest.setIdCard(vo.getIdCard());
                regRequest.setPersonName(vo.getPersonName());
                regRequest.setMobile(vo.getNewMobile());
                //如果该用户已经 绑定，那么直接返回成功
                if(userPlatform != null && ( userPlatform.getStatus() == 2 || userPlatform.getStatus() == 1) ){
                    String signData = vo.getPersonName()+"_"+vo.getNewMobile()+"_"+vo.getIdCard();
                    SignByPriKeyResponse platformSignResponse = nftCommonUtil.signByPriKey(nftProperties.getPriKey(), signData);
                    if ( platformSignResponse!=null ) {
                        regRequest.setPlatformPubKey(nftProperties.getPubKey());
                        regRequest.setPlatformSignData(platformSignResponse.getSignedData());
                        //1.调用nft平台自然人注册
                        SdkResponseBase<PersonRegResponse> personRegResponse = nftService.personRegPlatform(regRequest);
                        if (personRegResponse != null ) {
                            if (personRegResponse.getRetCode() == 0) {
                                if (!personRegResponse.getData().getUserIdentification().equals(userPlatform.getUserIdentification())) {
                                    throw new BusException("新旧手机号实名不一致");
                                }
                            } else {
                                throw new BusException(personRegResponse.getRetMsg());
                            }
                        } else {
                            throw new BusException("实名验证失败");
                        }
                    }
                } else {
                    PersonRegPlatformVO person = new PersonRegPlatformVO();
                    BeanUtil.copyProperties(regRequest, person);
                    JsonResult<NftUserPlatform> regResult = personRegPlatform(person);
                    if (regResult.getCode()!=200) {
                        return regResult;
                    }
                }

                redisService.del(RedisKeyFactory.getVerificationCodeKey(vo.getNewMobile()));
                redisService.del(RedisKeyFactory.getModMobileFlagKey(mobile));
                userService.lambdaUpdate()
                        .eq(NftUser::getUserId,currentUser.getUserId())
                        .set(NftUser::getMobile,vo.getNewMobile())
                        .update();
                //刷新redis
                UserVo userDetails = currentUser.getUserDetails();
                userDetails.setMobile(vo.getNewMobile());
                onlineUserService.updateUser(currentUser);
                return JsonResult.success();
            }
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"验证码输入错误");
        } else {
            //return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"验证码超时，请稍后再试");
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"验证码输入错误");
        }
    }

    @PostMapping("/tradePass/mod")
    @ApiOperation("修改转赠密码")
    public JsonResult<Void> tradePassMod(@Validated ModTradePassVO vo){
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        String mobile = currentUser.getUserDetails().getMobile();
        if (mobile == null) {
            return JsonResult.error(ApiStatusErrorEnum.INTERNAL_ERROR.getCode(),"用户未绑定手机号");
        }
        NftUserPlatform userPlatform = userPlatformService.getById(currentUser.getUserId());
        if (userPlatform == null) {
            return JsonResult.error(ApiStatusErrorEnum.INTERNAL_ERROR.getCode(),"请先进行实名认证");
        }

        String code = (String) redisService.get(RedisKeyFactory.getVerificationCodeKey(mobile));
        if (StrUtil.isNotBlank(code)) {
            if (code.equals(vo.getVerificationCode())) {
                redisService.del(RedisKeyFactory.getVerificationCodeKey(mobile));
                userPlatform.setTradePass(passwordEncoder.encode(vo.getNewPassword()));
                userPlatformService.updateById(userPlatform);
                return JsonResult.success();
            }
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"验证码输入错误");
        } else {
            //return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"验证码超时，请稍后再试");
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"验证码输入错误");
        }
    }

    @GetMapping("/initInviteCode")
    @ApiOperation("生成邀请码")
    public JsonResult<?> createInviteCode(){
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        if (currentUser.getUserDetails().getInviteCode()!=null) {
            return userInfo();
        }
        DateTime dateTime = DateUtil.offsetSecond(new Date(), 5);
        int inviteCode = RandomUtil.randomInt(100000, 999999);
        Integer count = userService.lambdaQuery()
                .eq(NftUser::getInviteCode, inviteCode)
                .count();
        while (count>0) {
            if (DateUtil.compare(dateTime,DateUtil.date())<0) {
                return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"生成邀请码失败");
            }
            inviteCode = RandomUtil.randomInt(100000, 999999);
            count = userService.lambdaQuery()
                    .eq(NftUser::getInviteCode, inviteCode)
                    .count();
        }
        userService.lambdaUpdate()
                .eq(NftUser::getUserId,currentUser.getUserId())
                .set(NftUser::getInviteCode,inviteCode)
                .update();
        //刷新redis
        UserVo userDetails = currentUser.getUserDetails();
        userDetails.setInviteCode(inviteCode);
        onlineUserService.updateUser(currentUser);
        return userInfo();
    }

    @GetMapping("/myAdvanceBuy")
    @ApiOperation("我的预约购买")
    public JsonResult<List<AdvanceBuy>> myAdvanceBuy(){
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        List<AdvanceBuy> advanceBuys = advanceBuyService.getByUserId(currentUser.getUserId());
        return JsonResult.success(advanceBuys);
    }


    @AnonymousGetMapping("/clearAdvance")
    @ApiOperation("清除预约-临时")
    public JsonResult<?> clearAdvance(@RequestParam(required = true) String mobile,String seriesId){
        if(StrUtil.isBlank(mobile) || StrUtil.isBlank(seriesId)){
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"手机号和系列id都不能为空");
        }
        NftUser userByMobile = userService.findUserByMobile(mobile);
        if(userByMobile == null){
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR);
        }
        advanceBuyService.clearUserAdvance(userByMobile.getUserId(),seriesId);
        if(StrUtil.isNotBlank(seriesId)){
            redisService.hdel(RedisKeyFactory.getAppointmentKey(seriesId),userByMobile.getUserId().toString());
        }
        return JsonResult.success();
    }


    @GetMapping("/canTransOrNo")
    @ApiOperation("查询nft是否可转赠")
    public JsonResult<Void> canTransOrNo(String actualNftId){
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        boolean exist = redisService.hHasKey(RedisKeyFactory.getPrimaryUserIdKey(), currentUser.getUserId()+"");
        NftRecordVO vo = recordService.getRecordVOByActualNftIdAndUserId(Math.toIntExact(currentUser.getUserId()), actualNftId);

        if (vo==null) {
            throw new BusException("不存在的藏品");
        }

        NftMetadata metadata = metadataService.getByMetaId(vo.getMetaId()+"");
        NftSeriesClaim seriesClaim = seriesClaimService.getBySeriesId(metadata.getSeriesId());

        Integer rightLevel = currentUser.getUserDetails().getRightLevel();
        if (rightLevel==null) {
            rightLevel = 0;
        }

        Integer transferTime = null;

        if (seriesClaim.getTransferTime()!=null && seriesClaim.getTransferTime()>0) {
            transferTime = seriesClaim.getTransferTime();
        } else {
            transferTime = (Integer) redisService.hget(RedisKeyFactory.getLeadTimeKey(), "level"+rightLevel);
            if (transferTime==null) {
                transferTime = 40;
            }
        }

        if (env.contains("prod")) {
            transferTime = transferTime * 24 * 60;
        }

        Date now = new Date();
        Date buyTime = vo.getCreateTime();

        DateTime canTransferTime = DateUtil.offsetMinute(buyTime, transferTime);
        if (DateUtil.compare(canTransferTime,now)>0) {
            throw new BusException("未到规定转赠时间");
        }

        if (vo.getBuyStatus()==2) {
            throw new BusException("转赠失败\n请联系客服：400-046-3366");
        }
        return JsonResult.success();
    }
}
