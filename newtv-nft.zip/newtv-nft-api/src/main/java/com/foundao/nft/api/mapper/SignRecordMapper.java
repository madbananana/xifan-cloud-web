package com.foundao.nft.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.foundao.nft.common.model.SignRecord;
import org.apache.ibatis.annotations.Mapper;

/**
    @Package: com.foundao.nft.api.mapper
    @ClassName: SignRecordMapper
    @Author: chenli
    @CreateTime: 2022/9/23 4:40 下午
    @Description:
*/
@Mapper
public interface SignRecordMapper extends BaseMapper<SignRecord> {
}