package com.foundao.nft.api.service.impl;

import cn.hutool.core.util.IdUtil;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.toolkit.ChainWrappers;
import com.foundao.nft.common.constant.FoundaoConstant;
import com.foundao.nft.common.model.*;
import com.foundao.nft.common.model.sdk.request.NftBuyRequest;
import com.foundao.nft.common.model.vo.CollectionBrandAndIssuerInfoVO;
import com.foundao.nft.common.model.vo.RecipeCollectionDetailsVO;
import com.foundao.nft.common.model.vo.RecipeCollectionListVO;
import com.foundao.nft.common.model.vo.RecipeMaterialVO;
import com.foundao.nft.common.properties.NftProperties;
import com.foundao.nft.common.util.RedisKeyFactory;
import com.foundao.nft.common.util.SortUtil;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.exception.BusException;
import com.tx.redis.annotation.FdRedisCache;
import com.tx.redis.service.RedisLockService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.api.mapper.RecipeCollectionMapper;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

@Service
@RequiredArgsConstructor
@Transactional
public class RecipeCollectionService extends ServiceImpl<RecipeCollectionMapper, RecipeCollection> {

    private final RecipeMaterialService materialService;
    private final RedisLockService redisLockService;
    private final NftRecordService recordService;
    private final MergeService mergeService;
    private final NftMetadataService metadataService;
    private final NftIdHelper nftIdHelper;
    private final NftUserPlatformService userPlatformService;
    private final NftProperties nftProperties;
    private final NftOrderInteractionService orderInteractionService;

    @FdRedisCache(expireTime = 3,key = "'collectionList:'+#request.page+'-'+#request.num")
    public List<RecipeCollectionListVO> collectionList(BaseRequestVo request) {
        Page<RecipeCollectionListVO> page = new Page<>(request.getPage(),request.getNum());
        SortUtil.handlePageSort(request, page, "create_time", FoundaoConstant.ORDER_DESC,true);
        return baseMapper.collectionList(page);
    }

    @FdRedisCache(expireTime = 100,key = "'collectionDetails:'+#collectionId")
    public RecipeCollectionDetailsVO collectionDetails(Integer collectionId) {
        return baseMapper.collectionDetails(collectionId);
    }

    @Transactional(rollbackFor = Exception.class)
    public void merge(RecipeCollection collection,Integer userId) {
        //可能会并发更新，分布式锁方式防止订单重复更新
        String mergeLockKey = RedisKeyFactory.getMergeLockKey(collection.getMetaId());
        boolean lockSuccess = redisLockService.tryLock(mergeLockKey, 10);
        try {
            if (lockSuccess) {
                //查询原料信息
                List<RecipeMaterialVO> materials = materialService.listMaterialVOByUserNoCache(collection.getRecipeId(), userId);

                if (CollectionUtils.isEmpty(materials)) {
                    throw new BusException("配方原料设置异常");
                }

                Merge merge = new Merge();
                merge.setUserId(userId);
                merge.setCollectionId(collection.getCollectionId());
                merge.setRecipeId(collection.getRecipeId());
                merge.setStatus(0);
                merge.setMetaId(collection.getMetaId());
                mergeService.save(merge);

                materials.forEach( material -> {
                    if (material.getCount()>material.getOwnCount()) {
                        throw new BusException("藏品 "+ material.getMetaName() +" 份数不足");
                    }
                    int updateCount = recordService.updateMaterial(merge.getMergeId(),userId, material.getMetaId(), material.getCount());
                    if (updateCount!=material.getCount()) {
                        throw new BusException("藏品 "+ material.getMetaName() +" 份数不足");
                    }
                } );
                String actualNftId = lockStockAndBuy(collection.getMetaId(),userId,merge.getMergeId());
                decrementCollectionStock(collection.getCollectionId(),1);
            }
        } finally {
            if (lockSuccess) {
                redisLockService.unlock(mergeLockKey);
            }
        }

    }

    private String lockStockAndBuy(Integer metaId,Integer userId,Integer mergeId) {
        //利用分布式锁扣除库存
        String orderLockKey = RedisKeyFactory.getPlaceOrderLock(metaId+"");
        boolean isSuccess = redisLockService.tryLock(orderLockKey, 5);
        String actualNftId;
        NftMetadata newNftMetaData=null;
        if (isSuccess) {
            try {
                //查询库存
                newNftMetaData = metadataService.getById(metaId);
                //检查库存
                if (newNftMetaData.getShowCount() <= 0) {
                    throw new BusException("该藏品库存不足");
                }
                if (newNftMetaData.getRestCount() <= 0) {
                    throw new BusException("该藏品库存不足");
                }
                //减少库存
                boolean isUpdateSuccess = metadataService.reduceNftStock(newNftMetaData.getMetaId(), newNftMetaData.getVersion(), 1);
                if (!isUpdateSuccess) {
                    throw new BusException("生成订单出现异常,请重试");
                }
                //获取唯一的真实的nftId
                actualNftId = nftIdHelper.popActualNftId(newNftMetaData.getNftId());
                if(actualNftId == null){
                    throw new BusException("该作品已经售罄");
                }
            } finally {
                redisLockService.unlock(orderLockKey);
            }
        } else {
            throw new BusException("当前合成人数过多，请稍后再试");
        }
        //获取用户认证信息
        NftUserPlatform userPlatform = userPlatformService.getById(userId);
        NftBuyRequest request = new NftBuyRequest();
        request.setApplyScore(newNftMetaData.getSellCount());
        request.setNftId(actualNftId);
        request.setOfferCount(newNftMetaData.getSellCount());
        request.setOperateId(IdUtil.fastUUID());
        request.setPointReceiverAddr(userPlatform.getAddr());
        request.setReceiverPubKey(userPlatform.getPubkey());
        request.setPlatformPubKey(nftProperties.getPubKey());

        NftTask task;
        try {
            NftTask.NftBuyExtInfo extData = new NftTask.NftBuyExtInfo();
            extData.setNftId(actualNftId);
            extData.setMetaId(newNftMetaData.getMetaId());
            extData.setMetaType(4);
            extData.setUserId(userId);
            extData.setIsReplenish("merge");
            extData.setMergeId(mergeId);
            task = orderInteractionService.doBuyNft(request, userPlatform.getPrikey(), extData);
            if (task == null || task.getTaskId()==null) {
                throw new BusException("合成发生异常,上链异常");
            }
        } catch (Exception e) {
            log.error("", e);
            //更新库存
            metadataService.incrementNftStock(newNftMetaData.getMetaId(), 1);
            //释放redis zset的nft标记
            nftIdHelper.releaseNftFlag(newNftMetaData.getNftId(), actualNftId);
            throw new BusException("合成发生异常", e);
        }
        return actualNftId;
    }

    public CollectionBrandAndIssuerInfoVO getBrandAndIssuerInfo(Integer metaId) {
        return baseMapper.getBrandAndIssuerInfo(metaId);
    }

    /**
     * 增加活动库存
     * @param collectionId 活动id
     * @param count 增加库存数量
     * @return
     */
    public boolean incrementCollectionStock(Integer collectionId,int count){
        return  ChainWrappers.lambdaUpdateChain(baseMapper)
                .eq(RecipeCollection::getCollectionId, collectionId)
                .setSql("rest_merge_count=rest_merge_count+" + count)
                .update();
    }

    /**
     * 减少活动库存
     * @param collectionId 活动id
     * @param count 增加库存数量
     * @return
     */
    public boolean decrementCollectionStock(Integer collectionId,int count){
        return  ChainWrappers.lambdaUpdateChain(baseMapper)
                .eq(RecipeCollection::getCollectionId, collectionId)
                .setSql("rest_merge_count=rest_merge_count-" + count)
                .update();
    }
}
