package com.foundao.nft.api.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.IdUtil;
import cn.hutool.core.util.RandomUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.extension.toolkit.ChainWrappers;
import com.foundao.nft.api.mapper.NftOrderMapper;
import com.foundao.nft.api.mapper.OrderExtMapper;
import com.foundao.nft.api.service.OrderPostHandler;
import com.foundao.nft.api.vo.PayOrderInfoVo;
import com.foundao.nft.common.constant.FoundaoConstant;
import com.foundao.nft.common.constant.OrderStatusEnum;
import com.foundao.nft.common.constant.PayTypeEnum;
import com.foundao.nft.common.constant.RabbitmqConst;
import com.foundao.nft.common.model.*;
import com.foundao.nft.common.model.apple.AppleOrderItem;
import com.foundao.nft.common.model.mq.CreateOrderMqDto;
import com.foundao.nft.common.model.sdk.request.BasePayRequest;
import com.foundao.nft.common.model.sdk.request.NftBuyRequest;
import com.foundao.nft.common.model.sdk.request.WechatMiniPayRequest;
import com.foundao.nft.common.model.sdk.response.WechatAppPayData;
import com.foundao.nft.common.model.sdk.response.WechatMiniPayData;
import com.foundao.nft.common.model.vo.H5ActivityLevelInfoVO;
import com.foundao.nft.common.model.vo.NftOrderVo;
import com.foundao.nft.common.model.vo.UserVo;
import com.foundao.nft.common.properties.NftProperties;
import com.foundao.nft.common.properties.PayProperties;
import com.foundao.nft.common.util.RedisKeyFactory;
import com.foundao.nft.common.util.SortUtil;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.exception.BusException;
import com.tx.core.util.HttpRequestUtil;
import com.tx.core.util.RedisLuaScriptUtil;
import com.tx.redis.service.RedisLockService;
import com.tx.redis.service.RedisService;
import com.tx.security.bean.AuthUser;
import com.tx.security.util.SecurityUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.script.DefaultRedisScript;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * @Package: com.foundao.nft.api.service.impl
 * @ClassName: NftOrderService
 * @Author: chenli
 * @CreateTime: 2021/12/22 6:16 下午
 * @Description:
 */
@Service
@RequiredArgsConstructor
public class NftOrderService extends ServiceImpl<NftOrderMapper, NftOrder> {
    private static final Integer ORDER_EXPIRE_TIME = 300;
    @Autowired
    private NftProperties nftProperties;
    @Autowired
    private RedisLockService redisLockService;
    @Autowired
    private NftUserConnectionService connectionService;
    @Autowired
    private PayProperties payProperties;
    @Autowired
    private ConfigurableListableBeanFactory beanFactory;
    @Autowired
    private PayService payService;
    @Autowired
    private NftMetadataService nftMetadataService;
    @Autowired
    private NftSeriesClaimService seriesClaimService;
    @Autowired
    private RabbitTemplate rabbitTemplate;
    @Autowired
    private NftIdHelper nftIdHelper;
    @Autowired
    private OrderExtMapper orderExtMapper;
    @Autowired
    private NftUserPlatformService userPlatformService;
    @Autowired
    private NftOrderInteractionService orderInteractionService;
    @Autowired
    private RedisService redisService;
    @Autowired
    private NftUserService userService;
    @Autowired
    private IntegralService integralService;
    @Autowired
    private RedisTemplate<String,Object> redisTemplate;
    @Autowired
    private RecieveAddrService recieveAddrService;

    public NftOrder getByTradeNo(String out_trade_no) {
        return ChainWrappers.lambdaQueryChain(baseMapper)
                .eq(NftOrder::getTradeNo, out_trade_no)
                .one();
    }


    public NftOrderVo getOrderDetail(String tradeNo,Integer userId){
        return baseMapper.getOrderDetail(tradeNo,userId);
    }

    /**
     * 获取待支付的订单
     *
     * @param userId    用户id
     * @param productId 商品id
     * @return
     */
    public NftOrder getWaitPayOrder(Integer userId, Integer productId) {
        return baseMapper.getWaitPayOrder(userId, productId);
    }

    /**
     * 获取待支付的盲盒订单
     *
     * @param userId    用户id
     * @param shortSeriesId 商品id
     * @return
     */
    public NftOrder getWaitPayBlindBoxOrder(Integer userId, Integer shortSeriesId) {
        return baseMapper.getWaitPayBlindBoxOrder(userId, shortSeriesId);
    }

    /**
     * 更新扩展信息
     *
     * @param tradeNo    订单号
     * @param extendInfo 要更新的扩展信息
     */
    public void updateExtInfo(String tradeNo, String extendInfo) {
        NftOrder oriOrder = getByTradeNo(tradeNo);
        if(oriOrder == null){
            throw new BusException("无效的订单");
        }
        OrderExt orderExt = orderExtMapper.getOrderExByOrderTradeNo(tradeNo);
        OrderExt newOrderExt = new OrderExt();
        newOrderExt.setExtId(orderExt.getExtId());
        newOrderExt.setExtend(extendInfo);
        orderExtMapper.updateById(newOrderExt);

        NftOrder updateOrder = new NftOrder();
        updateOrder.setOrderId(oriOrder.getOrderId());
        updateOrder.setPayType(PayTypeEnum.APPLE_PAY.getCode());
        updateById(updateOrder);
    }

    /**
     * 生成订单号
     *  *** 订单号生成方式 固定串Ntv+用户id+时间+随机数
     * @return String 订单号
     */
    private String generateOrderNo(Integer userId) {
        return StrUtil.format("Ntv{}{}{}",userId,DateUtil.format(new Date(),"yyMMddHHmmss"), RandomUtil.randomInt(10,99));
    }

    /**
     * 获取订单列表
     * @param request 查询信息
     * @return List<NftOrder> 订单列表
     */
    public List<NftOrderVo> orderList(BaseRequestVo request) {
        Page<NftOrderVo> page = new Page<>(request.getPage(),request.getNum(),false);
        SortUtil.handlePageSort(request, page, "order_id", FoundaoConstant.ORDER_DESC, true);
        Page<NftOrderVo> nftOrderList = baseMapper.orderList(page,request);
        nftOrderList.getRecords().forEach(order -> {
            NftSeriesClaim nftSeriesClaim = seriesClaimService.getByIdCache(order.getShortSeriesId() + "");
            order.setCanIntegralBuy(nftSeriesClaim==null?0:nftSeriesClaim.getCanIntegralBuy());
            if (order.getOrderType()==11) {
                if (nftSeriesClaim!=null) {
                    order.setName(nftSeriesClaim.getSeriesName());
                    order.setDisplayUrl(nftSeriesClaim.getCoverUrl());
                    order.setUrl(nftSeriesClaim.getCoverUrl());
                }
            }
        });
        return nftOrderList.getRecords();
    }

    public NftOrderVo waiPayOrder(String shortSeriesId) {
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        return baseMapper.waiPayOrder(shortSeriesId,currentUser.getUserId());
    }

    /**
     * 填充公共信息
     * @param order     订单
     * @param request     请求信息
     */
    private void fillCommonPayRequest(NftOrder order,BasePayRequest request) {
        NftMetadata nftMetadata = null;
        NftSeriesClaim seriesClaim = null;
        if (order.getProductId()==null) {
            seriesClaim = seriesClaimService.getById(order.getShortSeriesId());
            request.setProduct_id("series-"+seriesClaim.getId());
            request.setBody(seriesClaim.getSeriesName());
        } else {
            nftMetadata = nftMetadataService.getById(order.getProductId());
            request.setProduct_id("nft-"+nftMetadata.getMetaId());
            request.setBody(nftMetadata.getName());
        }
        request.setOut_trade_no(order.getTradeNo());
        request.setFee(order.getFee());
        request.setFrmid("newtv");
        request.setExpire_time(ORDER_EXPIRE_TIME);
        request.setNotify_url(payProperties.getNotifyUrl());
        request.setUser_id(order.getUserId().toString());
    }

    /**
     *
     * @param order 订单信息
     * @param payType 支付类型
     * @param paySubType 支付类型子类
     * @return PayOrderInfoVo 各自第三方需要的订单信息
     */
    private PayOrderInfoVo generateOrderInfo(NftOrder order,String payType,String paySubType){
        if(paySubType == null) {
            paySubType = "app";
        }
        PayOrderInfoVo payOrderInfoVo = new PayOrderInfoVo();
        payOrderInfoVo.setTradeNo(order.getTradeNo());
        payOrderInfoVo.setCurPayType(payType);
        payOrderInfoVo.setPaySubType(paySubType);

        if(payType.equalsIgnoreCase(PayTypeEnum.ALI_PAY.getCode()) && paySubType.equalsIgnoreCase("app")){
            BasePayRequest request = new BasePayRequest();
            fillCommonPayRequest(order,request);
            request.setPath("awlsc");
            Map<String, Object> aliOrderInfo = payService.aliAppPay(request);
            payOrderInfoVo.setAliAppPayData(aliOrderInfo);
        } else if(payType.equalsIgnoreCase(PayTypeEnum.ALI_PAY.getCode()) && paySubType.equalsIgnoreCase("h5")){
            BasePayRequest request = new BasePayRequest();
            fillCommonPayRequest(order,request);
            request.setPath("awlsc");
            String aliOrderInfo = payService.aliH5Pay(request);
            payOrderInfoVo.setH5PayRequestUrl(aliOrderInfo);
        } else if(payType.equalsIgnoreCase(PayTypeEnum.WX_PAY.getCode()) && paySubType.equalsIgnoreCase("h5")){
            BasePayRequest request = new BasePayRequest();
            fillCommonPayRequest(order,request);
            request.setPath("newtv");
            String wechatH5PayData = payService.wechatH5Pay(request);
            payOrderInfoVo.setH5PayRequestUrl(wechatH5PayData);
        } else if(payType.equalsIgnoreCase(PayTypeEnum.WX_PAY.getCode()) && paySubType.equalsIgnoreCase("app")){
            BasePayRequest request = new BasePayRequest();
            fillCommonPayRequest(order,request);
            request.setPath("wlscapp");
            WechatAppPayData wechatAppPayData = payService.wechatAppPay(request);
            payOrderInfoVo.setWxAppPayData(wechatAppPayData);
        }else if(payType.equalsIgnoreCase(PayTypeEnum.WX_PAY.getCode()) && paySubType.equalsIgnoreCase("mini")){
            NftUserConnection connection = connectionService.getById(order.getUserId());
            WechatMiniPayRequest request = new WechatMiniPayRequest();
            fillCommonPayRequest(order,request);
            request.setPath("wlsc");
            request.setOpenid(connection.getSocialUserId());
            WechatMiniPayData wechatMiniPayData = payService.wechatMiniPay(request);
            payOrderInfoVo.setWxMiniPayData(wechatMiniPayData);
        }
        return payOrderInfoVo;
    }


    /**
     * 锁定库存
     *
     * @param nftMetadata nft元数据信息
     * @return 锁定的nftId
     */
    private String lockStock(NftMetadata nftMetadata) {
        //利用分布式锁扣除库存
        String orderLockKey = RedisKeyFactory.getPlaceOrderLock(nftMetadata.getNftId());
        boolean isSuccess = redisLockService.tryLock(orderLockKey, 5);
        String actualNftId;
        if (isSuccess) {
            try {
                //查询库存
                NftMetadata newNftMetaData = nftMetadataService.getById(nftMetadata.getMetaId());
                //检查库存
                if (newNftMetaData.getShowCount() <= 0) {
                    throw new BusException("该藏品库存不足");
                }
                if (newNftMetaData.getRestCount() <= 0) {
                    throw new BusException("该藏品库存不足");
                }
                //减少库存
                boolean isUpdateSuccess = nftMetadataService.reduceNftStock(nftMetadata.getMetaId(), newNftMetaData.getVersion(), 1);
                if (!isUpdateSuccess) {
                    throw new BusException("生成订单出现异常,请重试");
                }
                //获取唯一的真实的nftId
                actualNftId = nftIdHelper.popActualNftId(nftMetadata.getNftId());
                if(actualNftId == null){
                    throw new BusException("该作品已经售罄");
                }
            } finally {
                redisLockService.unlock(orderLockKey);
            }
        } else {
            throw new BusException("当前购买人数过多，请稍后再试");
        }
        return actualNftId;
    }

    /**
     * 锁定库存
     *
     * @param seriesClaim 系列申明信息
     * @return
     */
    private String lockStockBlindBox(NftSeriesClaim seriesClaim,Integer count) {
        //利用分布式锁扣除库存
        String orderLockKey = RedisKeyFactory.getPlaceOrderLock(seriesClaim.getId()+"");
        boolean isSuccess = redisLockService.tryLock(orderLockKey, 5);
        if (isSuccess) {
            try {
                //查询库存
                Integer num = (Integer) redisService.get(RedisKeyFactory.getSeriesStockKey(seriesClaim.getId()));
                if (num<count) {
                    throw new BusException("库存不足");
                }
                //减少库存
                Long restCount = redisService.decr(RedisKeyFactory.getSeriesStockKey(seriesClaim.getId()), Long.valueOf(count));
            } finally {
                redisLockService.unlock(orderLockKey);
            }
        } else {
            throw new BusException("当前购买人数过多，请稍后再试");
        }
        return "";
    }

    /**
     * 发送订单创建消息到消息队列
     *
     * @param order 订单
     */
    private void sendOrderCreatedToMq(NftOrder order) {
        //把此订单发送到消息队列的延迟队列中
        CreateOrderMqDto mqDto = CreateOrderMqDto.builder().orderId(order.getOrderId()).build();
        rabbitTemplate.convertAndSend(RabbitmqConst.CREATE_ORDER_DELAY_EXCHANGE, RabbitmqConst.CREATE_ORDER_DELAY_QUEUE, mqDto, message -> {
            message.getMessageProperties().setDelay((int) (order.getExpireTime() * 1000 - System.currentTimeMillis()));
            return message;
        });
    }

    /**
     * 创建订单
     * @param nftMetadata nft元信息
     * @param user 用户信息
     * @param isIap 是否内狗狗
     * @return Map
     */
    @Transactional(rollbackFor = Exception.class)
    public Map<String,Object> createOrder(NftMetadata nftMetadata, UserVo user,boolean isIap,Integer addrId) {
        Map<String, Object> res = new HashMap<>(3);
        NftSeriesClaim seriesClaim = seriesClaimService.getBySeriesId(nftMetadata.getSeriesId());
        //if (isIap && seriesClaim.getIosPayType()!=null && seriesClaim.getIosPayType()==0) {
        //    throw new BusException("支付类型不支持");
        //}
        if (seriesClaim.getIosPayType()!=null && seriesClaim.getIosPayType()==0) {
            isIap = false;
        }
        if (seriesClaim.getMetaType()==3) {
            throw new BusException("盲盒系列不能直接购买藏品");
        }
        if (nftMetadata.getMetaType()==4) {
            throw new BusException("合成款不参与售卖");
        }
        RecieveAddr recieveAddr = null;
        Integer defaultAddrId = null;
        res.put("hasAddr","NO");
        res.put("hasGoods","NO");
        if (seriesClaim.getHasGoods()!=null && seriesClaim.getHasGoods()==1) {
            res.put("hasGoods","YES");
            //if (addrId==null) {
            //    throw new BusException("请选择收货地址");
            //} else {
            //    recieveAddr = recieveAddrService.getById(addrId);
            //    if (recieveAddr==null || !Objects.equals(recieveAddr.getUserId(),user.getUserId())) {
            //        throw new BusException("收货地址信息错误");
            //    }
            //}
            recieveAddr = recieveAddrService.getPrimaryAddr(user.getUserId());
            if (recieveAddr!=null){
                defaultAddrId = recieveAddr.getAddrId();
                res.put("hasAddr","YES");
            }
        }
        res.put("isNew","YES");
        NftOrder waitPayOrder = getWaitPayOrder(user.getUserId(), nftMetadata.getMetaId());
        if (waitPayOrder != null) {
            res.put("tradeNo", waitPayOrder.getTradeNo());
            res.put("isNew","NO");
            //if (recieveAddr!=null && !Objects.equals(recieveAddr.getAddrId(),addrId)) {
            if (recieveAddr!=null){
                waitPayOrder.setAddrId(recieveAddr.getAddrId());
                updateById(waitPayOrder);
            }
            return res;
        }
        String tradeNo = generateOrderNo(user.getUserId());
        //锁定库存
        String actualNftId = lockStock(nftMetadata);
        //保存订单信息
        NftOrder order = new NftOrder();
        order.setProductId2(actualNftId);//存放真实nftId
        order.setTradeNo(tradeNo);
        order.setStatus(OrderStatusEnum.PAY_WAIT_PAYMENT.getCode());
        order.setProductId(nftMetadata.getMetaId());
        order.setUserId(user.getUserId());
        order.setPayType(isIap ? PayTypeEnum.APPLE_PAY.getCode() : "");
        order.setAppleGoodsId(isIap ? nftMetadata.getAppleName() : "" );
        //普通订单，非牛头订单
        order.setOrderType(1);
        order.setFee(nftMetadata.getSellFee());
        order.setOrderFee(nftMetadata.getSellFee());
        order.setIp(HttpRequestUtil.getClientIp());
        order.setExpireTime(System.currentTimeMillis() / 1000 + ORDER_EXPIRE_TIME);
        order.setShortSeriesId(seriesClaim.getId());
        if (recieveAddr!=null) {
            order.setAddrId(recieveAddr.getAddrId());
        }
        save(order);

        //订单扩展表
        OrderExt orderExt = new OrderExt();
        orderExt.setOrderId(order.getOrderId());
        String uuid = HttpRequestUtil.getHeader("uuid");
        String appVersion = HttpRequestUtil.getHeader("appVersion");
        String packageName = HttpRequestUtil.getHeader("packageName");
        orderExt.setUuid(uuid);
        orderExt.setAppVersion(appVersion);
        orderExt.setPackageName(packageName);
        orderExtMapper.insert(orderExt);

        //发送数据到消息队列,订单过期自动释放库存
        sendOrderCreatedToMq(order);
        res.put("tradeNo", order.getTradeNo());
        redisService.hincr(RedisKeyFactory.getNftBuyCountKey(nftMetadata.getMetaId()), user.getUserId()+ "",1);
        redisService.expire(RedisKeyFactory.getNftBuyCountKey(nftMetadata.getMetaId()),60*60*24*10L);
        return res;
    }

    /**
     * 订单支付
     * @param tradeNo 订单号
     * @param payType 支付类型
     * @param subPayType 子支付类型
     * @param user 用户信息
     * @return Object 订单信息
     */
    @Transactional(rollbackFor = Exception.class)
    public PayOrderInfoVo payOrder(String tradeNo,String payType,String subPayType,UserVo user){
        //1.获取订单信息
        NftOrder order = getByTradeNo(tradeNo);
        if(order == null
                || order.getExpireTime() < System.currentTimeMillis() / 1000
                || order.getIsAbandon() == 1
                || order.getUserId() != user.getUserId().intValue()
                || !OrderStatusEnum.isWaitPay(order.getStatus())
        ){
            throw new BusException("无效的订单信息");
        }
        OrderExt orderExt = orderExtMapper.getOrderExtByOrderId(order.getOrderId());

        //2.更新订单信息
        NftOrder updateOrderInfo = new NftOrder();
        updateOrderInfo.setOrderId(order.getOrderId());
//        updateOrderInfo.setStatus(OrderStatusEnum.PAYING.getCode());
        updateOrderInfo.setPayType(payType);
        updateById(updateOrderInfo);

        //3.判断该支付的类型是否存在待支付的第三方订单信息
        PayOrderInfoVo oriPayOrderInfo = null;
        if(StrUtil.isNotBlank(orderExt.getPayData())){
            oriPayOrderInfo = JSONUtil.toBean(orderExt.getPayData(), PayOrderInfoVo.class);
            if(oriPayOrderInfo.getCurPayType().equalsIgnoreCase(payType) && oriPayOrderInfo.getPaySubType().equalsIgnoreCase(subPayType)){
                return oriPayOrderInfo;
            }
        }
        //4.创建三方订单信息
        PayOrderInfoVo payOrderInfoVo = generateOrderInfo(order, payType, subPayType);
        payOrderInfoVo.mergePayOrderInfoVo(oriPayOrderInfo);

        OrderExt updateOrderExt = new OrderExt();
        updateOrderExt.setExtId(orderExt.getExtId());
        updateOrderExt.setPayData(JSONUtil.toJsonStr(payOrderInfoVo));
        orderExtMapper.updateById(updateOrderExt);
        NftSeriesClaim serviceByIdCache = seriesClaimService.getByIdCache(order.getShortSeriesId() + "");
        if (serviceByIdCache!=null && serviceByIdCache.getMetaType()==3) {
            payOrderInfoVo.setOpenTime(serviceByIdCache.getOpenTime());
        }
        return payOrderInfoVo;
    }



    /**
     * 查询用户是否支付头像订单
     *
     * @param userId 用户id
     * @return boolean
     */
    public boolean isPayHeadImage(Integer userId) {
        NftOrder order = baseMapper.getUserAvatarOrder(userId);
        return order != null && order.getStatus() == OrderStatusEnum.PAY_SUCCESS.getCode();
    }

    /**
     * 通过订单号和用户id获取订单信息
     *
     * @param userId  用户id
     * @param tradeNo 订单号
     * @return
     */
    public NftOrder getOrderByTradeNoAndUserId(Long userId, String tradeNo) {
        return ChainWrappers.lambdaQueryChain(baseMapper)
                .eq(NftOrder::getTradeNo, tradeNo)
                .eq(NftOrder::getUserId, userId)
                .one();
    }


    /**
     * 订单完成
     *
     * @param tradeNo      本系统订单号
     * @param orderStatus  订单状态
     * @param thirdTradeNo 三方交易流水订单号 ，如果交易失败，传空
     */
    @Transactional(rollbackFor = Exception.class)
    public boolean finishOrder(String tradeNo, Integer orderStatus, String thirdTradeNo){
        return finishOrder(tradeNo,orderStatus,thirdTradeNo,null);
    }


    /**
     * 订单完成
     * @param tradeNo      本系统订单号
     * @param orderStatus  订单状态
     * @param thirdTradeNo 三方交易流水订单号 ，如果交易失败，传空
     * @param appleOrderItem 苹果支付完成之后的数据信息，如果是微信或支付宝等支付此字段直接为空
     */
    @Transactional(rollbackFor = Exception.class)
    public boolean finishOrder(String tradeNo, Integer orderStatus, String thirdTradeNo, AppleOrderItem appleOrderItem) {
        //可能会并发更新，分布式锁方式防止订单重复更新
        String orderFinishLockKey = RedisKeyFactory.getOrderFinishLockKey(tradeNo);
        boolean lockSuccess = redisLockService.tryLock(orderFinishLockKey, 10);
        try {
            if (lockSuccess) {
                NftOrder oriOrder = getByTradeNo(tradeNo);
                if(oriOrder.getStatus() == OrderStatusEnum.PAY_SUCCESS.getCode()){
                    return true;
                }
                NftOrder newOrder = new NftOrder();
                newOrder.setOrderId(oriOrder.getOrderId());
                newOrder.setStatus(orderStatus);
                newOrder.setThirdTransactionId(thirdTradeNo);
                if(orderStatus == OrderStatusEnum.PAY_SUCCESS.getCode()){
                    if (oriOrder.getPayType().equals("INTEGRAL_PAY")) {
                        int price = (int) Math.ceil((oriOrder.getOrderFee()/100.0));
                        if (price==0) {
                            if (oriOrder.getOrderFee()>0) {
                                price=1;
                            }
                        }
                        newOrder.setIntegral(price);
                        newOrder.setFee(0);
                    }
                    if(appleOrderItem != null && appleOrderItem.getPurchaseDateMs() != null){
                        newOrder.setPayTime(new Date(appleOrderItem.getPurchaseDateMs()));
                        newOrder.setPayType(PayTypeEnum.APPLE_PAY.getCode());
                    }else{
                        newOrder.setPayTime(new Date());
                    }
                }
                baseMapper.updateById(newOrder);
                if (orderStatus == OrderStatusEnum.PAY_SUCCESS.getCode()) {
                    OrderPostHandler orderPostHandler = getOrderPostHandler(oriOrder.getOrderType());
                    //如果是苹果内购，并且是在订单取消之后，重新上传票据，那么特殊处理，重新分配库存
                    //if(oriOrder.getPayType().equals(PayTypeEnum.APPLE_PAY.getCode()) && oriOrder.getStatus() == OrderStatusEnum.PAY_CANCEL.getCode()){
                    //    recoverCancelOrder(oriOrder);
                    //}
                    //如果是在订单取消之后，那么特殊处理，重新分配库存
                    if(oriOrder.getStatus() == OrderStatusEnum.PAY_CANCEL.getCode()){
                        recoverCancelOrder(oriOrder);
                    }
                    if (orderPostHandler != null) {
                        orderPostHandler.handleOrderFinish(tradeNo, oriOrder.getOrderType());
                    }
                }
                return true;
            }
        } finally {
            if (lockSuccess) {
                redisLockService.unlock(orderFinishLockKey);
            }
        }
        return false;
    }

    /**
     * 恢复取消订单为支付完成的订单
     * @param oriOrder 原始订单
     */
    private void  recoverCancelOrder(NftOrder oriOrder){

        if (oriOrder.getOrderType()==11) {
            NftSeriesClaim seriesClaim = seriesClaimService.getById(oriOrder.getShortSeriesId());
            lockStockBlindBox(seriesClaim,oriOrder.getCount());
            NftOrder newOrder = new NftOrder();
            newOrder.setOrderId(oriOrder.getOrderId());
            baseMapper.updateById(newOrder);
        } else {
            NftMetadata nftMetadata = nftMetadataService.getById(oriOrder.getProductId());
            String nftId = lockStock(nftMetadata);
            if(nftId == null){
                throw new BusException("该藏品已经售罄,请联系客服");
            }
            NftOrder newOrder = new NftOrder();
            newOrder.setOrderId(oriOrder.getOrderId());
            newOrder.setProductId2(nftId);
            baseMapper.updateById(newOrder);
        }
    }

    /**
     * 获取订单处理器
     *
     * @param orderType 订单类型
     * @return OrderPostHandler
     */
    public OrderPostHandler getOrderPostHandler(Integer orderType) {
        String[] beanNames = beanFactory.getBeanNamesForType(OrderPostHandler.class, false, false);
        for (String beanName : beanNames) {
            OrderPostHandler handler = beanFactory.getBean(beanName, OrderPostHandler.class);
            if (handler.supportOrderType(orderType)) {
                return handler;
            }
        }
        return null;
    }

    /**
     * 免费领取
     *
     * @param nftMetadata nft信息
     * @param user        用户信息
     */
    public NftTask freeAccess(NftMetadata nftMetadata, UserVo user) {
        String actualNftId = lockStock(nftMetadata);
        NftSeriesClaim seriesClaim = seriesClaimService.getByIdCache(nftMetadata.getShortSeriesId()+"");
        //获取用户认证信息
        NftUserPlatform userPlatform = userPlatformService.getById(user.getUserId());
        NftBuyRequest request = new NftBuyRequest();
        request.setApplyScore(1);
        request.setNftId(actualNftId);
        request.setOfferCount(1);
        request.setOperateId(IdUtil.fastUUID());
        request.setPointReceiverAddr(userPlatform.getAddr());
        request.setReceiverPubKey(userPlatform.getPubkey());
        request.setPlatformPubKey(nftProperties.getPubKey());

        NftTask task;
        try {
            NftTask.NftBuyExtInfo extData = new NftTask.NftBuyExtInfo();
            extData.setNftId(actualNftId);
            extData.setMetaId(nftMetadata.getMetaId());
            extData.setMetaType(1);
            extData.setUserId(user.getUserId());
            extData.setShortSeriesId(seriesClaim!=null?seriesClaim.getId():null);
            task = orderInteractionService.doBuyNft(request, userPlatform.getPrikey(), extData);
            if (task == null || task.getTaskId()==null) {
                throw new BusException("领取发生异常,上链异常");
            }
        } catch (Exception e) {
            log.error("", e);
            //更新库存
            nftMetadataService.incrementNftStock(nftMetadata.getMetaId(), 1);
            //释放redis zset的nft标记
            nftIdHelper.releaseNftFlag(nftMetadata.getNftId(), actualNftId);
            throw new BusException("领取发生异常", e);
        }
        return task;
    }

    /**
     * 创建免费订单
     *
     * @param userId      用户id
     * @param metaId      nft的metaId
     * @param actualNftId 实际的nftId
     * @param txHash      交易hash
     */
    public void createFreeOrder(Integer userId, Integer metaId, String actualNftId, String txHash,Integer shortSeriesId) {
        NftOrder order = new NftOrder();
        order.setUserId(userId);
        order.setOrderType(1);
        order.setStatus(2);
        order.setFee(0);
        order.setOrderFee(0);
        order.setMsg("免费领取");
        order.setProductId(metaId);
        order.setProductId2(actualNftId);
        order.setIp(HttpRequestUtil.getClientIp());
        Date date = new Date();
        order.setCreateTime(date);
        order.setCreateTime(date);
        order.setPayType(PayTypeEnum.FREE_ACCESS.getCode());
        order.setTxHash(txHash);
        order.setShortSeriesId(shortSeriesId);
        save(order);
        //订单扩展表
        OrderExt orderExt = new OrderExt();
        orderExt.setOrderId(order.getOrderId());
        orderExtMapper.insert(orderExt);
        //List<Integer> list = (List<Integer>) redisService.get(RedisKeyFactory.getStarMetaIdKey());
        //if (list!=null) {
        //    if (list.contains(metaId)) {
        //        userService.addRightUser(userId+"",metaId);
        //    }
        //}
    }

    /**
     * 创建补发订单
     *
     * @param userId      用户id
     * @param metaId      nft的metaId
     * @param actualNftId 实际的nftId
     * @param txHash      交易hash
     */
    public void createReplenishOrder(Integer userId, Integer metaId, String actualNftId, String txHash,Integer shortSeriesId,String isReplenish) {
        NftOrder order = new NftOrder();
        order.setUserId(userId);
        order.setOrderType(1);
        order.setStatus(2);
        order.setFee(0);
        order.setOrderFee(0);
        order.setMsg(isReplenish);
        order.setProductId(metaId);
        order.setProductId2(actualNftId);
        order.setIp(HttpRequestUtil.getClientIp());
        Date date = new Date();
        order.setCreateTime(date);
        order.setCreateTime(date);
        order.setPayType(PayTypeEnum.FREE_ACCESS.getCode());
        order.setShortSeriesId(shortSeriesId);
        order.setTxHash(txHash);
        save(order);
        //订单扩展表
        OrderExt orderExt = new OrderExt();
        orderExt.setOrderId(order.getOrderId());
        orderExtMapper.insert(orderExt);
    }


    public NftOrder getByNoTradeNo(Long userId, String appleGoodsId, String payTime) {
        NftOrder order = ChainWrappers.lambdaQueryChain(baseMapper)
                .eq(NftOrder::getUserId, userId)
                .eq(NftOrder::getAppleGoodsId, appleGoodsId)
                .eq(NftOrder::getPayType,"APPLE_PAY")
                .ne(NftOrder::getStatus, OrderStatusEnum.PAY_SUCCESS.getCode())
                .lt(NftOrder::getCreateTime, payTime)
                .orderByDesc(NftOrder::getCreateTime)
                .last("limit 1")
                .one();
        //if (order.getStatus() == OrderStatusEnum.PAY_CANCEL.getCode()) {
        //    NftMetadata metadata = nftMetadataService.getById(order.getProductId());
        //    String actualNftId = lockStock(metadata);
        //    order.setProductId2(actualNftId);
        //}
        return order;
    }

    /**
     * 创建订单
     * @param seriesClaim 系列申明
     * @param user 用户信息
     * @param isIap 是否内狗狗
     * @return Map
     */
    @Transactional(rollbackFor = Exception.class)
    public Map<String,Object> createBlindBoxOrder(NftSeriesClaim seriesClaim, UserVo user,boolean isIap,Integer count,Integer addrId) {
        Map<String, Object> res = new HashMap<>(3);
        RecieveAddr recieveAddr = null;
        Integer defaultAddrId = null;
        res.put("hasAddr","NO");
        res.put("hasGoods","NO");
        if (seriesClaim.getHasGoods()!=null && seriesClaim.getHasGoods()==1) {
            res.put("hasGoods","YES");
            //if (addrId==null) {
            //    throw new BusException("请选择收货地址");
            //} else {
            //    recieveAddr = recieveAddrService.getById(addrId);
            //    if (recieveAddr==null || !Objects.equals(recieveAddr.getUserId(),user.getUserId())) {
            //        throw new BusException("收货地址信息错误");
            //    }
            //}
            recieveAddr = recieveAddrService.getPrimaryAddr(user.getUserId());
            if (recieveAddr!=null) {
                defaultAddrId = recieveAddr.getAddrId();
                res.put("hasAddr","YES");
            }
        }
        //if (isIap && seriesClaim.getIosPayType()!=null && seriesClaim.getIosPayType()==0) {
        //    throw new BusException("支付类型不支持");
        //}
        if (seriesClaim.getIosPayType()!=null && seriesClaim.getIosPayType()==0) {
            isIap = false;
        }
        res.put("isNew","YES");
        NftOrder waitPayOrder = getWaitPayBlindBoxOrder(user.getUserId(), seriesClaim.getId());
        if (waitPayOrder != null) {
            res.put("tradeNo", waitPayOrder.getTradeNo());
            res.put("isNew","NO");
            waitPayOrder.setAddrId(defaultAddrId);
            updateById(waitPayOrder);
            return res;
        }
//        if (isIap) {
//            NftOrder waitPayOrder = getWaitPayBlindBoxOrder(user.getUserId(), seriesClaim.getId());
//            if (waitPayOrder != null) {
//                res.put("tradeNo", waitPayOrder.getTradeNo());
//                res.put("isNew","NO");
//                return res;
//            }
//        }

        String tradeNo = generateOrderNo(user.getUserId());
        //锁定库存
        lockStockBlindBox(seriesClaim,count);
        //保存订单信息
        NftOrder order = new NftOrder();
        order.setTradeNo(tradeNo);
        order.setCount(count);
        order.setOrderType(11);
        order.setShortSeriesId(seriesClaim.getId());
        order.setStatus(OrderStatusEnum.PAY_WAIT_PAYMENT.getCode());
        order.setUserId(user.getUserId());
        order.setPayType(isIap ? PayTypeEnum.APPLE_PAY.getCode() : "");
        order.setAppleGoodsId(isIap ? seriesClaim.getAppleName() : "" );
        //普通订单，非牛头订单
        order.setOrderType(11);
        order.setFee(seriesClaim.getPrice()*count);
        order.setOrderFee(seriesClaim.getPrice()*count);
        order.setIp(HttpRequestUtil.getClientIp());
        order.setExpireTime(System.currentTimeMillis() / 1000 + ORDER_EXPIRE_TIME);
        if (recieveAddr!=null) {
            order.setAddrId(recieveAddr.getAddrId());
        }
        save(order);

        //订单扩展表
        OrderExt orderExt = new OrderExt();
        orderExt.setOrderId(order.getOrderId());
        String uuid = HttpRequestUtil.getHeader("uuid");
        String appVersion = HttpRequestUtil.getHeader("appVersion");
        String packageName = HttpRequestUtil.getHeader("packageName");
        orderExt.setUuid(uuid);
        orderExt.setAppVersion(appVersion);
        orderExt.setPackageName(packageName);
        orderExtMapper.insert(orderExt);

        //发送数据到消息队列,订单过期自动释放库存
        sendOrderCreatedToMq(order);
        res.put("tradeNo", order.getTradeNo());
        redisService.hincr(RedisKeyFactory.getBuyCountKey(seriesClaim.getId()), user.getUserId()+ "",count);
        redisService.expire(RedisKeyFactory.getBuyCountKey(seriesClaim.getId()),60*60*24*10L);
        return res;
    }

    public Map<String,String> lockActualNftStock(NftOrder order){
        //利用分布式锁扣除库存
        String orderLockKey = RedisKeyFactory.getPlaceOrderLock(order.getShortSeriesId()+"");
        boolean isSuccess = redisLockService.tryLock(orderLockKey, 5);
        Map<String,String> actualNftIds;
        if (isSuccess) {
            try {

                //获取唯一的真实的nftId
                actualNftIds = nftIdHelper.popBlindBoxActualNftId(order.getShortSeriesId() + "", order.getCount());
                if(actualNftIds == null){
                    log.error("盲盒库存不足");
                }
                if (actualNftIds==null || actualNftIds.size()==0) {
                    throw new BusException("生成订单出现异常,请重试");
                }
                actualNftIds.forEach((nftId,metaId) -> {
                    //减少库存
                    boolean isUpdateSuccess = nftMetadataService.reduceNftStock(Integer.valueOf(metaId), null, 1);
                    if (!isUpdateSuccess) {
                        throw new BusException("生成订单出现异常,请重试");
                    }
                } );
            } finally {
                redisLockService.unlock(orderLockKey);
            }
        } else {
            throw new BusException("当前购买人数过多，请稍后再试");
        }
        return actualNftIds;
    }

    /**
     * 积分支付
     * @param tradeNo
     * @param payType
     * @param app
     * @param user
     */
    @Transactional(rollbackFor = Exception.class)
    public void integralPay(String tradeNo, String payType, String app, UserVo user) {

        //0.获取订单信息
        NftOrder order = getByTradeNo(tradeNo);
        if(order == null
                || order.getExpireTime() < System.currentTimeMillis() / 1000
                || order.getIsAbandon() == 1
                || order.getUserId() != user.getUserId().intValue()
                || !OrderStatusEnum.isWaitPay(order.getStatus())
        ){
            throw new BusException("无效的订单信息");
        }

        NftSeriesClaim seriesClaim = seriesClaimService.getByIdCache(order.getShortSeriesId()+"");

        if (seriesClaim.getCanIntegralBuy()==null || seriesClaim.getCanIntegralBuy()==0) {
            throw new BusException("该藏品不支持积分兑换");
        }

        String totalBuyCountKey = RedisKeyFactory.totalIntegralBuyCountKey(seriesClaim.getId());
        Integer totalBuyCount = (Integer)redisService.get(totalBuyCountKey);
        if (totalBuyCount==null) {
            totalBuyCount=0;
        }
        //用户购买总次数限制
        Integer totalBuyCountLimit = (Integer) redisService.hget(RedisKeyFactory.getIntegralKey(), "integralBuyCountLimit");;
        if (totalBuyCountLimit==null) {
            totalBuyCountLimit = 30;
        }
        if(totalBuyCount >= totalBuyCountLimit){
            //剩余投票数量
            throw new BusException("每个系列的藏品最多使用积分兑换"+totalBuyCountLimit+"份");
        }
        if (totalBuyCount + order.getCount() > totalBuyCountLimit) {
            //剩余投票数量
            throw new BusException("每个系列的藏品最多使用积分兑换"+totalBuyCountLimit+"份");
        }


        //当前用户积分兑换次数
        String buyCountKey = RedisKeyFactory.integralBuyCountKey(seriesClaim.getId(),user.getUserId());
        Integer todayBuyCount = (Integer)redisService.get(buyCountKey);
        todayBuyCount = todayBuyCount == null ? 0 : todayBuyCount;
        //用户购买总次数限制
        Integer singleIntegralBuyCountLimit = (Integer) redisService.hget(RedisKeyFactory.getIntegralKey(), "singleIntegralBuyCountLimit");;
        if (singleIntegralBuyCountLimit==null) {
            singleIntegralBuyCountLimit = 10;
        }
        if(todayBuyCount >= singleIntegralBuyCountLimit){
            //剩余投票数量
            throw new BusException("每个系列的藏品最多使用积分兑换"+singleIntegralBuyCountLimit+"份");
        }
        if (todayBuyCount + order.getCount() > singleIntegralBuyCountLimit) {
            //剩余投票数量
            throw new BusException("每个系列的藏品最多使用积分兑换"+singleIntegralBuyCountLimit+"份");
        }

        //每天限制购买几次，通过lua脚本执行
        long currentDayRestTime = (DateUtil.offsetDay(new Date(),20).getTime() - System.currentTimeMillis()) / 1000;
        DefaultRedisScript<Long> buyCountLuaScript = new DefaultRedisScript<>();
        buyCountLuaScript.setScriptSource(RedisLuaScriptUtil.getScriptSourceByScriptName("integral"));
        buyCountLuaScript.setResultType(Long.class);

        //1.查询用户积分
        Integral integral = integralService.getById(user.getUserId());
        int price = (int) Math.ceil((order.getOrderFee()/100.0));
        if (price==0) {
            if (order.getOrderFee()>0) {
                price=1;
            }
        }
        if (price>integral.getUsableIntegral()) {
            throw new BusException("积分不足");
        }

        //2.更新订单信息
        NftOrder updateOrderInfo = new NftOrder();
        updateOrderInfo.setOrderId(order.getOrderId());
        updateOrderInfo.setPayType(payType);
        updateById(updateOrderInfo);
        integralService.frozen(order.getUserId(),price);
        boolean flag = finishOrder(order.getTradeNo(), OrderStatusEnum.PAY_SUCCESS.getCode(), "integralPay" + order.getOrderId());
        if (!flag) {
            integralUnfrozen(order.getUserId(),price);
        } else {
            redisTemplate.execute(buyCountLuaScript, CollUtil.newArrayList(buyCountKey,totalBuyCountKey), currentDayRestTime,order.getCount());
        }
    }

    public void integralUnfrozen(Integer userId,Integer integral){
        integralService.unfrozen(userId,integral);
    }

    public void integralOperation(Integer userId,String sourceId,String sourceType,String symbol,Integer count,String remark,String date){
        integralService.integralOperation(userId,sourceId,sourceType,symbol,count,remark,date);
    }

    /**
     * 兑换码兑换
     * @param nftMetadata
     * @param user
     */
    public String exchange(NftMetadata nftMetadata, UserVo user) {
        String actualNftId = lockStock(nftMetadata);
        //获取用户认证信息
        NftUserPlatform userPlatform = userPlatformService.getById(user.getUserId());
        NftBuyRequest request = new NftBuyRequest();
        request.setApplyScore(nftMetadata.getSellCount());
        request.setNftId(actualNftId);
        request.setOfferCount(nftMetadata.getSellCount());
        request.setOperateId(IdUtil.fastUUID());
        request.setPointReceiverAddr(userPlatform.getAddr());
        request.setReceiverPubKey(userPlatform.getPubkey());
        request.setPlatformPubKey(nftProperties.getPubKey());

        NftTask task;
        try {
            NftTask.NftBuyExtInfo extData = new NftTask.NftBuyExtInfo();
            extData.setNftId(actualNftId);
            extData.setMetaId(nftMetadata.getMetaId());
            extData.setMetaType(1);
            extData.setUserId(user.getUserId());
            extData.setIsReplenish("exchange");
            task = orderInteractionService.doBuyNft(request, userPlatform.getPrikey(), extData);
            if (task == null || task.getTaskId()==null) {
                throw new BusException("领取发生异常,上链异常");
            }
        } catch (Exception e) {
            log.error("", e);
            //更新库存
            nftMetadataService.incrementNftStock(nftMetadata.getMetaId(), 1);
            //释放redis zset的nft标记
            nftIdHelper.releaseNftFlag(nftMetadata.getNftId(), actualNftId);
            throw new BusException("领取发生异常", e);
        }
        return actualNftId;
    }

}
