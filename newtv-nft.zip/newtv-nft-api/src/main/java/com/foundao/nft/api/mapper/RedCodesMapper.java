package com.foundao.nft.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.foundao.nft.common.model.RedCodes;
import org.apache.ibatis.annotations.Mapper;

/**
    @Package: com.foundao.nft.api.mapper
    @ClassName: RedCodesMapper
    @Author: chenli
    @CreateTime: 2022/11/23 9:47 AM
    @Description:
*/
@Mapper
public interface RedCodesMapper extends BaseMapper<RedCodes> {
}