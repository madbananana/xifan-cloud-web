package com.foundao.nft.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.foundao.nft.common.model.ExchangeCode;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ExchangeCodeMapper extends BaseMapper<ExchangeCode> {
}