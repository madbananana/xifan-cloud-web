package com.foundao.nft.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.api.vo.NftInfoVO;
import com.foundao.nft.common.model.Goods;
import com.foundao.nft.common.model.NftMetadata;
import com.tx.redis.annotation.FdRedisCache;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface NftMetadataMapper extends BaseMapper<NftMetadata> {


    List<NftInfoVO> listNftInfo(@Param("seriesId") String seriesId,@Param("isBlindBox") boolean isBlindBox);

    NftInfoVO firstNftInfo(String seriesId);

    NftInfoVO nftInfo(@Param("nftId") String nftId);

    Integer countRestCount(@Param("seriesId") String seriesId);

    @Select("select g.* from nft_metadata nm join nft_series_claim as nsc on nm.series_id=nsc.series_id join nft_goods as g on nsc.goods_id=g.id where nm.nft_id=#{nftId}")
    Goods getRelateGoodsByNftId(String nftId);

    Integer countShowRestCount(@Param("seriesId") String seriesId);

    IPage<NftInfoVO> pageNftInfoBySeriesId(Page<NftInfoVO> page,@Param("seriesId") String seriesId);
}
