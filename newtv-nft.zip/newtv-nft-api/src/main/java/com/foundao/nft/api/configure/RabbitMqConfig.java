package com.foundao.nft.api.configure;

import com.foundao.nft.common.constant.RabbitmqConst;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.*;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;

@Slf4j
@Configuration
public class RabbitMqConfig {

    /**
     * 延迟队列
     */
    @Bean
    public Queue createOrderQueue() {
        return new Queue(RabbitmqConst.CREATE_ORDER_DELAY_QUEUE, true);
    }

    /**
     * 延迟队列
     */
    @Bean
    public Queue appointmentMessageQueue() {
        return new Queue(RabbitmqConst.APPOINTMENT_MESSAGE_DELAY_QUEUE, true);
    }

    /**
     * 转赠超时延迟队列
     */
    @Bean
    public Queue transferCancelQueue() {
        return new Queue(RabbitmqConst.TRANSFER_CANCEL_DELAY_QUEUE, true);
    }

    /**
     * 延迟队列交换器, x-delayed-type 和 x-delayed-message 固定
     */
    @Bean
    public CustomExchange createOrderExchange() {
        Map<String, Object> args = new HashMap<>();
        args.put("x-delayed-type", "direct");
        return new CustomExchange(RabbitmqConst.CREATE_ORDER_DELAY_EXCHANGE, "x-delayed-message", true, false, args);
    }

    /**
     * 延迟队列绑定自定义交换器
     *
     * @param delayQueue    队列
     * @param delayExchange 延迟交换器
     */
    @Bean
    public Binding createOrderDelayBinding(@Qualifier("createOrderQueue") Queue delayQueue, CustomExchange delayExchange) {
        return BindingBuilder.bind(delayQueue).to(delayExchange).with(RabbitmqConst.CREATE_ORDER_DELAY_QUEUE).noargs();
    }

    /**
     * 延迟队列绑定自定义交换器
     *
     * @param delayQueue    队列
     * @param delayExchange 延迟交换器
     */
    @Bean
    public Binding appointmentMessageQueueDelayBinding(@Qualifier("appointmentMessageQueue") Queue delayQueue, CustomExchange delayExchange) {
        return BindingBuilder.bind(delayQueue).to(delayExchange).with(RabbitmqConst.APPOINTMENT_MESSAGE_DELAY_QUEUE).noargs();
    }

    /**
     * 延迟队列绑定自定义交换器
     *
     * @param delayQueue    队列
     * @param delayExchange 延迟交换器
     */
    @Bean
    public Binding transferCancelQueueDelayBinding(@Qualifier("transferCancelQueue") Queue delayQueue, CustomExchange delayExchange) {
        return BindingBuilder.bind(delayQueue).to(delayExchange).with(RabbitmqConst.TRANSFER_CANCEL_DELAY_QUEUE).noargs();
    }
}
