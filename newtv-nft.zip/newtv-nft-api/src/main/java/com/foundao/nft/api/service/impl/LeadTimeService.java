package com.foundao.nft.api.service.impl;

import com.foundao.nft.common.util.RedisKeyFactory;
import com.tx.core.beans.JsonResult;
import com.tx.core.enums.errcode.ParamErrorEnum;
import com.tx.redis.service.RedisService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/**
 * @Package: com.foundao.nft.api.service.impl
 * @ClassName: LeadTimeService
 * @Author: chenli
 * @CreateTime: 2022/6/23 11:30 上午
 * @Description:
 */
@Service
@RequiredArgsConstructor
public class LeadTimeService {

    private final RedisService redisService;

    public Integer getLeadTimeOffset(Integer userId,Integer categoryId,String seriesId){
        Integer totalTimeOffset = 0;

        Integer categoryMetaId = (Integer) redisService.hget(RedisKeyFactory.getCategoryMetaIdKey(), categoryId + "");
        if (categoryMetaId!=null) {
//            Boolean exist = redisService.sHasKey(RedisKeyFactory.getAboriginesKey(categoryMetaId+""),userId+"");
            Boolean exist = redisService.hHasKey(RedisKeyFactory.getStarUserIdKey(categoryMetaId), userId + "");
            if (exist) {
                Integer adLeadTime = (Integer) redisService.hget(RedisKeyFactory.getLeadTimeKey(), "adLeadTime");
                if (adLeadTime!=null) {
                    totalTimeOffset += adLeadTime;
                }

            }
        }
        if (seriesId!=null) {
            Integer flag = (Integer) redisService.hget(RedisKeyFactory.getAppointmentKey(seriesId), userId + "");
            if (flag !=null) {
                Integer leadTime = (Integer) redisService.hget(RedisKeyFactory.getLeadTimeKey(), "leadTime");
                if (leadTime!=null)
                    totalTimeOffset += leadTime;
            }
        }
        return totalTimeOffset;
    }
}
