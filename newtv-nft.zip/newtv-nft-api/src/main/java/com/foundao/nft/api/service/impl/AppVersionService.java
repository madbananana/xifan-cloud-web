package com.foundao.nft.api.service.impl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.api.mapper.AppVersionMapper;
import com.foundao.nft.common.model.AppVersion;

/**
 * @Package: com.foundao.nft.api.service.impl
 * @ClassName: AppVersionService
 * @Author: chenli
 * @CreateTime: 2022/4/29 6:14 下午
 * @Description:
 */
@Service
public class AppVersionService extends ServiceImpl<AppVersionMapper, AppVersion> {

}

