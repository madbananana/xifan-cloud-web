package com.foundao.nft.api.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.common.model.vo.UserVo;
import com.tx.core.beans.BaseRequestVo;
import com.tx.security.bean.AuthUser;
import com.tx.security.util.SecurityUtil;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.common.model.IntegralRecord;
import com.foundao.nft.api.mapper.IntegralRecordMapper;
@Service
public class IntegralRecordService extends ServiceImpl<IntegralRecordMapper, IntegralRecord> {

    public List<IntegralRecord> pageIntegral(BaseRequestVo request) {
        Page<IntegralRecord> page = new Page<>(request.getPage(),request.getNum(),false);
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        List<IntegralRecord> list = baseMapper.pageIntegral(page,currentUser.getUserId());
        return list;
    }
}
