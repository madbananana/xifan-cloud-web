package com.foundao.nft.api.service.impl;

import cn.hutool.core.bean.BeanUtil;
import cn.hutool.core.date.DatePattern;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.crypto.SecureUtil;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.toolkit.ChainWrappers;
import com.foundao.nft.common.model.Invite;
import com.foundao.nft.common.model.NftRecord;
import com.foundao.nft.common.model.SignRecord;
import com.foundao.nft.common.model.vo.UserVo;
import com.foundao.nft.common.model.NewtvEmp;
import com.foundao.nft.common.model.NftUserConnection;
import com.foundao.nft.common.model.vo.NftUserVO;
import com.foundao.nft.common.util.RedisKeyFactory;
import com.tx.core.beans.JsonResult;
import com.tx.core.enums.errcode.ApiStatusErrorEnum;
import com.tx.core.exception.BusException;
import com.tx.core.util.HttpRequestUtil;
import com.tx.redis.service.RedisService;
import com.tx.security.bean.AuthUser;
import com.tx.security.bean.JwtUserDto;
import com.tx.security.service.OnlineUserService;
import com.tx.security.util.SecurityUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import javax.servlet.http.HttpServlet;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.api.mapper.NftUserMapper;
import com.foundao.nft.common.model.NftUser;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

/**
    @Package: com.foundao.nft.api.service.impl
    @ClassName: NftUserService
    @Author: chenli
    @CreateTime: 2021/12/20 11:41 上午
    @Description:
*/
@Service
@Transactional
@RequiredArgsConstructor
@Slf4j
public class NftUserService extends ServiceImpl<NftUserMapper, NftUser> {

    private final NftUserConnectionService connectionService;
    private final OnlineUserService onlineUserService;
    private final NewtvEmpService empService;
    private final RedisService redisService;
    private final InviteService inviteService;
    private final SignRecordService signRecordService;
    private final RedisTemplate<String,Object> redisTemplate;
    private final NftRecordService recordService;
    private final SensorsAnalyticsService sensorsAnalyticsService;
    public NftUser findUserByMobile(String mobile){
        return this.baseMapper.findUserByMobile(mobile);
    }

    public NftUser findUserBySocial(String source,String uuid){
        return this.baseMapper.findUserBySocial(source,uuid);
    }

    public NftUser findUserByUserName(String username){
        return this.baseMapper.findUserByUserName(username);
    }

    public NftUser findUser( String from, String username) {
        if (from!=null && "username".equals(from)) {
            return findUserByUserName(username);
        }
        if (from!=null) {
            return findUserBySocial(from,username);
        } else {
            return findUserByMobile(username);
        }
    }

    /**
     * 三方用户登录
     * @param username 用户名
     * @param nickname 昵称
     * @param avatar 头像
     * @param from 来源
     */
    public NftUser thirdUserLogin(String username, String nickname, String avatar, String from){
        NftUser oldUser = findUserBySocial(from,username);
        //2.如果用户不存在，新增用户，用户存在则更新用户
        if (oldUser == null) {
            return registerThirdUser(username, nickname, avatar, from);
        } else {
            oldUser.setUpdateTime(new Date());
            updateById(oldUser);
        }
        return oldUser;
    }

    /**
     * 注册三方登录用户
     * @param userName 用户名
     * @param nickname 昵称
     * @param avatar 头像
     * @param from 来源
     * @return 用户对象
     */
    @Transactional(rollbackFor = Exception.class)
    public NftUser registerThirdUser(String userName,String nickname,String avatar,String from){
        NftUser user = new NftUser();
        user.setUserName(userName);
        //user.setNickName(nickname);
        //if (nickname.length()>=4) {
        //    user.setNickName("用户"+nickname.substring(nickname.length()-4));
        //}
        user.setAvatar(avatar);
        user.setCreateTime(new Date());
        save(user);
        NftUserConnection connection = NftUserConnection.builder()
                .socialType(from)
                .socialUserId(userName)
                .userId(user.getUserId())
                .build();
        connectionService.save(connection);
        return user;
    }

    /**
     * 手机号用户登录
     * @param mobile 用户名
     */
    public NftUser mobileUserLogin(String mobile){
        NftUser user = findUserByMobile(mobile);
        //2.如果用户不存在，新增用户，用户存在则更新用户
        if (user == null) {
            return registerMobileUser(mobile,null);
        }
        return user;
    }

    public NftUser registerMobileUser(String mobile,Integer inviteCode) {
        NftUser user = new NftUser();
        user.setUserName(mobile);
        //user.setNickName(mobile);
        if(mobile.length()>=4) {
            user.setNickName("用户"+mobile.substring(mobile.length()-4));
        }
        user.setMobile(mobile);
        Date regTime = new Date();
        user.setCreateTime(regTime);
        NftUser inviteUser = null;
        if (inviteCode!=null) {
            inviteUser = lambdaQuery()
                    .eq(NftUser::getInviteCode, inviteCode)
                    .last("limit 1")
                    .one();
            if (inviteUser!=null) {
                user.setInviteUserId(inviteUser.getUserId());
            }

        }
        save(user);
        if (inviteUser!=null) {
            Invite invite = new Invite();
            invite.setAuth(0);
            invite.setInviteMobile(inviteUser.getMobile());
            invite.setInviteNickName(inviteUser.getNickName());
            invite.setInviteUserId(inviteUser.getUserId());
            invite.setUserId(user.getUserId());
            invite.setMobile(user.getMobile());
            invite.setNickName(user.getNickName());
            invite.setRegTime(DateUtil.formatDateTime(regTime));
            inviteService.save(invite);
        }
        sensorsAnalyticsService.signUpEvent(user.getUserId()+"",true,"", user.getMobile());
        return user;
    }

    public void bindMobileUser(NftUser user, String userName, String oldUserId) {
        ChainWrappers.lambdaUpdateChain(connectionService.getBaseMapper())
                .eq(NftUserConnection::getUserId,oldUserId)
                .eq(NftUserConnection::getSocialUserId,userName)
                .set(NftUserConnection::getUserId,user.getUserId())
                .update();
        this.removeById(oldUserId);
        NewtvEmp emp = empService.getById(user.getMobile());
        if (emp!=null) {
            user.setInternalEmp(1);
        }
        updateById(user);
        onlineUserService.kickOut(Long.valueOf(oldUserId));
    }

    @Transactional(rollbackFor = Exception.class)
    public void setCancellationFlag() {
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        log.info("用户注销："+currentUser.getUserDetails().getUserName());
        onlineUserService.kickOut(currentUser.getUserId());
        redisService.set(RedisKeyFactory.getUserCancellationKey(currentUser.getUserId()+""),new Date());
        //修改用户注销标记
        ChainWrappers.lambdaUpdateChain(baseMapper)
                .eq(NftUser::getUserId,currentUser.getUserId())
                .set(NftUser::getStatus,2)
                .update();
    }

    public void initRightUser() {
        //初始化星球用户
        List<Integer> starMetaIds = (List<Integer>) redisService.get(RedisKeyFactory.getStarMetaIdKey());
        if ( starMetaIds!=null ) {
            starMetaIds.forEach(metaId -> {
                List<String> starUser = findUserIdByMetaIdDistinct(metaId);
                Map<String,Integer> map = starUser.stream().collect(Collectors.toMap(v->v, v->metaId));
                redisService.hmset(RedisKeyFactory.getStarUserIdKey(metaId),map);
            });
        }

        //初始化创世徽章用户
        Integer primaryMetaId = (Integer) redisService.get(RedisKeyFactory.getPrimaryNftMetaIdKey());
        if (primaryMetaId!=null) {
            List<String> userIds = findUserIdByMetaIdDistinct(primaryMetaId);
            Map<String,Integer> map = userIds.stream().collect(Collectors.toMap(v->v, v->primaryMetaId));
            redisService.hmset(RedisKeyFactory.getPrimaryUserIdKey(),map);
        }

        //初始化黄金创世徽章用户
        Integer goldPrimaryMetaId = (Integer) redisService.get(RedisKeyFactory.getGoldPrimaryNftMetaIdKey());
        if (goldPrimaryMetaId!=null) {
            List<String> userIds = findUserIdByMetaIdDistinct(goldPrimaryMetaId);
            Map<String,Integer> map = userIds.stream().collect(Collectors.toMap(v->v, v->goldPrimaryMetaId));
            redisService.hmset(RedisKeyFactory.getGoldPrimaryUserIdKey(),map);
        }
    }

    private List<String> findUserIdByMetaIdDistinct(Integer primaryMetaId) {
        return baseMapper.findUserIdByMetaIdDistinct(primaryMetaId);
    }

    public void addRightUser(String userId,int metaId){
        //boolean isPrimary = false;
        //Integer primaryMetaId = (Integer) redisService.get(RedisKeyFactory.getPrimaryNftMetaIdKey());
        //if (primaryMetaId!=null && metaId== primaryMetaId) {
        //    isPrimary = true;
        //}
        //if (isPrimary) {
        //    redisService.hset(RedisKeyFactory.getPrimaryUserIdKey(),userId,metaId);
        //} else {
        //    List<Integer> list = (List<Integer>) redisService.get(RedisKeyFactory.getStarMetaIdKey());
        //    if (list.contains(metaId)) {
        //        redisService.hset(RedisKeyFactory.getStarUserIdKey(metaId),userId,metaId);
        //    }
        //}
        List<Integer> list = (List<Integer>) redisService.get(RedisKeyFactory.getStarMetaIdKey());
        if (list.contains(metaId)) {
            redisService.hset(RedisKeyFactory.getStarUserIdKey(metaId),userId,metaId);
        }
        String setKey = RedisKeyFactory.getMetaId2RightLevelKey();
        Set<ZSetOperations.TypedTuple<Object>> sets = redisTemplate.opsForZSet().rangeByScoreWithScores(setKey, 1, 10);
        if (!CollectionUtils.isEmpty(sets)) {
            sets.forEach( metaId2RightLevel -> {
                int rightLevel = metaId2RightLevel.getScore().intValue();
                Integer rightMetaId = (Integer)metaId2RightLevel.getValue();
                if (Objects.equals(metaId,rightMetaId)) {
                    NftUser user = getById(userId);
                    if (user.getRightLevel()<rightLevel) {
                        user.setRightLevel(rightLevel);
                        updateById(user);
                        JwtUserDto<UserVo> one = onlineUserService.getOne( Long.valueOf(userId));
                        one.getUser().getUserDetails().setRightLevel(rightLevel);
                        onlineUserService.updateUser(one.getUser());
                    }
                }
            });
        }
    }

    public void removeRightUser(String userId,int metaId){
        //boolean isPrimary = false;
        //Integer primaryMetaId = (Integer) redisService.get(RedisKeyFactory.getPrimaryNftMetaIdKey());
        //if (primaryMetaId!=null && metaId== primaryMetaId) {
        //    isPrimary = true;
        //}
        //if (isPrimary) {
        //    redisService.hdel(RedisKeyFactory.getPrimaryUserIdKey(),userId);
        //} else {
        //    redisService.hdel(RedisKeyFactory.getStarUserIdKey(metaId),userId);
        //}
        List<Integer> list = (List<Integer>) redisService.get(RedisKeyFactory.getStarMetaIdKey());
        if (list.contains(metaId)) {
            redisService.hdel(RedisKeyFactory.getStarUserIdKey(metaId),userId);
        }
        String setKey = RedisKeyFactory.getMetaId2RightLevelKey();
        Set<ZSetOperations.TypedTuple<Object>> sets = redisTemplate.opsForZSet().reverseRangeByScoreWithScores(setKey, 1, 10);
        NftUser user = getById(userId);
        Integer ownCount = recordService.lambdaQuery()
                .eq(NftRecord::getMetaId, metaId)
                .eq(NftRecord::getUserId, userId)
                .in(NftRecord::getBuyStatus, 7, 11)
                .count();
        if (!CollectionUtils.isEmpty(sets)) {
            sets.forEach( metaId2RightLevel -> {
                int rightLevel = metaId2RightLevel.getScore().intValue();
                Integer rightMetaId = (Integer)metaId2RightLevel.getValue();
                if (Objects.equals(metaId,rightMetaId)) {
                    if (Objects.equals(user.getRightLevel(),rightLevel)&&ownCount<=0) {
                        user.setRightLevel(0);
                        updateById(user);
                    }
                } else {
                    Integer count = recordService.lambdaQuery()
                            .eq(NftRecord::getUserId, userId)
                            .eq(NftRecord::getMetaId, rightMetaId)
                            .eq(NftRecord::getBuyStatus, 7)
                            .count();
                    if (count!=null && count>0) {
                        if (user.getRightLevel()==0) {
                            user.setRightLevel(rightLevel);
                        }
                    }
                }
            });
        }
        updateById(user);
        JwtUserDto<UserVo> one = onlineUserService.getOne( Long.valueOf(userId));
        one.getUser().getUserDetails().setRightLevel(user.getRightLevel());
        onlineUserService.updateUser(one.getUser());
    }

    public void checkSign() {
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();

        Integer checkSign = (Integer)redisService.get(RedisKeyFactory.getCheckSignKey(Math.toIntExact(currentUser.getUserId())));
        if (checkSign==null) {
            checkSign = 0;
        }
        if (checkSign>0) {
            throw new BusException("今日已签到");
        }
        //校验重复提交
        Map<String,Object> hashData = new HashMap<>(3);
        hashData.put("userId",currentUser.getUserId());

        String repeatLimitKey = RedisKeyFactory.getRepeatLimitKey("checkSign",SecureUtil.md5(JSON.toJSONString(hashData)));
        if(redisService.get(repeatLimitKey) != null){
            throw new BusException("操作过于频繁,请稍后再试");
        }
        redisService.set(repeatLimitKey,currentUser.getUserId(),3L);

        //连续签到过期时间
        DateTime now = DateUtil.date();
        DateTime yesterday = DateUtil.offsetDay(now,-1);
        String yesterdayDate = DateUtil.format(yesterday, DatePattern.NORM_DATE_PATTERN);
        String todayDate = DateUtil.format(now, DatePattern.NORM_DATE_PATTERN);
        long currentDayRestTime = (DateUtil.endOfDay(now).getTime() - System.currentTimeMillis()) / 1000;
        SignRecord newSignRecord = new SignRecord();
        newSignRecord.setContinueNumber(1);
        newSignRecord.setCreateTime(DateUtil.now());
        newSignRecord.setUserId(Math.toIntExact(currentUser.getUserId()));
        newSignRecord.setSignDate(todayDate);
        newSignRecord.setSignIp(HttpRequestUtil.getClientIp());
        SignRecord yesterdayRecord = signRecordService.lambdaQuery()
                .eq(SignRecord::getUserId, currentUser.getUserId())
                .eq(SignRecord::getSignDate, yesterdayDate)
                .last("limit 1")
                .one();
        if (yesterdayRecord!=null) {
            newSignRecord.setContinueNumber(yesterdayRecord.getContinueNumber()+1);
        }
        signRecordService.save(newSignRecord);
        redisService.set(RedisKeyFactory.getCheckSignKey(Math.toIntExact(currentUser.getUserId())),1,currentDayRestTime);

    }

    public NftUser findUserByInviteUserId(Integer inviteUserId) {
        return  baseMapper.findUserByInviteUserId(inviteUserId);
    }
}
