package com.foundao.nft.api.service.impl;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.common.constant.FoundaoConstant;
import com.foundao.nft.common.model.mq.TransferCancelMqDto;
import com.foundao.nft.common.model.vo.UserVo;
import com.foundao.nft.common.util.SortUtil;
import com.tx.core.beans.BaseRequestVo;
import com.tx.security.bean.AuthUser;
import com.tx.security.util.SecurityUtil;
import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.common.model.TransferRecord;
import com.foundao.nft.api.mapper.TransferRecordMapper;

import java.util.List;

/**
    @Package: com.foundao.nft.api.service.impl
    @ClassName: TransferRecordService
    @Author: chenli
    @CreateTime: 2022/7/28 2:50 下午
    @Description:
*/
@Service
public class TransferRecordService extends ServiceImpl<TransferRecordMapper, TransferRecord> {

    public List<TransferRecord> myTransfer(BaseRequestVo request, Integer status) {
        Page<TransferRecord> page = new Page<>(request.getPage(),request.getNum());
        SortUtil.handlePageSort(request, page, "trans_id", FoundaoConstant.ORDER_DESC, true);
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        return baseMapper.myTransfer(page,currentUser.getUserId(),status);
    }

}
