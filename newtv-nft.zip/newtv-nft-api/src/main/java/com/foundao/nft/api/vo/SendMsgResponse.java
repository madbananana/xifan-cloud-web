package com.foundao.nft.api.vo;

import lombok.Data;

/**
 * @Package: com.foundao.nft.api.vo
 * @ClassName: SendMsgResponse
 * @Author: chenli
 * @CreateTime: 2022/2/18 5:52 下午
 * @Description:
 */
@Data
public class SendMsgResponse {

    private Boolean response;

    private String statusCode;

    private String message;
}
