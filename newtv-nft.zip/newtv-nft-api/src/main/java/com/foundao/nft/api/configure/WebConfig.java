package com.foundao.nft.api.configure;

import com.foundao.nft.api.handler.WeChatMappingJackson2HttpMessageConverter;
import com.foundao.nft.common.properties.CustomProperties;
import com.foundao.nft.common.properties.MsgProperties;
import com.foundao.nft.common.properties.NftProperties;
import com.foundao.nft.common.properties.PayProperties;
import com.foundao.nft.common.util.NftCommonUtil;
import com.foundao.nft.common.properties.WeChatProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

/**
 * @Package: com.foundao.nft.api.configure
 * @ClassName: WebConfig
 * @Author: chenli
 * @CreateTime: 2021/12/9 3:39 下午
 * @Description:
 */
@Configuration
@ComponentScan(basePackages = {"com.foundao.nft.common.model.sdk.client"})
public class WebConfig {

    @Bean
    public RestTemplate restTemplate(){
        RestTemplate restTemplate = new RestTemplate();
        restTemplate.getMessageConverters().add(new WeChatMappingJackson2HttpMessageConverter());
        return restTemplate;
    }

    @Bean
    @ConfigurationProperties(prefix = "nft")
    public NftProperties nftProperties() {
        return new NftProperties();
    }

    @Bean
    public NftCommonUtil nftCommonUtil(){
        return new NftCommonUtil(restTemplate(),nftProperties());
    }

    @Bean
    @ConfigurationProperties(prefix = "social.wechat")
    public WeChatProperties weChatProperties(){
        return new WeChatProperties();
    }


    @Bean
    @ConfigurationProperties(prefix = "newtv.pay")
    public PayProperties payProperties(){
        return new PayProperties();
    }

    @Bean
    @ConfigurationProperties(prefix = "newtv.msg")
    public MsgProperties msgProperties(){
        return new MsgProperties();
    }

    @Bean
    public FilterRegistrationBean<CorsFilter> corsFilter() {
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowCredentials(true);
        config.addAllowedOrigin("*");
        config.addAllowedHeader("*");
        config.addAllowedMethod("*");
        source.registerCorsConfiguration("/**", config);
        FilterRegistrationBean<CorsFilter> filterRegistrationBean = new FilterRegistrationBean<>(new CorsFilter(source));
        // 代表这个过滤器在众多过滤器中级别最高，也就是过滤的时候最先执行
        filterRegistrationBean.setOrder(Ordered.HIGHEST_PRECEDENCE);
        return filterRegistrationBean;
    }

    @Bean
    @ConfigurationProperties(prefix = "foundao.custom")
    public CustomProperties customProperties() {
        return new CustomProperties();
    }

}
