package com.foundao.nft.api.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Package: com.foundao.nft.common.model.vo
 * @ClassName: MyNftVO
 * @Author: chenli
 * @CreateTime: 2021/12/23 5:42 下午
 * @Description:
 */
@Data
@ApiModel("我的nft")
public class MyNftVO {

    @ApiModelProperty("id")
    private Integer id;

    @ApiModelProperty("metaId")
    private Integer metaId;

    @ApiModelProperty("nftId")
    private String nftId;

    @ApiModelProperty("获取时间")
    private String ownerTime;

    @ApiModelProperty("创建时间")
    private String createTime;

    @ApiModelProperty("预览图")
    private String displayUrl;

    @ApiModelProperty("作品链接")
    private String url;

    @ApiModelProperty("获取类型 1:购买 2:获赠")
    private int obtainType;

    @ApiModelProperty("nft名称")
    private String name;

    @ApiModelProperty("描述")
    private String desc;

    @ApiModelProperty("hash")
    private String hash;

    @ApiModelProperty("作者")
    private String author;

    @ApiModelProperty("作品拥有人的钱包地址")
    private String ownerAddr;

    @ApiModelProperty("赠送人名称")
    private String giverUserName;

    @ApiModelProperty("图片介绍列表")
    private String imageDesc;

    @ApiModelProperty("作品类型 0：图片 1：视频")
    private String type;

    @ApiModelProperty("藏品地址")
    private String txHash;

    @ApiModelProperty("2 上链中 7 上链成功 10 上链失败")
    private Integer buyStatus;

    @ApiModelProperty("1普通款 3隐藏款")
    private Integer metaType;

    @ApiModelProperty("1普通款 3盲盒款")
    private Integer seriesMetaType;

    @ApiModelProperty("发行数量")
    private Integer publishCount;

    @ApiModelProperty("总数量")
    private Integer totalCount;

    @ApiModelProperty("实际nftId")
    private String actualNftId;

    @ApiModelProperty("是否能转赠 0：不能 1可以")
    private Integer canTrans;

    @ApiModelProperty("不能转赠的理由")
    private String transMsg;

    @ApiModelProperty(value = "合成id号")
    private Integer mergeId;
}
