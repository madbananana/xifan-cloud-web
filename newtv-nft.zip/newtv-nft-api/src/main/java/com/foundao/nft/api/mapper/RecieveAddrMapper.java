package com.foundao.nft.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.foundao.nft.common.model.RecieveAddr;
import org.apache.ibatis.annotations.Mapper;

/**
    @Package: com.foundao.nft.api.mapper
    @ClassName: RecieveAddrMapper
    @Author: chenli
    @CreateTime: 2022/7/12 3:12 下午
    @Description:
*/
@Mapper
public interface RecieveAddrMapper extends BaseMapper<RecieveAddr> {
}