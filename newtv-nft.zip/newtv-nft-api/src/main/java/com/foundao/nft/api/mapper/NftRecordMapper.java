package com.foundao.nft.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.api.vo.MyNftGroupByMetaIdVO;
import com.foundao.nft.api.vo.MyNftVO;
import com.foundao.nft.api.vo.NftInfoVO;
import com.foundao.nft.common.model.NftRecord;
import com.foundao.nft.common.model.vo.NftRecordVO;
import com.tx.core.beans.BaseRequestVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Update;

import java.util.List;

@Mapper
public interface NftRecordMapper extends BaseMapper<NftRecord> {

    IPage<MyNftVO> listMyNft(Page<?> page, @Param("request") BaseRequestVo requestVo);

    NftInfoVO nftInfo(@Param("nftId") String nftId, @Param("userId") Integer userId);

    NftRecordVO getRecordVOByNftIdAndUserId(@Param("nftId") String nftId,@Param("userId") Integer userId,@Param("actualNftId")String actualNftId);

    NftRecordVO isPaySeriesId(@Param("userId") Integer userId,@Param("seriesId") String seriesId);

    void deleteBak(Integer recordId);

    NftInfoVO nftDetails(@Param("metaId") String metaId,@Param("actualNftId") String actualNftId,@Param("userId") Integer userId);

    NftInfoVO shareDetails(@Param("metaId") String metaId,@Param("actualNftId") String actualNftId,@Param("userId") Integer userId);

    IPage<MyNftGroupByMetaIdVO> listMyNftGroupByMetaId(Page<MyNftGroupByMetaIdVO> page, @Param("userId") Integer userId);

    List<MyNftVO> selectByMetaId(@Param("metaId")Integer metaId,@Param("userId")Integer userId);

    NftRecordVO getRecordVOByActualNftIdAndUserId(@Param("userId") Integer userId,@Param("actualNftId") String actualNftId);

    @Update("update nft_record r set buy_status=14,merge_id=#{mergeId} where user_id=#{userId} and meta_id=#{metaId} and buy_status=7  order by id limit #{count}")
    int updateMaterial(@Param("mergeId") Integer mergeId,@Param("userId") Integer userId,@Param("metaId") Integer metaId,@Param("count") Integer count);
}
