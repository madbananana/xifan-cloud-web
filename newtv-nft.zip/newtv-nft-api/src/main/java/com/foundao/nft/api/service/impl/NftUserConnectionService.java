package com.foundao.nft.api.service.impl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.common.model.NftUserConnection;
import com.foundao.nft.api.mapper.NftUserConnectionMapper;

/**
 * @Package: com.foundao.nft.api.service.impl
 * @ClassName: NftUserConnectionService
 * @Author: chenli
 * @CreateTime: 2021/12/20 3:58 下午
 * @Description:
 */
@Service
public class NftUserConnectionService extends ServiceImpl<NftUserConnectionMapper, NftUserConnection> {

}

