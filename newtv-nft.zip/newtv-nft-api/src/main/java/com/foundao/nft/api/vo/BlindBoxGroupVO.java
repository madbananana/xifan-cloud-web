package com.foundao.nft.api.vo;

import com.foundao.nft.common.model.vo.BlindBoxVO;
import lombok.Data;

import java.util.List;

/**
 * @Package: com.foundao.nft.api.vo
 * @ClassName: BlindBoxGroupVO
 * @Author: chenli
 * @CreateTime: 2022/7/20 3:15 下午
 * @Description:
 */
@Data
public class BlindBoxGroupVO {
    private Integer shortSeriesId;
    private Integer count;
    private List<BlindBoxVO> boxs;
}
