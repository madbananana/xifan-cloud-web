package com.foundao.nft.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.foundao.nft.common.model.UserConsume;
import com.foundao.nft.common.model.vo.UserConsumeRankVO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
    @Package: com.foundao.nft.api.mapper
    @ClassName: UserConsumeMapper
    @Author: chenli
    @CreateTime: 2022/11/3 11:17 AM
    @Description:
*/
@Mapper
public interface UserConsumeMapper extends BaseMapper<UserConsume> {
    List<UserConsumeRankVO> consumeTop50(String activityId);
}