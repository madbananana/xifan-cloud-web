package com.foundao.nft.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.foundao.nft.common.model.WaitChainUp;
import org.apache.ibatis.annotations.Mapper;

/**
    @Author: chenli
    @CreateTime: 2023/2/3 11:45
    @Description:
*/
@Mapper
public interface WaitChainUpMapper extends BaseMapper<WaitChainUp> {
}