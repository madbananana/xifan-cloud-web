package com.foundao.nft.api.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.foundao.nft.api.mapper.NftOrderMapper;
import com.foundao.nft.api.mapper.OrderExtMapper;
import com.foundao.nft.common.constant.AppleStatusEnum;
import com.foundao.nft.common.constant.OrderStatusEnum;
import com.foundao.nft.common.model.Goods;
import com.foundao.nft.common.model.NftOrder;
import com.foundao.nft.common.model.OrderExt;
import com.foundao.nft.common.model.apple.AppleOrderItem;
import com.foundao.nft.common.properties.PayProperties;
import com.foundao.nft.common.util.apple.AppleSdk;
import com.foundao.nft.common.util.apple.OrderUtils;
import com.tx.core.exception.BusException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 *
 * @author tomxia
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class OrderServiceApplePayImpl {
    private final OrderExtMapper orderExtMapper;
    private final NftOrderMapper orderMapper;
    private final NftOrderService orderService;
    private final AppleGoodsServiceImpl goodsService;
    private final PayProperties payProperties;

    /**
     * 验证用户的票据
     *
     * @param tradeNo
     */
    public void checkReceiptByTradeNo(String tradeNo) {
        //检查订单
        NftOrder oldOrder = orderService.getByTradeNo(tradeNo);
        if(oldOrder == null) {
            throw new BusException("异常订单信息");
        }
        OrderExt oldOrderExt = orderExtMapper.getOrderExtByOrderId(oldOrder.getOrderId());
        Goods goods = goodsService.getRowByGoodsName(oldOrder.getAppleGoodsId());
        //获取票据
        String receipt = oldOrderExt.getExtend();
        AppleSdk appleSdk = new AppleSdk(payProperties.getAppleSecret(), true);
        String receiptData = appleSdk.getReceiptData(receipt);
        JSONObject root = JSON.parseObject(receiptData);
        if (root == null || root.getInteger("status") != AppleStatusEnum.SUCCESS.getStatus()) {
            log.error("receiptData status Error, receiptData => {}", receiptData);
            throw new BusException("校验内购支付票据失败");
        }
        JSONObject rootReceipt = root.getJSONObject("receipt");
        //app购买时 数据在 in_app 中
        JSONArray inAppArray = rootReceipt.getJSONArray("in_app");
        AppleOrderItem nowAppleOrderItem = OrderUtils.getLatestReceiptInfo(inAppArray);
        String env = OrderUtils.getEnvFromReceiptData(root);
        doApiReceiptCore(nowAppleOrderItem, oldOrder,oldOrderExt,goods, env);
    }
    /**
     * 票据处理更新用订单信息-Api接口调用
     *
     * @param appleOrderItem
     * @param oldOrder
     * @param oldOrderExt
     * @param env
     */
    private void doApiReceiptCore(AppleOrderItem appleOrderItem, NftOrder oldOrder, OrderExt oldOrderExt, Goods goods, String env) {
        //当前订单可能就是  用户购买的订单
        NftOrder nowOrder = orderMapper.getRowByThirdTradeNo(appleOrderItem.getTransactionId());
        if (nowOrder != null) {
            log.info("当前订单已经处理 nowOrder => {}", nowOrder);
            return;
        }
        if (!goods.getAppleName().equals(appleOrderItem.getProductId())) {
            log.warn("productId and appName not match appleOrderItem => {},oldOrder=>{}", appleOrderItem, oldOrder);
            return;
        }
        OrderStatusEnum orderStatusEnum =  getOrderStatusEnum(appleOrderItem);
        //完成订单
        orderService.finishOrder(oldOrder.getTradeNo(),orderStatusEnum.getCode(),appleOrderItem.getTransactionId(),appleOrderItem);
        //更新订单扩展表
        OrderExt newOrderExt = new OrderExt();
        newOrderExt.setExtId(oldOrderExt.getExtId());
        newOrderExt.setMark(env);
        orderExtMapper.updateById(newOrderExt);
    }



    /**
     * 从苹果内购订单数据中提取订单状态
     * @param appleOrderItem
     * @return
     */
    private OrderStatusEnum getOrderStatusEnum(AppleOrderItem appleOrderItem){
        OrderStatusEnum orderStatusEnum = null;
        if ("true".equalsIgnoreCase(appleOrderItem.getIsInIntroOfferPeriod())) {
            orderStatusEnum = OrderStatusEnum.PAY_FAIL;
        }else if (appleOrderItem.getTransactionId().equals(appleOrderItem.getOriginalTransactionId())) {
            orderStatusEnum = OrderStatusEnum.PAY_SUCCESS;
        }else {
            orderStatusEnum = OrderStatusEnum.PAY_FAIL;
        }
        return orderStatusEnum;
    }
}
