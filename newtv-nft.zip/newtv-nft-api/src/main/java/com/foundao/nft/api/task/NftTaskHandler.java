package com.foundao.nft.api.task;

import cn.hutool.core.net.Ipv4Util;
import cn.hutool.core.net.NetUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.foundao.nft.api.service.impl.NftMetadataService;
import com.foundao.nft.api.service.impl.NftSeriesClaimService;
import com.foundao.nft.api.service.impl.NftTaskService;
import com.foundao.nft.api.service.impl.NftUserPlatformService;
import com.foundao.nft.common.constant.TaskEnum;
import com.foundao.nft.common.model.NftMetadata;
import com.foundao.nft.common.model.NftSeriesClaim;
import com.foundao.nft.common.model.NftTask;
import com.foundao.nft.common.model.NftUserPlatform;
import com.foundao.nft.common.model.sdk.client.NftService;
import com.foundao.nft.common.model.sdk.response.NftPublishTaskResultResponse;
import com.foundao.nft.common.model.sdk.response.NftTaskResultResponse;
import com.foundao.nft.common.model.sdk.response.SdkResponseBase;
import com.foundao.nft.common.model.sdk.response.SeriesTaskResultResponse;
import com.foundao.nft.common.properties.NftProperties;
import com.tx.core.util.RunShellUtil;
import com.tx.redis.service.RedisLockService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;

/**
 * @ClassName NftTaskHandler
 * @Description TODO
 * @Author xifan
 * @Date 2021/12/22 23:28
 * @Version 1.0
 */
@Component
@RequiredArgsConstructor
public class NftTaskHandler {

    private final NftTaskService taskService;
    private final NftSeriesClaimService seriesClaimService;
    private final NftMetadataService metadataService;
    private final NftService nftService;
    private final RedisLockService lockService;
    private final NftUserPlatformService platformService;
    private final NftProperties nftProperties;

    @Value("${task.execute-ip}")
    private String executeIp;

    private static final String LOCK = "lock:newtv-nft:task:";

    @Scheduled(initialDelay = 5 * 1000, fixedDelay = 1000)
    public void scanTask() {
        LinkedHashSet<String> strings = NetUtil.localIpv4s();
        if (!strings.contains(executeIp)) {
            return ;
        }
        List<NftTask> nftTasks = taskService.scanTask("2");
        if (nftTasks != null && nftTasks.size() > 0) {
            nftTasks.forEach(task -> {
                String lockName = LOCK+ task.getId();
                boolean isObtainLock = lockService.tryLock(lockName);
                if (isObtainLock) {
                    try {
                        NftTask newtask = taskService.getTaskByTaskId(task.getTaskId());
                        if (newtask.getStatus()!=2) {
                            return;
                        }
                        if (task.getType().equals(TaskEnum.SERIES_CLAIM.getCode())) {
                            SdkResponseBase<SeriesTaskResultResponse> taskResult = nftService.seriesClaimResult(task.getTaskId());
                            if (taskResult.getRetCode() == 0) {
                                NftSeriesClaim seriesClaim = seriesClaimService.getByTaskId(task.getTaskId());
                                SeriesTaskResultResponse result = taskResult.getData();
                                task.setStatus(result.getTaskStatus());
                                task.setChainTimestamp(new Date(result.getChainTimestamp()*1000L));
                                task.setTxHash(result.getTxHash());
                                task.setTaskMsg(result.getTaskMsg());
                                seriesClaim.setSeriesId(result.getSeriesId());
                                seriesClaim.setTaskStatus(result.getTaskStatus());
                                taskService.updateSeriesClaimTask(task, seriesClaim);
                            }
                        } else if (task.getType().equals(TaskEnum.NFT_PUBLISH.getCode())) {
                            SdkResponseBase<NftPublishTaskResultResponse> taskResult = nftService.nftPublishResult(task.getTaskId());
                            if (taskResult.getRetCode() == 0) {
                                NftMetadata metadata = metadataService.getByTaskId(task.getTaskId());
                                NftPublishTaskResultResponse result = taskResult.getData();
                                task.setStatus(result.getTaskStatus());
                                task.setChainTimestamp(new Date(result.getChainTimestamp()*1000L));
                                task.setTxHash(result.getTxHash());
                                task.setTaskMsg(result.getTaskMsg());
                                task.setExtend1(result.getNftIdBegin());

                                if (metadata!=null) {
                                    metadata.setNftId(result.getNftIdBegin());
                                    metadata.setTaskStatus(result.getTaskStatus());
                                }

                                taskService.updateNftPublishTask(task, metadata);
                            }

                        } else if (task.getType().equals(TaskEnum.NFT_BUY.getCode())) {
                            SdkResponseBase<NftTaskResultResponse> taskResult = nftService.nftBuyResult(task.getTaskId());
                            if (taskResult.getRetCode() == 0) {
                                NftTaskResultResponse result = taskResult.getData();
                                task.setStatus(result.getTaskStatus());
                                task.setChainTimestamp(new Date(result.getChainTimestamp()*1000L));
                                task.setTxHash(result.getTxHash());
                                task.setTaskMsg(result.getTaskMsg());
                                taskService.updateNftBuyTask(task);
                            }
                        } else if (task.getType().equals(TaskEnum.NFT_TRANSFER.getCode())) {
                            //获取转赠用户的公钥
                            JSONObject extData = JSON.parseObject(task.getExtend3());
                            String transferUserId = extData.getString("transferUserId");//赠送人id
                            SdkResponseBase<NftTaskResultResponse> taskResult = null;
                            if ("平台".equals(transferUserId)) {
                                taskResult = nftService.nftTransferResult(nftProperties.getPubKey(), task.getTaskId());
                            } else {
                                NftUserPlatform userPlatform = platformService.getById(transferUserId);
                                taskResult = nftService.nftTransferResult(userPlatform.getPubkey(), task.getTaskId());
                            }
                            if (taskResult.getRetCode() == 0) {
                                NftTaskResultResponse result = taskResult.getData();
                                task.setStatus(result.getTaskStatus());
                                task.setChainTimestamp(new Date(result.getChainTimestamp()*1000L));
                                task.setTxHash(result.getTxHash());
                                task.setTaskMsg(result.getTaskMsg());
                                taskService.updateNftTransferTask(task);
                            }
                        }
                    } finally {
                        lockService.unlock(lockName);
                    }

                }
            });
        }
    }
}
