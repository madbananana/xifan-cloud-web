package com.foundao.nft.api.service.impl;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.extension.toolkit.ChainWrappers;
import com.foundao.nft.api.mapper.NftTaskMapper;
import com.foundao.nft.common.constant.IntegralTypeEnum;
import com.foundao.nft.common.constant.PayTypeEnum;
import com.foundao.nft.common.model.*;
import com.foundao.nft.common.util.RedisKeyFactory;
import com.tx.redis.service.RedisService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
@Slf4j
public class NftTaskService extends ServiceImpl<NftTaskMapper, NftTask> {

    @Autowired
    private NftSeriesClaimService seriesClaimService;
    @Autowired
    private NftRecordService recordService;
    @Autowired
    private NftUserService userService;
    @Autowired
    private NftUserPlatformService userPlatformService;
    @Autowired
    private AvatarServiceImpl avatarService;
    @Autowired
    private NftIdHelper nftIdHelper;
    @Autowired
    private NftMetadataService metadataService;
    @Autowired
    private RedisService redisService;
    @Autowired
    private NftOrderService orderService;
    @Autowired
    private ExchangeCodeService exchangeCodeService;
    @Autowired
    private RecipeService recipeService;

    public NftTask getTaskByTaskId(String taskId){
        return ChainWrappers.lambdaQueryChain(baseMapper)
                .eq(NftTask::getTaskId,taskId)
                .one();
    }


    public List<NftTask> scanTask(String status) {
        return ChainWrappers.lambdaQueryChain(baseMapper)
                .eq(NftTask::getStatus,status)
                .last("limit 10")
                .orderByAsc(NftTask::getId)
                .list();
    }

    public void updateByTaskId(NftTask newTask){
        if(newTask.getId() == null){
            NftTask task = ChainWrappers.lambdaQueryChain(baseMapper)
                    .eq(NftTask::getTaskId, newTask.getTaskId())
                    .one();
            newTask.setId(task.getId());
        }
        updateById(newTask);
    }


    @Transactional(rollbackFor = Exception.class)
    public void updateSeriesClaimTask(NftTask task, NftSeriesClaim seriesClaim){
        updateByTaskId(task);
        seriesClaimService.updateById(seriesClaim);
    }

    @Transactional(rollbackFor = Exception.class)
    public void updateNftPublishTask(NftTask task, NftMetadata metadata) {
        updateByTaskId(task);
        if (metadata!=null) {
            metadataService.updateById(metadata);
            if (task.getStatus() == 7) {
                NftSeriesClaim seriesClaim = seriesClaimService.getBySeriesId(metadata.getSeriesId());
                //为盲盒切不为合成款
                if (seriesClaim.getMetaType()==3 && metadata.getMetaType()!=4) {
                    //redisService.incr(RedisKeyFactory.getSeriesStockKey(seriesClaim.getId()), Long.valueOf(metadata.getShowCount()));
                    //盲盒藏品
                    nftIdHelper.entryNftIdToZSet(seriesClaim.getId(),metadata.getNftId(),metadata.getPublishCount(),metadata.getMetaId(),metadata.getShowCount());
                    redisService.hset(RedisKeyFactory.getBlindBoxShowCountKey(),metadata.getMetaId()+"",metadata.getShowCount());
                } else {
                    //普通藏品
                    nftIdHelper.entryNftIdToZSet(metadata.getNftId(),metadata.getPublishCount(),metadata.getShowCount());
                    if (seriesClaim.getExchange()!=null && seriesClaim.getExchange()==1) {
                        exchangeCodeService.entryExchangeCode(metadata.getMetaId(),seriesClaim.getId(),metadata.getPublishCount());
                    }
                    ////如果是合成款
                    //if (metadata.getMetaType()==4) {
                    //    recipeService.creatRecipe(metadata);
                    //}
                }
                //seriesClaim.setTotalCount(seriesClaim.getTotalCount()+metadata.getShowCount());
                redisService.hset(RedisKeyFactory.getShowCountKey(),metadata.getMetaId()+"",metadata.getShowCount());
                seriesClaimService.updateById(seriesClaim);
            }
        }
    }

    @Transactional(rollbackFor = Exception.class)
    public void updateNftBuyTask(NftTask task) {
        updateByTaskId(task);
        NftTask.NftBuyExtInfo extInfo = JSON.parseObject(task.getExtend3(),NftTask.NftBuyExtInfo.class);
        if (extInfo==null) {
            log.error("updateNftBuyTask任务执行错误");
            return ;
        }
        if (extInfo.getMetaType()==null) {
            extInfo.setMetaType(1);
        }

        if (task.getStatus()==7){
            //新增一个记录
            try{
                if ("replenish".equals(extInfo.getIsReplenish()) || "exchange".equals(extInfo.getIsReplenish())) {
                    recordService.updateReplenishRecord(task,extInfo);
                } else if ("merge".equals(extInfo.getIsReplenish())) {
                    recordService.updateMergeRecord(task,extInfo);
                } else {
                    recordService.updateBuyRecord(task,extInfo);
                }
                userService.addRightUser(extInfo.getUserId()+"",extInfo.getMetaId());
            }catch (Exception ignored){
                //可能会并发冲突，直接忽略
                log.error("执行购买异常",ignored);
            }
        }else if(task.getStatus() == 10){
            if (extInfo.getOrderId()!=null) {
                NftOrder order = orderService.getById(extInfo.getOrderId());
                if (order.getOrderType()!=11) {
                    if (order.getPayType().equals(PayTypeEnum.INTEGRAL_PAY.getCode())) {
                        orderService.integralUnfrozen(order.getUserId(),(int) Math.ceil((order.getOrderFee()/100.0)));
                    }
                }
            }
            if ("merge".equals(extInfo.getIsReplenish())) {
                recordService.updateMergeRecord(task,extInfo);
            } else {
                recordService.deleteBak(extInfo.getRecordId());
            }
            if(extInfo.getMetaType() == 2){
                Integer fullAvatarId = extInfo.getFullAvatarId();
                avatarService.releaseFullAvatarToLotteryPool(fullAvatarId);
            }
        }
    }

    @Transactional(rollbackFor = Exception.class)
    public void updateNftTransferTask(NftTask task) {
        JSONObject extData = JSON.parseObject(task.getExtend3());
        Integer recordId = extData.getInteger("recordId");//记录id
        String transferUserId = extData.getString("transferUserId");//赠送人id
        String receiveUserId = extData.getString("receiveUserId");//接受人id

        if (task.getStatus()==7){
            if ("平台".equals(receiveUserId) || "destroy".equals(receiveUserId)) {
                recordService.deleteBak(recordId);
            } else {
                NftRecord record = recordService.getById(recordId);

                if (record!=null) {
                    if (record.getBuyStatus()==11) {
                        recordService.finishTransfer(record,true,task);
                    } else {
                        NftUserPlatform receiveUserPlatform = userPlatformService.getById(receiveUserId);
                        if ("平台".equals(transferUserId)) {
                            record.setObtainType(1);
                        } else {
                            NftUser transferUser = userService.getById(transferUserId);
                            record.setGiverUserName(transferUser.getUserName());
                            record.setObtainType(2);
                            record.setOwnerAddr(receiveUserPlatform.getAddr());
                            record.setUserId(Integer.valueOf(receiveUserId));
                            record.setOwnerTime(new Date());
                            record.setGiverUserId(Integer.valueOf(transferUserId));
                        }
                        record.setBuyStatus(7);
                        record.setUpdateTime(DateUtil.now());
                        recordService.updateById(record);
                    }
                }
            }
        } else if (task.getStatus()==2) {
            log.info("至信链尚未处理完成："+task.getTaskId());
        } else {
            NftRecord record = recordService.getById(recordId);
            if (record != null) {
                if (record.getBuyStatus() == 11) {
                    recordService.finishTransfer(record, false, task);
                } else {
                    record.setBuyStatus(7);
                    record.setUpdateTime(DateUtil.now());
                    recordService.updateById(record);
                }
            }
        }

        updateByTaskId(task);
    }
}
