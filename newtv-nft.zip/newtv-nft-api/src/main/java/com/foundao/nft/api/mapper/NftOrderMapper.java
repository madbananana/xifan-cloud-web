package com.foundao.nft.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.foundao.nft.common.model.NftOrder;
import com.foundao.nft.common.model.vo.NftOrderVo;
import com.tx.core.beans.BaseRequestVo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
    @Package: com.foundao.nft.api.mapper
    @ClassName: NftOrderMapper
    @Author: chenli
    @CreateTime: 2021/12/22 6:16 下午
    @Description:
*/
@Mapper
public interface NftOrderMapper extends BaseMapper<NftOrder> {

    @Select("select * from nft_order where user_id = #{userId} and order_type = 10 and status = 2 order by order_id desc limit 1 ")
    NftOrder getUserAvatarOrder(Integer userId);

    @Select("select * from nft_order where third_transaction_id=#{thirdTransactionId} limit 1")
    NftOrder getRowByThirdTradeNo(String thirdTransactionId);

    @Select("select * from nft_order where user_id = #{userId} and product_id=#{productId}  and (status = 1 or status = 11) and is_abandon = 0 and expire_time > unix_timestamp() limit 1")
    NftOrder getWaitPayOrder(@Param("userId") Integer userId, @Param("productId") Integer productId);

    Page<NftOrderVo> orderList(Page<NftOrderVo> page, @Param("request") BaseRequestVo request);

    @Select(" select trade_no,fee,create_time,pay_time,`status`,product_id,product_id2,third_transaction_id,expire_time,pay_type,tx_hash  from nft_order where user_id = #{userId} and trade_no = #{tradeNo} limit 1 ")
    NftOrder getSimpleOrderTradeNo(@Param("tradeNo") String tradeNo,@Param("userId") Integer userId);

    @Select("      select  norder.trade_no,norder.fee,norder.count,norder.create_time,norder.pay_time,norder.`status`,norder.apple_goods_id\n" +
            "        ,norder.product_id,norder.product_id2,norder.third_transaction_id,norder.expire_time,norder.integral,norder.addr_id\n" +
            "        ,norder.pay_type,norder.order_type,norder.short_series_id,norder.tx_hash,norder.order_fee,nft.nft_id,nft.url,nft.`name`\n" +
            "        ,nft.display_url,nft.type,series.can_integral_buy,series.ios_pay_type\n" +
            "      from nft_order as norder left join nft_metadata as nft on norder.product_id = nft.meta_id left join nft_series_claim as series on norder.short_series_id = series.id where norder.user_id = #{userId} and norder.trade_no = #{tradeNo} limit 1")
    NftOrderVo getOrderDetail(@Param("tradeNo") String tradeNo,@Param("userId") Integer userId);

    @Select("select * from nft_order where user_id = #{userId} and short_series_id=#{shortSeriesId}  and (status = 1 or status = 11) and is_abandon = 0 and expire_time > unix_timestamp() limit 1")
    NftOrder getWaitPayBlindBoxOrder(@Param("userId") Integer userId,@Param("shortSeriesId") Integer shortSeriesId);

    NftOrderVo waiPayOrder(@Param("shortSeriesId") String shortSeriesId,@Param("userId") Long userId);
}
