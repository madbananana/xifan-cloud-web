package com.foundao.nft.api.mq;

import com.alibaba.fastjson.JSON;
import com.foundao.nft.api.service.impl.MessageService;
import com.foundao.nft.api.service.impl.NftRecordService;
import com.foundao.nft.api.service.impl.TransferRecordService;
import com.foundao.nft.common.constant.RabbitmqConst;
import com.foundao.nft.common.model.TransferRecord;
import com.foundao.nft.common.model.mq.SendMessageMqDto;
import com.foundao.nft.common.model.mq.TransferCancelMqDto;
import com.foundao.nft.common.model.vo.SendMsgResponse;
import com.rabbitmq.client.Channel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;

/**
 * @Package: com.foundao.nft.api.mq
 * @ClassName: AppointmentSendMessageHandler
 * @Author: chenli
 * @CreateTime: 2022/4/26 12:01 下午
 * @Description:
 */
@Slf4j
@RabbitListener(queues = RabbitmqConst.TRANSFER_CANCEL_DELAY_QUEUE)
@Component
public class TransferCancelHandler {

    @Autowired
    private NftRecordService recordService;
    @Autowired
    private TransferRecordService transferRecordService;

    @RabbitHandler
    public void appointmentSendMessageListener(TransferCancelMqDto messageMqDto, Message message, Channel channel) {
        //  如果手动ACK,消息会被监听消费,但是消息在队列中依旧存在,如果 未配置 acknowledge-mode 默认是会在消费完毕后自动ACK掉
        final long deliveryTag = message.getMessageProperties().getDeliveryTag();
        try {
            log.info("转赠队列:{},手动ACK，接收消息：{}", RabbitmqConst.APPOINTMENT_MESSAGE_DELAY_QUEUE, JSON.toJSON(messageMqDto));
            TransferRecord transferRecord = transferRecordService.getById(messageMqDto.getTransId());
            if (transferRecord.getStatus() == 0) {
                recordService.transferCancel(messageMqDto.getGiveRecordId(),messageMqDto.getReceiveUserId(),messageMqDto.getTransId(),messageMqDto.getActualNftId(),"对方未接收您的转赠");
            }
            channel.basicAck(deliveryTag, false);

        } catch (Exception e) {
            try {
                // 处理失败,重新压入MQ
                channel.basicRecover();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        }
    }
}
