package com.foundao.nft.api.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.foundao.nft.api.mapper.AppleGoodsMapper;
import com.foundao.nft.common.model.Goods;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class AppleGoodsServiceImpl {
    private final AppleGoodsMapper goodsMapper;

    /**
     * 通过商品名称获取苹果内购商品
     * @param goodsName 商品名称
     * @return
     */
    public Goods getRowByGoodsName(String goodsName){
        LambdaQueryWrapper<Goods> eq = Wrappers.lambdaQuery(Goods.class)
                .eq(Goods::getAppleName, goodsName)
                .last("LIMIT 1");
        return goodsMapper.selectOne(eq);
    }
}
