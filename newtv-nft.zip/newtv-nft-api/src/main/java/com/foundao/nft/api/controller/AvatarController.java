package com.foundao.nft.api.controller;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.IdUtil;
import com.alibaba.fastjson.JSON;
import com.foundao.nft.api.service.impl.*;
import com.foundao.nft.common.model.vo.AvatarVo;
import com.foundao.nft.common.constant.TaskEnum;
import com.foundao.nft.common.model.*;
import com.foundao.nft.common.model.sdk.client.NftService;
import com.foundao.nft.common.model.sdk.request.NftBuyRequest;
import com.foundao.nft.common.model.sdk.response.NftTaskResultResponse;
import com.foundao.nft.common.model.sdk.response.SdkResponseBase;
import com.foundao.nft.common.model.sdk.response.TaskResponse;
import com.foundao.nft.common.model.vo.UserVo;
import com.foundao.nft.common.properties.NftProperties;
import com.foundao.nft.common.util.NftCommonUtil;
import com.tx.core.beans.JsonResult;
import com.tx.core.enums.errcode.ApiStatusErrorEnum;
import com.tx.core.enums.errcode.ParamErrorEnum;
import com.tx.core.exception.BusException;
import com.tx.security.bean.AuthUser;
import com.tx.security.util.SecurityUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

@RequestMapping("/nft")
@Slf4j
@RestController
@RequiredArgsConstructor
@Api(tags = "仅牛头相关")
public class AvatarController {

    private final NftUserPlatformService userPlatformService;
    private final NftProperties nftProperties;
    private final NftCommonUtil nftCommonUtil;
    private final NftService nftService;
    private final NftTaskService taskService;
    private final AvatarServiceImpl avatarService;
    private final NftMetadataService nftMetadataService;
    private final NftUserService userService;
    private final NftSeriesClaimService seriesClaimService;



    @ApiOperation("抽取nft")
    @PostMapping("/lottery")
    public JsonResult<AvatarVo> lottery(){
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        if (currentUser.getUserDetails().getInternalEmp()==0) {
            return JsonResult.error(HttpStatus.INTERNAL_SERVER_ERROR.value(),"仅内部员工参与");
        }
        NftSeriesClaim seriesClaim = seriesClaimService.getById(1);
        if (seriesClaim!=null ) {
            String beginTime = seriesClaim.getBeginTime();
            String endTime = seriesClaim.getEndTime();
            DateTime beginDate = DateUtil.parseDateTime(beginTime);
            DateTime endDate = DateUtil.parseDateTime(endTime);
            Date now = new Date();
            if (DateUtil.compare(beginDate,now)>0) {
                return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"作品未到发售时间");
            }
            if (DateUtil.compare(endDate,now)<0) {
                return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"作品发售已结束");
            }
        } else {
            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"系列还未发行");
        }
//        //1.判断该用户是否已经付费，安卓用户必须付费才能抽取
//        boolean payHeadImage = orderService.isPayHeadImage(currentUser.getUserId().intValue());
//        if(!payHeadImage){
//            return JsonResult.error(ParamErrorEnum.PARAM_COMMON_ERROR.getCode(),"请完成付费后抽取");
//        }
//        //判断该用户是否已经抽奖过了，如果已经抽奖了，就不能继续抽奖了
        //2.参与抽奖
        AvatarVo lotteryAvatarVo = avatarService.lottery(currentUser.getUserDetails().getUserId(),currentUser.getUserDetails().isSpecial());
        return JsonResult.success(lotteryAvatarVo);
    }


    @ApiOperation("确认选择头像")
    @GetMapping("/confirmAvatar")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id",required = true,value = "完整头像的id")
    })
    public JsonResult<?> confirmAvatar(@RequestParam(name = "id") Integer id){
        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        AvatarFull avatarFull = avatarService.getAvatarFullById(id);
        if(avatarFull == null){
            return JsonResult.error(ApiStatusErrorEnum.INTERNAL_ERROR.getCode(),"未知的参数");
        }
        //判断用户是否已经抽取过头像，如果抽取过，不能重复抽取
        AvatarPart oldAvatarPart = avatarService.getUserLockAvatarPart(currentUser.getUserId().intValue());
        if(oldAvatarPart == null){
            return JsonResult.error(ApiStatusErrorEnum.INTERNAL_ERROR.getCode(),"您还没有参与抽取，请先抽取头像");
        }
        if( oldAvatarPart.getStatus() == 2){
            return JsonResult.error(ApiStatusErrorEnum.INTERNAL_ERROR.getCode(),"您已经参与过头像领取，请不要重复参与");
        }
        AvatarPart avatarPart = avatarService.getAvatarPartById(avatarFull.getAvatarPartId());
        if(avatarPart.getLockUserId() != currentUser.getUserId().intValue()){
            return JsonResult.error(ApiStatusErrorEnum.INTERNAL_ERROR.getCode(),"该头像已被别人抽取");
        }
        NftMetadata nftMetadata = nftMetadataService.getById(avatarFull.getNftMetaId());
        try{
            Map<String,String> res = new HashMap<>(2);
            //获取用户认证信息
            NftUserPlatform userPlatform = userPlatformService.getById(currentUser.getUserId());
            NftBuyRequest request = new NftBuyRequest();
            request.setApplyScore(1);
            request.setNftId(nftMetadata.getNftId());
            request.setOfferCount(1);
            request.setOperateId(IdUtil.fastUUID());
            request.setPointReceiverAddr(userPlatform.getAddr());
            request.setReceiverPubKey(userPlatform.getPubkey());
            request.setPlatformPubKey(nftProperties.getPubKey());

            SdkResponseBase<TaskResponse> taskResponse = nftService.nftBuy(request,userPlatform.getPrikey());
            if (taskResponse.getRetCode()==0) {
                res.put("taskId",taskResponse.getData().getTaskId());
                CompletableFuture.runAsync(()->{
                    Map<String,Object> extData = new HashMap<>();
                    extData.put("nftId",request.getNftId());
                    extData.put("userId",currentUser.getUserId());
                    extData.put("metaId",nftMetadata.getMetaId());
                    extData.put("partId",avatarPart.getPartId());
                    extData.put("fullAvatarId",id);
                    extData.put("metaType",2);

                    NftTask task = new NftTask();
                    task.setStatus(2);
                    task.setType(TaskEnum.NFT_BUY.getCode());
                    task.setExtend1(request.getNftId());
                    task.setExtend2(currentUser.getUserId()+"");
                    task.setExtend3(JSON.toJSONString(extData));
                    task.setTaskId(taskResponse.getData().getTaskId());
                    taskService.save(task);
                });

            }else{
                throw new BusException("抽取发生异常");
            }
            return JsonResult.success(res);
        }catch (Exception e){
            e.printStackTrace();
            avatarService.releaseAvatarToLotteryPool(avatarFull.getAvatarPartId(),nftMetadata.getNftId());
        }
        return JsonResult.error(ApiStatusErrorEnum.INTERNAL_ERROR.getCode(),"抽奖发生异常");

    }


    @ApiOperation("查询抽奖结果")
    @GetMapping("/queryLotteryResult")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "taskId",required = true,value = "任务id，抽奖返回"),
            @ApiImplicitParam(name = "id",required = true,value = "头像id抽奖返回")
    })
    public JsonResult<NftTaskResultResponse> queryLotteryResult(@RequestParam(name = "taskId") String taskId,@RequestParam(name = "id",required = false) Integer id){
        //查询任务是否存在
        NftTask task = taskService.getTaskByTaskId(taskId);
        if(task == null){
            return JsonResult.error(ApiStatusErrorEnum.INTERNAL_ERROR.getCode(),"无效的请求");
        }
        //查询id是否存在
//        AvatarFull avatarFullById = avatarService.getAvatarFullById(id);
        SdkResponseBase<NftTaskResultResponse> taskResult = nftService.nftBuyResult(taskId);
        if(taskResult.getRetCode() != 0){
            return JsonResult.error(ApiStatusErrorEnum.INTERNAL_ERROR.getCode(),"无效的请求");
        }
        NftTaskResultResponse resultResponse = taskResult.getData();

        task.setStatus(resultResponse.getTaskStatus());
        task.setChainTimestamp(new Date(resultResponse.getChainTimestamp()));
        task.setTxHash(resultResponse.getTxHash());
        task.setTaskMsg(resultResponse.getTaskMsg());

        taskService.updateNftBuyTask(task);
        return JsonResult.success(resultResponse);
    }


}
