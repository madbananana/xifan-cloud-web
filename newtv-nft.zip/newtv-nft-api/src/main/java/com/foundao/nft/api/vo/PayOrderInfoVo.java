package com.foundao.nft.api.vo;

import cn.hutool.core.util.ReflectUtil;
import com.foundao.nft.common.model.sdk.response.WechatAppPayData;
import com.foundao.nft.common.model.sdk.response.WechatMiniPayData;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.util.Map;

@Data
public class PayOrderInfoVo implements Serializable {


    /**
     * 微信app支付
     */
    @ApiModelProperty("微信app支付")
    private WechatAppPayData wxAppPayData;

    /**
     * 支付app支付
     */
    @ApiModelProperty("支付app支付")
    private Map<String,Object> aliAppPayData;

    /**
     * 支付宝H5支付
     */
    @ApiModelProperty("H5支付请求地址")
    private String h5PayRequestUrl;

    /**
     * 微信小程序
     */
    @ApiModelProperty("微信小程序支付")
    private WechatMiniPayData wxMiniPayData;

    /**
     * 当前支付类型
     */
    private String curPayType;
    /**
     * 支付子类型
     */
    private String paySubType = "app";
    /**
     * 订单号
     */
    private String tradeNo;

    private String openTime;

    public void mergePayOrderInfoVo(PayOrderInfoVo oldPayOrderInfoVo){
        if(oldPayOrderInfoVo == null){
            return;
        }
        Map<String, Field> fieldMap = ReflectUtil.getFieldMap(PayOrderInfoVo.class);
        fieldMap.forEach((name,field)->{
            if(field.getType() != String.class){
                if(ReflectUtil.getFieldValue(this,field) == null && ReflectUtil.getFieldValue(oldPayOrderInfoVo,field) != null ){
                    ReflectUtil.setFieldValue(this,field, ReflectUtil.getFieldValue(oldPayOrderInfoVo, field));
                }
            }
        });
    }
}
