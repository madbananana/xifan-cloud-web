package com.foundao.nft.api.service.impl;

import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.util.List;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.foundao.nft.api.mapper.SignRecordMapper;
import com.foundao.nft.common.model.SignRecord;
/**
    @Package: com.foundao.nft.api.service.impl
    @ClassName: SignRecordService
    @Author: chenli
    @CreateTime: 2022/9/23 4:40 下午
    @Description:
*/
@Service
public class SignRecordService extends ServiceImpl<SignRecordMapper, SignRecord> {

}
