package com.foundao.nft.api.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.foundao.nft.common.model.vo.UserVo;
import com.foundao.nft.common.model.AvatarPart;
import com.foundao.nft.common.model.NewtvEmp;
import com.foundao.nft.common.model.NftUser;
import com.foundao.nft.common.model.NftUserPlatform;
import com.tx.security.bean.AuthUser;
import com.tx.security.bean.JwtUserDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * @Package: com.foundao.nft.api.service.impl
 * @ClassName: UserDetailServiceImpl
 * @Author: chenli
 * @CreateTime: 2021/12/20 3:01 下午
 * @Description:
 */
@Component
@Slf4j
@RequiredArgsConstructor
public class UserDetailServiceImpl implements UserDetailsService {
    private final NftUserService userService;
    private final NftUserPlatformService userPlatformService;
    private final NftOrderService orderService;
    private final NewtvEmpService empService;
    private final NftRecordService recordService;
    private final AvatarServiceImpl avatarService;

    @Override
    public UserDetails loadUserByUsername(String userNameJsoNStr) throws UsernameNotFoundException {
        Map<String, Object> userNameMap = JSON.parseObject(userNameJsoNStr, new TypeReference<Map<String, Object>>(){});
        String username = (String)userNameMap.get("userName");
        String from = (String) userNameMap.get("from");
        AuthUser<UserVo> authUser = new AuthUser<>();

        UserVo userVo = new UserVo();
        //1.用户基本信息
        NftUser user = userService.findUser(from, username);
        if (user!=null) {
            if (user.getStatus()==1) {
                throw new LockedException("用户已锁定");
            }

            BeanUtils.copyProperties(user,userVo);
            //2.用户认证信息
            NftUserPlatform userPlatform = userPlatformService.getById(user.getUserId());
            if(userPlatform != null) {
                userVo.setAuth(true);
                userVo.setAddr(userPlatform.getAddr());
            }
            //3.用户支付信息
            userVo.setPay(orderService.isPayHeadImage(user.getUserId()));
            //4.判断用户是否已经领取牛头
            AvatarPart userLockAvatarPart = avatarService.getUserLockAvatarPart(user.getUserId());
            if(userLockAvatarPart != null) {
                if(userLockAvatarPart.getStatus() == 1){
                    userVo.setAvatarStep(2);
                }else{
                    userVo.setAvatarStep(10);
                }
            }
            //5.判断是否老员工用户
            NewtvEmp emp = empService.getById(user.getMobile());
            if(emp != null && emp.getSpecialType() == 1){
                userVo.setSpecial(true);
            }

            //构建userDetails
            authUser.setUserDetails(userVo);
            authUser.setUserId((long)authUser.getUserDetails().getUserId());
            authUser.setLoginName(username);
            JwtUserDto<UserVo> jwtUserDto = new JwtUserDto<>();
            jwtUserDto.setUser(authUser);
            return jwtUserDto;
        } else {
            throw new UsernameNotFoundException("用户不存在");
        }
    }
}
