package com.foundao.nft.api.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.foundao.nft.api.service.impl.BannerService;
import com.foundao.nft.api.vo.ProductListVo;
import com.foundao.nft.common.model.Banner;
import com.github.xiaoymin.knife4j.annotations.ApiOperationSupport;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.JsonResult;
import com.tx.security.annotation.AnonymousGetMapping;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @Package: com.foundao.nft.api.controller
 * @ClassName: BannerController
 * @Author: chenli
 * @CreateTime: 2022/6/7 11:46 上午
 * @Description:
 */
@RestController
@RequiredArgsConstructor
@Api(tags = "banner相关")
@RequestMapping("banner")
@Slf4j
@Validated
public class BannerController {

    private final BannerService bannerService;

    @ApiOperation("banner列表")
    @AnonymousGetMapping("/list")
    public JsonResult<List<Banner>> bannerList(){
        List<Banner> list = bannerService.bannerList();
        return JsonResult.success(list);
    }
}
