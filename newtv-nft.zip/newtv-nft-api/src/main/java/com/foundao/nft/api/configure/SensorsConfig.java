package com.foundao.nft.api.configure;

import com.foundao.nft.common.properties.NftProperties;
import com.sensorsdata.analytics.javasdk.ISensorsAnalytics;
import com.sensorsdata.analytics.javasdk.SensorsAnalytics;
import com.sensorsdata.analytics.javasdk.bean.FailedData;
import com.sensorsdata.analytics.javasdk.consumer.Callback;
import com.sensorsdata.analytics.javasdk.consumer.ConcurrentLoggingConsumer;
import com.sensorsdata.analytics.javasdk.consumer.FastBatchConsumer;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * @Package: com.foundao.nft.api.configure
 * @ClassName: SensorsConfig
 * @Author: chenli
 * @CreateTime: 2022/12/5 14:52
 * @Description:
 */
@Configuration
@Slf4j
public class SensorsConfig {

    //@Autowired
    //private NftProperties nftProperties;

    @Value("${spring.profiles.active}")
    private String env;

    @Bean(destroyMethod = "shutdown")
    public ISensorsAnalytics sensorsAnalytics() {
        //本地日志模式（此模式会在指定路径生成相应的日志文件）
        String path = null;
        if (env.contains("prod")) {
            path = "https://datareport.cloud.ottcn.com:18106/sa?project=lianhechanpin";
        } else {
            path = "https://datareport.cloud.ottcn.com:18106/sa?project=test04";
        }

        //发送失败的数据，收集容器。（仅测试使用，避免网络异常时，大批量数据发送失败同时保存内存中，导致 OOM ）
        //参数含义：数据接收地址，是否定时上报，非定时上报阈值触发条数，内部缓存最大容量，定时刷新时间间隔，网络请求超时时间，请求失败之后异常数据回调
        //提供多重构造函数，可以根据实际去调用不同的构造函数
        //收集发送失败的数据
        final FastBatchConsumer fastBatchConsumer =
                new FastBatchConsumer(path, false, 1, 6000, 2, 3, failedData -> {
                    log.error("上报数据失败：{}",failedData);
                });

        //return new SensorsAnalytics(new ConcurrentLoggingConsumer(path));
        //debug 模式(此模式只适用于测试集成 SDK 功能，千万不要使用到生产环境！！！)
        //return new SensorsAnalytics(new DebugConsumer("数据接收地址", true));
        //网络批量发送模式（此模式在容器关闭的时候，如果存在数据还没有发送完毕，就会丢失未发送的数据！！！）
        //return new SensorsAnalytics(new BatchConsumer("数据接收地址"));
        return new SensorsAnalytics(fastBatchConsumer);
    }
}
