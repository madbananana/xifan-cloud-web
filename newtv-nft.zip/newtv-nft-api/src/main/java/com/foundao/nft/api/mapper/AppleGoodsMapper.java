package com.foundao.nft.api.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.foundao.nft.common.model.Goods;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface AppleGoodsMapper extends BaseMapper<Goods> {
}
