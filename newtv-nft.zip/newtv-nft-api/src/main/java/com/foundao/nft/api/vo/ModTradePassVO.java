package com.foundao.nft.api.vo;

import lombok.Data;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import java.math.BigDecimal;

/**
 * @ClassName ModTradePassVO
 * @Description TODO
 * @Author xifan
 * @Date 2022/7/30 12:57
 * @Version 1.0
 */
@Data
@Validated
public class ModTradePassVO {

    @NotBlank(message = "验证码不能为空")
    private String verificationCode;

    @NotBlank(message = "密码不能为空")
    @Pattern(regexp = "\\d{6}",message = "转赠密码只能为6位的数字")
    private String newPassword;
}
