package com.foundao.nft.api.controller;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.crypto.SecureUtil;
import com.alibaba.fastjson.JSON;
import com.foundao.nft.api.service.impl.BlindboxRecordService;
import com.foundao.nft.api.vo.BlindBoxGroupVO;
import com.foundao.nft.common.model.BlindboxRecord;
import com.foundao.nft.common.model.vo.BlindBoxOpenVO;
import com.foundao.nft.common.model.vo.BlindBoxVO;
import com.foundao.nft.common.model.vo.UserVo;
import com.foundao.nft.common.util.RedisKeyFactory;
import com.tx.base.ratelimiter.annotation.TokenBucketRateLimiter;
import com.tx.core.beans.BaseRequestVo;
import com.tx.core.beans.JsonResult;
import com.tx.core.enums.errcode.ApiStatusErrorEnum;
import com.tx.redis.service.RedisService;
import com.tx.security.bean.AuthUser;
import com.tx.security.util.SecurityUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @ClassName BlindBoxController
 * @Description TODO
 * @Author xifan
 * @Date 2022/7/14 22:14
 * @Version 1.0
 */
@RestController
@RequiredArgsConstructor
@Api(tags = "盲盒")
@RequestMapping("blindBox")
@Slf4j
@Validated
public class BlindBoxController {

    private final BlindboxRecordService blindboxRecordService;
    private final RedisService redisService;

    @ApiOperation("我的盲盒")
    @PostMapping("my")
    @TokenBucketRateLimiter(key = "'newtv-nft:limit:myBlindBox'",capacity=1000,rate=1000,limitNote = "服务繁忙，请稍后再试")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "page",value = "页码"),
            @ApiImplicitParam(name = "num",value = "每页个数"),
            @ApiImplicitParam(name = "status",value = "状态 0：未开 1：已开"),
    })
    public JsonResult<List<BlindBoxVO>> my(BaseRequestVo requestVo, Integer status){
        List<BlindBoxVO> list = blindboxRecordService.listBlindBox(requestVo,status);
        return JsonResult.success(list);
    }

    @ApiOperation("我的盲盒列表分类")
    @PostMapping("my/group")
    @TokenBucketRateLimiter(key = "'newtv-nft:limit:myBlindBox'",capacity=1000,rate=1000,limitNote = "服务繁忙，请稍后再试")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "page",value = "页码"),
            @ApiImplicitParam(name = "num",value = "每页个数"),
            @ApiImplicitParam(name = "status",value = "状态 0：未开 1：已开"),
    })
    public JsonResult<List<BlindBoxGroupVO>> myGroupByMetaId(BaseRequestVo requestVo, Integer status){
        List<BlindBoxGroupVO> list = blindboxRecordService.listBlindGroupBySeriesId(requestVo,status);
        return JsonResult.success(list);
    }

    @ApiOperation("开盲盒")
    @PostMapping("open")
    @TokenBucketRateLimiter(key = "'newtv-nft:limit:openBlindBox'",capacity=1000,rate=1000,limitNote = "当前开启盲盒人数过多，请稍后再试")
    public JsonResult<BlindBoxOpenVO> open(String boxId){
        BlindboxRecord blindboxRecord = blindboxRecordService.getById(boxId);

        if (blindboxRecord==null) {
            return JsonResult.error(HttpStatus.INTERNAL_SERVER_ERROR.value(),"不存在的盲盒");
        }
        if (blindboxRecord.getStatus()==1) {
            return JsonResult.error(HttpStatus.INTERNAL_SERVER_ERROR.value(),"不能重复开启盲盒");
        }

        AuthUser<UserVo> currentUser = SecurityUtil.getCurrentUser();
        if (!currentUser.getUserDetails().isAuth()) {
            return JsonResult.error(HttpStatus.INTERNAL_SERVER_ERROR.value(),"请先完成实名认证");
        }

        //校验重复提交
        Map<String,Object> hashData = new HashMap<>(3);
        hashData.put("boxId",boxId);
        hashData.put("userId",blindboxRecord.getUserId());
        hashData.put("metaId",blindboxRecord.getMetaId());

        String orderRepeatLimitKey = RedisKeyFactory.getOrderRepeatLimitKey(SecureUtil.md5(JSON.toJSONString(hashData)));
        if(redisService.get(orderRepeatLimitKey) != null){
            return JsonResult.error(ApiStatusErrorEnum.BAD_REQUEST.getCode(),"操作过于频繁,请稍后再试");
        }
        redisService.set(orderRepeatLimitKey,blindboxRecord.getBoxId(),3L);
        DateTime openTime = DateUtil.parse( blindboxRecord.getOpenTime());
        if (DateUtil.compare(new Date(),openTime)<0) {
            return JsonResult.error(HttpStatus.INTERNAL_SERVER_ERROR.value(),"盲盒未到开启时间");
        }
        BlindBoxOpenVO vo = blindboxRecordService.open(blindboxRecord);
        if (vo != null ) {
            return JsonResult.success(vo);
        } else {
            return JsonResult.error(HttpStatus.INTERNAL_SERVER_ERROR.value(),"盲盒开启失败");
        }
    }
}
