package com.foundao.nft.api.service;

public interface OrderNotifyService {
    /**
     * 保存通知
     * @param notifyData 通知数据
     * @param notifyType 通知类型 2 成功 3失败
     * @param thirdTradeNo 三方交易流水号
     * @param tradeNo 本系统交易单号
     */
    void addNotify(String notifyData,Integer notifyType,String thirdTradeNo,String tradeNo);
}
