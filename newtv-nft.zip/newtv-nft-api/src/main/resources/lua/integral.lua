local num = {}
for i = 1,#(KEYS) do
    num[i] = redis.call('INCRBY',KEYS[i],ARGV[2])
redis.call('EXPIRE',KEYS[1],ARGV[1])
end
return num;
