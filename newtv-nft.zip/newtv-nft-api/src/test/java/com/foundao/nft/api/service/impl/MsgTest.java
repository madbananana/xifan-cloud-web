package com.foundao.nft.api.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import cn.hutool.core.text.StrJoiner;
import cn.hutool.core.util.IdUtil;
import cn.hutool.core.util.RandomUtil;
import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.foundao.nft.api.BaseApplicationTest;
import com.foundao.nft.common.model.AwardInfo;
import com.foundao.nft.common.model.vo.SendMessageVO;
import com.foundao.nft.common.model.vo.SendMsgResponse;
import com.foundao.nft.common.model.vo.SendMsgV2Response;
import com.foundao.nft.common.properties.MsgProperties;
import com.foundao.nft.common.util.RedisKeyFactory;
import com.foundao.nft.common.util.newtv.MapUtils;
import com.foundao.nft.common.util.newtv.UnifyPayUtil;
import com.tx.redis.service.RedisService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * @Package: com.foundao.nft.api.service.impl
 * @ClassName: MsgTest
 * @Author: chenli
 * @CreateTime: 2022/2/18 5:56 下午
 * @Description:
 */
public class MsgTest extends BaseApplicationTest {


    @Autowired
    private RedisService redisService;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private MsgProperties properties;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private MessageService messageService;

    @Autowired
    private AwardInfoService awardInfoService;

    @Autowired
    private UserConsumeService userConsumeService;

    @Test
    public void testSendMessage() throws NoSuchAlgorithmException, InvalidKeyException, UnsupportedEncodingException {
        String phone = "17323048583";
        Long incr = redisService.incr(RedisKeyFactory.getSendMsgCountKey(phone), 1L);
        SendMsgResponse response ;
        redisService.setExpire(phone,5*60, TimeUnit.SECONDS);
        String verificationCode = StrJoiner.of("").append(RandomUtil.randomInts(6)).toString();

        String url = properties.getRequestUrl()+"/api/sms/open/sendtext";
        // 配置参数
        MultiValueMap<String, String> param = new LinkedMultiValueMap<>(5);
        param.add("appKey", properties.getAppKey());
        param.add("channel", "OVERSEAS");
        param.add("content", String.format("【未来数藏】您正在登录账号，验证码%s。5分钟内有效，如非本人操作，请忽略本短信。",verificationCode));
        param.add("mobile", phone);
        param.add("purpose", "VERIFY_CODE");
        String signValue = UnifyPayUtil.buildMapMsgSign(param,properties.getAppSecret());
        param.add("sign", signValue);

        response = restTemplate.postForObject(url,param,SendMsgResponse.class);
        redisService.set(RedisKeyFactory.getVerificationCodeKey(phone), verificationCode, 5*60L);
        System.out.println(response);
    }

    @Test
    public void testMsgV2() throws Exception {
        SendMessageVO vo = new SendMessageVO();
        vo.setMobile("17323048583");
        vo.setUserIp("182.148.14.123");
        vo.setRandStr("@0Kh");
        vo.setTicket("t039SlAUbgHa1Bbbm0rK_6fW_Srreemk7K8gZX5fXJAjkMaQc5-nYMcmPh6b4AmNuZXlrq8LLRTcPemUkVsqLhXoIe43hQ3C60xnbMbyniTL64TJBt2AHE26ygtIz2kipw_LIZcmdmxOK0*");
        vo.setTemplateId("da38466fa2b49759284a8bb653824c53ac71b8d8");
        vo.setTemplateParamSet(CollUtil.newArrayList("123456"));
        SendMsgV2Response sendMsgResponse = messageService.sendMessageV2(vo);
        System.out.println(sendMsgResponse);
    }



    public static void main(String[] args) throws JsonProcessingException {
        String endDateStr = "2022-11-29 23:59:59";
        String beginDateStr = "2022-11-01";
        DateTime beginDate = DateUtil.parse(beginDateStr);
        DateTime endDate = DateUtil.parse(endDateStr);
        DateTime now = DateUtil.date();
        System.out.println(now);
        System.out.println(DateUtil.compare(now, beginDate) >= 0);
        System.out.println(DateUtil.compare(endDate, now) >= 0);
    }

    @Test
    public void testSensitive() {
        List<String> list = new ArrayList<>();
        list.add("1111111");
        list.add("222222");
        list.add("1111333111");
        list.add("44444");
        String mobiles = StrUtil.join(",", list);
        System.out.println(mobiles);
    }

    @Test
    public void testPassword(){
        String encode = passwordEncoder.encode("123456");
        System.out.println(encode);
    }

    @Test
    public void testAwardInfo(){

        userConsumeService.incrUserConsume(502,20000);
        System.out.println(111);
    }
}
