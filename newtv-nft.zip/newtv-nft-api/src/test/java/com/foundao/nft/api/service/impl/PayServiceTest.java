package com.foundao.nft.api.service.impl;

import cn.hutool.json.JSONUtil;
import com.foundao.nft.api.BaseApplicationTest;
import com.foundao.nft.common.model.sdk.response.OrderQueryResponse;
import com.foundao.nft.common.model.sdk.response.OrderResponseWrapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;


public class PayServiceTest extends BaseApplicationTest {
    @Autowired
    private PayService payService;

    @Test
    public void testOderQuery(){
        OrderResponseWrapper<OrderQueryResponse> orderQueryResponse = payService.orderQuery("Ntv60822071615431087");

        System.out.println("=====================");
        System.out.println(JSONUtil.toJsonStr(orderQueryResponse));
    }



}