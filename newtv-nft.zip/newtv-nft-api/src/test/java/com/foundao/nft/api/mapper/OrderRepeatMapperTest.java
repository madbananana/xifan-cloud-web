package com.foundao.nft.api.mapper;

import com.foundao.nft.api.BaseApplicationTest;
import com.foundao.nft.common.model.OrderRepeat;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;



public class OrderRepeatMapperTest extends BaseApplicationTest {

    @Autowired
    private OrderRepeatMapper orderRepeatMapper;
    @Test
    public void testInsert(){
        OrderRepeat orderRepeat = OrderRepeat.builder().orderId(1).userId(1)
                .metaId(1).mark("已拥有藏品,再次付款").build();
        orderRepeatMapper.insert(orderRepeat);
    }
}