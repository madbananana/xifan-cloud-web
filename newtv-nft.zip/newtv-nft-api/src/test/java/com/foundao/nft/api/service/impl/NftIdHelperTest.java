package com.foundao.nft.api.service.impl;

import cn.hutool.http.HttpUtil;
import com.foundao.nft.api.BaseApplicationTest;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

public class NftIdHelperTest extends BaseApplicationTest {
    @Autowired
    private NftIdHelper nftIdHelper;
    @Autowired
    private NftOrderService nftOrderService;

    @Test
    public void entryNftIdToZSetTest(){
//        nftIdHelper.entryNftIdToZSet("152895838b1ff47bec08e4c169664c3501c85ce2a1da74f8b58d260d3c5cfe1c_23",2);
    }

    @Test
    public void releaseNftFlagTest(){
       nftIdHelper.releaseNftFlag("ef70e0681a16708338ed49fdb41ec0f5ae17d9b1a752ec412d9d3984fdfb4855_1","ef70e0681a16708338ed49fdb41ec0f5ae17d9b1a752ec412d9d3984fdfb4855_1");
    }

    @Test
    public void popActualNftIdTest(){
        String nftId = nftIdHelper.popActualNftId("ef70e0681a16708338ed49fdb41ec0f5ae17d9b1a752ec412d9d3984fdfb4855_1");
        System.out.println(nftId);
    }

    public static void main(String[] args) {
        try{
            String respBody = HttpUtil.createGet("https://www.google.com")
//                    .setHttpProxy("127.0.0.1",7890)
                    .timeout(1000).execute().body();
            System.out.println(respBody);

        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
