package com.foundao.nft.api.service.impl;

import cn.hutool.core.util.HashUtil;
import com.alibaba.fastjson.JSON;
import com.foundao.nft.api.BaseApplicationTest;
import com.foundao.nft.common.model.NftTask;
import com.foundao.nft.common.model.NftUserPlatform;
import com.foundao.nft.common.model.sdk.client.NftService;
import com.foundao.nft.common.model.sdk.request.FaceUrlRequest;
import com.foundao.nft.common.model.sdk.request.NftAddressListRequest;
import com.foundao.nft.common.model.sdk.response.FaceUrlResponse;
import com.foundao.nft.common.model.sdk.response.NftInfoListResponse;
import com.foundao.nft.common.model.sdk.response.NftInfoResponse;
import com.foundao.nft.common.model.sdk.response.NftInfoResultResponse;
import com.foundao.nft.common.model.sdk.response.NftTaskResultResponse;
import com.foundao.nft.common.model.sdk.response.SdkResponseBase;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

public class NftServiceTest extends BaseApplicationTest {
    @Autowired
    private NftService nftService;
    @Autowired
    private NftTaskService taskService;
    @Autowired
    private NftUserPlatformService platformService;

    @Test
    public void testAddrList(){
        NftAddressListRequest request = new NftAddressListRequest();
        request.setAddr("ZXe5d4d950fdd36e842a50ea127255e013697d816d");
        request.setLimit(10);
        request.setOffset(0);
        SdkResponseBase<NftInfoListResponse> responseSdkResponseBase = nftService.nftAddressList(request);
        System.out.println(JSON.toJSONString(responseSdkResponseBase));
    }

    @Test
    public void testTransferResult(){
        NftTask task = taskService.getById(3);
        NftUserPlatform userPlatform = platformService.getById(task.getExtend3());
        SdkResponseBase<NftTaskResultResponse> taskResult = nftService.nftTransferResult(userPlatform.getPubkey(),task.getTaskId());

        System.out.println(JSON.toJSONString(taskResult));

    }

    @Test
    public void testNftCount(){
        final SdkResponseBase<NftInfoResultResponse> nft = nftService.nftInfo("aa6673eeaa2336d10d24fdeccd1ea8641d3a93844480d307c4acb19e61653031_2");
        System.out.println(111);
    }

    @Test
    public void testFaceUrl(){
        FaceUrlRequest request = new FaceUrlRequest();
        request.setUserIdentification("c7327c77a71ba26cc8154e9db52e190a09b64e7e66b1108c64ff55631f90ff4f");
        request.setFrom("App");
        SdkResponseBase<FaceUrlResponse> faceUrlResponse = nftService.faceUrl(request);
        System.out.println(faceUrlResponse);
    }

    public static void main(String[] args) {
        int i = HashUtil.javaDefaultHash("链接哦骄傲到的风景奥法打发大水发大发大发发发大法师法定");
        System.out.println(i);
    }
}