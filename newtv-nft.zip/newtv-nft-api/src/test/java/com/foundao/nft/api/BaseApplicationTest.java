package com.foundao.nft.api;


import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles({"uat"})
public class BaseApplicationTest {
}
