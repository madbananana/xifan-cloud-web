package com.foundao.nft.api.service.impl;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import com.alibaba.fastjson.JSON;
import com.foundao.nft.api.BaseApplicationTest;
import com.foundao.nft.common.model.vo.AvatarVo;
import com.foundao.nft.common.model.NftSeriesClaim;
import com.tx.core.beans.JsonResult;
import com.tx.core.enums.errcode.ParamErrorEnum;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;

public class AvatarServiceImplTest extends BaseApplicationTest {
    @Autowired
    private AvatarServiceImpl avatarService;

    @Autowired
    private NftSeriesClaimService seriesClaimService;

    @Test
    public void testLottery(){
        AvatarVo lottery = avatarService.lotteryPartInfo(34L);
        System.out.println(JSON.toJSONString(lottery));
    }

    @Test
    public void testBeginTime(){
        NftSeriesClaim seriesClaim = seriesClaimService.getById(1);
        if (seriesClaim!=null ) {
            String beginTime = seriesClaim.getBeginTime();
            DateTime dateTime = DateUtil.parseDateTime(beginTime);
            if (DateUtil.compare(dateTime,new Date())<0) {
                System.out.println("未到发售时间");
            }
        }
    }
}
