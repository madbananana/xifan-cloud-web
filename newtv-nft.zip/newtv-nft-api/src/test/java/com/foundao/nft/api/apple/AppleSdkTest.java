package com.foundao.nft.api.apple;

import cn.hutool.core.io.FileUtil;
import cn.hutool.core.lang.Assert;
import com.foundao.nft.common.util.apple.AppleSdk;
import org.junit.Test;

import java.net.URL;
import java.nio.charset.Charset;

/**
 * IAP内购测试
 */
public class AppleSdkTest {
    private final static String password = "24f93216dfd44980ae288ff43d99c312";

    @Test
    public void receipt(){
        URL resource = AppleSdkTest.class.getResource("/recipe.txt");
        Assert.notNull(resource,"请在test/resource下面新建recipe.txt");
        String rs = FileUtil.readString(resource, Charset.defaultCharset());
        Assert.notBlank(rs,"请在test/resource/recipe.txt文件中配置票据信息");
        AppleSdk appleSdk = new AppleSdk(password, true);
        System.out.println("=================================================");
        String result = appleSdk.getReceiptData(rs);
        System.out.println(result);
    }

    @Test
    public void testHuToolFileUtil(){
        URL resource = AppleSdkTest.class.getResource("/META-INF/spring.factories");
        Assert.notNull(resource,"不能为空");
        String rs = FileUtil.readString(resource, Charset.defaultCharset());
        System.out.println(rs);
    }

}