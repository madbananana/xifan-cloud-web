package com.foundao.nft.api.service.impl;

import com.alibaba.fastjson.JSON;
import com.foundao.nft.api.BaseApplicationTest;
import com.foundao.nft.api.vo.MyNftVO;
import com.foundao.nft.common.model.NftRecord;
import com.tx.core.beans.BaseRequestVo;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class NftRecordServiceTest extends BaseApplicationTest {

    @Autowired
    private NftRecordService recordService;


    @Test
    public void testListNft(){
        List<MyNftVO> myNftVOS = recordService.listMyNft(new BaseRequestVo() {{
            setPage(1);
            setNum(10);
            getMultiValueSearch().put("userId", 8);
        }});
        System.out.println(JSON.toJSONString(myNftVOS));
    }

    @Test
    public void testUpdate(){
        int i = recordService.updateMaterial(1,502, 6807, 3);
        System.out.println(i);
    }
}
