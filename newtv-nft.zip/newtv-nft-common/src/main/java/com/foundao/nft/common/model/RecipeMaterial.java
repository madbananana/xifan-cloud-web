package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import lombok.Data;

@ApiModel(value = "com-foundao-nft-common-model-RecipeMaterial")
@Data
@TableName(value = "nft_recipe_material")
public class RecipeMaterial implements Serializable {
    @TableId(value = "id", type = IdType.AUTO)
    @ApiModelProperty(value = "")
    private Integer id;

    /**
     * 所属配方
     */
    @TableField(value = "recipe_id")
    @ApiModelProperty(value = "所属配方")
    private Integer recipeId;

    /**
     * 原料所属系列
     */
    @TableField(value = "series_id")
    @ApiModelProperty(value = "原料所属系列")
    private Integer seriesId;

    /**
     * 原料系列名称
     */
    @TableField(value = "series_name")
    @ApiModelProperty(value = "原料系列名称")
    private String seriesName;

    /**
     * 原料藏品id
     */
    @TableField(value = "meta_id")
    @ApiModelProperty(value = "原料藏品id")
    private Integer metaId;

    /**
     * 原料藏品名称
     */
    @TableField(value = "meta_name")
    @ApiModelProperty(value = "原料藏品名称")
    private String metaName;

    /**
     * 合成所需数量
     */
    @TableField(value = "`count`")
    @ApiModelProperty(value = "合成所需数量")
    private Integer count;

    private static final long serialVersionUID = 1L;
}