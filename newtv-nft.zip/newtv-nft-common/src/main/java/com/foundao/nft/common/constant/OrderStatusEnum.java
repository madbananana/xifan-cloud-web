package com.foundao.nft.common.constant;

/**
 * 订单状态
 */
public enum  OrderStatusEnum {
    PAY_WAIT_PAYMENT(1,"待支付"),
    PAYING(11,"支付中"),
    PAY_SUCCESS(2,"支付成功"),
    PAY_FAIL(3,"支付失败"),
    PAY_CANCEL(20,"取消支付");

    /**
     * 返回码
     */
    private int code;

    /**
     * 返回码代表的意思
     */
    private String msg;

    OrderStatusEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public int getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }

    public static boolean isWaitPay(int payStatus){
        return payStatus == OrderStatusEnum.PAY_WAIT_PAYMENT.getCode() || payStatus == OrderStatusEnum.PAYING.getCode();
    }
}
