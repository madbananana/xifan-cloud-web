package com.foundao.nft.common.model;

import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.annotation.*;
import com.foundao.nft.common.constant.IntegralTypeEnum;
import com.foundao.nft.common.constant.PayTypeEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 积分记录表
 */
@ApiModel(value = "com-foundao-nft-common-model-IntegralRecord")
@Data
@TableName(value = "nft_integral_record")
public class IntegralRecord implements Serializable {

    @TableId(value = "id", type = IdType.AUTO)
    @ApiModelProperty(value = "")
    private Integer id;

    @TableField(value = "user_id")
    @ApiModelProperty(value = "")
    private Integer userId;

    /**
     * 分值
     */
    @TableField(value = "integral")
    @ApiModelProperty(value = "分值")
    private Integer integral;

    /**
     * 来源id
     */
    @TableField(value = "source_id")
    @ApiModelProperty(value = "来源id")
    private String sourceId;

    /**
     * 1邀请 2实名 3邀请实名
     */
    @TableField(value = "source_type")
    @ApiModelProperty(value = "类型")
    private String sourceType;

    @TableField(value = "create_time",fill = FieldFill.INSERT)
    @ApiModelProperty(value = "")
    private String createTime;

    /**
     * in 收入 out 支出
     */
    @TableField(value = "symbol")
    @ApiModelProperty(value = "in 收入 out 支出")
    private String symbol;

    /**
     * 备注
     */
    @TableField(value = "remark")
    @ApiModelProperty(value = "备注")
    private String remark;

    @ApiModelProperty(value = "来源类型")
    @TableField(exist = false)
    private String sourceTypeText;

    @ApiModelProperty(value = "剩余积分")
    private Integer restUsableIntegral;

    public String getSourceTypeText(){
        if(StrUtil.isBlank(sourceType)){
            return "";
        }
        if (sourceType.equals(IntegralTypeEnum.BUY_NFT.getType())) {
            return IntegralTypeEnum.getTypeName(sourceType) + "：" +remark;
        } else {
            return IntegralTypeEnum.getTypeName(sourceType);
        }
    }

    private static final long serialVersionUID = 1L;
}
