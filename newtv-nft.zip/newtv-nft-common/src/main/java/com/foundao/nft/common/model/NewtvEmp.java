package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

/**
    @Package: com.foundao.nft.common.model
    @ClassName: NewtvEmp
    @Author: chenli
    @CreateTime: 2021/12/20 6:17 下午
    @Description:
*/
@ApiModel(value="com-foundao-nft-common-model-NewtvEmp")
@Data
@Builder
@TableName(value = "newtv_emp")
public class NewtvEmp {

    @TableId(value = "mobile", type = IdType.INPUT)
    @ApiModelProperty(value="")
    @NotEmpty
    private String mobile;

    @TableField(value = "`name`")
    @ApiModelProperty(value="")
    @NotEmpty
    private String name;

    @ApiModelProperty(value="0 普通员工 1年老员工")
    @NotNull
    @Max(1)
    @Min(0)
    private Integer specialType;

    public static final String COL_MOBILE = "mobile";

    public static final String COL_NAME = "name";
}
