package com.foundao.nft.common.model.sdk.response;

import lombok.Data;

/**
 * @ClassName PriKey2PubKeyResponse
 * @Description TODO
 * @Author xifan
 * @Date 2021/12/15 22:13
 * @Version 1.0
 */
@Data
public class PriKey2PubKeyResponse {

    /**
     * 公钥
     */
    private String pub;

    /**
     * 错误信息
     */
    private String err;
}
