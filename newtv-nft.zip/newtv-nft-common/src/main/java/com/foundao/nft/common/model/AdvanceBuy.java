package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * @Package: com.foundao.nft.common.model
 * @ClassName: AdvanceBuy
 * @Author: chenli
 * @CreateTime: 2022/4/14 4:48 下午
 * @Description:
 */
@ApiModel(value = "com-foundao-nft-common-model-AdvanceBuy")
@Data
@TableName(value = "nft_advance_buy")
public class AdvanceBuy implements Serializable {
    @TableId(value = "id", type = IdType.AUTO)
    @ApiModelProperty(value = "")
    private Integer id;

    /**
     * 系列id
     */
    @TableField(value = "series_id")
    @ApiModelProperty(value = "系列id")
    private String seriesId;

    /**
     * 用户id
     */
    @TableField(value = "user_id")
    @ApiModelProperty(value = "用户id")
    private Long userId;

    /**
     * 预约时间
     */
    @TableField(value = "create_time")
    @ApiModelProperty(value = "预约时间")
    private String createTime;

    /**
     * 发售时间
     */
    @TableField(value = "begin_time")
    @ApiModelProperty(value = "发售时间")
    private String beginTime;

    /**
     * 系列名称
     */
    @TableField(value = "series_name")
    @ApiModelProperty(value = "系列名称")
    private String seriesName;

    /**
     * 预约序号
     */
    @TableField(value = "appointment_num")
    @ApiModelProperty(value = "预约序号")
    private Integer appointmentNum;

    private static final long serialVersionUID = 1L;
    @TableField(exist = false)
    @ApiModelProperty(value = "系列封面url")
    private String coverUrl;


    @TableField(exist = false)
    @ApiModelProperty(value = "品牌名称")
    private String brandName;

    @TableField(exist = false)
    @ApiModelProperty(value = "发行方名称")
    private String issuerName;

    @TableField(value = "notice_status")
    @ApiModelProperty(value = "通知状态")
    private Integer noticeStatus;

    @TableField(exist = false)
    @ApiModelProperty(value = "电话")
    private String mobile;

    @ApiModelProperty(value = "是否为高级用户 0：不是 1：是")
    private Integer advancedUser = 0;
}
