package com.foundao.nft.common.model.mq;

import com.baomidou.mybatisplus.annotation.TableField;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @Package: com.foundao.nft.common.model.mq
 * @ClassName: SendMessageMqDto
 * @Author: chenli
 * @CreateTime: 2022/4/26 2:34 下午
 * @Description:
 */
@Data
public class SendMessageMqDto implements Serializable {

    /**
     * 发售时间
     */
    @ApiModelProperty(value = "发售时间")
    private Date realBeginTime;

    private String beginTimeHour;

    /**
     * 系列名称
     */
    @ApiModelProperty(value = "系列名称")
    private String seriesName;

    private String mobile;
}
