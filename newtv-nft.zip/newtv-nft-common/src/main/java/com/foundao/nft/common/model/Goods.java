package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;
import lombok.NonNull;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
    @Package: com.foundao.nft.common.model
    @ClassName: Goods
    @Author: chenli
    @CreateTime: 2022/2/21 4:11 下午
    @Description:
*/
@ApiModel(value="com-foundao-nft-common-model-Goods")
@Data
@TableName(value = "nft_goods")
public class Goods implements Serializable {
    @TableId(value = "id", type = IdType.AUTO)
    @ApiModelProperty(value="")
    private Integer id;

    /**
     * 内购名称
     */
    @TableField(value = "`name`")
    @ApiModelProperty(value="内购名称")
    @NotBlank(message = "内购名称")
    private String name;

    /**
     * 苹果内购名称
     */
    @TableField(value = "apple_name")
    @ApiModelProperty(value="苹果内购名称")
    @NotBlank(message = "苹果内购名称")
    private String appleName;

    /**
     * 内购价格（分）
     */
    @TableField(value = "price")
    @ApiModelProperty(value="内购价格（分）")
    @NotNull(message = "内购价格（分）")
    private Integer price;

    @TableField(value = "create_time")
    @ApiModelProperty(value="")
    private String createTime;

    @TableField(value = "update_time")
    @ApiModelProperty(value="")
    private String updateTime;

}