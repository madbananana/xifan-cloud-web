package com.foundao.nft.common.constant;

/**
 * rabbitmq 常量池
 */
public interface RabbitmqConst {



    /*****************交换机 ********************************/
    /**
     * topic类型交换机名称
     */
    String CREATE_ORDER_DELAY_EXCHANGE = "nft.create.order.dealy.exchange";




    /*****************消息队列 ********************************/

    /**
     *  订单创建的延迟队列
     */
    String CREATE_ORDER_DELAY_QUEUE  = "nft.create.order.delay.queue";

    /*****************消息队列 ********************************/

    /**
     *  预约短信通知的延迟队列
     */
    String APPOINTMENT_MESSAGE_DELAY_QUEUE  = "nft.appointment.message.delay.queue";

    /**
     *  取消转赠的延迟队列
     */
    String TRANSFER_CANCEL_DELAY_QUEUE = "nft.transfer.cancel.delay.queue";
}
