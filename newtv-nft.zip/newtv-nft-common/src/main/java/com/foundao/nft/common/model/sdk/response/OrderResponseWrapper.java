package com.foundao.nft.common.model.sdk.response;

import lombok.Data;

@Data
public class OrderResponseWrapper<T> {
    private Integer errorCode;
    private String errorMessage;
    private T data;
}
