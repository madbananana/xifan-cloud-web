package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

@Data
@TableName("nft_order_ext")
public class OrderExt {
    @TableId(value = "ext_id",type = IdType.AUTO)
    private Integer extId;
    private Integer orderId;
    private String extend;
    @TableField(fill = FieldFill.INSERT)
    private String createTime;
    /**
     * 标记沙盒和正式环境
     */
    private String mark;

    private String payData;

    private String appVersion;

    private String uuid;

    private String packageName;
}
