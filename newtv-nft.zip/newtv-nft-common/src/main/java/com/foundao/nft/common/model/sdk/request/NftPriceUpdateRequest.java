package com.foundao.nft.common.model.sdk.request;

import lombok.Data;

/**
 * @ClassName NftPriceUpdateRequest
 * @Description TODO
 * @Author xifan
 * @Date 2021/12/18 20:59
 * @Version 1.0
 */
@Data
public class NftPriceUpdateRequest {

    /**
     * 平台公钥
     */
    private String platformPubKey;

    /**
     * 操作者公钥
     */
    private String operatorPubKey;

    /**
     * 要操作的nftId
     */
    private String nftId;

    /**
     * 销售价格
     */
    private int transPrice;

    /**
     * 请求id 每个请求需要填唯一id 重复请求用相同id
     */
    private String operateId;

    /**
     * 操作者的私钥签名，签名对象是（platformPubKey_operatorPubKey_接口名_nftId_transPrice_operateId）
     * 接口名：nft_update_sell
     */
    private String signature;

    /**
     * 平台方的私钥签名，签名对象和signature对象一致。
     */
    private String platformSignature;
}
