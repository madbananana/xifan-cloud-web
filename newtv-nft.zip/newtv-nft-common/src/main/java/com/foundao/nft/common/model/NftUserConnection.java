package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;

/**
    @Package: com.foundao.nft.common.model
    @ClassName: NftUserConnection
    @Author: chenli
    @CreateTime: 2021/12/20 3:58 下午
    @Description:
*/
@ApiModel(value="com-foundao-nft-common-model-NftUserConnection")
@Data
@Builder
@TableName(value = "nft_user_connection")
public class NftUserConnection {
    @TableId(value = "user_id", type = IdType.INPUT)
    @ApiModelProperty(value="")
    private Integer userId;

    @TableField(value = "social_type")
    @ApiModelProperty(value="")
    private String socialType;

    @TableField(value = "social_user_id")
    @ApiModelProperty(value="")
    private String socialUserId;

    public static final String COL_USER_ID = "user_id";

    public static final String COL_SOCIAL_TYPE = "social_type";

    public static final String COL_SOCIAL_USER_ID = "social_user_id";
}
