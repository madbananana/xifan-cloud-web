package com.foundao.nft.common.model.sdk.request;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

/**
 * @Package: com.foundao.nft.common.model.sdk.request
 * @ClassName: OfficialLetterUploadPlatformRequest
 * @Author: chenli
 * @CreateTime: 2021/12/14 2:54 下午
 * @Description:
 */
@Data
public class OfficialLetterUploadPlatformRequest {

    private MultipartFile file;

    private String mobile;

    private String verifyCode;
}
