package com.foundao.nft.common.model.sdk.response;

import lombok.Data;

import java.util.List;

/**
 * @ClassName NftTradeInOutListResponse
 * @Description TODO
 * @Author xifan
 * @Date 2021/12/18 10:27
 * @Version 1.0
 */
@Data
public class NftTradeInOutListResponse {

    private int total;

    private List<TradeInfo> tradeList;
}
