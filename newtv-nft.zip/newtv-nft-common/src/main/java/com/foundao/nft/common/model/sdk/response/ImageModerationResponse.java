package com.foundao.nft.common.model.sdk.response;

import lombok.Data;

/**
 * @Package: com.foundao.nft.common.model.sdk.response
 * @ClassName: ImageModerationResponse
 * @Author: chenli
 * @CreateTime: 2021/12/14 3:16 下午
 * @Description:
 */
@Data
public class ImageModerationResponse {

    /**
     * 建议拿到判断结果后执行的操作 Block：建议屏蔽 Review：建议复审 Pass：建议通过
     */
    private String suggestion;

    /**
     * 恶意标签 Normal：正常 Porn：色情 Abuse：谩骂 Ad：广告
     */
    private String label;

    /**
     * 机器判断当前分类的置信度 0-100 分数越高，表示月可能属于当前分类
     */
    private String score;


}
