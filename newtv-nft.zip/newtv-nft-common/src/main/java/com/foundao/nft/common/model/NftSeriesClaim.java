package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@ApiModel(value = "com-foundao-nft-common-model-NftSeriesClaim")
@Data
@TableName(value = "nft_series_claim")
public class NftSeriesClaim implements Serializable {
    @TableId(value = "id", type = IdType.AUTO)
    @ApiModelProperty(value = "")
    private Integer id;

    /**
     * 系列id
     */
    @TableField(value = "series_id")
    @ApiModelProperty(value = "系列id")
    private String seriesId;

    /**
     * 系列声明人 cms_userid
     */
    @TableField(value = "`operator`")
    @ApiModelProperty(value = "系列声明人 cms_userid")
    private Integer operator;

    /**
     * 系列名
     */
    @TableField(value = "series_name")
    @ApiModelProperty(value = "系列名")
    private String seriesName;

    /**
     * 系列一共多少个 0表示没限制
     */
    @TableField(value = "total_count")
    @ApiModelProperty(value = "系列一共多少个 0表示没限制")
    private Integer totalCount;

    /**
     * 请求流水号
     */
    @TableField(value = "operate_id")
    @ApiModelProperty(value = "请求流水号")
    private String operateId;

    /**
     * 系列封面
     */
    @TableField(value = "cover_url")
    @ApiModelProperty(value = "系列封面")
    private String coverUrl;

    /**
     * 描述
     */
    @TableField(value = "`desc`")
    @ApiModelProperty(value = "描述")
    private String desc;

    /**
     * 开始时间
     */
    @ApiModelProperty(value = "开始时间")
    private String beginTime;

    /**
     * 开始时间
     */
    @ApiModelProperty(value = "截止时间")
    private String endTime;

    /**
     * 系列下的nftId后缀 是否从0开始 true就是从0开始，默认为false从1开始
     */
    @TableField(value = "series_begin_from_zero")
    @ApiModelProperty(value = "系列下的nftId后缀 默认为false从1开始,0表示从0 开始1 表示 从1 开始',")
    private Integer seriesBeginFromZero;

    /**
     * 状态 0：未展示 1：展示中
     */
    @TableField(value = "show_status")
    @ApiModelProperty(value = "状态 0：未展示 1：展示中")
    private Integer showStatus;

    /**
     * 任务id
     */
    @TableField(value = "task_id")
    @ApiModelProperty(value = "任务id")
    private String taskId;

    /**
     * 任务id
     */
    @TableField(value = "task_status")
    @ApiModelProperty(value = "任务状态 2：任务执行中 7：执行成功 10：执行失败")
    private Integer taskStatus;

    /**
     * 作者
     */
    @TableField(value = "author")
    @ApiModelProperty(value = "作者")
    private String author;

    @TableField(value = "meta_type")
    @ApiModelProperty(value = "1普通资源 2 牛头资源 3盲盒资源")
    private Integer metaType;
    /**
     * 新增时间
     */
    @ApiModelProperty(value = "新增时间")
    private String createTime;

    /**
     * 更新时间
     */
    @ApiModelProperty(value = "更新时间")
    private String updateTime;


    /**
     * 品牌方id
     */
    @ApiModelProperty(value = "品牌方id")
    private Integer brandId;

    /**
     * 描述图片列表
     */
    @ApiModelProperty(value = "描述图片列表")
    private String imageDesc;

    /**
     * 描述图片列表
     */
    @ApiModelProperty(value = "系列是否免费 0：收费 1：免费")
    private Integer charge;

    /**
     * 描述图片列表
     */
    @TableField(exist = false)
    @ApiModelProperty(value = "剩余数量")
    private Integer restCount;

    @ApiModelProperty(value = "能否提前购买 0不能 1可以")
    private Integer advanceBuy;

    @ApiModelProperty(value = "作品分类")
    private Integer categoryId;

    @ApiModelProperty(value = "苹果内购id")
    private String appleName;

    @ApiModelProperty(value = "盲盒系列价格")
    private Integer price;

    @ApiModelProperty(value = "发行方")
    private Integer issuerId;

    @ApiModelProperty(value = "盲盒开始时间")
    private String openTime;

    @ApiModelProperty(value = "盲盒封面")
    private String blindBoxIcon;

    @ApiModelProperty(value = "可买份数")
    private Integer buyCount=10;

    @ApiModelProperty(value = "稀有款封面")
    private String rareCover;

    @ApiModelProperty(value = "开启特效")
    private String openSpecialEffects;

    @ApiModelProperty(value = "能否通过积分购买 0：不能 1：能")
    private Integer canIntegralBuy;

    @ApiModelProperty(value = "是否支持兑换 0：不支持 1：支持")
    private Integer exchange;

    @ApiModelProperty(value = "转赠时间")
    private Integer transferTime;

    @ApiModelProperty(value = "是否显示流通信息 0：不显示 1：显示")
    private Integer showCountInfo;

    @ApiModelProperty(value = "是否显示发行数量 0：不显示 1：显示")
    private Integer showPublishCount;

    @ApiModelProperty(value = "是否包含实物 0不包含 1包含")
    private Integer hasGoods;

    @ApiModelProperty(value = "苹果支付类型 0：微信支付宝 1：苹果内购")
    private Integer iosPayType;

}
