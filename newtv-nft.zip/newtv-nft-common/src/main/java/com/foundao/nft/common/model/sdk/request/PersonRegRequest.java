package com.foundao.nft.common.model.sdk.request;

import lombok.Data;

/**
 * @Package: com.foundao.nft.common.model.sdk.request
 * @ClassName: PersonRegRequest
 * @Author: chenli
 * @CreateTime: 2021/12/13 5:44 下午
 * @Description:
 */
@Data
public class PersonRegRequest {

    private String personName;
    private String email;
    private String verifyCode;
    private String idCard;
    private String cardType;
    private String mobile;

}
