package com.foundao.nft.common.model.sdk.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Package: com.foundao.nft.common.model.sdk.response
 * @ClassName: NftInfoResponse
 * @Author: chenli
 * @CreateTime: 2021/12/17 4:34 下午
 * @Description:
 */
@Data
public class NftInfoResponse {

    /**
     * nftId
     */
    @ApiModelProperty("nftId")
    private String nftId;

    /**
     * 所有者地址
     */
    @ApiModelProperty("拥有者地址")
    private String ownerAddr;

    /**
     * 作品名字
     */
    @ApiModelProperty("名称")
    private String name;

    /**
     * 作品url
     */
    @ApiModelProperty("作品url")
    private String url;

    /**
     * 预览图url
     */
    @ApiModelProperty("预览图")
    private String displayUrl;

    /**
     * nft介质的hash,长度64字符 调用sdk的hdsignature.SM3Hash方法，再使用hex.EncodeToString方法生成字符串
     */
    private String hash;

    /**
     * 此owner获得此nft的时间戳
     */
    @ApiModelProperty("获得作品的时间")
    private String ownerGainedTime;


    /**
     * 描述信息
     */
    @ApiModelProperty("作品描述")
    private String desc;

    /**
     * 作品标签
     */
    private String flag;

    /**
     * 作品系列
     */
    @ApiModelProperty("系列名称")
    private String seriesName;

    /**
     * 系列id
     */
    @ApiModelProperty("系列Id")
    private String seriesId;

    /**
     * 系列nft总数
     */
    private int seriesTotalNum;

    /**
     * 扩展字段 用户自定义
     */
    @ApiModelProperty("自定义字段")
    private String metaData;

    /**
     * 发行者地址
     */
    @ApiModelProperty("发行者的地址")
    private String publisherAddr;

    /**
     * 发行平台地址
     */
    @ApiModelProperty("发行平台的地址")
    private String publishPlatformAddr;


    /**
     * 系列偏移id
     */
    private int seriesIndexId;

    /**
     * 发行时交易hash
     */
    private String publishTxHash;

    /**
     * 1可售 2不可售
     */
    private int sellStatus;

    /**
     * 卖多少积分 可售状态下才有效
     */
    private int sellCount;
}
