package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
    @Package: com.foundao.nft.common.model
    @ClassName: Category
    @Author: chenli
    @CreateTime: 2022/6/23 11:38 上午
    @Description:
*/
@ApiModel(value="com-foundao-nft-common-model-Category")
@Data
@TableName(value = "nft_category")
public class Category implements Serializable {
    @TableId(value = "category_id", type = IdType.AUTO)
    @ApiModelProperty(value="")
    private Integer categoryId;

    /**
     * 类别名称
     */
    @TableField(value = "category_name")
    @ApiModelProperty(value="类别名称")
    private String categoryName;

    /**
     * 所属藏品 1:梦幻星球 2:科幻星球
     */
    @TableField(value = "`type`")
    @ApiModelProperty(value="所属藏品 1:梦幻星球 2:科幻星球")
    private Integer type;

    /**
     * 创建时间
     */
    @TableField(value = "create_time")
    @ApiModelProperty(value="创建时间")
    private String createTime;

    /**
     * 状态 0：正常 1：禁用
     */
    @TableField(value = "`status`")
    @ApiModelProperty(value="状态 0：正常 1：禁用")
    private Integer status;

    private static final long serialVersionUID = 1L;
}
