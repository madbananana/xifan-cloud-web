package com.foundao.nft.common.model.sdk.request;

import lombok.Data;

/**
 * @Package: com.foundao.nft.common.model.sdk.request
 * @ClassName: UploadToCosRequest
 * @Author: chenli
 * @CreateTime: 2021/12/16 3:13 下午
 * @Description:
 */
@Data
public class UploadToCosRequest {

    /**
     * 上传到cos的url
     */
    private String cosPath;

    /**
     * cos临时密钥key
     */
    private String tempSecretKey;

    /**
     * cos临时密钥id
     */
    private String tempSecretId;

    /**
     * 请求时需要用的token字符串
     */
    private String sessionToken;

    /**
     * 本地文件名 包含路径
     */
    private String filePath;
}
