package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import lombok.Data;

/**
    @Author: chenli
    @CreateTime: 2023/2/3 11:45
    @Description:
*/

/**
 * 待上链表
 */
@ApiModel(value = "待上链表")
@Data
@TableName(value = "nft_wait_chain_up")
public class WaitChainUp implements Serializable {
    @TableId(value = "id", type = IdType.AUTO)
    @ApiModelProperty(value = "")
    private Integer id;

    /**
     * 用户ID
     */
    @TableField(value = "user_id")
    @ApiModelProperty(value = "用户ID")
    private Integer userId;

    /**
     * 订单id
     */
    @TableField(value = "order_id")
    @ApiModelProperty(value = "订单id")
    private Integer orderId;

    /**
     * 记录id
     */
    @TableField(value = "record_id")
    @ApiModelProperty(value = "记录id")
    private Integer recordId;

    /**
     * 状态0 未处理 1已处理
     */
    @TableField(value = "status")
    @ApiModelProperty(value = "状态0 未处理 1已处理")
    private Integer status;

    private static final long serialVersionUID = 1L;
}