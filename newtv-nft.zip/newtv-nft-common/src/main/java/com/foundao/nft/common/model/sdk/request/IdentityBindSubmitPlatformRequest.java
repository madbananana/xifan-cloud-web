package com.foundao.nft.common.model.sdk.request;

import lombok.Data;

/**
 * @Package: com.foundao.nft.common.model.sdk.request
 * @ClassName: IdentityBindSubmitPlatformRequest
 * @Author: chenli
 * @CreateTime: 2021/12/14 4:14 下午
 * @Description:
 */
@Data
public class IdentityBindSubmitPlatformRequest {

    private String userSignData;

    private String userPubKey;

    private String platformPubKey;

    private String userIdentification;

    private String platformSignData;

}
