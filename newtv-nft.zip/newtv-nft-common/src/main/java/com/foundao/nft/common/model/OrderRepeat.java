package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@TableName(value = "order_repeat")
public class OrderRepeat {
    @TableId(type = IdType.AUTO)
    private Integer id;
    /**
     * 用户id
     */
    private Integer userId;
    /**
     * 订单id
     */
    private Integer orderId;

    /**
     * nft的metaId
     */
    private Integer metaId;
    /**
     * 创建时间
     */
    @TableField(fill = FieldFill.INSERT)
    private String createTime;
    /**
     * 备注
     */
    private String mark;
    /**
     * 详情
     */
    private String detail;
}
