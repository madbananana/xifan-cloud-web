package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
    @Package: com.foundao.nft.common.model
    @ClassName: UserDelete
    @Author: chenli
    @CreateTime: 2022/4/14 6:25 下午
    @Description:
*/
@ApiModel(value="com-foundao-nft-common-model-UserDelete")
@Data
@TableName(value = "nft_user_delete")
public class UserDelete implements Serializable {
    @TableId(value = "user_id", type = IdType.INPUT)
    @ApiModelProperty(value="")
    private Integer userId;

    @TableField(value = "user_name")
    @ApiModelProperty(value="")
    private String userName;

    @TableField(value = "nick_name")
    @ApiModelProperty(value="")
    private String nickName;

    @TableField(value = "`password`")
    @ApiModelProperty(value="")
    private String password;

    @TableField(value = "avatar")
    @ApiModelProperty(value="")
    private String avatar;

    @TableField(value = "mobile")
    @ApiModelProperty(value="")
    private String mobile;

    /**
     * 身份证信息
     */
    @TableField(value = "id_card")
    @ApiModelProperty(value="身份证信息")
    private String idCard;

    /**
     * 状态 0有效 1锁定 2待注销 3已注销
     */
    @TableField(value = "`status`")
    @ApiModelProperty(value="状态 0有效 1锁定 2待注销 3已注销")
    private Integer status;

    @TableField(value = "create_time")
    @ApiModelProperty(value="")
    private Date createTime;

    @TableField(value = "update_time")
    @ApiModelProperty(value="")
    private Date updateTime;

    /**
     * 是否内部员工 0：不是 1：是
     */
    @TableField(value = "internal_emp")
    @ApiModelProperty(value="是否内部员工 0：不是 1：是")
    private Integer internalEmp;

    /**
     * 是否实名认证 0 否 1 是
     */
    @TableField(value = "is_auth")
    @ApiModelProperty(value="是否实名认证 0 否 1 是")
    private Byte isAuth;

    private static final long serialVersionUID = 1L;
}