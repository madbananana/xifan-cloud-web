package com.foundao.nft.common.model.sdk.response;

import lombok.Data;

/**
 * @ClassName PointQueryResponse
 * @Description TODO
 * @Author xifan
 * @Date 2021/12/16 22:34
 * @Version 1.0
 */
@Data
public class PointQueryResponse {

    /**
     * 积分数量
     */
    private int count;
}
