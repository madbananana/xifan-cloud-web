package com.foundao.nft.common.constant;

/**
 * @Enum TaskEnum
 * @Description TODO
 * @Author xifan
 * @Date 2021/12/22 23:39
 * @Version 1.0
 */
public enum TaskEnum {

    //任务类型 1：系列声明 2：nft发行 3：积分申请 4：积分销毁 5：nft购买 6：nft转移 7：销售状态变更 8：售价变更 9：积分转移
    SERIES_CLAIM(1,"系列声明"),
    NFT_PUBLISH(2,"nft发行"),
    POINT_APPLY(3,"积分申请"),
    POINT_DESTROY(4,"积分销毁"),
    NFT_BUY(5,"NFT购买"),
    NFT_TRANSFER(6,"NFT转移");

    /**
     * 返回码
     */
    private Integer code;

    /**
     * 返回码代表的意思
     */
    private String msg;

    TaskEnum(Integer code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Integer getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}
