package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.*;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

import lombok.Data;

@ApiModel(value = "com-foundao-nft-common-model-RecipeCollection")
@Data
@TableName(value = "nft_recipe_collection")
public class RecipeCollection implements Serializable {
    /**
     * 配方集合id
     */
    @TableId(value = "collection_id", type = IdType.AUTO)
    @ApiModelProperty(value = "配方集合id")
    private Integer collectionId;

    /**
     * 集合名称
     */
    @TableField(value = "collection_name")
    @ApiModelProperty(value = "集合名称")
    private String collectionName;

    /**
     * 开始时间
     */
    @TableField(value = "begin_time")
    @ApiModelProperty(value = "开始时间")
    private String beginTime;

    /**
     * 结束时间
     */
    @TableField(value = "end_time")
    @ApiModelProperty(value = "结束时间")
    private String endTime;

    /**
     * 0：未上线 1：上线中
     */
    @TableField(value = "`status`")
    @ApiModelProperty(value = "0：未上线 1：上线中")
    private Integer status;

    /**
     * 封面
     */
    @TableField(value = "display_url")
    @ApiModelProperty(value = "顶部展示图")
    private String displayUrl;

    /**
     * 描述图
     */
    @TableField(value = "image_desc")
    @ApiModelProperty(value = "描述图")
    private String imageDesc;

    /**
     * 选择的配方
     */
    @TableField(value = "recipe_id")
    @ApiModelProperty(value = "选择的配方")
    private Integer recipeId;

    /**
     * 关联的藏品id
     */
    @TableField(value = "meta_id")
    @ApiModelProperty(value = "关联的藏品id")
    private Integer metaId;

    /**
     * 藏品名
     */
    @TableField(exist = false)
    @ApiModelProperty(value = "藏品名")
    private String name;

    /**
     * 创建时间
     */
    @TableField(value = "create_time",fill = FieldFill.INSERT)
    @ApiModelProperty(value="创建时间")
    private String createTime;

    /**
     * 更新时间
     */
    @TableField(value = "update_time",fill = FieldFill.INSERT_UPDATE)
    @ApiModelProperty(value="更新时间")
    private String updateTime;

    @TableField(exist = false)
    @ApiModelProperty(value="合成原料")
    private List<RecipeMaterial> materials;

    @TableField(exist = false)
    @ApiModelProperty(value="已合成份数")
    private Integer mergeCount;

    @TableField(value = "short_series_id")
    @ApiModelProperty(value="系列id")
    private Integer shortSeriesId;

    /**
     * 系列名
     */
    @TableField(exist = false)
    @ApiModelProperty(value = "系列名")
    private String seriesName;

    @TableField(value = "rest_merge_count")
    @ApiModelProperty(value="剩余合成份数")
    private Integer restMergeCount;

    @TableField(value = "total_merge_count")
    @ApiModelProperty(value="总合成份数")
    private Integer totalMergeCount;

    private static final long serialVersionUID = 1L;
}
