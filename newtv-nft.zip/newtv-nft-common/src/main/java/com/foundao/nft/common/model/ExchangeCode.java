package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.*;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

@ApiModel(value = "com-foundao-nft-common-model-ExchangeCode")
@Data
@TableName(value = "nft_exchange_code")
public class ExchangeCode implements Serializable {
    @TableId(value = "code_id", type = IdType.AUTO)
    @ApiModelProperty(value = "")
    private Integer codeId;

    /**
     * 系列id
     */
    @TableField(value = "short_series_id")
    @ApiModelProperty(value = "系列id")
    private Integer shortSeriesId;

    /**
     * metaid
     */
    @TableField(value = "meta_id")
    @ApiModelProperty(value = "metaid")
    private Integer metaId;

    /**
     * 兑换码
     */
    @TableField(value = "code")
    @ApiModelProperty(value = "兑换码")
    private String code;

    @TableField(value = "create_time",fill = FieldFill.INSERT)
    @ApiModelProperty(value = "")
    private String createTime;

    @TableField(value = "update_time",fill = FieldFill.INSERT_UPDATE)
    @ApiModelProperty(value = "")
    private String updateTime;

    /**
     * 0：未使用 1：已使用
     */
    @TableField(value = "`status`")
    @ApiModelProperty(value = "0：未使用 1：已使用")
    private Integer status;

    /**
     * 使用的用户id
     */
    @TableField(value = "used_user_id")
    @ApiModelProperty(value = "使用的用户id")
    private Integer usedUserId;

    private static final long serialVersionUID = 1L;
}
