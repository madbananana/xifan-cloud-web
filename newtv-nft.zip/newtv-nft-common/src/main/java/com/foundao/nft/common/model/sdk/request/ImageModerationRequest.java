package com.foundao.nft.common.model.sdk.request;

import lombok.Data;

/**
 * @Package: com.foundao.nft.common.model.sdk.request
 * @ClassName: ImageModerationRequest
 * @Author: chenli
 * @CreateTime: 2021/12/14 3:11 下午
 * @Description:
 */
@Data
public class ImageModerationRequest {

    private String imageUrl;

    /**
     * 截帧频率 GIT/长图监测专用，默认值0，表示只会监测gif/长图第一帧
     */
    private int interval;

    /**
     * GIT/长图监测专用，代表最大截帧数量，默认值为1
     */
    private int maxFrames;
}
