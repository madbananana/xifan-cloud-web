package com.foundao.nft.common.model.sdk.request;

import lombok.Data;

/**
 * @ClassName SignByPriKeyRequest
 * @Description TODO
 * @Author xifan
 * @Date 2021/12/15 22:33
 * @Version 1.0
 */
@Data
public class SignByPriKeyRequest {

    /**
     * 私钥
     */
    private String priKey;

    /**
     * 签名前的数据
     */
    private String data;
}
