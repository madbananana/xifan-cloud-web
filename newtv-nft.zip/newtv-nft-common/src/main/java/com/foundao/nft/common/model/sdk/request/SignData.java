package com.foundao.nft.common.model.sdk.request;

import lombok.Data;

/**
 * @Package: com.foundao.nft.common.model.sdk.request
 * @ClassName: SignData
 * @Author: chenli
 * @CreateTime: 2021/12/10 5:19 下午
 * @Description: 签名数据
 */
@Data
public class SignData {

    private String appId;

    /**
     * 签名后的数据
     */
    private String signature;

    /**
     * 时间戳
     */
    private String signatureTime;

    /**
     * 随机数
     */
    private String nonce;

    /**
     * 错误信息
     */
    private String err;
}
