package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@ApiModel(value = "com-foundao-nft-common-model-NftRecord")
@Data
@TableName(value = "nft_record")
public class NftRecord implements Serializable {

    @TableId(value = "id", type = IdType.AUTO)
    @ApiModelProperty(value = "")
    private String id;

    @TableField(value = "nft_id")
    @ApiModelProperty(value = "")
    private String nftId;

    @ApiModelProperty(value = "资源nft的自增id")
    private Integer metaId;

    @ApiModelProperty("1普通款 3隐藏款")
    private Integer metaType;
    /**
     * 获取时间
     */
    @TableField(value = "owner_time")
    @ApiModelProperty(value = "获取时间")
    private Date ownerTime;

    @ApiModelProperty(value = "用有人的地址")
    private String ownerAddr;


    /**
     * 获取时间
     */
    @TableField(value = "create_time")
    @ApiModelProperty(value = "新增时间")
    private Date createTime;

    /**
     * 获取时间
     */
    @TableField(value = "update_time",fill = FieldFill.INSERT_UPDATE)
    @ApiModelProperty(value = "更新时间")
    private String updateTime;


    /**
     * 获取类型 1：购买 2：他人赠送
     */
    @TableField(value = "obtain_type")
    @ApiModelProperty(value = "获取类型 1：购买 2：他人赠送")
    private Integer obtainType;

    /**
     * 赠送人id
     */
    @TableField(value = "giver_user_id")
    @ApiModelProperty(value = "赠送人id")
    private Integer giverUserId;

    @TableField(value = "giver_user_name")
    @ApiModelProperty(value = "赠送人姓名")
    private String giverUserName;

    /**
     * 拥有者用户id
     */
    @TableField(value = "user_id")
    @ApiModelProperty(value = "拥有者用户id")
    private Integer userId;

    /**
     * 真实nftId
     */
    @TableField(value = "actual_nft_id")
    @ApiModelProperty(value = "真实nftId")
    private String actualNftId;

    /**
     * 交易hash
     */
    @TableField(value = "tx_hash")
    @ApiModelProperty(value = "交易hash")
    private String txHash;

    /**
     * 交易hash
     */
    @TableField(value = "buy_status")
    @ApiModelProperty(value = "2 执行中 7 成功 10 失败 5转移中 11转赠中 12待接收 13领取中 14合成锁定中 15销毁中")
    private Integer buyStatus;

    /**
     * 交易hash
     */
    @TableField(value = "merge_id")
    @ApiModelProperty(value = "合成id号")
    private Integer mergeId;
}
