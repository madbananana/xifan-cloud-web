package com.foundao.nft.common.constant;

/**
 * 订单状态
 */
public enum IntegralTypeEnum {
    /**
     * 邀请好友注册成功
     */
    INVITE("invite","邀请好友注册成功"),
    /**
     * 邀请好用实名认证成功
     */
    INVITE_REAL_NAME_AUTH("inviteRealNameAuth","邀请好友实名认证成功"),
    /**
     * 实名认证成功
     */
    REAL_NAME_AUTH("realNameAuth","实名认证成功"),
    /**
     * 兑换藏品
     */
    BUY_NFT("buyNft","兑换藏品"),
    /**
     * 系统发放
     */
    SYSTEM_REWARD("systemReward","系统发放"),
    /**
     * 系统扣除
     */
    SYSTEM_REDUCE("systemReduce","系统扣除");

    /**
     * type
     */
    private String type;

    /**
     * 返回码代表的意思
     */
    private String typeName;

    IntegralTypeEnum(String type, String typeName) {
        this.type = type;
        this.typeName = typeName;
    }

    public String getType() {
        return type;
    }

    public String getTypeName() {
        return typeName;
    }

    public static String getType(String type){
        IntegralTypeEnum[] values = IntegralTypeEnum.values();
        for (int i = 0; i < values.length; i++) {
            if (type.equals(values[i].type)) {
                return values[i].type;
            }
        }
        return null;
    }

    public static String getTypeName(String type){
        IntegralTypeEnum[] values = IntegralTypeEnum.values();
        for (int i = 0; i < values.length; i++) {
            if (type.equals(values[i].type)) {
                return values[i].typeName;
            }
        }
        return null;
    }
}
