package com.foundao.nft.common.model.mq;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @Package: com.foundao.nft.common.model.mq
 * @ClassName: TransferCancelMqDto
 * @Author: chenli
 * @CreateTime: 2022/7/29 2:57 下午
 * @Description:
 */
@Data
public class TransferCancelMqDto implements Serializable {

    @ApiModelProperty(value="")
    private Integer transId;

    /**
     * 送者用户id
     */
    @ApiModelProperty(value="送者用户id")
    private Integer giveUserId;

    /**
     * 接收用户id
     */
    @ApiModelProperty(value="接收用户id")
    private Integer receiveUserId;

    /**
     * 真实nftId
     */
    @ApiModelProperty(value="真实nftId")
    private String actualNftId;

    /**
     * 转赠记录id
     */
    @ApiModelProperty(value="转赠记录id")
    private String giveRecordId;
}
