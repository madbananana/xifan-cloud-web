package com.foundao.nft.common.model.sdk.response;

import lombok.Data;

/**
 * @ClassName SignByPriKeyResponse
 * @Description TODO
 * @Author xifan
 * @Date 2021/12/15 22:35
 * @Version 1.0
 */
@Data
public class SignByPriKeyResponse {

    /**
     * 签名后的数据
     */
    private String signedData;

    /**
     * 错误信息
     */
    private String err;
}
