package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 公告表
 */
@ApiModel(value = "com-foundao-nft-common-model-Issuer")
@Data
@TableName(value = "nft_issuer")
public class Issuer implements Serializable {

    @TableId(value = "id", type = IdType.AUTO)
    @ApiModelProperty(value = "")
    private Integer id;

    /**
     * 发行方名称
     */
    @TableField(value = "issuer_name")
    @ApiModelProperty(value = "发行方名称")
    private String issuerName;

    /**
     * 发行方图标
     */
    @TableField(value = "issuer_icon")
    @ApiModelProperty(value = "发行方图标")
    private String issuerIcon;

    /**
     * 品牌描述
     */
    @TableField(value = "`desc`")
    @ApiModelProperty(value = "发行方描述")
    private String desc;

    private static final long serialVersionUID = 1L;
}
