package com.foundao.nft.common.model.sdk.response;

import lombok.Data;

/**
 * @ClassName TranInfo
 * @Description TODO
 * @Author xifan
 * @Date 2021/12/18 0:12
 * @Version 1.0
 */
@Data
public class TranInfo {

    private String fromAddr;

    private String toAddr;

    private int dealCount;

    private String txHash;

    /**
     * 积分接收地址
     */
    private String pointReceiverAddr;

    /**
     * 链上成交时间
     */
    private int dealTimestamp;

    /**
     * 交易类别 1发行 2购买 3转移 4设置价格 5设置状态
     */
    private int txType;

}
