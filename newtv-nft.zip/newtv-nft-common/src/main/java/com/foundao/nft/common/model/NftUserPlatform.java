package com.foundao.nft.common.model;

import com.alibaba.fastjson.annotation.JSONField;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
    @Package: com.foundao.nft.common.model
    @ClassName: NftUserPlatform
    @Author: chenli
    @CreateTime: 2021/12/21 3:24 下午
    @Description:
*/
@ApiModel(value="com-foundao-nft-common-model-NftUserPlatform")
@Data
@TableName(value = "nft_user_platform")
public class NftUserPlatform implements Serializable {
    @TableId(value = "user_id", type = IdType.INPUT)
    @ApiModelProperty(value="")
    private Integer userId;

    /**
     * nft平台唯一标识
     */
    @TableField(value = "user_identification")
    @ApiModelProperty(value="nft平台唯一标识")
    private String userIdentification;

    /**
     * 用户至信链地址
     */
    @TableField(value = "addr")
    @ApiModelProperty(value="用户至信链地址")
    private String addr;

    /**
     * 用户公钥
     */
    @TableField(value = "pubKey")
    @ApiModelProperty(value="用户公钥")
    private String pubkey;

    /**
     * 用户私钥
     */
    @TableField(value = "priKey")
    @ApiModelProperty(value="用户私钥")
    @JSONField(serialize = false)
    @JsonIgnore
    private String prikey;

    /**
     * 助记词
     */
    @TableField(value = "mnemonic")
    @ApiModelProperty(value="助记词")
    @JSONField(serialize = false)
    @JsonIgnore
    private String mnemonic;

    /**
     * nft地址和唯一标识绑定状态 1：绑定中 2：已绑定 3：绑定失败 4：未发起绑定
     */
    @TableField(value = "status")
    @ApiModelProperty(value="nft地址和唯一标识绑定状态 1：绑定中 2：已绑定 3：绑定失败 4：未发起绑定")
    private Integer status;

    /**
     * 转赠密码
     */
    @TableField(value = "trade_pass")
    @ApiModelProperty(value="转赠密码")
    @JsonIgnore
    private String tradePass;
}
