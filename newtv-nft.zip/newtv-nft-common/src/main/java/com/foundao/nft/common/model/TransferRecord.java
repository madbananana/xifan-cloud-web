package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.*;
import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 @Package: com.foundao.nft.common.model
 @ClassName: TransferRecord
 @Author: chenli
 @CreateTime: 2022/7/28 2:50 下午
 @Description:
 */
/**
 * 未使用
 */
@ApiModel(value="com-foundao-nft-common-model-TransferRecord")
@Data
@TableName(value = "nft_transfer_record")
public class TransferRecord implements Serializable {
    @TableId(value = "trans_id", type = IdType.AUTO)
    @ApiModelProperty(value="")
    private Integer transId;

    /**
     * 真实nftid
     */
    @TableField(value = "actual_nft_id")
    @ApiModelProperty(value="真实nftid")
    private String actualNftId;

    /**
     * 送者用户id
     */
    @TableField(value = "give_user_id")
    @ApiModelProperty(value="送者用户id")
    private Integer giveUserId;

    /**
     * 接收用户id
     */
    @TableField(value = "receive_user_id")
    @ApiModelProperty(value="接收用户id")
    private Integer receiveUserId;

    /**
     * 转赠状态 0：转赠中 1：转赠成功 2：转赠失败
     */
    @TableField(value = "`status`")
    @ApiModelProperty(value="转赠状态 0：转赠中 1：转赠成功 2：转赠失败")
    private Integer status;

    /**
     * 接收者电话
     */
    @TableField(value = "receive_mobile")
    @ApiModelProperty(value="接收者电话")
    private String receiveMobile;

    /**
     * 赠送者电话
     */
    @TableField(exist = false)
    @ApiModelProperty(value="赠送者电话")
    private String giveMobile;

    /**
     * 创建时间
     */
    @TableField(value = "create_time")
    @ApiModelProperty(value="创建时间")
    private String createTime;

    /**
     * 藏品名
     */
    @TableField(value = "`name`")
    @ApiModelProperty(value="藏品名")
    private String name;

    /**
     * 系列名
     */
    @TableField(value = "series_name")
    @ApiModelProperty(value="系列名")
    private String seriesName;

    /**
     * 更新时间
     */
    @TableField(value = "update_time",fill = FieldFill.UPDATE)
    @ApiModelProperty(value="更新时间")
    private String updateTime;

    /**
     * 失败原因
     */
    @TableField(value = "msg")
    @ApiModelProperty(value="失败原因")
    private String msg;

    /**
     * 藏品id
     */
    @TableField(value = "meta_id")
    @ApiModelProperty(value="藏品id")
    private Integer metaId;

    /**
     * 系列id
     */
    @TableField(value = "short_series_id")
    @ApiModelProperty(value="系列id")
    private Integer shortSeriesId;

    /**
     * 接受者名称
     */
    @TableField(value = "receive_name")
    @ApiModelProperty(value="接受者名称")
    private String receiveName;

    /**
     * 藏品封面
     */
    @TableField(value = "display_url")
    @ApiModelProperty(value="藏品封面")
    private String displayUrl;

    /**
     * 任务id
     */
    @TableField(value = "task_id")
    @ApiModelProperty(value="任务id")
    @JsonIgnore
    private String taskId;

    /**
     * 领取时间
     */
    @TableField(value = "receive_time")
    @ApiModelProperty(value="领取时间")
    private String receiveTime;

    /**
     * 领取时间
     */
    @TableField(value = "expire_time")
    @ApiModelProperty(value="过期时间")
    private String expireTime;

    /**
     * 赠送人
     */
    @TableField(value = "give_name")
    @ApiModelProperty(value="赠送人")
    private String giveName;

    private static final long serialVersionUID = 1L;
}
