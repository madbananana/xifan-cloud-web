package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.*;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 积分表
 */
@ApiModel(value="com-foundao-nft-common-model-Integral")
@Data
@TableName(value = "nft_integral")
public class Integral implements Serializable {
    @TableId(value = "user_id", type = IdType.INPUT)
    @ApiModelProperty(value="")
    private Integer userId;

    /**
     * 积分
     */
    @TableField(value = "usable_integral")
    @ApiModelProperty(value="可用积分")
    private Integer usableIntegral;

    /**
     * 冻结积分
     */
    @TableField(value = "frozen_integral")
    @ApiModelProperty(value="冻结积分")
    private Integer frozenIntegral;

    @TableField(value = "create_time",fill = FieldFill.INSERT)
    @ApiModelProperty(value="")
    private String createTime;

    @TableField(value = "update_time",fill = FieldFill.INSERT_UPDATE)
    @ApiModelProperty(value="")
    private String updateTime;

    @TableField(exist = false)
    @ApiModelProperty(value="用户昵称")
    private String nickName;

    @TableField(exist = false)
    @ApiModelProperty(value="手机号")
    private String mobile;

    private static final long serialVersionUID = 1L;
}
