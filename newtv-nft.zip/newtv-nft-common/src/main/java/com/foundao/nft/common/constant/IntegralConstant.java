package com.foundao.nft.common.constant;

import lombok.Data;

/**
 * @Interface IntegralConstant
 * @Description TODO
 * @Author xifan
 * @Date 2022/8/22 12:17
 * @Version 1.0
 */
public interface IntegralConstant {

    /**
     * 邀请
     */
    String INVITE = "invite";

    /**
     * 被邀请人实名认证
     */
    String INVITE_REAL_NAME_AUTH = "inviteRealNameAuth";

    /**
     * 实名认证
     */
    String REAL_NAME_AUTH = "realNameAuth";

    /**
     * 买NFT
     */
    String BUY_NFT = "buyNft";
}
