package com.foundao.nft.common.model.sdk.response;

import lombok.Data;

/**
 * @Package: com.foundao.nft.common.model.sdk.response
 * @ClassName: UploadSecretResponse
 * @Author: chenli
 * @CreateTime: 2021/12/16 5:52 下午
 * @Description:
 */
@Data
public class UploadSecretResponse {

    private String tempSecretId;

    private String tempSecretKey;

    private String sessionToken;

    private String uploadAddress;
}
