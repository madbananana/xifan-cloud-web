package com.foundao.nft.common.model.sdk.request;

import lombok.Data;

/**
 * @Package: com.foundao.nft.common.model.sdk.request
 * @ClassName: UploadUrlGetRequest
 * @Author: chenli
 * @CreateTime: 2021/12/16 3:31 下午
 * @Description:
 */
@Data
public class UploadUrlGetRequest {

    /**
     * 系列名
     */
    private String seriesName;

    /**
     * 平台唯一标识
     */
    private String platformIdentification;

    /**
     * 发行唯一标识
     */
    private String userIdentification;

}
