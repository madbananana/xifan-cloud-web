package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 合成记录表
 */
@ApiModel(value = "合成记录表")
@Data
@TableName(value = "nft_merge")
public class Merge implements Serializable {
    @TableId(value = "merge_id", type = IdType.AUTO)
    @ApiModelProperty(value = "")
    private Integer mergeId;

    /**
     * 藏品ID
     */
    @TableField(value = "meta_id")
    @ApiModelProperty(value = "藏品ID")
    private Integer metaId;

    /**
     * 用户ID
     */
    @TableField(value = "user_id")
    @ApiModelProperty(value = "用户ID")
    private Integer userId;

    /**
     * 配方ID
     */
    @TableField(value = "recipe_id")
    @ApiModelProperty(value = "配方ID")
    private Integer recipeId;

    /**
     * 活动ID
     */
    @TableField(value = "collection_id")
    @ApiModelProperty(value = "活动ID")
    private Integer collectionId;

    /**
     * 状态 0：未完成 1：已完成 2：失败
     */
    @TableField(value = "`status`")
    @ApiModelProperty(value = "状态 0：未完成 1：已完成 2：失败")
    private Integer status;

    @TableField(value = "create_time",fill = FieldFill.INSERT)
    @ApiModelProperty(value = "")
    private String createTime;

    @TableField(value = "update_time",fill = FieldFill.INSERT_UPDATE)
    @ApiModelProperty(value = "")
    private String updateTime;

    private static final long serialVersionUID = 1L;
}
