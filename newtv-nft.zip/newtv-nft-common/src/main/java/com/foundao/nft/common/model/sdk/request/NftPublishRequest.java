package com.foundao.nft.common.model.sdk.request;

import lombok.Data;

/**
 * @Package: com.foundao.nft.common.model.sdk.request
 * @ClassName: NftPublishRequest
 * @Author: chenli
 * @CreateTime: 2021/12/17 9:47 上午
 * @Description:
 */
@Data
public class NftPublishRequest {


    /**
     * 作者名
     */
    private String author;

    /**
     * nft名字
     */
    private String name;

    /**
     * 介质url
     */
    private String url;

    /**
     * 预览图url
     */
    private String displayUrl;

    /**
     * nft介质的hash,长度64字符 调用sdk的hdsignature.SM3Hash方法，再使用hex.EncodeToString方法生成字符串
     */
    private String hash;

    /**
     * 描述信息
     */
    private String desc;

    /**
     * 标签
     */
    private String flag;

    /**
     * 发行数量
     */
    private int publishCount;


    private String seriesId;

    private int seriesBeginIndex;

    /**
     * 1可售 2不可售
     */
    private int sellStatus;

    /**
     * 售价多少积分
     */
    private int sellCount;

    /**
     * 请求id 每个请求需要填唯一id 重复请求用相同id
     */
    private String operateId;

    /**
     * 扩展字段
     */
    private String metaData;


    /* ***** 以下字段不需要填充  sdk自动填充 ***********/
    /**
     * 系列声明人公钥
     */
    private String pubKey;

    /**
     * 平台公钥
     */
    private String platformPubKey;

    /**
     * 发行人的私钥签名，
     * 接口名=series_claim
     */
    private String signature;

    /**
     * 平台方的私钥签名，签名对象和signature一致
     */
    private String platformSignature;

}
