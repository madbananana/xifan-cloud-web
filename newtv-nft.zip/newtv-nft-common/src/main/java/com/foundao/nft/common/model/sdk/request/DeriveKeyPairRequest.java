package com.foundao.nft.common.model.sdk.request;

import lombok.Data;

/**
 * @ClassName DeriveKeyPairRequest
 * @Description TODO
 * @Author xifan
 * @Date 2021/12/15 21:56
 * @Version 1.0
 */
@Data
public class DeriveKeyPairRequest {

    /**
     * 助记词
     */
    private String mnemonic;

    /**
     * 默认子账户序号前缀：m/66/0/0/0/index
     */
    private int index;
}
