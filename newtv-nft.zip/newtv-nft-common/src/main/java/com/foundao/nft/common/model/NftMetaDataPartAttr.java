package com.foundao.nft.common.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
public class NftMetaDataPartAttr implements Serializable {
        /**
         * 部件位置
         */
        @ApiModelProperty("部件类型 1 背景 2 道具 3 耳机   4 头饰 5 眼镜 6 衣服")
        private Integer partType;
        /**
         * 部件名称
         */
        @ApiModelProperty("部件名称")
        private String partName;
        /**
         * 比例
         */
        @ApiModelProperty("比例")
        private Double ratio;
        /**
         * 是否老员工  是  否
         */
        @ApiModelProperty("是否老员工 1是 0 否")
        private Integer isSpecialType;
        /**
         * 是否唯一 1是  0否
         */
        @ApiModelProperty("是否唯一 1是 0 否")
        private Integer IsUnique;
}
