package com.foundao.nft.common.model.sdk.client;

import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.foundao.nft.common.model.sdk.request.*;
import com.foundao.nft.common.model.sdk.response.*;
import com.foundao.nft.common.properties.NftProperties;
import com.foundao.nft.common.util.NftCommonUtil;
import com.foundao.nft.common.util.newtv.MapUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RequiredArgsConstructor
@Slf4j
@Component
public class NftService {

    private final RestTemplate restTemplate;
    private final NftProperties properties;
    private final NftCommonUtil nftCommonUtil;


    private String getEncodeQueryParamUrl(String url, Map<String,String> params){
        return url + "?" + MapUtils.mapJoin(params,false,true);
    }


    public SdkResponseBase<Void> verifyCode(String mobile){
        String path = "api/v1/nft/register/verify_code";
        SignData signData = nftCommonUtil.generateApiSign(true);
        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(signData);

        MultiValueMap<String, Object> param = new LinkedMultiValueMap<>(8);
        param.add("mobile", mobile);

        HttpEntity<MultiValueMap<String, Object>> httpEntity = new HttpEntity<>(param, httpHeaders);

        ParameterizedTypeReference<SdkResponseBase<Void>> typeRef = new ParameterizedTypeReference<SdkResponseBase<Void>>() {};
        ResponseEntity<SdkResponseBase<Void>> responseEntity = restTemplate.exchange(properties.getReqUrl()+path, HttpMethod.POST,httpEntity,typeRef);

        SdkResponseBase<Void> respBody = responseEntity.getBody();
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }

    public SdkResponseBase<PersonRegResponse> personReg(SignData signData, PersonRegRequest personRegRequest){
        String path = "api/v1/nft/register/person";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(signData);

        HttpEntity<PersonRegRequest> httpEntity = new HttpEntity<>(personRegRequest, httpHeaders);

        ParameterizedTypeReference<SdkResponseBase<PersonRegResponse>> typeRef = new ParameterizedTypeReference<SdkResponseBase<PersonRegResponse>>() {};
        ResponseEntity<SdkResponseBase<PersonRegResponse>> responseEntity = restTemplate.exchange(properties.getReqUrl()+path, HttpMethod.POST,httpEntity,typeRef);

        SdkResponseBase<PersonRegResponse> respBody = responseEntity.getBody();
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }

    /**
     * 自然人注册实名接口（平台签名）
     * @param request 请求对象
     * @return
     */
    public SdkResponseBase<PersonRegResponse> personRegPlatform(PersonRegPlatformRequest request){

        String path = "api/v1/nft/register/person_platform";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(true));
        httpHeaders.add("App_Id", properties.getAppId());

        HttpEntity<PersonRegPlatformRequest> httpEntity = new HttpEntity<>(request, httpHeaders);


        ParameterizedTypeReference<SdkResponseBase<PersonRegResponse>> typeRef = new ParameterizedTypeReference<SdkResponseBase<PersonRegResponse>>() {};
        ResponseEntity<SdkResponseBase<PersonRegResponse>> responseEntity = restTemplate.exchange(properties.getReqUrl()+path, HttpMethod.POST,httpEntity,typeRef);

        SdkResponseBase<PersonRegResponse> respBody = responseEntity.getBody();
        log.info("自然人注册实名接口:请求:{},返回:{}", JSON.toJSONString(request),JSON.toJSONString(respBody));

        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }

    /**
     * 营业执照上传接口
     * @param request
     * @return
     */
    public SdkResponseBase<ImageUploadResponse> bsLicenseUpload(BsLicenseUploadRequest request){

        String path = "api/v1/nft/business_license/upload";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(false));
        httpHeaders.add("App_Id", properties.getAppId());
        httpHeaders.setContentType(MediaType.MULTIPART_FORM_DATA);

        HttpEntity<BsLicenseUploadRequest> httpEntity = new HttpEntity<>(request, httpHeaders);


        ParameterizedTypeReference<SdkResponseBase<ImageUploadResponse>> typeRef = new ParameterizedTypeReference<SdkResponseBase<ImageUploadResponse>>() {};
        ResponseEntity<SdkResponseBase<ImageUploadResponse>> responseEntity = restTemplate.exchange(properties.getReqUrl()+path, HttpMethod.POST,httpEntity,typeRef);

        SdkResponseBase<ImageUploadResponse> respBody = responseEntity.getBody();
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }

    /**
     * 电子公函上传
     * @param request
     * @return
     */
    public SdkResponseBase<ImageUploadResponse> officialLetterUpload(OfficialLetterUploadRequest request){

        String path = "api/v1/nft/official_letter/upload";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(false));
        httpHeaders.add("App_Id", properties.getAppId());
        httpHeaders.setContentType(MediaType.MULTIPART_FORM_DATA);

        HttpEntity<OfficialLetterUploadRequest> httpEntity = new HttpEntity<>(request, httpHeaders);


        ParameterizedTypeReference<SdkResponseBase<ImageUploadResponse>> typeRef = new ParameterizedTypeReference<SdkResponseBase<ImageUploadResponse>>() {};
        ResponseEntity<SdkResponseBase<ImageUploadResponse>> responseEntity = restTemplate.exchange(properties.getReqUrl()+path, HttpMethod.POST,httpEntity,typeRef);

        SdkResponseBase<ImageUploadResponse> respBody = responseEntity.getBody();
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }


    /**
     * 企业注册实名
     * @param request
     * @return
     */
    public SdkResponseBase<PersonRegResponse> companyReg(CompanyRegisRequest request){
        String path = "api/v1/nft/register/company";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(false));

        HttpEntity<CompanyRegisRequest> httpEntity = new HttpEntity<>(request, httpHeaders);

        ParameterizedTypeReference<SdkResponseBase<PersonRegResponse>> typeRef = new ParameterizedTypeReference<SdkResponseBase<PersonRegResponse>>() {};
        ResponseEntity<SdkResponseBase<PersonRegResponse>> responseEntity = restTemplate.exchange(properties.getReqUrl()+path, HttpMethod.POST,httpEntity,typeRef);

        SdkResponseBase<PersonRegResponse> respBody = responseEntity.getBody();
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }

    /**
     * 下发查询用户信息验证码接口
     * @param request
     * @return
     */
    public SdkResponseBase<Void> userQueryVerifyCode(UserQueryVerifyCodeRequest request){
        String path = "api/v1/nft/user/query/verify_code";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(false));

        HttpEntity<UserQueryVerifyCodeRequest> httpEntity = new HttpEntity<>(request, httpHeaders);

        ParameterizedTypeReference<SdkResponseBase<Void>> typeRef = new ParameterizedTypeReference<SdkResponseBase<Void>>() {};
        ResponseEntity<SdkResponseBase<Void>> responseEntity = restTemplate.exchange(properties.getReqUrl()+path, HttpMethod.POST,httpEntity,typeRef);

        SdkResponseBase<Void> respBody = responseEntity.getBody();
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }

    /**
     * 查询用户信息
     * @param request
     * @return
     */
    public SdkResponseBase<PersonRegResponse> userQuery(UserQueryRequest request){
        String path = "api/v1/nft/user/query";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(false));

        HttpEntity<UserQueryRequest> httpEntity = new HttpEntity<>(request, httpHeaders);

        ParameterizedTypeReference<SdkResponseBase<PersonRegResponse>> typeRef = new ParameterizedTypeReference<SdkResponseBase<PersonRegResponse>>() {};
        ResponseEntity<SdkResponseBase<PersonRegResponse>> responseEntity = restTemplate.exchange(properties.getReqUrl()+path, HttpMethod.POST,httpEntity,typeRef);

        SdkResponseBase<PersonRegResponse> respBody = responseEntity.getBody();
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }

    /**
     * nft用户地址绑定接口
     * @param request
     * @return
     */
    public SdkResponseBase<String> identityBindSubmit(IdentityBindSubmitRequest request){
        String path = "api/v1/nft/identity/bind/submit";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(false));

        HttpEntity<IdentityBindSubmitRequest> httpEntity = new HttpEntity<>(request, httpHeaders);

        ParameterizedTypeReference<SdkResponseBase<String>> typeRef = new ParameterizedTypeReference<SdkResponseBase<String>>() {};
        ResponseEntity<SdkResponseBase<String>> responseEntity = restTemplate.exchange(properties.getReqUrl()+path, HttpMethod.POST,httpEntity,typeRef);

        SdkResponseBase<String> respBody = responseEntity.getBody();
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }


    /**
     * 受信平台nft地址绑定
     * @param request
     * @return
     */
    public SdkResponseBase<String> identityBindSubmitPlatform(IdentityBindSubmitPlatformRequest request){
        String path = "api/v1/nft/identity/bind/submit_by_trusted_platform";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(true));
        httpHeaders.add("App_Id", properties.getAppId());

        HttpEntity<IdentityBindSubmitPlatformRequest> httpEntity = new HttpEntity<>(request, httpHeaders);

        ParameterizedTypeReference<SdkResponseBase<String>> typeRef = new ParameterizedTypeReference<SdkResponseBase<String>>() {};
        ResponseEntity<SdkResponseBase<String>> responseEntity = restTemplate.exchange(properties.getReqUrl()+path, HttpMethod.POST,httpEntity,typeRef);

        SdkResponseBase<String> respBody = responseEntity.getBody();
        log.info("受信平台nft地址绑定:请求:{},返回:{}",JSON.toJSONString(request),JSON.toJSONString(respBody));
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }

    /**
     * 绑定状态批量查询
     * @param addressList 地址列表
     * @return
     */
    public SdkResponseBase<List<AddressStatusResponse>> identityBindQuery(List<String> addressList){
        String path = "api/v1/nft/identity/bind/query";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(false));
        httpHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(properties.getReqUrl()+path)
                .queryParam("addressList",addressList);

        ParameterizedTypeReference<SdkResponseBase<List<AddressStatusResponse>>> typeRef = new ParameterizedTypeReference<SdkResponseBase<List<AddressStatusResponse>>>() {};
        ResponseEntity<SdkResponseBase<List<AddressStatusResponse>>> responseEntity = restTemplate.exchange(builder.toUriString(),HttpMethod.GET,null, typeRef);

        SdkResponseBase<List<AddressStatusResponse>> respBody = responseEntity.getBody();
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }

    /**
     * 地址与身份对应关系检验
     * @param request 地址列表
     * @return
     */
    public SdkResponseBase<PersonRegResponse> addressIdentity(AddressIdentityRequest request){
        String path = "api/v1/nft/identity/verify/address_identity";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(false));

        HttpEntity<AddressIdentityRequest> httpEntity = new HttpEntity<>(request, httpHeaders);

        ParameterizedTypeReference<SdkResponseBase<PersonRegResponse>> typeRef = new ParameterizedTypeReference<SdkResponseBase<PersonRegResponse>>() {};
        ResponseEntity<SdkResponseBase<PersonRegResponse>> responseEntity = restTemplate.exchange(properties.getReqUrl()+path, HttpMethod.POST,httpEntity,typeRef);

        SdkResponseBase<PersonRegResponse> respBody = responseEntity.getBody();
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }

    /**
     * 请求人脸核身h5 url
     * @param request 请求对象
     * @return
     */
    public SdkResponseBase<FaceUrlResponse> faceUrl(FaceUrlRequest request){
        String path = "api/v1/nft/face/url";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(false));

        HttpEntity<FaceUrlRequest> httpEntity = new HttpEntity<>(request, httpHeaders);

        ParameterizedTypeReference<SdkResponseBase<FaceUrlResponse>> typeRef = new ParameterizedTypeReference<SdkResponseBase<FaceUrlResponse>>() {};
        ResponseEntity<SdkResponseBase<FaceUrlResponse>> responseEntity = restTemplate.exchange(properties.getReqUrl()+path, HttpMethod.POST,httpEntity,typeRef);

        SdkResponseBase<FaceUrlResponse> respBody = responseEntity.getBody();
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }


    /**
     * 通过用户地址请求人脸核身h5 url
     * @param request 地址列表
     * @return
     */
    public SdkResponseBase<FaceUrlResponse> faceUrlByAddr(FaceUrlByAddrRequest request){
        String path = "api/v1/nft/face/url_by_address";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(false));

        HttpEntity<FaceUrlByAddrRequest> httpEntity = new HttpEntity<>(request, httpHeaders);

        ParameterizedTypeReference<SdkResponseBase<FaceUrlResponse>> typeRef = new ParameterizedTypeReference<SdkResponseBase<FaceUrlResponse>>() {};
        ResponseEntity<SdkResponseBase<FaceUrlResponse>> responseEntity = restTemplate.exchange(properties.getReqUrl()+path, HttpMethod.POST,httpEntity,typeRef);

        SdkResponseBase<FaceUrlResponse> respBody = responseEntity.getBody();
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }

    /**
     * 通过用户地址请求人脸核身h5 url
     * @param request 地址列表
     * @return
     */
    public SdkResponseBase<FaceQueryResponse> faceQuery(FaceQueryRequest request){
        String path = "api/v1/nft/face/query";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(false));

        HttpEntity<FaceQueryRequest> httpEntity = new HttpEntity<>(request, httpHeaders);

        ParameterizedTypeReference<SdkResponseBase<FaceQueryResponse>> typeRef = new ParameterizedTypeReference<SdkResponseBase<FaceQueryResponse>>() {};
        ResponseEntity<SdkResponseBase<FaceQueryResponse>> responseEntity = restTemplate.exchange(properties.getReqUrl()+path, HttpMethod.POST,httpEntity,typeRef);

        SdkResponseBase<FaceQueryResponse> respBody = responseEntity.getBody();
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }

    /**
     * 查询素材地址 GET
     * @param request 请求对象
     * @return
     */
    public SdkResponseBase<UploadUrlGetResponse> uploadUrlGet(UploadUrlGetRequest request){
        String path = "api/v1/nft/upload/url";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(true));
        httpHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(properties.getReqUrl()+path)
                .queryParam("platformIdentification",request.getPlatformIdentification())
                .queryParam("seriesName",request.getSeriesName())
                .queryParam("userIdentification",request.getUserIdentification());

        ParameterizedTypeReference<SdkResponseBase<UploadUrlGetResponse>> typeRef = new ParameterizedTypeReference<SdkResponseBase<UploadUrlGetResponse>>() {};
        ResponseEntity<SdkResponseBase<UploadUrlGetResponse>> responseEntity = restTemplate.exchange(builder.toUriString(),HttpMethod.GET,null, typeRef);

        SdkResponseBase<UploadUrlGetResponse> respBody = responseEntity.getBody();
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }


    /**
     * 申请积分 POST
     * @param request 请求对象
     * @return
     */
    public SdkResponseBase<TaskResponse> pointApply(PointApplyRequest request){
        String path = "api/v1/nft/point/apply";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(true));

        HttpEntity<PointApplyRequest> httpEntity = new HttpEntity<>(request, httpHeaders);

        ParameterizedTypeReference<SdkResponseBase<TaskResponse>> typeRef = new ParameterizedTypeReference<SdkResponseBase<TaskResponse>>() {};
        ResponseEntity<SdkResponseBase<TaskResponse>> responseEntity = restTemplate.exchange(properties.getReqUrl()+path, HttpMethod.POST,httpEntity,typeRef);

        SdkResponseBase<TaskResponse> respBody = responseEntity.getBody();
        log.info("申请积分，请求:{},返回:{}",JSON.toJSONString(request),JSON.toJSONString(respBody));

        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }


    /**
     * 积分销毁 POST
     * @param request 请求对象
     * @return
     */
    public SdkResponseBase<TaskResponse> pointDestroy(PointDestroyRequest request){
        String path = "api/v1/nft/point/destroy";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(true));

        HttpEntity<PointDestroyRequest> httpEntity = new HttpEntity<>(request, httpHeaders);

        ParameterizedTypeReference<SdkResponseBase<TaskResponse>> typeRef = new ParameterizedTypeReference<SdkResponseBase<TaskResponse>>() {};
        ResponseEntity<SdkResponseBase<TaskResponse>> responseEntity = restTemplate.exchange(properties.getReqUrl()+path, HttpMethod.POST,httpEntity,typeRef);

        SdkResponseBase<TaskResponse> respBody = responseEntity.getBody();
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }

    /**
     * 查询积分申请结果 GET
     * @param platformPubKey 平台公钥
     * @param taskId 任务id
     * @return
     */
    public SdkResponseBase<PointTaskResultResponse> pointApplyTaskResult(String platformPubKey,String taskId){
        return pointTaskResult("apply",platformPubKey,taskId);
    }

    /**
     * 查询积分申请结果 GET
     * @param platformPubKey 平台公钥
     * @param taskId 任务id
     * @return
     */
    public SdkResponseBase<PointTaskResultResponse> pointDestroyTaskResult(String platformPubKey,String taskId){
        return pointTaskResult("destroy",platformPubKey,taskId);
    }


    /**
     * 查询积分申请/销毁结果 GET
     * @param operation 操作类型 不传为申请积分，destroy为销毁
     * @param platformPubKey 平台公钥
     * @param taskId 任务id
     * @return
     */
    private SdkResponseBase<PointTaskResultResponse> pointTaskResult(String operation,String platformPubKey,String taskId){
        String path = "";
        if ("destroy".equals(operation)) {
            path = "api/v1/nft/point/destroy/result";
        } else if ("apply".equals(operation)) {
            path = "api/v1/nft/point/apply/result";
        }

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(true));
        httpHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(properties.getReqUrl()+path)
                .queryParam("platformPubKey",platformPubKey)
                .queryParam("taskId",taskId);

        ParameterizedTypeReference<SdkResponseBase<PointTaskResultResponse>> typeRef = new ParameterizedTypeReference<SdkResponseBase<PointTaskResultResponse>>() {};
        ResponseEntity<SdkResponseBase<PointTaskResultResponse>> responseEntity = restTemplate.exchange(builder.toUriString(),HttpMethod.GET,null, typeRef);

        SdkResponseBase<PointTaskResultResponse> respBody = responseEntity.getBody();
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }

    /**
     * 积分查询 GET
     * @param addr 查询人地址
     * @param platformAddr 平台公钥
     * @return
     */
    public SdkResponseBase<PointQueryResponse> pointQuery(String addr,String platformAddr){
        String path = "api/v1/nft/point/query";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(true));
        httpHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(properties.getReqUrl()+path)
                .queryParam("platformAddr",platformAddr)
                .queryParam("addr",addr);

        ParameterizedTypeReference<SdkResponseBase<PointQueryResponse>> typeRef = new ParameterizedTypeReference<SdkResponseBase<PointQueryResponse>>() {};
        ResponseEntity<SdkResponseBase<PointQueryResponse>> responseEntity = restTemplate.exchange(builder.toUriString(),HttpMethod.GET,null, typeRef);

        SdkResponseBase<PointQueryResponse> respBody = responseEntity.getBody();
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }


    /**
     * 查询系列信息 GET
     * @param seriesId 系列id
     * @return
     */
    public SdkResponseBase<SeriesInfoResponse> seriesInfo(String seriesId){
        String path = "api/v1/nft/series";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(true));
        httpHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(properties.getReqUrl()+path)
                .queryParam("seriesId",seriesId);

        ParameterizedTypeReference<SdkResponseBase<SeriesInfoResponse>> typeRef = new ParameterizedTypeReference<SdkResponseBase<SeriesInfoResponse>>() {};
        ResponseEntity<SdkResponseBase<SeriesInfoResponse>> responseEntity = restTemplate.exchange(builder.toUriString(),HttpMethod.GET,null, typeRef);

        SdkResponseBase<SeriesInfoResponse> respBody = responseEntity.getBody();
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }

    /**
     * 查询NFT原信息 GET
     * @param nftId
     * @return
     */
    public SdkResponseBase<NftInfoResultResponse> nftInfo(String nftId){
        String path = "api/v1/nft/info";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(false));
        httpHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(properties.getReqUrl()+path)
                .queryParam("nftId",nftId);
        HttpEntity<?> httpEntity = new HttpEntity<>(httpHeaders);
        ParameterizedTypeReference<SdkResponseBase<NftInfoResultResponse>> typeRef = new ParameterizedTypeReference<SdkResponseBase<NftInfoResultResponse>>() {};
        ResponseEntity<SdkResponseBase<NftInfoResultResponse>> responseEntity = restTemplate.exchange(builder.toUriString(),HttpMethod.GET,httpEntity, typeRef);

        SdkResponseBase<NftInfoResultResponse> respBody = responseEntity.getBody();
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }

    /**
     * 查询账户NFT列表 GET
     * @param request 请求对象
     * @return
     */
    public SdkResponseBase<NftInfoListResponse> nftAddressList(NftAddressListRequest request){
        String path = "api/v1/nft/address/list";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(false));
        httpHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(properties.getReqUrl()+path)
                .queryParam("addr",request.getAddr())
                .queryParam("seriesId",request.getSeriesId())
                .queryParam("offset",request.getOffset())
                .queryParam("limit",request.getLimit());
        HttpEntity<?> httpEntity = new HttpEntity<>(httpHeaders);
        ParameterizedTypeReference<SdkResponseBase<NftInfoListResponse>> typeRef = new ParameterizedTypeReference<SdkResponseBase<NftInfoListResponse>>() {};
        ResponseEntity<SdkResponseBase<NftInfoListResponse>> responseEntity = restTemplate.exchange(builder.build(true).toUri(),HttpMethod.GET,httpEntity, typeRef);

        SdkResponseBase<NftInfoListResponse> respBody = responseEntity.getBody();
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }

    /**
     * 查询无系列NFT列表 GET
     * @param request 请求对象
     * @return
     */
    public SdkResponseBase<NftInfoListResponse> nftAddressWithoutSeriesList(NftAddressListRequest request){
        String path = "api/v1/nft/address/without/series/list";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(true));
        httpHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(properties.getReqUrl()+path)
                .queryParam("addr",request.getAddr())
                .queryParam("offset",request.getOffset())
                .queryParam("limit",request.getLimit());

        ParameterizedTypeReference<SdkResponseBase<NftInfoListResponse>> typeRef = new ParameterizedTypeReference<SdkResponseBase<NftInfoListResponse>>() {};
        ResponseEntity<SdkResponseBase<NftInfoListResponse>> responseEntity = restTemplate.exchange(builder.toUriString(),HttpMethod.GET,null, typeRef);

        SdkResponseBase<NftInfoListResponse> respBody = responseEntity.getBody();
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }

    /**
     * 查询NFT交易信息列表 GET
     * @param request 请求对象
     * @return
     */
    public SdkResponseBase<NftTradeListResponse> nftTradeList(NftTradeListRequest request){
        String path = "api/v1/nft/trade/list";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(true));
        httpHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(properties.getReqUrl()+path)
                .queryParam("nftId",request.getNftId())
                .queryParam("offset",request.getOffset())
                .queryParam("limit",request.getLimit());

        ParameterizedTypeReference<SdkResponseBase<NftTradeListResponse>> typeRef = new ParameterizedTypeReference<SdkResponseBase<NftTradeListResponse>>() {};
        ResponseEntity<SdkResponseBase<NftTradeListResponse>> responseEntity = restTemplate.exchange(builder.toUriString(),HttpMethod.GET,null, typeRef);

        SdkResponseBase<NftTradeListResponse> respBody = responseEntity.getBody();
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }

    /**
     * 查询转入NFT交易信息列表 GET
     * @param request 请求对象
     * @return
     */
    public SdkResponseBase<NftTradeInOutListResponse> nftTradeInList(NftTradeInListRequest request){
        return nftTradeInOutList(request,"in");
    }

    /**
     * 查询转出NFT交易信息列表 GET
     * @param request 请求对象
     * @return
     */
    public SdkResponseBase<NftTradeInOutListResponse> nftTradeOutList(NftTradeInListRequest request){
        return nftTradeInOutList(request,"out");
    }

    /**
     * 查询地址下NFT交易列表 GET
     * @param request 请求对象
     * @return
     */
    public SdkResponseBase<NftTradeInOutListResponse> nftTradeAllList(NftTradeInListRequest request){
        return nftTradeInOutList(request,null);
    }

    /**
     * 查询转入转出NFT交易信息列表 GET
     * @param request 请求对象
     * @return
     */
    private SdkResponseBase<NftTradeInOutListResponse> nftTradeInOutList(NftTradeInListRequest request,String tradeType){
        String path = "api/v1/nft/trade/all/list";

        if ("in".equals(tradeType)) {
            path = "api/v1/nft/trade/in/list";
        } else if ("out".equals(tradeType)){
            path = "api/v1/nft/trade/out/list";
        }

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(true));
        httpHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(properties.getReqUrl()+path)
                .queryParam("addr",request.getAddr())
                .queryParam("offset",request.getOffset())
                .queryParam("limit",request.getLimit());

        ParameterizedTypeReference<SdkResponseBase<NftTradeInOutListResponse>> typeRef = new ParameterizedTypeReference<SdkResponseBase<NftTradeInOutListResponse>>() {};
        ResponseEntity<SdkResponseBase<NftTradeInOutListResponse>> responseEntity = restTemplate.exchange(builder.toUriString(),HttpMethod.GET,null, typeRef);

        SdkResponseBase<NftTradeInOutListResponse> respBody = responseEntity.getBody();
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }

    /**
     * 购买nft（可以申请积分，此接口只购买，不到账，到账由taskman内部发起任务） POST
     * @param request 请求对象
     * @param receiverPriKey 接收人私钥
     * @return
     */
    public SdkResponseBase<TaskResponse> nftBuy(NftBuyRequest request,String receiverPriKey){

        String str = "{}_{}_{}_{}_{}_{}_{}_{}";
        String signData = StrUtil.format(str, properties.getPubKey(), request.getReceiverPubKey(), request.getPointReceiverAddr()
                , request.getApplyScore(), "buy_nft", request.getNftId(), request.getOfferCount(), request.getOperateId());
        SignByPriKeyResponse platformSignResponse = nftCommonUtil.signByPriKey(properties.getPriKey(), signData);
        SignByPriKeyResponse userSignResponse = nftCommonUtil.signByPriKey(receiverPriKey, signData);

        request.setSignature(userSignResponse.getSignedData());
        request.setPlatformSignature(platformSignResponse.getSignedData());

        String path = "api/v1/nft/buy";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(true));

        HttpEntity<NftBuyRequest> httpEntity = new HttpEntity<>(request, httpHeaders);

        ParameterizedTypeReference<SdkResponseBase<TaskResponse>> typeRef = new ParameterizedTypeReference<SdkResponseBase<TaskResponse>>() {};
        ResponseEntity<SdkResponseBase<TaskResponse>> responseEntity = restTemplate.exchange(properties.getReqUrl()+path, HttpMethod.POST,httpEntity,typeRef);

        SdkResponseBase<TaskResponse> respBody = responseEntity.getBody();
        log.info("购买nft,请求:{},返回:{}",JSON.toJSONString(request),JSON.toJSONString(respBody));
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }

    /**
     * 查询nft购买结果 GET
     * @param taskId 任务id
     * @return
     */
    public SdkResponseBase<NftTaskResultResponse> nftBuyResult(String taskId){
        String path = "api/v1/nft/buy/result";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(true));
        httpHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        String url = properties.getReqUrl()+path;

        Map<String,String> params = new HashMap<>(3);
        params.put("platformPubKey",properties.getPubKey());
        params.put("taskId",taskId);
        HttpEntity<?> httpEntity = new HttpEntity<>(httpHeaders);
        URI uri = UriComponentsBuilder.fromHttpUrl(getEncodeQueryParamUrl(url, params)).build(true).toUri();

        ParameterizedTypeReference<SdkResponseBase<NftTaskResultResponse>> typeRef = new ParameterizedTypeReference<SdkResponseBase<NftTaskResultResponse>>() {};
        ResponseEntity<SdkResponseBase<NftTaskResultResponse>> responseEntity = restTemplate.exchange(uri,HttpMethod.GET,httpEntity, typeRef);
        SdkResponseBase<NftTaskResultResponse> respBody = responseEntity.getBody();
        log.info("查询nft购买结果,响应：taskId:{}  {}",taskId, JSON.toJSONString(respBody));
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }

    /**
     * 查询nft购买支付结果 GET
     * @param platformPubKey 平台公钥
     * @param taskId 任务id
     * @return
     */
    private SdkResponseBase<NftTaskResultResponse> nftBuyPayResult(String platformPubKey,String taskId){
        String path = "api/v1/nft/buy/pay/result";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(true));
        httpHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(properties.getReqUrl()+path)
                .queryParam("platformPubKey",platformPubKey)
                .queryParam("taskId",taskId);

        ParameterizedTypeReference<SdkResponseBase<NftTaskResultResponse>> typeRef = new ParameterizedTypeReference<SdkResponseBase<NftTaskResultResponse>>() {};
        ResponseEntity<SdkResponseBase<NftTaskResultResponse>> responseEntity = restTemplate.exchange(builder.toUriString(),HttpMethod.GET,null, typeRef);

        SdkResponseBase<NftTaskResultResponse> respBody = responseEntity.getBody();
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }

    /**
     * nft转移 POST
     * @param request 请求对象
     * @return
     */
    public SdkResponseBase<TaskResponse> nftTransfer(NftTransferRequest request){
        String path = "api/v1/nft/transfer";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(false));

        HttpEntity<NftTransferRequest> httpEntity = new HttpEntity<>(request, httpHeaders);

        ParameterizedTypeReference<SdkResponseBase<TaskResponse>> typeRef = new ParameterizedTypeReference<SdkResponseBase<TaskResponse>>() {};
        ResponseEntity<SdkResponseBase<TaskResponse>> responseEntity = restTemplate.exchange(properties.getReqUrl()+path, HttpMethod.POST,httpEntity,typeRef);
        SdkResponseBase<TaskResponse> respBody = responseEntity.getBody();
        log.info("nft转移,请求：{}  响应{}",JSON.toJSONString(request), JSON.toJSONString(respBody));
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }

    /**
     * nft转移 POST
     * @param request 请求对象
     * @return
     */
    public SdkResponseBase<TaskResponse> nftTransferV2(NftTransferRequest request){
        String path = "api/v2/nft/transfer";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(false));

        HttpEntity<NftTransferRequest> httpEntity = new HttpEntity<>(request, httpHeaders);

        ParameterizedTypeReference<SdkResponseBase<TaskResponse>> typeRef = new ParameterizedTypeReference<SdkResponseBase<TaskResponse>>() {};
        ResponseEntity<SdkResponseBase<TaskResponse>> responseEntity = restTemplate.exchange(properties.getReqUrl()+path, HttpMethod.POST,httpEntity,typeRef);
        SdkResponseBase<TaskResponse> respBody = responseEntity.getBody();
        log.info("nft转移,请求：{}  响应{}",JSON.toJSONString(request), JSON.toJSONString(respBody));
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }

    /**
     * nft转移 POST
     * @param request 请求对象
     * @return
     */
    public SdkResponseBase<TaskResponse> nftSelfTransfer(NftTransferRequest request){
        String path = "api/v1/nft/self_transfer";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(true));

        HttpEntity<NftTransferRequest> httpEntity = new HttpEntity<>(request, httpHeaders);

        ParameterizedTypeReference<SdkResponseBase<TaskResponse>> typeRef = new ParameterizedTypeReference<SdkResponseBase<TaskResponse>>() {};
        ResponseEntity<SdkResponseBase<TaskResponse>> responseEntity = restTemplate.exchange(properties.getReqUrl()+path, HttpMethod.POST,httpEntity,typeRef);

        SdkResponseBase<TaskResponse> respBody = responseEntity.getBody();
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }

    /**
     * nft转移状态查询 GET
     * @param operatorPubKey 原始nft人的公钥
     * @param taskId 任务id
     * @return
     */
    public SdkResponseBase<NftTaskResultResponse> nftTransferResult(String operatorPubKey,String taskId){
        String path = "api/v1/nft/transfer/result";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(false));
        httpHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        String url = properties.getReqUrl()+path;

        Map<String,String> params = new HashMap<>(3);
        params.put("operatorPubKey",operatorPubKey);
        params.put("taskId",taskId);
        HttpEntity<?> httpEntity = new HttpEntity<>(httpHeaders);
        URI uri = UriComponentsBuilder.fromHttpUrl(getEncodeQueryParamUrl(url, params)).build(true).toUri();

        ParameterizedTypeReference<SdkResponseBase<NftTaskResultResponse>> typeRef = new ParameterizedTypeReference<SdkResponseBase<NftTaskResultResponse>>() {};
        ResponseEntity<SdkResponseBase<NftTaskResultResponse>> responseEntity = restTemplate.exchange(uri,HttpMethod.GET,httpEntity, typeRef);
        SdkResponseBase<NftTaskResultResponse> respBody = responseEntity.getBody();
        log.info("nft转移状态查询,响应：taskId:{}  {}",taskId, JSON.toJSONString(respBody));
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }

    /**
     * nft销售状态变更 POST
     * @param request 请求对象
     * @return
     */
    public SdkResponseBase<TaskResponse> nftStatusUpdate(NftStatusUpdateRequest request){
        String path = "api/v1/nft/status/update";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(true));

        HttpEntity<NftStatusUpdateRequest> httpEntity = new HttpEntity<>(request, httpHeaders);

        ParameterizedTypeReference<SdkResponseBase<TaskResponse>> typeRef = new ParameterizedTypeReference<SdkResponseBase<TaskResponse>>() {};
        ResponseEntity<SdkResponseBase<TaskResponse>> responseEntity = restTemplate.exchange(properties.getReqUrl()+path, HttpMethod.POST,httpEntity,typeRef);

        SdkResponseBase<TaskResponse> respBody = responseEntity.getBody();
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }

    /**
     * nft销售状态变更查询 GET
     * @param platformPubKey 平台公钥
     * @param taskId 任务id
     * @return
     */
    private SdkResponseBase<NftTaskResultResponse> nftStatusUpdateResult(String platformPubKey,String taskId){
        String path = "api/v1/nft/status/update/result";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(true));
        httpHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(properties.getReqUrl()+path)
                .queryParam("platformPubKey",platformPubKey)
                .queryParam("taskId",taskId);

        ParameterizedTypeReference<SdkResponseBase<NftTaskResultResponse>> typeRef = new ParameterizedTypeReference<SdkResponseBase<NftTaskResultResponse>>() {};
        ResponseEntity<SdkResponseBase<NftTaskResultResponse>> responseEntity = restTemplate.exchange(builder.toUriString(),HttpMethod.GET,null, typeRef);

        SdkResponseBase<NftTaskResultResponse> respBody = responseEntity.getBody();
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }

    /**
     * nft售价变更 POST
     * @param request 请求对象
     * @return
     */
    public SdkResponseBase<TaskResponse> nftPriceUpdate(NftPriceUpdateRequest request){
        String path = "api/v1/nft/price/update";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(true));

        HttpEntity<NftPriceUpdateRequest> httpEntity = new HttpEntity<>(request, httpHeaders);

        ParameterizedTypeReference<SdkResponseBase<TaskResponse>> typeRef = new ParameterizedTypeReference<SdkResponseBase<TaskResponse>>() {};
        ResponseEntity<SdkResponseBase<TaskResponse>> responseEntity = restTemplate.exchange(properties.getReqUrl()+path, HttpMethod.POST,httpEntity,typeRef);

        SdkResponseBase<TaskResponse> respBody = responseEntity.getBody();
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }

    /**
     * nft销售价格变更查询 GET
     * @param platformPubKey 平台公钥
     * @param taskId 任务id
     * @return
     */
    private SdkResponseBase<NftTaskResultResponse> nftPriceUpdateResult(String platformPubKey,String taskId){
        String path = "api/v1/nft/price/update/result";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(true));
        httpHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(properties.getReqUrl()+path)
                .queryParam("platformPubKey",platformPubKey)
                .queryParam("taskId",taskId);

        ParameterizedTypeReference<SdkResponseBase<NftTaskResultResponse>> typeRef = new ParameterizedTypeReference<SdkResponseBase<NftTaskResultResponse>>() {};
        ResponseEntity<SdkResponseBase<NftTaskResultResponse>> responseEntity = restTemplate.exchange(builder.toUriString(),HttpMethod.GET,null, typeRef);

        SdkResponseBase<NftTaskResultResponse> respBody = responseEntity.getBody();
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }

    /**
     * 平台积分转移 POST
     * @param request 请求对象
     * @return
     */
    public SdkResponseBase<TaskResponse> nftPointTransfer(PointTransferRequest request){
        String path = "api/v1/nft/point/transfer";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(true));

        HttpEntity<PointTransferRequest> httpEntity = new HttpEntity<>(request, httpHeaders);

        ParameterizedTypeReference<SdkResponseBase<TaskResponse>> typeRef = new ParameterizedTypeReference<SdkResponseBase<TaskResponse>>() {};
        ResponseEntity<SdkResponseBase<TaskResponse>> responseEntity = restTemplate.exchange(properties.getReqUrl()+path, HttpMethod.POST,httpEntity,typeRef);

        SdkResponseBase<TaskResponse> respBody = responseEntity.getBody();
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }

    /**
     * 平台积分转移状态查询 GET
     * @param taskId 任务id
     * @return
     */
    private SdkResponseBase<NftTaskResultResponse> nftPointTransferResult(String taskId){
        String path = "api/v1/nft/point/transfer/result";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(true));
        httpHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(properties.getReqUrl()+path)
                .queryParam("platformPubKey",properties.getPubKey())
                .queryParam("taskId",taskId);

        ParameterizedTypeReference<SdkResponseBase<NftTaskResultResponse>> typeRef = new ParameterizedTypeReference<SdkResponseBase<NftTaskResultResponse>>() {};
        ResponseEntity<SdkResponseBase<NftTaskResultResponse>> responseEntity = restTemplate.exchange(builder.toUriString(),HttpMethod.GET,null, typeRef);

        SdkResponseBase<NftTaskResultResponse> respBody = responseEntity.getBody();
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }

    /**
     * nft系列声明 POST
     * @param request 请求对象
     * @return
     */
    public SdkResponseBase<TaskResponse> seriesClaim(SeriesClaimRequest request){
        String str = "{}_{}_{}_{}_{}_{}_{}_{}_{}_{}";
        String signData = StrUtil.format(str, properties.getPubKey(), properties.getPubKey(), "series_claim", request.getSeriesName()
                , request.getTotalCount(), request.getCoverUrl(), request.getDesc(), request.getMaxPublishCount()
                , request.isSeriesBeginFromZero(), request.getOperateId());
        SignByPriKeyResponse userSignResponse = nftCommonUtil.signByPriKey(properties.getPriKey(), signData);
        SignByPriKeyResponse platformSignResponse = nftCommonUtil.signByPriKey(properties.getPriKey(), signData);

        request.setSignature(userSignResponse.getSignedData());
        request.setPlatformSignature(platformSignResponse.getSignedData());
        request.setPubKey(properties.getPubKey());
        request.setPlatformPubKey(properties.getPubKey());


        String path = "api/v1/nft/series/claim";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(true));

        HttpEntity<SeriesClaimRequest> httpEntity = new HttpEntity<>(request, httpHeaders);

        ParameterizedTypeReference<SdkResponseBase<TaskResponse>> typeRef = new ParameterizedTypeReference<SdkResponseBase<TaskResponse>>() {};
        ResponseEntity<SdkResponseBase<TaskResponse>> responseEntity = restTemplate.exchange(properties.getReqUrl()+path, HttpMethod.POST,httpEntity,typeRef);

        SdkResponseBase<TaskResponse> respBody = responseEntity.getBody();
        log.info("声明系列-请求:{},响应:{}",JSON.toJSONString(request),JSON.toJSONString(respBody));
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody != null ) {
            return respBody;
        }
        return null;
    }


    /**
     * 发行NFT POST
     * @param request 请求对象
     * @return
     */
    public SdkResponseBase<TaskResponse> nftPublish(NftPublishRequest request){
        //platformPubKey_ pubKey_ publish_nft_ author_ name _url _ displayUrl _hash _desc _flag _ publishCount _ seriesId _ seriesBeginIndex _ sellStatus _ sellCount _ metaData_ operateId
        String str = "{}_{}_{}_{}_{}_{}_{}_{}_{}_{}_{}_{}_{}_{}_{}_{}_{}";
        String signData = StrUtil.format(str, properties.getPubKey(), properties.getPubKey(), "publish_nft", request.getAuthor()
                , request.getName(), request.getUrl(), request.getDisplayUrl(), request.getHash(), request.getDesc()
                , request.getFlag(), request.getPublishCount(), request.getSeriesId(), request.getSeriesBeginIndex()
                , request.getSellStatus(), request.getSellCount(), request.getMetaData(), request.getOperateId());
        SignByPriKeyResponse userSignResponse = nftCommonUtil.signByPriKey(properties.getPriKey(), signData);
        SignByPriKeyResponse platformSignResponse = nftCommonUtil.signByPriKey(properties.getPriKey(), signData);

        request.setSignature(userSignResponse.getSignedData());
        request.setPlatformSignature(platformSignResponse.getSignedData());
        request.setPubKey(properties.getPubKey());
        request.setPlatformPubKey(properties.getPubKey());


        String path = "api/v1/nft/publish";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(true));

        HttpEntity<NftPublishRequest> httpEntity = new HttpEntity<>(request, httpHeaders);

        ParameterizedTypeReference<SdkResponseBase<TaskResponse>> typeRef = new ParameterizedTypeReference<SdkResponseBase<TaskResponse>>() {};
        ResponseEntity<SdkResponseBase<TaskResponse>> responseEntity = restTemplate.exchange(properties.getReqUrl()+path, HttpMethod.POST,httpEntity,typeRef);
        SdkResponseBase<TaskResponse> respBody = responseEntity.getBody();

        log.info("发行NFT-请求:{},响应:{}",JSON.toJSONString(request),JSON.toJSONString(respBody));
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }


    /**
     * 查询NFT系列声明结果 GET
     * @param taskId 任务id
     * @return
     */
    public SdkResponseBase<SeriesTaskResultResponse> seriesClaimResult(String taskId){
        String path = "api/v1/nft/series/claim/result";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(true));
        httpHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        String url = properties.getReqUrl()+path;

        Map<String,String> params = new HashMap<>(3);
        params.put("platformPubKey",properties.getPubKey());
        params.put("taskId",taskId);
        HttpEntity<?> httpEntity = new HttpEntity<>(httpHeaders);
        URI uri = UriComponentsBuilder.fromHttpUrl(getEncodeQueryParamUrl(url, params)).build(true).toUri();
        ParameterizedTypeReference<SdkResponseBase<SeriesTaskResultResponse>> typeRef = new ParameterizedTypeReference<SdkResponseBase<SeriesTaskResultResponse>>() {};
        ResponseEntity<SdkResponseBase<SeriesTaskResultResponse>> responseEntity = restTemplate.exchange(uri,HttpMethod.GET,httpEntity, typeRef);
        SdkResponseBase<SeriesTaskResultResponse> respBody = responseEntity.getBody();
        log.info("查询NFT系列声明结果,响应：{}", JSON.toJSONString(respBody));
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }

    /**
     * 查询NFT发行结果 GET
     * @param taskId 任务id
     * @return
     */
    public SdkResponseBase<NftPublishTaskResultResponse> nftPublishResult(String taskId){
        String path = "api/v1/nft/publish/result";


        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(true));
        httpHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        String url = properties.getReqUrl()+path;

        Map<String,String> params = new HashMap<>(3);
        params.put("platformPubKey",properties.getPubKey());
        params.put("taskId",taskId);
        HttpEntity<?> httpEntity = new HttpEntity<>(httpHeaders);
        URI uri = UriComponentsBuilder.fromHttpUrl(getEncodeQueryParamUrl(url, params)).build(true).toUri();
        ParameterizedTypeReference<SdkResponseBase<NftPublishTaskResultResponse>> typeRef = new ParameterizedTypeReference<SdkResponseBase<NftPublishTaskResultResponse>>() {};
        ResponseEntity<SdkResponseBase<NftPublishTaskResultResponse>> responseEntity = restTemplate.exchange(uri,HttpMethod.GET,httpEntity, typeRef);
        SdkResponseBase<NftPublishTaskResultResponse> respBody = responseEntity.getBody();
        log.info("查询NFT发行结果,响应：{}", JSON.toJSONString(respBody));
        if (HttpStatus.OK.equals(responseEntity.getStatusCode()) && respBody!=null) {
            return respBody;
        }
        return null;
    }


    /**
     * 查询NFT系列声明结果 GET
     * @param platformAddr 平台地址
     * @return
     */
    public void seriesList (String platformAddr){
        String path = "/api/v1/nft/series/list";

        HttpHeaders httpHeaders = nftCommonUtil.buildHeader(nftCommonUtil.generateApiSign(true));
        httpHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        String url = properties.getReqUrl()+path;

        Map<String,String> params = new HashMap<>(3);
        params.put("addr",platformAddr);
        HttpEntity<?> httpEntity = new HttpEntity<>(httpHeaders);
        URI uri = UriComponentsBuilder.fromHttpUrl(getEncodeQueryParamUrl(url, params)).build(true).toUri();
        ResponseEntity<String> responseEntity = restTemplate.exchange(uri,HttpMethod.GET,httpEntity, String.class);
        String respBody = responseEntity.getBody();
        log.info("查询NFT系列声明结果,响应：{}", JSON.toJSONString(respBody));
    }



}
