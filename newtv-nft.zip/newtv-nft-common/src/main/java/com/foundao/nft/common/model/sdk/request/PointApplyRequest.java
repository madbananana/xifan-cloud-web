package com.foundao.nft.common.model.sdk.request;

import lombok.Data;

/**
 * @ClassName PointApplyRequest
 * @Description TODO
 * @Author xifan
 * @Date 2021/12/16 21:25
 * @Version 1.0
 */
@Data
public class PointApplyRequest {

    /**
     * 申请对象地址
     */
    private String applyerAddr;

    /**
     * 平台公钥
     */
    private String platformPubKey;

    /**
     * 积分数量
     */
    private int count;

    /**
     * 请求id 每个请求需要唯一的id 重复请求用相同的id
     */
    private String operateId;

    /**
     * 平台方的私钥签名，签名对象和signature对象一致。签名对象是（platformPubKey_applyerAddr_接口名_count_operateId）
     * 接口名=apply_point
     */
    private String platformSignature;

}
