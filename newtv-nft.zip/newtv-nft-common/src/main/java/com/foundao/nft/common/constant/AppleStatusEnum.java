package com.foundao.nft.common.constant;

/**
 * 21000 App Store不能读取你提供的JSON对象
 * * 21002 receipt-data域的数据有问题
 * * 21003 receipt无法通过验证
 * * 21004 提供的shared secret不匹配你账号中的shared secret
 * * 21005 receipt服务器当前不可用
 * * 21006 receipt合法，但是订阅已过期。服务器接收到这个状态码时，receipt数据仍然会解码并一起发送
 * * 21007 receipt是Sandbox receipt，但却发送至生产系统的验证服务
 * * 21008 receipt是生产receipt，但却发送至Sandbox环境的验证服务
 * ————————————————
 * 版权声明：本文为CSDN博主「清水贤人」的原创文章，遵循 CC 4.0 BY-SA 版权协议，转载请附上原文出处链接及本声明。
 * 原文链接：https://blog.csdn.net/wjsshhx/article/details/73088094
 */
public enum AppleStatusEnum {
    RECEIPT_FORMAT_ERROR(21002, "receipt-data域的数据有问题"),
    RECEIPT_ERROR(21003, "receipt无法通过验证"),
    SECRECT_ERROR(21004, "提供的shared secret不匹配你账号中的shared secret"),
    RECEIPT_SERVER_ERROR(21005, "receipt服务器当前不可用"),
    RECEIPT_EXPIRE(21006, "receipt合法，但是订阅已过期。服务器接收到这个状态码时，receipt数据仍然会解码并一起发送"),
    RECEIPT_SANDBOX(21007, "receipt是Sandbox receipt，但却发送至生产系统的验证服务"),
    RECEIPT_PRODUCT(21008, "receipt是生产receipt，但却发送至Sandbox环境的验证服务"),
    SUCCESS(0, "OK"),
    DEFAULT(-1, "未知错误");

    private int status;
    private String errorMsg;

    AppleStatusEnum(int status, String errorMsg) {
        this.status = status;
        this.errorMsg = errorMsg;
    }

    public int getStatus() {
        return status;
    }

    public String getErrorMsg() {
        return errorMsg;
    }
}
