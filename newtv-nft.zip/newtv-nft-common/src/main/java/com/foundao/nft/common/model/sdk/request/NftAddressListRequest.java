package com.foundao.nft.common.model.sdk.request;

import lombok.Data;

/**
 * @ClassName NftAddressListRequest
 * @Description TODO
 * @Author xifan
 * @Date 2021/12/17 23:25
 * @Version 1.0
 */
@Data
public class NftAddressListRequest {

    /**
     * 账户地址
     */
    private String addr;

    /**
     * 通过系列id过滤 可选
     */
    private String seriesId;

    /**
     * 查询偏移量
     */
    private int offset;

    /**
     * 最大1000
     */
    private int limit;
}
