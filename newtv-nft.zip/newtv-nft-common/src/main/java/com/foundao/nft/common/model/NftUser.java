package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.io.Serializable;
import java.util.Date;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
    @Package: com.foundao.nft.common.model
    @ClassName: NftUser
    @Author: chenli
    @CreateTime: 2021/12/20 11:41 上午
    @Description:
*/
@ApiModel(value="用户")
@Data
@TableName(value = "nft_user")
public class NftUser implements Serializable {

    @TableId(value = "user_id", type = IdType.AUTO)
    @ApiModelProperty(value="用户id")
    private Integer userId;

    @TableField(value = "user_name")
    @ApiModelProperty(value="用户名")
    private String userName;

    @TableField(value = "nick_name")
    @ApiModelProperty(value="昵称")
    private String nickName;

    @TableField(value = "`password`")
    @ApiModelProperty(value="")
    private String password;

    @TableField(value = "avatar")
    @ApiModelProperty(value="头像")
    private String avatar;

    @TableField(value = "mobile")
    @ApiModelProperty(value="电话")
    private String mobile;

    /**
     * 状态 0锁定 1有效
     */
    @TableField(value = "`status`")
    @ApiModelProperty(value="状态 0有效 1锁定 ")
    private Integer status;

    @TableField(value = "create_time")
    @ApiModelProperty(value="创建时间")
    private Date createTime;

    @TableField(value = "update_time")
    @ApiModelProperty(value="修改时间")
    private Date updateTime;

    /**
     * 是否内部员工 0：不是 1：是
     */
    @TableField(value = "internal_emp")
    @ApiModelProperty(value="是否内部员工 0：不是 1：是")
    private Integer internalEmp;

    /**
     * 是否禁止用户修改信息 0：不禁止 1：禁止
     */
    @TableField(value = "modify_inhibit")
    @ApiModelProperty(value="是否禁止用户修改信息 0：不禁止 1：禁止")
    private Integer modifyInhibit;

    @ApiModelProperty(value="邀请码")
    private Integer inviteCode;

    @ApiModelProperty(value="邀请用户id")
    private Integer inviteUserId;

    @ApiModelProperty(value="最后登录ip")
    private String lastLoginIp;

    @ApiModelProperty(value="权益等级")
    private Integer rightLevel;
}
