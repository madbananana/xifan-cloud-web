package com.foundao.nft.common.model.sdk.response;

import lombok.Data;

/**
 * @Package: com.foundao.nft.common.model.sdk.response
 * @ClassName: NftInfoResultResponse
 * @Author: chenli
 * @CreateTime: 2022/2/16 10:16 上午
 * @Description:
 */
@Data
public class NftInfoResultResponse {

    private NftInfoResponse nftInfo;
}
