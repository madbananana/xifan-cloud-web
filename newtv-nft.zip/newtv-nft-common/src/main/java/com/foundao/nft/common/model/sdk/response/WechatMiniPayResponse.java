package com.foundao.nft.common.model.sdk.response;

import lombok.Data;

/**
 * @Package: com.foundao.nft.common.model.sdk.response
 * @ClassName: WechatMiniPayResponse
 * @Author: chenli
 * @CreateTime: 2021/12/22 4:42 下午
 * @Description:
 */
@Data
public class WechatMiniPayResponse<T> {

    private String errorCode;

    private String errorMessage;

    private T data;
}
