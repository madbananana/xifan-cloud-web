package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.*;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
    @Package: com.foundao.nft.common.model
    @ClassName: NftOrder
    @Author: chenli
    @CreateTime: 2021/12/22 6:16 下午
    @Description:
*/
@ApiModel(value="com-foundao-nft-common-model-NftOrder")
@Data
@TableName(value = "nft_order")
public class NftOrder implements Serializable {
    @TableId(value = "order_id", type = IdType.AUTO)
    @ApiModelProperty(value="")
    private Integer orderId;

    @TableField(value = "user_id")
    @ApiModelProperty(value="用户id")
    private Integer userId;

    @TableField(value = "order_type")
    @ApiModelProperty(value="订单类型 1普通订单 10 头像订单 11盲盒订单")
    private Integer orderType;

    /**
     * 金额 分
     */
    @TableField(value = "fee")
    @ApiModelProperty(value="金额 分")
    private Integer fee;

    @TableField(value = "create_time",fill = FieldFill.INSERT)
    @ApiModelProperty(value="")
    private Date createTime;

    @TableField(value = "update_time",fill = FieldFill.INSERT_UPDATE)
    @ApiModelProperty(value="")
    private Date updateTime;

    @ApiModelProperty(value="支付时间")
    private Date payTime;

    /**
     * 支付状态 1：初始状态 2：成功 3失败
     */
    @TableField(value = "`status`")
    @ApiModelProperty(value="支付状态 1：初始状态 2：成功 3失败 11 付款中 20 已取消")
    private Integer status;

    /**
     * 失败原因
     */
    @TableField(value = "msg")
    @ApiModelProperty(value="失败原因")
    private String msg;

    /**
     * 订单号
     */
    @TableField(value = "trade_no")
    @ApiModelProperty(value="订单号")
    private String tradeNo;

    /**
     * 产品id
     */
    @TableField(value = "product_id")
    @ApiModelProperty(value="产品id")
    private Integer productId;


    /**
     * 产品id2
     */
    @TableField(value = "product_id2")
    @ApiModelProperty(value="产品id2")
    private String productId2;

    @ApiModelProperty(value = "三方交易流水号")
    private String thirdTransactionId;

    @ApiModelProperty(value = "订单过期时间")
    private Long expireTime;

    @ApiModelProperty(value = "是否废弃订单 1 是 0 否")
    private Integer isAbandon;
    @ApiModelProperty(value = "支付类型 WX_PAY,ALI_PAY,APPLE_PAY")
    private String payType;
    @ApiModelProperty(value = "苹果内购商品标记")
    private String appleGoodsId;
    @ApiModelProperty(value = "IP地址")
    private String ip;

    @ApiModelProperty(value = "订单待支付数据")
    private String payData;

    @ApiModelProperty(value = "交易hash")
    private String txHash;

    @ApiModelProperty(value = "短系列id")
    private Integer shortSeriesId;

    @ApiModelProperty(value = "购买份数")
    private Integer count;

    @ApiModelProperty(value = "支付积分")
    private Integer integral;

    @ApiModelProperty(value = "订单金额")
    private Integer orderFee;

    @ApiModelProperty(value = "收货地址id")
    private Integer addrId;

}
