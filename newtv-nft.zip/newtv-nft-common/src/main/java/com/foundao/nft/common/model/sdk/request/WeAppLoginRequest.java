package com.foundao.nft.common.model.sdk.request;

import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @ClassName WeAppLoginRequest
 * @Description TODO
 * @Author xifan
 * @Date 2021/12/19 11:34
 * @Version 1.0
 */
@Data
public class WeAppLoginRequest {

    @NotBlank(message = "{required}")
    private String code;

    @NotBlank(message = "{required}")
    private String wx_sign;

    @NotBlank(message = "{required}")
    private String raw_user_data;

    @NotBlank(message = "{required}")
    private String userInfo;
}
