package com.foundao.nft.common.model.sdk.response;

import lombok.Data;

import java.util.List;

/**
 * @ClassName NftTradeListResponse
 * @Description TODO
 * @Author xifan
 * @Date 2021/12/18 0:17
 * @Version 1.0
 */
@Data
public class NftTradeListResponse {

    private int total;

    private List<TranInfo> transList;
}
