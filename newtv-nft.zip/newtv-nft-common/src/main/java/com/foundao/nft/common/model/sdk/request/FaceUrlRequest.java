package com.foundao.nft.common.model.sdk.request;

import lombok.Data;

/**
 * @Package: com.foundao.nft.common.model.sdk.request
 * @ClassName: FaceUrlRequest
 * @Author: chenli
 * @CreateTime: 2021/12/15 4:46 下午
 * @Description:
 */
@Data
public class FaceUrlRequest {

    private String userIdentification;

    private String from;
}
