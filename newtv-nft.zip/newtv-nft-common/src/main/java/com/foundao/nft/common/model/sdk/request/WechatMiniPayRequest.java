package com.foundao.nft.common.model.sdk.request;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @Package: com.foundao.nft.common.model.sdk.request
 * @ClassName: WechatMiniPayRequest
 * @Author: chenli
 * @CreateTime: 2021/12/22 4:03 下午
 * @Description:
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class WechatMiniPayRequest extends BasePayRequest{

    /**
     * openid
     */
    private String openid;

    /**
     * 微信登录后的jscode码
     */
    private String js_code;
}
