package com.foundao.nft.common.model.sdk.request;

import lombok.Data;

/**
 * @Package: com.foundao.nft.common.model.sdk.request
 * @ClassName: UploadSecretRequest
 * @Author: chenli
 * @CreateTime: 2021/12/16 4:36 下午
 * @Description:
 */
@Data
public class UploadSecretRequest {

    /**
     * 系列名
     */
    private String seriesName;

    /**
     * 10位时间戳，秒为单位5分钟有效
     */
    private String timestamp;

    /**
     * 平台公钥
     */
    private String pubKey;

    /**
     * 1 系列不为空 签名 timestamp_seriesName_userPubKey
     * 2 系列为空 签名 timestamp_userPubKey
     */
    private String pubSignedData;

    /**
     * 发行人公钥
     */
    private String userPubKey;

    /**
     * 1 系列不为空 签名 timestamp_seriesName
     * 2 系列为空 签名 timestamp
     */
    private String userSignedData;

}
