package com.foundao.nft.common.model.sdk.response;

import lombok.Data;

/**
 * @ClassName MnemonicResponse
 * @Description TODO
 * @Author xifan
 * @Date 2021/12/15 21:51
 * @Version 1.0
 */
@Data
public class MnemonicResponse {

    /**
     * 12个英文磁珠
     */
    private String mnemonic;

    /**
     * 错误信息
     */
    private String err;
}
