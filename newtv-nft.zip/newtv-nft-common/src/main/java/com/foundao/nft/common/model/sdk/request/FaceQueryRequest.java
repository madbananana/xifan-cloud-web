package com.foundao.nft.common.model.sdk.request;

import lombok.Data;

/**
 * @ClassName FaceQueryRequest
 * @Description TODO
 * @Author xifan
 * @Date 2021/12/15 21:33
 * @Version 1.0
 */
@Data
public class FaceQueryRequest {

    private String userIdentification;

    private String faceId;
}
