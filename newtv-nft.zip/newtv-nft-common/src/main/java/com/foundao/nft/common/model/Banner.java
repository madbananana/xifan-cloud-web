package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.handlers.FastjsonTypeHandler;
import com.baomidou.mybatisplus.extension.handlers.JacksonTypeHandler;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.List;

import lombok.Data;

/**
 * @Package: com.foundao.nft.common.model
 * @ClassName: Banner
 * @Author: chenli
 * @CreateTime: 2022/6/7 11:07 上午
 * @Description:
 */
@ApiModel(value = "com-foundao-nft-common-model-Banner")
@Data
@TableName(value = "nft_banner",autoResultMap = true)
public class Banner implements Serializable {
    @TableId(value = "banner_id", type = IdType.AUTO)
    @ApiModelProperty(value = "")
    private Integer bannerId;

    /**
     * 名称
     */
    @TableField(value = "`name`")
    @ApiModelProperty(value = "名称")
    private String name;

    /**
     * 图片地址
     */
    @TableField(value = "picture")
    @ApiModelProperty(value = "图片地址")
    private String picture;

    /**
     * 跳转地址
     */
    @TableField(value = "redirect_uri",typeHandler = JacksonTypeHandler.class)
    @ApiModelProperty(value = "跳转地址")
    private List<String> redirectUri;

    /**
     * 展示状态 0：不展示 1：展示
     */
    @TableField(value = "show_status")
    @ApiModelProperty(value = "展示状态 0：不展示 1：展示")
    private Integer showStatus;

    /**
     * 展示状态 0：不展示 1：展示
     */
    @TableField(value = "create_time")
    @ApiModelProperty(value = "创建时间")
    private String createTime;

    /**
     * 类型 0图片 1 h5地址
     */
    @TableField(value = "type")
    @ApiModelProperty(value = "类型 0图片 1 h5地址")
    private Integer type;


    @TableField(value = "h5_url")
    @ApiModelProperty(value = "h5地址")
    private String h5Url;

    private static final long serialVersionUID = 1L;
}