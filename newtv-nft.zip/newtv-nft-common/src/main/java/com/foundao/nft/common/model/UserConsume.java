package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
    @Package: com.foundao.nft.common.model
    @ClassName: UserConsume
    @Author: chenli
    @CreateTime: 2022/11/3 11:17 AM
    @Description:
*/

/**
 * 用户消费
 */
@ApiModel(value = "用户消费")
@Data
@TableName(value = "nft_user_consume")
public class UserConsume implements Serializable {
    @TableId(value = "id", type = IdType.AUTO)
    @ApiModelProperty(value = "")
    private Integer id;

    /**
     * 用户id
     */
    @TableField(value = "user_id")
    @ApiModelProperty(value = "用户id")
    private Integer userId;

    /**
     * 活动id
     */
    @TableField(value = "activity_id")
    @ApiModelProperty(value = "活动id")
    private Integer activityId;

    /**
     * 总消费金额
     */
    @TableField(value = "total_cost_fee")
    @ApiModelProperty(value = "总消费金额")
    private Integer totalCostFee;

    @TableField(value = "create_time",fill = FieldFill.INSERT)
    @ApiModelProperty(value = "")
    private String createTime;

    @TableField(value = "update_time",fill = FieldFill.INSERT_UPDATE)
    @ApiModelProperty(value = "")
    private String updateTime;

    private static final long serialVersionUID = 1L;
}