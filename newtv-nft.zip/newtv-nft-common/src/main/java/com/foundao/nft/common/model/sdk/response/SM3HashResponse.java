package com.foundao.nft.common.model.sdk.response;

import lombok.Data;

/**
 * @Package: com.foundao.nft.common.model.sdk.response
 * @ClassName: SM3HashResponse
 * @Author: chenli
 * @CreateTime: 2021/12/16 3:10 下午
 * @Description:
 */
@Data
public class SM3HashResponse {

    /**
     * data的sm3哈希值
     */
    private String digest;

    /**
     * 错误信息
     */
    private String err;
}
