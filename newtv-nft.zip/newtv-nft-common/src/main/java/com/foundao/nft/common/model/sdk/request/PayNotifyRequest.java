package com.foundao.nft.common.model.sdk.request;

import lombok.Data;

/**
 * @ClassName PayNotifyRequest
 * @Description TODO
 * @Author xifan
 * @Date 2021/12/23 0:42
 * @Version 1.0
 */
@Data
public class PayNotifyRequest {

    /**
     * 订单号
     */
    private String out_trade_no;

    /**
     * 订单名
     */
    private String body;

    /**
     * 用户id
     */
    private String user_id;

    /**
     * 产品id
     */
    private String product_id;


    /**
     * 金额 单位分
     */
    private Integer fee;


    /**
     * 订单来源渠道
     */
    private String frmid;


    /**
     * 支付方式
     */
    private Integer pay_type;

    /**
     * 支付方式细分
     */
    private Integer pay_type_m;

    /**
     * 支付状态 2已支付 3失败
     */
    private Integer pay_status;

    /**
     * 现金金额
     */
    private Integer cash_fee;

    /**
     * 13位时间戳
     */
    private Long pay_time;

    /**
     * 下单附加数据
     */
    private String attach;

    /**
     * 仅微信支付返回
     */
    private String openid;

    private String is_subscribe;

    private String transid;

    private String pay_fail_info;

    private String papay;

    private String papay_out_trade_no;

    private long papay_expire_time;

    private int papay_exec_n;

    private String currency;



}
