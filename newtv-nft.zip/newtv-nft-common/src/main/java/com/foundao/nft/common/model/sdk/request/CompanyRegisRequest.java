package com.foundao.nft.common.model.sdk.request;

import lombok.Data;

/**
 * @Package: com.foundao.nft.common.model.sdk.request
 * @ClassName: CompanyRegisRequest
 * @Author: chenli
 * @CreateTime: 2021/12/14 3:23 下午
 * @Description: 企业注册实名接口
 */
@Data
public class CompanyRegisRequest {

    private String epName;

    private String email;

    private String verifyCode;

    private String creditCode;

    private int busiLicenseId;

    private int officicalLetterId;

    private String representativeName;

    private String contact;

    private String mobile;

    private String idcard;

    private int cardType;

    private String platformUrl;

    private String platformName;

    private int businessType;
}
