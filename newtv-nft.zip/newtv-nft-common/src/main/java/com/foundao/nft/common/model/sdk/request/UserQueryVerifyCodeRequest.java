package com.foundao.nft.common.model.sdk.request;

import lombok.Data;

/**
 * @Package: com.foundao.nft.common.model.sdk.request
 * @ClassName: UserQueryVerifyCodeRequest
 * @Author: chenli
 * @CreateTime: 2021/12/14 3:58 下午
 * @Description:
 */
@Data
public class UserQueryVerifyCodeRequest {

    /**
     * 1企业 2个人
     */
    private int type;

    /**
     * 身份证号
     */
    private String cardNo;

    /**
     * 验证码场景： 1查询用户信息 2nft平台绑定地址
     */
    private int scene;
}
