package com.foundao.nft.common.model.sdk.response;

import lombok.Data;

/**
 * @ClassName FaceQueryResponse
 * @Description TODO
 * @Author xifan
 * @Date 2021/12/15 21:34
 * @Version 1.0
 */
@Data
public class FaceQueryResponse {

    private boolean result;
}
