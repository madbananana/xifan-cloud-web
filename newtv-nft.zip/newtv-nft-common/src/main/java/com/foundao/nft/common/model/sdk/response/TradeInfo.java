package com.foundao.nft.common.model.sdk.response;

import lombok.Data;

/**
 * @ClassName TradeInfo
 * @Description TODO
 * @Author xifan
 * @Date 2021/12/18 10:22
 * @Version 1.0
 */
@Data
public class TradeInfo {

    /**
     * 藏品缩略图
     */
    private String displayUrl;

    /**
     * 系列缩略图
     */
    private String coverUrl;

    /**
     * 藏品hash
     */
    private String hash;

    /**
     * nftId
     */
    private String nftId;

    /**
     * 藏品名称
     */
    private String name;

    /**
     * 发行时间
     */
    private String publishTime;

    /**
     * 藏品url
     */
    private String url;

    /**
     * 成交时间
     */
    private String dealTime;

    /**
     * 成交金额
     */
    private int dealCount;

    /**
     * 转入地址
     */
    private String fromAddr;

    /**
     * 转出地址
     */
    private String toAddr;

    /**
     * 交易类别 1发行 2购买 3转移 4设置价格 5设置状态
     */
    private int txType;

}
