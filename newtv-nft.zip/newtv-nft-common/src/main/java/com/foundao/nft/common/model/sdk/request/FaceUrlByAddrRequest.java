package com.foundao.nft.common.model.sdk.request;

import lombok.Data;

/**
 * @Package: com.foundao.nft.common.model.sdk.request
 * @ClassName: FaceUrlByAddrRequest
 * @Author: chenli
 * @CreateTime: 2021/12/15 4:46 下午
 * @Description:
 */
@Data
public class FaceUrlByAddrRequest {

    private String address;

    private String from;
}
