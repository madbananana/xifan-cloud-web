package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import lombok.Data;

/**
 * @Package: com.foundao.nft.common.model
 * @ClassName: RedCodes
 * @Author: chenli
 * @CreateTime: 2022/11/23 9:47 AM
 * @Description:
 */
@ApiModel(value = "nft_red_codes")
@Data
@TableName(value = "nft_red_codes")
public class RedCodes implements Serializable {
    @TableId(value = "id", type = IdType.AUTO)
    @ApiModelProperty(value = "")
    private Integer id;

    @TableField(value = "user_id")
    @ApiModelProperty(value = "")
    private Integer userId;

    /**
     * 兑换码
     */
    @TableField(value = "red_code")
    @ApiModelProperty(value = "兑换码")
    private String redCode;

    private static final long serialVersionUID = 1L;
}