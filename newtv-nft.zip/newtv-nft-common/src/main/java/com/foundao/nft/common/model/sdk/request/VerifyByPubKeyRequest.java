package com.foundao.nft.common.model.sdk.request;

import lombok.Data;

/**
 * @ClassName VerifyByPubKeyRequest
 * @Description TODO
 * @Author xifan
 * @Date 2021/12/15 22:52
 * @Version 1.0
 */
@Data
public class VerifyByPubKeyRequest {

    private String pubKey;

    private String signedData;

    private String data;
}
