package com.foundao.nft.common.model.sdk.request;

import lombok.Data;

/**
 * @Package: com.foundao.nft.common.model.sdk.request
 * @ClassName: WechatMiniPayRequest
 * @Author: chenli
 * @CreateTime: 2021/12/22 4:03 下午
 * @Description:
 */
@Data
public class BasePayRequest {

    /**
     * 订单号
     */
    private String out_trade_no;

    /**
     * 订单名
     */
    private String body;

    /**
     * 用户id
     */
    private String user_id;

    /**
     * 产品id
     */
    private String product_id;
    /**
     * 金额 单位分
     */
    private int fee;

    /**
     * 收款账户别名 固定值newtv
     */
    private String path;

    /**
     * 订单来源渠道
     */
    private String frmid;

    /**
     * expire_time订单过期时间
     */
    private int expire_time;

    /**
     * 支付异步通知地址
     */
    private String notify_url;

    /**
     * 下单附加数据
     */
    private String attach;
    /**
     * ip
     */
    private String ip;


}
