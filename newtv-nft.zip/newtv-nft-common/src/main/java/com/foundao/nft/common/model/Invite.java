package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

@ApiModel(value = "com-foundao-nft-common-model-Invite")
@Data
@TableName(value = "nft_invite")
public class Invite implements Serializable {
    /**
     * 被邀请人id
     */
    @TableId(value = "user_id", type = IdType.INPUT)
    @ApiModelProperty(value = "被邀请人id")
    private Integer userId;

    /**
     * 被邀请人手机号
     */
    @TableField(value = "mobile")
    @ApiModelProperty(value = "被邀请人手机号")
    private String mobile;

    /**
     * 被邀请人昵称
     */
    @TableField(value = "nick_name")
    @ApiModelProperty(value = "被邀请人昵称")
    private String nickName;

    /**
     * 邀请人id
     */
    @TableField(value = "invite_user_id")
    @ApiModelProperty(value = "邀请人id")
    private Integer inviteUserId;

    /**
     * 邀请人手机号
     */
    @TableField(value = "invite_mobile")
    @ApiModelProperty(value = "邀请人手机号")
    private String inviteMobile;

    /**
     * 邀请人昵称
     */
    @TableField(value = "invite_nick_name")
    @ApiModelProperty(value = "邀请人昵称")
    private String inviteNickName;

    /**
     * 注册时间
     */
    @TableField(value = "reg_time")
    @ApiModelProperty(value = "注册时间")
    private String regTime;

    /**
     * 是否已实名 0：未实名 1：已实名
     */
    @TableField(value = "auth")
    @ApiModelProperty(value = "是否已实名 0：未实名 1：已实名")
    private Integer auth;

    /**
     * 实名时间
     */
    @TableField(value = "auth_time")
    @ApiModelProperty(value = "实名时间")
    private String authTime;

    private static final long serialVersionUID = 1L;
}
