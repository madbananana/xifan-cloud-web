package com.foundao.nft.common.model.sdk.response;

import lombok.Data;

/**
 * @Package: com.foundao.nft.common.model.sdk.response
 * @ClassName: AddressStatusResponse
 * @Author: chenli
 * @CreateTime: 2021/12/14 5:44 下午
 * @Description:
 */
@Data
public class AddressStatusResponse {

    private String address;

    /**
     * 1绑定中 2已绑定 3绑定失败 4未发起过绑定
     */
    private int status;
}
