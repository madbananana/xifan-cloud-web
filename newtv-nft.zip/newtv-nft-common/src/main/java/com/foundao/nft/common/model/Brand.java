package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import lombok.Data;

/**
    @Package: com.foundao.nft.common.model
    @ClassName: Brand
    @Author: chenli
    @CreateTime: 2022/2/22 2:26 下午
    @Description:
*/

/**
 * Nft品牌方
 */
@ApiModel(value = "com-foundao-nft-common-model-Brand")
@Data
@TableName(value = "nft_brand")
public class Brand implements Serializable {
    @TableId(value = "id", type = IdType.AUTO)
    @ApiModelProperty(value = "")
    private Integer id;

    /**
     * 品牌名
     */
    @TableField(value = "brand_name")
    @ApiModelProperty(value = "品牌名")
    private String brandName;

    /**
     * 品牌图标
     */
    @TableField(value = "brand_icon")
    @ApiModelProperty(value = "品牌图标")
    private String brandIcon;

    /**
     * 品牌描述
     */
    @TableField(value = "`desc`")
    @ApiModelProperty(value = "品牌描述")
    private String desc;

    private static final long serialVersionUID = 1L;
}