package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.*;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

@ApiModel(value = "com-foundao-nft-common-model-NftMetadata")
@Data
@TableName(value = "nft_metadata")
public class NftMetadata implements Serializable {
    /**
     * 资源id
     */
    @TableId(value = "meta_id", type = IdType.AUTO)
    @ApiModelProperty(value = "资源id")
    private Integer metaId;


    @TableField(value = "nft_id")
    @ApiModelProperty(value = "nft链上id")
    private String nftId;

    /**
     * 作者名
     */
    @TableField(value = "author")
    @ApiModelProperty(value = "作者名")
    private String author = "newTv";

    /**
     * nft名字
     */
    @TableField(value = "`name`")
    @ApiModelProperty(value = "nft名字")
    private String name;

    /**
     * 介质url
     */
    @TableField(value = "url")
    @ApiModelProperty(value = "介质url")
    private String url;

    /**
     * 预览图url
     */
    @TableField(value = "display_url")
    @ApiModelProperty(value = "预览图url")
    private String displayUrl;

    /**
     * 原始作品地址
     */
    @TableField(value = "ori_url")
    @ApiModelProperty(value = "原始作品地址")
    private String oriUrl;

    /**
     * 是否有预览图url
     */
    @ApiModelProperty(value = "是否自定义ntf预览图 0：否 1：是",required = true)
    @NotNull
    private Integer hasDisplayUrl;

    @TableField(value = "hash")
    @ApiModelProperty(value = "")
    private String hash;

    /**
     * 简介
     */
    @TableField(value = "`desc`")
    @ApiModelProperty(value = "简介")
    private String desc;

    /**
     * 标签
     */
    @TableField(value = "flag")
    @ApiModelProperty(value = "标签")
    private String flag = "";

    /**
     * 发行数量
     */
    @TableField(value = "publish_count")
    @ApiModelProperty(value = "发行数量")
    private Integer publishCount;

    /**
     * 发行数量
     */
    @TableField(value = "rest_count")
    @ApiModelProperty(value = "剩余未售卖份数")
    private Integer restCount;

    /**
     * 发行数量
     */
    @TableField(value = "series_begin_index")
    @ApiModelProperty(value = "系列子id从多少开始")
    private Integer seriesBeginIndex = 1;


    /**
     * 系列id
     */
    @TableField(value = "series_id")
    @ApiModelProperty(value = "系列id")
    private String seriesId = "";

    /**
     * 是否可售 1：可售 2：不可售
     */
    @TableField(value = "sell_status")
    @ApiModelProperty(value = "是否可售 1：可售 2：不可售")
    private Integer sellStatus = 1;


    /**
     * 售价，单位分，如果是免费 该字段为0
     */
    @TableField(value = "sell_fee")
    @ApiModelProperty(value = "售价，单位分，如果是免费 该字段为0")
    private Integer sellFee;

    /**
     * 可售状态下表示出售多少积分
     */
    @TableField(value = "sell_count")
    @ApiModelProperty(value = "可售状态下表示出售多少积分")
    private Integer sellCount = 0;

    /**
     * 请求id
     */
    @TableField(value = "operate_id")
    @ApiModelProperty(value = "请求id")
    private String operateId;

    /**
     * 扩展字段
     */
    @TableField(value = "meta_data")
    @ApiModelProperty(value = "扩展字段")
    private String metaData = "";

    @TableField(value = "meta_type")
    @ApiModelProperty(value = "1普通款 3隐藏款")
    private Integer metaType;

    /**
     * 发行人
     */
    @TableField(value = "creator")
    @ApiModelProperty(value = "发行人")
    private Integer creator;

    /**
     * 任务id
     */
    @TableField(value = "task_id")
    @ApiModelProperty(value = "任务id")
    private String taskId;

    /**
     * 任务id
     */
    @TableField(value = "task_status")
    @ApiModelProperty(value = "任务状态 2：任务执行中 7：执行成功 10：执行失败")
    private Integer taskStatus;

    /**
     * 新增时间
     */
    @TableField(value = "create_time",fill = FieldFill.INSERT)
    @ApiModelProperty(value = "新增时间")
    private String createTime;


    /**
     * 更新时间
     */
    @TableField(value = "update_time",fill = FieldFill.INSERT_UPDATE)
    @ApiModelProperty(value = "更新时间")
    private String updateTime;

    @TableField(value = "version")
    @ApiModelProperty(value = "版本号")
    private Integer version;

    @TableField(value = "image_desc")
    @ApiModelProperty(value = "图片描述")
    private String imageDesc;

    @TableField(value = "apple_name")
    @ApiModelProperty(value = "苹果内购id")
    private String appleName;

    @TableField(value = "type")
    @ApiModelProperty(value = "作品类型 0：图片 1：视频")
    private Integer type;

    /**
     * 状态 0：未展示 1：展示中
     */
    @TableField(value = "show_status")
    @ApiModelProperty(value = "状态 0：未展示 1：展示中")
    private Integer showStatus;

    /**
     * 状态 0：未展示 1：展示中
     */
    @TableField(value = "show_count")
    @ApiModelProperty(value = "展示份数")
    private Integer showCount;

    @TableField(exist = false)
    @ApiModelProperty(value = "总展示份数")
    private Integer totalShowCount;

    /**
     * 系列短id
     */
    @TableField(value = "short_series_id")
    @ApiModelProperty(value = "系列短id")
    private Integer shortSeriesId;

}
