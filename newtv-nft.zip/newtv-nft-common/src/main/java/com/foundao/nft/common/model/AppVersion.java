package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import lombok.Data;
import org.hibernate.validator.constraints.Range;
import org.springframework.validation.annotation.Validated;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 @Package: com.foundao.nft.common.model
 @ClassName: AppVersion
 @Author: chenli
 @CreateTime: 2022/4/29 4:09 下午
 @Description:
 */
/**
 * app版本控制表
 */
@ApiModel(value="com-foundao-nft-common-model-AppVersion")
@Data
@TableName(value = "nft_app_version")
@Validated
public class AppVersion implements Serializable {
    @TableId(value = "id", type = IdType.AUTO)
    @ApiModelProperty(value="")
    private Integer id;

    /**
     * 设备类型 1安卓 2ios
     */
    @TableField(value = "device_type")
    @ApiModelProperty(value="设备类型 1安卓 2ios",required = true)
    @NotNull(message = "设备类型不能为空")
    @Range(min = 1, max = 2, message = "设备类型只能为1或2")
    private Integer deviceType;

    /**
     * 下载链接 IOS不需要填写
     */
    @TableField(value = "down_url")
    @ApiModelProperty(value="下载链接 IOS不需要填写")
    private String downUrl;

    /**
     * 更新时间
     */
    @TableField(value = "begin_time")
    @ApiModelProperty(value="更新时间")
    private String beginTime;

    /**
     * 是否强制更新 0：非强制 1：强制
     */
    @TableField(value = "`force`")
    @ApiModelProperty(value="是否强制更新 0：非强制 1：强制")
    @NotNull(message = "是否强制更新不能为空")
    private Integer force;

    /**
     * 版本号
     */
    @TableField(value = "version")
    @ApiModelProperty(value="版本号")
    @NotNull(message = "版本号不能为空")
    private String version;

    /**
     * 更新时间
     */
    @TableField(value = "create_time")
    @ApiModelProperty(value="创建时间")
    private String createTime;

    /**
     * 是否即刻更新 0：否1：定时更新
     */
    @TableField(value = "execute_now")
    @ApiModelProperty(value="是否即刻更新 0：否1：是")
    @Range(min = 0, max = 1, message = "是否即刻更新只能为0或1")
    @NotNull(message = "是否即刻更新不能为空")
    private Integer executeNow;

    /**
     * 更新日志
     */
    @TableField(value = "note")
    @ApiModelProperty(value="更新日志")
    private String note;

    /**
     * 文件md5
     */
    @TableField(value = "content_md5")
    @ApiModelProperty(value="文件md5")
    private String contentMd5;


    private static final long serialVersionUID = 1L;
}