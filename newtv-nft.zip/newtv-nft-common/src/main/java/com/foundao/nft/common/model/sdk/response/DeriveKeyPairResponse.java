package com.foundao.nft.common.model.sdk.response;

import lombok.Data;

/**
 * @ClassName DeriveKeyPairResponse
 * @Description TODO
 * @Author xifan
 * @Date 2021/12/15 21:59
 * @Version 1.0
 */
@Data
public class DeriveKeyPairResponse {

    /**
     * 私钥
     */
    private String priKey;

    /**
     * 公钥
     */
    private String pubKey;

    /**
     * 错误信息
     */
    private String err;
}
