package com.foundao.nft.common.model.sdk.response;

import lombok.Data;

/**
 * @Package: com.foundao.nft.common.model.sdk.response
 * @ClassName: NftPublishTaskResultResponse
 * @Author: chenli
 * @CreateTime: 2021/12/17 3:28 下午
 * @Description:
 */
@Data
public class NftPublishTaskResultResponse {

    /**
     * nftId格式，发行人公钥hash_系列_系列索引id，申请多少个，最后一段计算出来即可
     * 比如申请10个，nftIdBegin位xx_xx_1，那么久可以推导出x_xx_1到x_xx_10
     */
    private String nftIdBegin;

    /**
     * 标记任务状态
     * 任务执行中：2
     * 任务成功：7
     * 任务失败：10
     */
    private int taskStatus;

    /**
     * 失败情况下会有提示信息
     */
    private String taskMsg;

    /**
     * 系列id，后面用于查询系列信息
     */
    private String seriesId;

    /**
     * 交易hash
     */
    private String txHash;

    /**
     * 链上交易时间戳
     */
    private int chainTimestamp;
}
