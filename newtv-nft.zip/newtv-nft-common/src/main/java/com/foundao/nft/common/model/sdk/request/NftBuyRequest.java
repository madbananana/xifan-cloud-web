package com.foundao.nft.common.model.sdk.request;

import lombok.Data;

/**
 * @ClassName NftBuyRequest
 * @Description TODO
 * @Author xifan
 * @Date 2021/12/18 10:47
 * @Version 1.0
 */
@Data
public class NftBuyRequest {

    private String nftId;

    /**
     * 申请多少积分给购买者
     */
    private int applyScore;

    /**
     * nft接收者公钥
     */
    private String receiverPubKey;

    /**
     * 积分接收者地址
     */
    private String pointReceiverAddr;

    /**
     * 平台公钥
     */
    private String platformPubKey;

    /**
     * 出多少积分
     */
    private int offerCount;

    /**
     * 请求id 每个请求需要填唯一id 重复请求用相同id
     */
    private String operateId;

    /**
     * 接收人的私钥签名，签名对象是（platformPubKey_receiverPubKey_pointReceiverAddr_applyScore_接口名_nftId_offerCount_operateId）
     * 接口名=buy_nft
     */
    private String signature;

    /**
     * 平台方的私钥签名，签名对象和signature对象一致。
     */
    private String platformSignature;

}
