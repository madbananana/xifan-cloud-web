package com.foundao.nft.common.model.sdk.request;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

/**
 * @Package: com.foundao.nft.common.model.sdk.request
 * @ClassName: BsLicenseUploadPlatformRequest
 * @Author: chenli
 * @CreateTime: 2021/12/14 2:39 下午
 * @Description:
 */
@Data
public class BsLicenseUploadPlatformRequest {

    private MultipartFile file;

    /**
     * 用户平台唯一标识
     */
    private String platformIdentification;

    /**
     * 平台公钥
     */
    private String platformPubKey;

    /**
     * 平台签名信息
     */
    private String platformSignData;
}
