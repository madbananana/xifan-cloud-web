package com.foundao.nft.common.model.sdk.request;

import lombok.Data;

/**
 * @ClassName PointTransferRequest
 * @Description TODO
 * @Author xifan
 * @Date 2021/12/18 21:03
 * @Version 1.0
 */
@Data
public class PointTransferRequest {

    /**
     * 平台公钥
     */
    private String platformPubKey;

    /**
     * 转出者公钥（可以与平台公钥相同，前提是账户有积分可转）
     */
    private String fromPubKey;

    /**
     * 积分接收者地址
     */
    private String toAddr;

    /**
     * 积分数量
     */
    private int count;

    /**
     * 请求id 每个请求需要填唯一id 重复请求用相同id
     */
    private String operateId;

    /**
     * 操作者的私钥签名，签名对象是（platformPubKey_fromPubKey_toAddr_接口名_count_operateId）
     * 接口名：transfer_point
     */
    private String signature;

    /**
     * 平台方的私钥签名，签名对象和signature对象一致。
     */
    private String platformSignature;
}
