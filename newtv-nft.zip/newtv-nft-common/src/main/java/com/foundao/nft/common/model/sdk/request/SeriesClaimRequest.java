package com.foundao.nft.common.model.sdk.request;

import lombok.Data;

/**
 * @ClassName SeriesClaimRequest
 * @Description TODO
 * @Author xifan
 * @Date 2021/12/16 22:36
 * @Version 1.0
 */
@Data
public class SeriesClaimRequest {
    /**
     * 系列名
     */
    private String seriesName;

    /**
     * 系列一共有多少个。0表示没限制
     */
    private Integer totalCount = 0 ;

    /**
     * 请求id 每个请求需要填唯一id 重复请求用相同id
     */
    private String operateId;

    /**
     * 系列封面url
     */
    private String coverUrl;

    /**
     * 描述信息
     */
    private String desc;

    /**
     * 历史遗留字段
     */
    private Integer maxPublishCount = 0;

    /**
     * 系列下的nftId后缀 是否从0开始 true就是从0开始，默认为false从1开始
     */
    private boolean seriesBeginFromZero = false;


    /* *******以下是非必须参数 SDK会自动填充************************/
    /**
     * 系列声明人公钥
     */
    private String pubKey;

    /**
     * 平台公钥
     */
    private String platformPubKey;

    /**
     * 系列声明人的私钥签名，签名对象是（platformPubKey_pubKey_接口名_seriesName_totalCount_coverUrl_desc_maxPublishCount_seriesBeginFromZero_operated）
     * 接口名=series_claim
     */
    private String signature;

    /**
     * 平台方的私钥签名，签名对象和signature一致
     */
    private String platformSignature;

}
