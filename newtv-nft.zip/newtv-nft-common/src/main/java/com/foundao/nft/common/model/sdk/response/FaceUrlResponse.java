package com.foundao.nft.common.model.sdk.response;

import lombok.Data;

/**
 * @ClassName FaceUrlResponse
 * @Description TODO
 * @Author xifan
 * @Date 2021/12/15 21:28
 * @Version 1.0
 */
@Data
public class FaceUrlResponse {

    /**
     * 启动人脸核身的h5 url
     */
    private String h5Url;

    /**
     * 人脸核验请求的唯一标识 需要保存
     */
    private String faceId;
}
