package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
    * 订单通知表
    */
@ApiModel(value="com-foundao-nft-common-model-OrderNotify")
@Data
@TableName("order_notify")
public class OrderNotify implements Serializable {
    @ApiModelProperty(value="")
    @TableId(value = "notify_id",type = IdType.AUTO)
    private Integer notifyId;

    /**
    * 2 支付成功  3 失败
    */
    @ApiModelProperty(value="2 支付成功  3 失败")
    private Integer notifyType;

    /**
    * 通知数据
    */
    @ApiModelProperty(value="通知数据")
    private String notifyData;

    @ApiModelProperty(value="三方交易流水号")
    private String thirdTradeNo;

    @ApiModelProperty(value="本系统订单号")
    private String tradeNo;
    /**
    * 新增时间
    */
    @ApiModelProperty(value="新增时间")
    private String createTime;

    @ApiModelProperty(value="环境，沙盒或正式")
    private String env;


    @ApiModelProperty(value="环境，沙盒或正式")
    private String appleNotifyType;

    @ApiModelProperty(value="通知处理状态")
    private String status;
    private static final long serialVersionUID = 1L;
}