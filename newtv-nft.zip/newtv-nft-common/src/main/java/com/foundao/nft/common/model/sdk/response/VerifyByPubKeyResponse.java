package com.foundao.nft.common.model.sdk.response;

import lombok.Data;

/**
 * @ClassName VerifyByPubKeyResponse
 * @Description TODO
 * @Author xifan
 * @Date 2021/12/15 22:59
 * @Version 1.0
 */
@Data
public class VerifyByPubKeyResponse {

    private boolean isValid;

    private String err;
}
