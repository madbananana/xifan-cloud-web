package com.foundao.nft.common.model.sdk.response;

import lombok.Data;

/**
 * @Package: com.foundao.nft.common.model.sdk.response
 * @ClassName: PersonRegResponse
 * @Author: chenli
 * @CreateTime: 2021/12/13 5:27 下午
 * @Description:
 */
@Data
public class PersonRegResponse {

    /**
     * 用户唯一标识
     */
    private String userIdentification;
}
