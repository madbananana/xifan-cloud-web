package com.foundao.nft.common.model.sdk.response;

import lombok.Data;

/**
 * @Package: com.foundao.nft.common.model.sdk.response
 * @ClassName: UploadUrlGetResponse
 * @Author: chenli
 * @CreateTime: 2021/12/16 4:06 下午
 * @Description:
 */
@Data
public class UploadUrlGetResponse {

    /**
     * cos地址
     */
    private String materialAddress;
}
