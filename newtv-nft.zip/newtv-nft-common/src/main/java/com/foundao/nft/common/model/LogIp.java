package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import lombok.Data;

@ApiModel(value="log_ip")
@Data
@TableName(value = "log_ip")
public class LogIp implements Serializable {
    @TableId(value = "id", type = IdType.AUTO)
    @ApiModelProperty(value="")
    private Integer id;

    @TableField(value = "invite_code")
    @ApiModelProperty(value="")
    private Integer inviteCode;

    @TableField(value = "`count`")
    @ApiModelProperty(value="")
    private Integer count;

    @TableField(value = "ip")
    @ApiModelProperty(value="")
    private String ip;

    private static final long serialVersionUID = 1L;
}