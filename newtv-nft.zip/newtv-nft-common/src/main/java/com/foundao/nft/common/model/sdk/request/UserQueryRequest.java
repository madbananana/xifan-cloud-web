package com.foundao.nft.common.model.sdk.request;

import lombok.Data;

/**
 * @Package: com.foundao.nft.common.model.sdk.request
 * @ClassName: UserQueryRequest
 * @Author: chenli
 * @CreateTime: 2021/12/14 4:05 下午
 * @Description:
 */
@Data
public class UserQueryRequest {

    private String type;

    private String cardNo;

    private String verifyCode;
}
