package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import lombok.Data;

@ApiModel(value = "com-foundao-nft-common-model-Recipe")
@Data
@TableName(value = "nft_recipe")
public class Recipe implements Serializable {
    /**
     * 配方id
     */
    @TableId(value = "recipe_id", type = IdType.AUTO)
    @ApiModelProperty(value = "配方id")
    private Integer recipeId;

    /**
     * 配方名称
     */
    @TableField(value = "recipe_name")
    @ApiModelProperty(value = "配方名称")
    private String recipeName;

    /**
     * 合成结果所属系列
     */
    @TableField(value = "result_series_id")
    @ApiModelProperty(value = "合成结果所属系列")
    private Integer resultSeriesId;

    /**
     * 合成结果藏品id
     */
    @TableField(value = "result_meta_id")
    @ApiModelProperty(value = "合成结果藏品id")
    private Integer resultMetaId;


    private static final long serialVersionUID = 1L;
}
