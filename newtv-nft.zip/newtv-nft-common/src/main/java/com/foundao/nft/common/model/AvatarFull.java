package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
    * 牛头像组件
    */
@ApiModel(value="com-foundao-nft-common-model-AvatarFull")
@Data
@TableName(value = "avatar_full")
public class AvatarFull implements Serializable {
    /**
    * 头像id
    */
    @ApiModelProperty(value="头像id")
    @TableId(value = "id",type = IdType.AUTO)
    private Integer id;

    /**
    * 0 普通头像，1 特殊头像(10年老员工使用)
    */
    @ApiModelProperty(value="0 普通头像，1 特殊头像(10年老员工使用) 2唯一背景头像")
    private Integer specialType;

    /**
    * 文件访问地址
    */
    @ApiModelProperty(value="文件访问地址")
    private String url;

    /**
    * 新增时间
    */
    @ApiModelProperty(value="新增时间")
    private Date createTime;

    /**
    * 构成头像的部件
    */
    @ApiModelProperty(value="构成头像的部件")
    private String parts;


    @ApiModelProperty(value="来源文件的原始名称")
    private String sourceFileName;

    @ApiModelProperty(value="nft的自增id")
    private Integer nftMetaId;

    @ApiModelProperty(value="0 未抽取 1 抽取锁定 2 已经被抽取'")
    private Integer status;

    @ApiModelProperty(value = "头像部件id")
    private Integer avatarPartId;


    /**
     * 非数据库字段
     */
    @ApiModelProperty(value = "背景图片")
    @TableField(exist = false)
    private String backendGroundUrl;

    /**
     * 非数据库字段
     */
    @ApiModelProperty(value = "完整背景图片")
    @TableField(exist = false)
    private String fullBackendGroundUrl;

    @ApiModelProperty(value = "锁定用户id")
    private Integer lockUserId;


    private static final long serialVersionUID = 1L;
}
