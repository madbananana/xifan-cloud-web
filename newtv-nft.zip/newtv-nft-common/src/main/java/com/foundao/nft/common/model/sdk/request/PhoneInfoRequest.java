package com.foundao.nft.common.model.sdk.request;

import lombok.Data;

/**
 * @Package: com.foundao.nft.common.model.sdk.request
 * @ClassName: PhoneInfoRequest
 * @Author: chenli
 * @CreateTime: 2021/12/20 5:03 下午
 * @Description:
 */
@Data
public class PhoneInfoRequest {

    private String encryptedData;

    private String iv;

}
