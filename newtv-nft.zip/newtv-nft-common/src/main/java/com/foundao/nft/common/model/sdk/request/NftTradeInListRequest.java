package com.foundao.nft.common.model.sdk.request;

import lombok.Data;

/**
 * @ClassName NftTradeInListRequest
 * @Description TODO
 * @Author xifan
 * @Date 2021/12/18 10:21
 * @Version 1.0
 */
@Data
public class NftTradeInListRequest {

    private String addr;

    private int offset;

    private int limit;

}
