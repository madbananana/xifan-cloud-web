package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * @Package: com.foundao.nft.common.model
 * @ClassName: SignRecord
 * @Author: chenli
 * @CreateTime: 2022/9/23 4:41 下午
 * @Description:
 */
@ApiModel(value = "com-foundao-nft-common-model-SignRecord")
@Data
@TableName(value = "nft_sign_record")
public class SignRecord implements Serializable {
    @TableId(value = "id", type = IdType.AUTO)
    @ApiModelProperty(value = "")
    private Integer id;

    /**
     * 签到日期
     */
    @TableField(value = "sign_date")
    @ApiModelProperty(value = "签到日期")
    private String signDate;

    @TableField(value = "user_id")
    @ApiModelProperty(value = "")
    private Integer userId;

    /**
     * 连续签到次数
     */
    @TableField(value = "continue_number")
    @ApiModelProperty(value = "连续签到次数")
    private Integer continueNumber;

    /**
     * 签到时间
     */
    @TableField(value = "create_time")
    @ApiModelProperty(value = "签到时间")
    private String createTime;

    /**
     * 签到IP
     */
    @TableField(value = "sign_ip")
    @ApiModelProperty(value = "签到IP")
    private String signIp;

    private static final long serialVersionUID = 1L;
}
