package com.foundao.nft.common.constant;

/**
 * 订单状态
 */
public enum PayTypeEnum {
    WX_PAY("WX_PAY","微信支付"),
    ALI_PAY("ALI_PAY","支付宝支付"),
    APPLE_PAY("APPLE_PAY","苹果支付"),
    FREE_ACCESS("FREEACCESS","免费领取"),
    INTEGRAL_PAY("INTEGRAL_PAY","积分兑换");

    /**
     * 返回码
     */
    private String code;

    /**
     * 返回码代表的意思
     */
    private String msg;

    PayTypeEnum(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public String getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }
}
