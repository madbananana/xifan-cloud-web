package com.foundao.nft.common.model.sdk.response;

import lombok.Data;

/**
 * @Package: com.foundao.nft.common.model.sdk.response
 * @ClassName: UploadToCosResponse
 * @Author: chenli
 * @CreateTime: 2021/12/16 3:16 下午
 * @Description:
 */
@Data
public class UploadToCosResponse {

    private String err;
}
