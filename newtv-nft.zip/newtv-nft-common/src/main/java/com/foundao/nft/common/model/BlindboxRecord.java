package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 @Package: com.foundao.nft.common.model
 @ClassName: BlindboxRecord
 @Author: chenli
 @CreateTime: 2022/7/14 5:08 下午
 @Description:
 */
/**
 * 盲盒记录表
 */
@ApiModel(value="com-foundao-nft-common-model-BlindboxRecord")
@Data
@TableName(value = "nft_blindbox_record")
public class BlindboxRecord implements Serializable {
    @TableId(value = "box_id", type = IdType.AUTO)
    @ApiModelProperty(value="")
    private Integer boxId;

    /**
     * 用户id
     */
    @TableField(value = "user_id")
    @ApiModelProperty(value="用户id")
    private Integer userId;

    /**
     * metaId
     */
    @TableField(value = "meta_id")
    @ApiModelProperty(value="metaId")
    private Integer metaId;

    /**
     * 真实nftId
     */
    @TableField(value = "actual_nft_id")
    @ApiModelProperty(value="真实nftId")
    private String actualNftId;

    /**
     * 短系列id
     */
    @TableField(value = "short_series_id")
    @ApiModelProperty(value="短系列id")
    private Integer shortSeriesId;

    /**
     * 订单号
     */
    @TableField(value = "order_id")
    @ApiModelProperty(value="订单号")
    private Integer orderId;

    /**
     * 是否开启 0：未开启 1：已开启
     */
    @TableField(value = "`status`")
    @ApiModelProperty(value="是否开启 0：未开启 1：已开启")
    private Integer status;

    /**
     * 创建时间
     */
    @TableField(value = "create_time",fill = FieldFill.INSERT)
    @ApiModelProperty(value="创建时间")
    private String createTime;

    /**
     * 更新时间
     */
    @TableField(value = "update_time",fill = FieldFill.INSERT_UPDATE)
    @ApiModelProperty(value="更新时间")
    private String updateTime;

    @ApiModelProperty(value = "盲盒开始时间")
    private String openTime;

    @ApiModelProperty(value = "盲盒封面")
    private String blindBoxIcon;

    private static final long serialVersionUID = 1L;
}
