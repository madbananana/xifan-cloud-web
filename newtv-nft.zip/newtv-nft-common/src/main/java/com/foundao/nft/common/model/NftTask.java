package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@ApiModel(value = "com-foundao-nft-common-model-NftTask")
@Data
@TableName(value = "nft_task")
public class NftTask implements Serializable {

    @Data
    public static class NftBuyExtInfo implements Serializable{
        //nftid
        private String nftId;
        private Integer userId;
        private Integer metaId;
        private Integer orderId;
        /**
         * 1 普通作品 2 牛头作品人物 3盲盒资源
         */
        private Integer metaType;
        /** 下面两个字段用于 牛头像人物 */
        private Integer partId;
        private Integer fullAvatarId;
        private String isReplenish;
        private Integer shortSeriesId;
        private Integer mergeId;
        private Integer recordId;
    }
    /**
     * 任务id
     */
    @TableId(value = "id", type = IdType.AUTO)
    @ApiModelProperty(value = "id")
    private String id;

    /**
     * 任务id
     */
    @ApiModelProperty(value = "任务id")
    private String taskId;

    /**
     * 任务类型 1：系列声明 2：nft发行 3：积分申请 4：积分销毁 5：nft购买 6：nft转移 7：销售状态变更 8：售价变更 9：积分转移
     */
    @TableField(value = "`type`")
    @ApiModelProperty(value = "任务类型 1：系列声明 2：nft发行 3：积分申请 4：积分销毁 5：nft购买 6：nft转移 7：销售状态变更 8：售价变更 9：积分转移")
    private Integer type;

    /**
     * 任务状态 2：任务执行中 7：执行成功 10：执行失败
     */
    @TableField(value = "`status`")
    @ApiModelProperty(value = "任务状态 2：任务执行中 7：执行成功 10：执行失败")
    private Integer status;

    /**
     * 失败提示
     */
    @TableField(value = "task_msg")
    @ApiModelProperty(value = "失败提示")
    private String taskMsg;

    /**
     * nft_id格式
     */
    @TableField(value = "nft_id_begin")
    @ApiModelProperty(value = "nft_id格式")
    private String nftIdBegin;

    /**
     * 交易hash
     */
    @TableField(value = "tx_hash")
    @ApiModelProperty(value = "交易hash")
    private String txHash;

    /**
     * 链上交易时间
     */
    @TableField(value = "chain_timestamp")
    @ApiModelProperty(value = "链上交易时间")
    private Date chainTimestamp;

    /**
     * 链上交易时间
     */
    @TableField(value = "operate_id")
    @ApiModelProperty(value = "唯一流水号")
    private String operateId;

    /**
     * 扩展字段1
     */
    @TableField(value = "extend1")
    @ApiModelProperty(value = "扩展字段1")
    private String extend1;

    /**
     * 扩展字段2
     */
    @TableField(value = "extend2")
    @ApiModelProperty(value = "扩展字段2")
    private String extend2;

    /**
     * 扩展字段3
     */
    @TableField(value = "extend3")
    @ApiModelProperty(value = "扩展字段3")
    private String extend3;

    /**
     * 扩展字段3
     */
    @TableField(exist = false)
    @ApiModelProperty(value = "记录ID")
    private String recordId;

    private static final long serialVersionUID = 1L;

    public static final String COL_TASK_ID = "task_id";

    public static final String COL_TYPE = "type";

    public static final String COL_STATUS = "status";

    public static final String COL_TASK_MSG = "task_msg";

    public static final String COL_NFT_ID_BEGIN = "nft_id_begin";

    public static final String COL_TX_HASH = "tx_hash";

    public static final String COL_CHAIN_TIMESTAMP = "chain_timestamp";
}
