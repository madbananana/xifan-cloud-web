package com.foundao.nft.common.model.sdk.response;

import lombok.Data;

/**
 * @Package: com.foundao.nft.common.model.sdk.response
 * @ClassName: ImageUploadResponse
 * @Author: chenli
 * @CreateTime: 2021/12/14 2:45 下午
 * @Description:
 */
@Data
public class ImageUploadResponse {

    /**
     * 图片id
     */
    private String id;
}
