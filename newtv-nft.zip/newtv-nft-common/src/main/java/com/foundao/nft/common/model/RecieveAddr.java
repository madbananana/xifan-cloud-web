package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import lombok.Data;

/**
    @Package: com.foundao.nft.common.model
    @ClassName: RecieveAddr
    @Author: chenli
    @CreateTime: 2022/7/12 3:55 下午
    @Description:
*/

/**
 * 用户地址表
 */
@ApiModel(value = "com-foundao-nft-common-model-RecieveAddr")
@Data
@TableName(value = "nft_recieve_addr")
public class RecieveAddr implements Serializable {
    @TableId(value = "addr_id", type = IdType.AUTO)
    @ApiModelProperty(value = "")
    private Integer addrId;

    /**
     * 用户id
     */
    @TableField(value = "user_id")
    @ApiModelProperty(value = "用户id")
    private Integer userId;

    /**
     * 收货人
     */
    @TableField(value = "consignee")
    @ApiModelProperty(value = "收货人")
    private String consignee;

    /**
     * 省id
     */
    @TableField(value = "province_id")
    @ApiModelProperty(value = "省id")
    private Integer provinceId;

    /**
     * 省
     */
    @TableField(value = "province")
    @ApiModelProperty(value = "省")
    private String province;

    /**
     * 城市id
     */
    @TableField(value = "city_id")
    @ApiModelProperty(value = "城市id")
    private Integer cityId;

    /**
     * 城市
     */
    @TableField(value = "city")
    @ApiModelProperty(value = "城市")
    private String city;

    /**
     * 区域id
     */
    @TableField(value = "area_id")
    @ApiModelProperty(value = "区域id")
    private Integer areaId;

    /**
     * 区
     */
    @TableField(value = "area")
    @ApiModelProperty(value = "区")
    private String area;

    /**
     * 详细地址
     */
    @TableField(value = "addr")
    @ApiModelProperty(value = "详细地址")
    private String addr;

    /**
     * 邮编
     */
    @TableField(value = "post_code")
    @ApiModelProperty(value = "邮编")
    private String postCode;

    /**
     * 电话
     */
    @TableField(value = "mobile")
    @ApiModelProperty(value = "电话")
    private String mobile;

    /**
     * 电话
     */
    @TableField(exist = false)
    @ApiModelProperty(value = "电话")
    private String bindMobile;

    /**
     * 是否默认地址 0:否 1:是
     */
    @TableField(value = "is_default")
    @ApiModelProperty(value="是否默认地址 0:否 1:是")
    private Integer isDefault;

    private static final long serialVersionUID = 1L;
}