package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import lombok.Data;

/**
    @Package: com.foundao.nft.common.model
    @ClassName: AwardInfo
    @Author: chenli
    @CreateTime: 2022/11/3 11:17 AM
    @Description:
*/

/**
 * 奖品信息
 */
@ApiModel(value = "奖品信息")
@Data
@TableName(value = "nft_award_info")
public class AwardInfo implements Serializable {
    @TableId(value = "award_id", type = IdType.AUTO)
    @ApiModelProperty(value = "")
    private Integer awardId;

    /**
     * 奖品名称
     */
    @TableField(value = "`name`")
    @ApiModelProperty(value = "奖品名称")
    private String name;

    /**
     * 奖品等级
     */
    @TableField(value = "`level`")
    @ApiModelProperty(value = "奖品等级")
    private Integer level;

    /**
     * 总库存
     */
    @TableField(value = "total_count")
    @ApiModelProperty(value = "总库存")
    private Integer totalCount;

    /**
     * 剩余库存
     */
    @TableField(value = "rest_count")
    @ApiModelProperty(value = "剩余库存")
    private Integer restCount;

    /**
     * 活动id
     */
    @TableField(value = "activity_id")
    @ApiModelProperty(value = "活动id")
    private Integer activityId;

    /**
     * 是否是黄金用户奖励
     */
    @TableField(value = "is_gold_award")
    @ApiModelProperty(value = "是否是黄金用户奖励")
    private Integer isGoldAward;

    private static final long serialVersionUID = 1L;
}