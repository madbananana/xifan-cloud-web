package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
    * 牛头像组件
    */
@ApiModel(value="com-foundao-nft-common-model-AvatarPart")
@Data
@TableName(value = "avatar_part")
public class AvatarPart implements Serializable {
    /**
    * 部件id
    */
    @ApiModelProperty(value="部件id")
    @TableId(value = "part_id",type = IdType.AUTO)
    private Integer partId;

    @ApiModelProperty(value = "1 背景 2 道具 3 耳机   4 头饰 5 眼镜 6 衣服 100 人物")
    private Integer partType;

    /**
    * 文件访问地址
    */
    @ApiModelProperty(value="文件访问地址")
    private String url;

    /**
    * 新增时间
    */
    @ApiModelProperty(value="新增时间")
    private Date createTime;


    @ApiModelProperty(value="来源文件的原始名称")
    private String sourceFileName;
    @ApiModelProperty(value = "0 未抽取 1 抽取锁定 2 已经被抽取")
    private Integer status;
    @ApiModelProperty(value="持有头像的用户id")
    private Integer lockUserId;

    @ApiModelProperty(value="0 普通头像，1 特殊头像(10年老员工使用)")
    private Integer specialType;

    @ApiModelProperty(value="部件名称")
    private String name;
    @ApiModelProperty(value="比例")
    private BigDecimal ratio;
    @ApiModelProperty(value="是否唯一 0 否，1 是")
    private Integer isUnique;


    private static final long serialVersionUID = 1L;
}