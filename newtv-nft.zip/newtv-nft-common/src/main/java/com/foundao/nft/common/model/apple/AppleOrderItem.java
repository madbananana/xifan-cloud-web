package com.foundao.nft.common.model.apple;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.annotation.JSONField;
import lombok.Data;

import java.io.Serializable;

/**
 * @author tomxia
 */
@Data
public class AppleOrderItem implements Serializable {

    /**
     * 取消订单(退单)的时间  2021-03-10 09:32:47 America/Los_Angeles
     */
    @JSONField(name = "cancellation_date_pst")
    private String cancellationDatePst;

    /**
     * 取消订单(退单)的时间戳
     */
    @JSONField(name = "cancellation_date_ms")
    private Long cancellationDateMs;

    /**
     * 取消订阅的时间
     */
    @JSONField(name = "cancellation_date")
    private String cancellationDate;


    /**
     * 交易ID
     */
    @JSONField(name = "transaction_id")
    private String transactionId;

    /**
     * // 交易id "370000437964939"
     * //String transactionId = inAppArrayItem.getString("transaction_id");
     * // 在in_app中的交易id 应当取 此字段
     */
    @JSONField(name = "original_transaction_id")
    private String originalTransactionId;

    /**
     * 原始订单购买时间戳
     */
    @JSONField(name = "original_purchase_date_ms")
    private Long originalPurchaseDateMs;

    /**
     * 原始订单时间 在恢复购买时 会产生新的时间
     */
    @JSONField(name = "original_purchase_date_pst")
    private String originalPurchaseDatePst;

    /**
     * 获取购买的时间戳
     */
    @JSONField(name = "purchase_date_ms")
    private Long purchaseDateMs;

    /**
     * 购买时间 "2020-11-19 06:12:16 America/Los_Angeles"
     */
    @JSONField(name = "purchase_date_pst")
    private String purchaseDatePst;

    /**
     * 购买时间 2021-03-05 05:05:29 Etc/GMT
     */
    @JSONField(name = "purchase_date")
    private String purchaseDate;


    /**
     * 过期时间 "2020-11-19 06:12:16 America/Los_Angeles"
     */
    @JSONField(name = "expires_date_pst")
    private String expiresDatePst;

    /**
     * 过期时间戳 2021-09-08 04:05:29 Etc/GMT
     */
    @JSONField(name = "expires_date")
    private String expiresDate;

    /**
     * 过期时间戳
     */
    @JSONField(name = "expires_date_ms")
    private Long expiresDateMs;

    /**
     * 是否在订单宽限期，扣款失败，苹果会重新尝试扣款 "false"
     */
    @JSONField(name = "is_in_intro_offer_period")
    private String isInIntroOfferPeriod;

    /**
     * vip_product_year
     */
    @JSONField(name = "product_id")
    private String productId;
    /**
     * 是否是试用订单 "false"
     */
    @JSONField(name = "is_trial_period")
    private String isTrialPeriod;

    @JSONField(serialize = false)
    private String rawAppleOrderItem;




    public static AppleOrderItem parseFromJson(JSONObject inAppArrayItem) {
        AppleOrderItem appleOrderItem = new AppleOrderItem();
        if (inAppArrayItem == null) {
            return appleOrderItem;
        }
        String rawAppleOrderItem = JSON.toJSONString(inAppArrayItem);
        appleOrderItem = JSON.parseObject(rawAppleOrderItem,AppleOrderItem.class);
        appleOrderItem.setRawAppleOrderItem(rawAppleOrderItem);
        return appleOrderItem;
    }

    public static AppleOrderItem parseFromString(String inAppArrayItem) {
        AppleOrderItem appleOrderItem = new AppleOrderItem();
        if (inAppArrayItem == null) {
            return appleOrderItem;
        }
        appleOrderItem = JSON.parseObject(inAppArrayItem,AppleOrderItem.class);
        appleOrderItem.setRawAppleOrderItem(inAppArrayItem);
        return appleOrderItem;
    }
}
