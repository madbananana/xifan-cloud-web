package com.foundao.nft.common.model.sdk.request;

import lombok.Data;

/**
 * @Package: com.foundao.nft.common.model.sdk.request
 * @ClassName: PersonRegPlatformRequest
 * @Author: chenli
 * @CreateTime: 2021/12/13 5:55 下午
 * @Description:
 */
@Data
public class PersonRegPlatformRequest {

    private String personName;
    private String email;
//    private String verifyCode;
    private String idCard;
    private Integer cardType;
    private String mobile;
    private String platformPubKey;
    private String platformSignData;
}
