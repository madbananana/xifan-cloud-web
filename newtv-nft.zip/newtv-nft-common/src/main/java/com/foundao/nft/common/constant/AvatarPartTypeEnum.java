package com.foundao.nft.common.constant;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * 头像部件相关枚举
 */
public enum AvatarPartTypeEnum {
    BACKGROUND(1,"背景"),
    PROPS(2,"道具"),
    HEADSET(3,"耳机"),
    HEAD_WEAR(4,"头饰"),
    GLASSES(5,"眼镜"),
    CLOTHES(6,"衣服"),
    FULL_BACKGROUND(7,"完整背景"),
    PERSONAGE(100,"人物");

    /**
     * 返回码
     */
    private int code;

    /**
     * 返回码代表的意思
     */
    private String msg;

    AvatarPartTypeEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }


    public int getCode() {
        return code;
    }

    public String getMsg() {
        return msg;
    }

    public static Integer getCodeByName(String name){
        List<AvatarPartTypeEnum> collect = Stream.of(AvatarPartTypeEnum.values()).collect(Collectors.toList());
        Optional<AvatarPartTypeEnum> first = collect.stream().filter(p -> p.getMsg().equals(name)).findFirst();
        if(first.isPresent()){
            return first.get().getCode();
        }else {
            return null;
        }
    }
}
