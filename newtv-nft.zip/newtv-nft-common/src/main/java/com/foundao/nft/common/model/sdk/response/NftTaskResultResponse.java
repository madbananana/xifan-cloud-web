package com.foundao.nft.common.model.sdk.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @ClassName NftTaskResultResponse
 * @Description TODO
 * @Author xifan
 * @Date 2021/12/18 12:34
 * @Version 1.0
 */
@Data
public class NftTaskResultResponse {

    /**
     * 标记任务状态
     * 任务执行中：2
     * 任务成功：7
     * 任务失败：10
     */
    @ApiModelProperty(value = "任务执行中：2 任务成功：7 任务失败：10")
    private int taskStatus;

    /**
     * 失败情况下会有提示信息
     */
    private String taskMsg;

    /**
     * 交易hash
     */
    private String txHash;

    /**
     * 链上交易时间戳
     */
    private int chainTimestamp;
}
