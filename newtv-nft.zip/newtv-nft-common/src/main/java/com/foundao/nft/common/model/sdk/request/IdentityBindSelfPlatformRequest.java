package com.foundao.nft.common.model.sdk.request;

import lombok.Data;

/**
 * @Package: com.foundao.nft.common.model.sdk.request
 * @ClassName: IdentityBindSubmitPlatformRequest
 * @Author: chenli
 * @CreateTime: 2021/12/14 4:14 下午
 * @Description:
 */
@Data
public class IdentityBindSelfPlatformRequest {

    private String signData;

    private String pubKey;

    private String userIdentification;

    private String verifyCode;

}
