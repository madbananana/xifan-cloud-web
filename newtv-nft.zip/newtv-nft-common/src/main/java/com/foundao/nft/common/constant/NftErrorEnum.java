package com.foundao.nft.common.constant;

import com.tx.core.enums.errcode.ErrorCodeEnum;

/**
 * @Package: com.foundao.nft.common.constant
 * @ClassName: NftErrorEnum
 * @Author: chenli
 * @CreateTime: 2022/4/15 10:35 上午
 * @Description:
 */
public enum NftErrorEnum implements ErrorCodeEnum {

    APPOINTMENT_SERIES_EXIST_ERROR(410,"系列不存在"),
    APPOINTMENT_DUPLICATE_ERROR(411,"不能重复预约"),
    APPOINTMENT_NO_ERROR(412,"系列不可预约"),
    APPOINTMENT_START_ERROR(413,"系列已开售，请直接购买或领取"),
    APPOINTMENT_TIMEOUT_ERROR(414,"系列已过预约时间");

    private int code;
    private String msg;

    private NftErrorEnum(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }
    @Override
    public int getCode() {
        return code;
    }

    @Override
    public String getMsg() {
        return msg;
    }
}