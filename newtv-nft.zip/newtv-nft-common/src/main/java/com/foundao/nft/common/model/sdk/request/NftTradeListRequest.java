package com.foundao.nft.common.model.sdk.request;

import lombok.Data;

/**
 * @ClassName NftTradeListRequest
 * @Description TODO
 * @Author xifan
 * @Date 2021/12/18 0:11
 * @Version 1.0
 */
@Data
public class NftTradeListRequest {

    private String nftId;

    private int offset;

    private int limit;
}
