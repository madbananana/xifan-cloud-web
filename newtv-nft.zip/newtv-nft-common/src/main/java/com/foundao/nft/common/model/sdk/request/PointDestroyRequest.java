package com.foundao.nft.common.model.sdk.request;

import lombok.Data;

/**
 * @ClassName PointDestroyRequest
 * @Description TODO
 * @Author xifan
 * @Date 2021/12/16 22:13
 * @Version 1.0
 */
@Data
public class PointDestroyRequest {

    /**
     * 销毁人地址
     */
    private String addr;

    /**
     * 平台公钥
     */
    private String platformPubKey;

    /**
     * 积分数量
     */
    private int count;

    /**
     * 请求id 每个请求需要唯一的id 重复请求用相同的id
     */
    private String operateId;

    /**
     * 销毁人的私钥签名，签名对象是（platformPubKey_add_接口名_count_operatedId）
     * 接口名=destroy_point
     */
    private String signature;

    /**
     * 平台方的私钥签名，签名对象和signature对象一致。
     */
    private String platformSignature;
}
