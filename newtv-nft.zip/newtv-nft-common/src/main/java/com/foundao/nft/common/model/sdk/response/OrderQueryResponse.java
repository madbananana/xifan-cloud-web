package com.foundao.nft.common.model.sdk.response;

import lombok.Data;

/**
 * @Package: com.foundao.nft.common.model.sdk.response
 * @ClassName: OrderQueryResponse
 * @Author: chenli
 * @CreateTime: 2021/12/23 10:47 上午
 * @Description:
 */
@Data
public class OrderQueryResponse {

    private int pay_status;

    private int pay_type;

    private int pay_type_m;

    private boolean notified;

    private String transid;

    private long pay_time;

    private String out_trade_no;

    private String user_id;

    private String product_id;

    private String frmid;

    private String pay_fail_info;

    private long timestamp;

}
