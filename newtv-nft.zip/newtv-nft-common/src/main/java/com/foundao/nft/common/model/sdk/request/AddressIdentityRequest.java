package com.foundao.nft.common.model.sdk.request;

import lombok.Data;

/**
 * @Package: com.foundao.nft.common.model.sdk.request
 * @ClassName: AddressIdentityRequest
 * @Author: chenli
 * @CreateTime: 2021/12/15 4:09 下午
 * @Description:
 */
@Data
public class AddressIdentityRequest {

    /**
     * 地址
     */
    private String address;

    /**
     * 人脸结果id
     */
    private String faceResultId;
}
