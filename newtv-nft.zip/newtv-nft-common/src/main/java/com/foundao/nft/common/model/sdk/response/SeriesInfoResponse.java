package com.foundao.nft.common.model.sdk.response;

import lombok.Data;

/**
 * @ClassName SeriesInfoResponse
 * @Description TODO
 * @Author xifan
 * @Date 2021/12/16 23:51
 * @Version 1.0
 */
@Data
public class SeriesInfoResponse {

    private String seriesId;

    private String name;

    private String creatorAddr;

    private int totalCount;

    private boolean seriesBeginFromZero;

    private String crtCount;

    private String coverUrl;

    private String desc;

    private String creatTimestamp;

}
