package com.foundao.nft.common.model.sdk.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Package: com.foundao.nft.common.model.sdk.response
 * @ClassName: WechatMiniPayData
 * @Author: chenli
 * @CreateTime: 2021/12/22 4:51 下午
 * @Description:
 */
@Data
public class WechatMiniPayData {

    private String appId;

    private String nonceStr;

    private String signType;

    private String pkage;

    private String timeStamp;

    private String paySign;

    @ApiModelProperty("本系统订单号")
    private String tradeNo;

    public String getPackage() {
        return pkage;
    }

    public void setPackage(String pack_age) {
        this.pkage = pack_age;
    }
}
