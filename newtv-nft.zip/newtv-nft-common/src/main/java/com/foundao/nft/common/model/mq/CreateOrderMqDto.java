package com.foundao.nft.common.model.mq;

import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

@Data
@Builder
public class CreateOrderMqDto implements Serializable {
    /**
     * 订单id
     */
    private Integer orderId;
}
