package com.foundao.nft.common.model.sdk.response;

import lombok.Data;

/**
 * @ClassName PointOperateResponse
 * @Description TODO
 * @Author xifan
 * @Date 2021/12/16 22:00
 * @Version 1.0
 */
@Data
public class TaskResponse {

    /**
     * 任务id
     */
    private String taskId;
}
