package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
    @Package: com.foundao.nft.common.model
    @ClassName: NftRecordDelete
    @Author: chenli
    @CreateTime: 2022/3/10 10:06 上午
    @Description:
*/
/**
    * NFT用户拥有的记录
    */
@ApiModel(value="com-foundao-nft-common-model-NftRecordDelete")
@Data
@TableName(value = "nft_record_delete")
public class NftRecordDelete implements Serializable {
    @TableId(value = "id", type = IdType.AUTO)
    @ApiModelProperty(value="")
    private Integer id;

    /**
     * nft的id
     */
    @TableField(value = "nft_id")
    @ApiModelProperty(value="nft的id")
    private String nftId;

    /**
     * 获取时间
     */
    @TableField(value = "owner_time")
    @ApiModelProperty(value="获取时间")
    private Date ownerTime;

    /**
     * 拥有人的地址
     */
    @TableField(value = "owner_addr")
    @ApiModelProperty(value="拥有人的地址")
    private String ownerAddr;

    /**
     * 资源id
     */
    @TableField(value = "meta_id")
    @ApiModelProperty(value="资源id")
    private Integer metaId;

    /**
     * 获取类型 1：购买/领取 2：他人赠送
     */
    @TableField(value = "obtain_type")
    @ApiModelProperty(value="获取类型 1：购买/领取 2：他人赠送")
    private Integer obtainType;

    /**
     * 赠送人/出售者id
     */
    @TableField(value = "giver_user_id")
    @ApiModelProperty(value="赠送人/出售者id")
    private Integer giverUserId;

    /**
     * 赠送人姓名
     */
    @TableField(value = "giver_user_name")
    @ApiModelProperty(value="赠送人姓名")
    private String giverUserName;

    /**
     * 拥有者用户id
     */
    @TableField(value = "user_id")
    @ApiModelProperty(value="拥有者用户id")
    private Integer userId;

    /**
     * 1普通资源 2 牛头资源
     */
    @TableField(value = "meta_type")
    @ApiModelProperty("1普通款 3隐藏款")
    private Byte metaType;

    /**
     * 新增时间
     */
    @TableField(value = "create_time")
    @ApiModelProperty(value="新增时间")
    private Date createTime;

    /**
     * 真实nftId
     */
    @TableField(value = "actual_nft_id")
    @ApiModelProperty(value="真实nftId")
    private String actualNftId;

    /**
     * 删除时间
     */
    @TableField(value = "delete_time")
    @ApiModelProperty(value="删除时间")
    private Date deleteTime;

    private static final long serialVersionUID = 1L;
}