package com.foundao.nft.common.model;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
    @Package: com.foundao.nft.common.model
    @ClassName: AwardRecord
    @Author: chenli
    @CreateTime: 2022/11/3 11:17 AM
    @Description:
*/

/**
 * 奖励领取记录
 */
@ApiModel(value = "奖励领取记录")
@Data
@TableName(value = "nft_award_record")
public class AwardRecord implements Serializable {
    @TableId(value = "id", type = IdType.AUTO)
    @ApiModelProperty(value = "")
    private Integer id;

    @TableField(value = "user_id")
    @ApiModelProperty(value = "")
    private Integer userId;

    @TableField(value = "activity_id")
    @ApiModelProperty(value = "")
    private Integer activityId;

    /**
     * 奖励档次
     */
    @TableField(value = "`level`")
    @ApiModelProperty(value = "奖励档次")
    private Integer level;

    /**
     * 是否黄金用户奖励
     */
    @TableField(value = "is_gold_award")
    @ApiModelProperty(value = "是否黄金用户奖励")
    private Integer isGoldAward;

    /**
     * 奖品编号
     */
    @TableField(value = "award_id")
    @ApiModelProperty(value = "奖品编号")
    private Integer awardId;

    @TableField(value = "create_time",fill = FieldFill.INSERT)
    @ApiModelProperty(value = "")
    private String createTime;


    private static final long serialVersionUID = 1L;
}