package com.foundao.nft.common.model.vo;

import lombok.Data;

import java.io.Serializable;

/**
 * @Package: com.foundao.nft.common.model.vo
 * @ClassName: AvatarPartAttr
 * @Author: chenli
 * @CreateTime: 2022/1/17 5:48 下午
 * @Description:
 */
@Data
public class AvatarPartAttr implements Serializable {
    /**
     * 图片文件名称
     */
    private String sourceFileName;
    /**
     * 部件位置
     */
    private String partPosition;
    /**
     * 部件名称
     */
    private String partName;
    /**
     * 比例
     */
    private String ratio;
    /**
     * 是否老员工  是  否
     */
    private String isSpecialType;
    /**
     * 是否唯一 是  否
     */
    private String IsUnique;
}

