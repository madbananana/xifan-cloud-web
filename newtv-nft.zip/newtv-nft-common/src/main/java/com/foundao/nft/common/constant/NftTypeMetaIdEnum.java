package com.foundao.nft.common.constant;

import lombok.Data;

/**
 * @Package: com.foundao.nft.common.constant
 * @ClassName: NftTypeMetaIdEnum
 * @Author: chenli
 * @CreateTime: 2022/6/23 10:21 上午
 * @Description:
 */
public enum NftTypeMetaIdEnum {
    DREAM_STAR(1,6426),
    SCIENCE_STAR(2,6427);

    private Integer nftType;

    private Integer metaId;

    NftTypeMetaIdEnum(Integer nftType,Integer metaId) {
        this.nftType = nftType;
        this.metaId = metaId;
    }


    public Integer getMetaId() {
        return metaId;
    }

    public Integer getNftType() {
        return nftType;
    }

    public static Integer getValue(Integer nftType){
        NftTypeMetaIdEnum[] values = NftTypeMetaIdEnum.values();
        for (int i = 0; i < values.length; i++) {
            if (values[i].nftType==nftType) {
                return values[i].metaId;
            }
        }
        return null;
    }
}
