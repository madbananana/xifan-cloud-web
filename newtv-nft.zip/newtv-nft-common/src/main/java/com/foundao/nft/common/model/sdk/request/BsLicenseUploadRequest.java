package com.foundao.nft.common.model.sdk.request;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

/**
 * @Package: com.foundao.nft.common.model.sdk.request
 * @ClassName: BsLicenseUploadRequest
 * @Author: chenli
 * @CreateTime: 2021/12/14 2:39 下午
 * @Description:
 */
@Data
public class BsLicenseUploadRequest {

    private String mobile;

    private String verifyCode;

    private MultipartFile file;
}
