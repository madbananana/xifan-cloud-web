package com.foundao.nft.common.model.sdk.response;

import lombok.Data;

/**
 * @Package: com.foundao.nft.common.model.sdk.response
 * @ClassName: WechatMiniPayData
 * @Author: chenli
 * @CreateTime: 2021/12/22 4:51 下午
 * @Description:
 */
@Data
public class WechatAppPayData {

    private String appId;

    private String nonceStr;

    private String partnerid;

    private String prepayid;

    private String pkage;

    private String timeStamp;

    private String sign;

//    @ApiModelProperty("本系统订单号")
//    private String tradeNo;

    public String getPackage() {
        return pkage;
    }

    public void setPackage(String pack_age) {
        this.pkage = pack_age;
    }
}
