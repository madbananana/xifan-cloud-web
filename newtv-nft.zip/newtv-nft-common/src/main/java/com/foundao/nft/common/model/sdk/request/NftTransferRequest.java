package com.foundao.nft.common.model.sdk.request;

import lombok.Data;

/**
 * @ClassName NftTransferRequest
 * @Description TODO
 * @Author xifan
 * @Date 2021/12/18 12:39
 * @Version 1.0
 */
@Data
public class NftTransferRequest {

    private String pubKey;

    private String receiverAddr;

    private String nftId;

    private String operateId;

    /**
     * 操作者的私钥签名 签名对象是（pubKey_receiverAddr_接口名_nftId_operateId）
     * nft_transfer
     */
    private String signature;

}
